import { createCookieSessionStorage, redirect } from "@remix-run/node";
import { SessionManagerImpl } from "@docusign-alternative/auth";
import type { SessionData, SecurityEvent } from "@docusign-alternative/auth";

// Initialize session manager
const sessionManager = new SessionManagerImpl(
    process.env.JWT_SECRET || 'default-secret-change-in-production',
    async (event: SecurityEvent) => {
        // Log security events (in production, send to logging service)
        console.log('Security Event:', event);
    }
);

// Cookie session storage for Remix
const sessionStorage = createCookieSessionStorage({
    cookie: {
        name: "__session",
        httpOnly: true,
        maxAge: 60 * 60 * 24 * 30, // 30 days
        path: "/",
        sameSite: "lax",
        secrets: [process.env.SESSION_SECRET || 'default-secret-change-in-production'],
        secure: process.env.NODE_ENV === "production",
    },
});

/**
 * Get session from request
 */
export async function getSession(request: Request) {
    const cookie = request.headers.get("Cookie");
    return sessionStorage.getSession(cookie);
}

/**
 * Get user session data from request
 */
export async function getUserSession(request: Request): Promise<SessionData | null> {
    const session = await getSession(request);
    const sessionToken = session.get("sessionToken");

    if (!sessionToken) {
        return null;
    }

    try {
        return await sessionManager.validateSession(sessionToken);
    } catch (error) {
        // Session is invalid, return null
        return null;
    }
}

/**
 * Require user to be authenticated
 */
export async function requireUserSession(
    request: Request,
    redirectTo: string = new URL(request.url).pathname
): Promise<SessionData> {
    const userSession = await getUserSession(request);

    if (!userSession) {
        const searchParams = new URLSearchParams([["redirectTo", redirectTo]]);
        throw redirect(`/login?${searchParams}`);
    }

    return userSession;
}

/**
 * Create user session
 */
export async function createUserSession({
    request,
    userId,
    remember = false,
    redirectTo = "/dashboard",
}: {
    request: Request;
    userId: string;
    remember?: boolean;
    redirectTo?: string;
}) {
    const userAgent = request.headers.get("User-Agent") || undefined;
    const ipAddress = getClientIPAddress(request);

    const { sessionToken } = await sessionManager.createSession(userId, {
        rememberMe: remember,
        userAgent,
        ipAddress,
    });

    const session = await getSession(request);
    session.set("sessionToken", sessionToken);

    return redirect(redirectTo, {
        headers: {
            "Set-Cookie": await sessionStorage.commitSession(session, {
                maxAge: remember ? 60 * 60 * 24 * 30 : 60 * 60 * 24, // 30 days or 1 day
            }),
        },
    });
}

/**
 * Logout user
 */
export async function logout(request: Request) {
    const session = await getSession(request);
    const sessionToken = session.get("sessionToken");

    if (sessionToken) {
        try {
            await sessionManager.revokeSession(sessionToken);
        } catch (error) {
            // Session might already be invalid, which is fine
        }
    }

    return redirect("/", {
        headers: {
            "Set-Cookie": await sessionStorage.destroySession(session),
        },
    });
}

/**
 * Rotate user session
 */
export async function rotateUserSession(request: Request) {
    const session = await getSession(request);
    const sessionToken = session.get("sessionToken");

    if (!sessionToken) {
        throw new Error("No session to rotate");
    }

    try {
        const { newSessionToken } = await sessionManager.rotateSession(sessionToken);
        session.set("sessionToken", newSessionToken);

        return {
            headers: {
                "Set-Cookie": await sessionStorage.commitSession(session),
            },
        };
    } catch (error) {
        // If rotation fails, logout the user
        return logout(request);
    }
}

/**
 * Get client IP address from request
 */
function getClientIPAddress(request: Request): string {
    const forwarded = request.headers.get("x-forwarded-for");
    const realIP = request.headers.get("x-real-ip");
    const cfConnectingIP = request.headers.get("cf-connecting-ip");

    if (cfConnectingIP) return cfConnectingIP;
    if (realIP) return realIP;
    if (forwarded) return forwarded.split(",")[0].trim();

    return "unknown";
}

/**
 * Get session manager instance (for advanced operations)
 */
export function getSessionManager() {
    return sessionManager;
}