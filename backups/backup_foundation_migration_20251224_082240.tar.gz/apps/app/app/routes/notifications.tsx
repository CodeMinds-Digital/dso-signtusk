import type { MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import { NotificationCenter, useNotifications } from "@docusign-alternative/ui";
import { requireAuth } from "~/lib/auth.server";
import type { LoaderFunctionArgs } from "@remix-run/node";

export const meta: MetaFunction = () => {
    return [
        { title: "Notification Center - DocuSign Alternative" },
        { name: "description", content: "Manage your notifications and activity history" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const user = await requireAuth(request);

    return json({
        user,
        pageTitle: "Notification Center",
    });
}

export default function NotificationsPage() {
    const { user, pageTitle } = useLoaderData<typeof loader>();
    const navigate = useNavigate();

    const {
        notifications,
        counts,
        activityHistory,
        isLoading,
        markAsRead,
        markAllAsRead,
        archive,
        unarchive,
        deleteNotification,
        refresh,
        createSample,
    } = useNotifications({
        enableRealtime: true,
    });

    const handleNotificationClick = (notification: any) => {
        // Mark as read when clicked
        if (!notification.read) {
            markAsRead(notification.id);
        }

        // Navigate to action URL if available
        if (notification.actionUrl) {
            navigate(notification.actionUrl);
        }
    };

    return (
        <div className="container mx-auto py-6 px-4">
            <div className="mb-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">{pageTitle}</h1>
                        <p className="text-muted-foreground">
                            Stay updated with real-time notifications and activity history
                        </p>
                    </div>

                    {/* Development helper - remove in production */}
                    {process.env.NODE_ENV === 'development' && (
                        <button
                            onClick={() => createSample()}
                            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                        >
                            Create Sample Notifications
                        </button>
                    )}
                </div>
            </div>

            <NotificationCenter
                notifications={notifications}
                counts={counts}
                activityHistory={activityHistory}
                isLoading={isLoading}
                onNotificationClick={handleNotificationClick}
                onMarkAsRead={markAsRead}
                onMarkAllAsRead={markAllAsRead}
                onArchive={archive}
                onUnarchive={unarchive}
                onDelete={deleteNotification}
                onRefresh={refresh}
            />
        </div>
    );
}