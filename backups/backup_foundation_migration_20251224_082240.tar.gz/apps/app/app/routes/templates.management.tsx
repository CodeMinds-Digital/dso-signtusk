import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useActionData, useFetcher, useNavigate } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    Button,
    useToast,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from "@docusign-alternative/ui";
import {
    TemplateManagementDashboard,
    TemplateAnalyticsDashboard,
    TemplateSharingManager,
    EnhancedTemplateWizard,
} from "@docusign-alternative/ui";
import { useState, useEffect } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Template Management - DocuSign Alternative" },
        { name: "description", content: "Comprehensive template management with analytics and sharing capabilities" },
    ];
};

// Enhanced template interface with comprehensive data
interface EnhancedTemplate {
    id: string;
    name: string;
    description?: string;
    category?: string;
    tags: string[];
    isPublic: boolean;
    isFavorite: boolean;
    createdAt: string;
    updatedAt: string;
    usageCount: number;
    fields: number;
    recipients: number;
    createdBy: string;
    version: number;
    status: 'active' | 'draft' | 'archived';
    permissions: {
        canView: boolean;
        canEdit: boolean;
        canDelete: boolean;
        canShare: boolean;
        canUse: boolean;
    };
    analytics: {
        completionRate: number;
        averageCompletionTime: number;
        totalUsage: number;
        recentUsage: number;
        performanceScore: number;
        optimizationOpportunities: string[];
    };
    sharing: {
        isShared: boolean;
        shareCount: number;
        publicLink?: string;
        shares: Array<{
            id: string;
            targetName: string;
            targetEmail?: string;
            shareType: string;
            status: string;
            permissions: Record<string, boolean>;
            sharedAt: string;
            accessCount: number;
        }>;
    };
    collaboration: {
        isCollaborative: boolean;
        collaboratorCount: number;
        activeEditSessions: number;
        pendingReviews: number;
        unreadComments: number;
    };
}

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const url = new URL(request.url);

    // Get query parameters
    const view = url.searchParams.get('view') || 'dashboard';
    const search = url.searchParams.get('search') || '';
    const category = url.searchParams.get('category') || 'all';
    const timeframe = url.searchParams.get('timeframe') || '30d';

    // Enhanced mock template data with comprehensive analytics
    const templates: EnhancedTemplate[] = [
        {
            id: "template-1",
            name: "Employment Contract Template",
            description: "Comprehensive employment contract with signature fields for HR department",
            category: "HR",
            tags: ["employment", "contract", "hr", "legal"],
            isPublic: false,
            isFavorite: true,
            createdAt: "2024-01-10T10:30:00Z",
            updatedAt: "2024-01-15T14:20:00Z",
            usageCount: 156,
            fields: 8,
            recipients: 2,
            createdBy: "HR Team",
            version: 3,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 97.4,
                averageCompletionTime: 2.3,
                totalUsage: 156,
                recentUsage: 23,
                performanceScore: 94,
                optimizationOpportunities: ["Consider reducing field count", "Add field validation"],
            },
            sharing: {
                isShared: true,
                shareCount: 5,
                shares: [
                    {
                        id: "share-1",
                        targetName: "Legal Team",
                        shareType: "team",
                        status: "active",
                        permissions: { canView: true, canUse: true, canDuplicate: false, canEdit: false, canShare: false, canDelete: false },
                        sharedAt: "2024-01-12T09:00:00Z",
                        accessCount: 12,
                    },
                ],
            },
            collaboration: {
                isCollaborative: true,
                collaboratorCount: 3,
                activeEditSessions: 0,
                pendingReviews: 1,
                unreadComments: 2,
            },
        },
        {
            id: "template-2",
            name: "Sales Agreement Template",
            description: "Standard sales agreement with customizable terms and conditions",
            category: "Sales",
            tags: ["sales", "agreement", "contract", "terms"],
            isPublic: true,
            isFavorite: false,
            createdAt: "2024-01-08T09:15:00Z",
            updatedAt: "2024-01-18T11:45:00Z",
            usageCount: 89,
            fields: 12,
            recipients: 3,
            createdBy: "Sales Team",
            version: 2,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: false,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 84.2,
                averageCompletionTime: 3.7,
                totalUsage: 89,
                recentUsage: 15,
                performanceScore: 78,
                optimizationOpportunities: ["Simplify approval workflow", "Reduce required fields"],
            },
            sharing: {
                isShared: true,
                shareCount: 8,
                shares: [
                    {
                        id: "share-2",
                        targetName: "Finance Team",
                        shareType: "team",
                        status: "active",
                        permissions: { canView: true, canUse: true, canDuplicate: true, canEdit: false, canShare: false, canDelete: false },
                        sharedAt: "2024-01-10T14:30:00Z",
                        accessCount: 25,
                    },
                ],
            },
            collaboration: {
                isCollaborative: false,
                collaboratorCount: 1,
                activeEditSessions: 0,
                pendingReviews: 0,
                unreadComments: 0,
            },
        },
        {
            id: "template-3",
            name: "NDA Template",
            description: "Non-disclosure agreement for confidential business discussions",
            category: "Legal",
            tags: ["nda", "confidentiality", "legal", "agreement"],
            isPublic: false,
            isFavorite: true,
            createdAt: "2024-01-05T16:20:00Z",
            updatedAt: "2024-01-20T08:30:00Z",
            usageCount: 234,
            fields: 6,
            recipients: 2,
            createdBy: "Legal Team",
            version: 4,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 95.8,
                averageCompletionTime: 1.8,
                totalUsage: 234,
                recentUsage: 42,
                performanceScore: 96,
                optimizationOpportunities: ["Add electronic signature validation"],
            },
            sharing: {
                isShared: true,
                shareCount: 12,
                shares: [
                    {
                        id: "share-3",
                        targetName: "All Users",
                        shareType: "organization",
                        status: "active",
                        permissions: { canView: true, canUse: true, canDuplicate: true, canEdit: false, canShare: false, canDelete: false },
                        sharedAt: "2024-01-06T10:00:00Z",
                        accessCount: 156,
                    },
                ],
            },
            collaboration: {
                isCollaborative: true,
                collaboratorCount: 5,
                activeEditSessions: 1,
                pendingReviews: 0,
                unreadComments: 3,
            },
        },
    ];

    // Enhanced analytics data with comprehensive metrics
    const analyticsData = {
        overview: {
            totalTemplates: templates.length,
            totalUsage: templates.reduce((sum, t) => sum + t.usageCount, 0),
            averageCompletionRate: templates.reduce((sum, t) => sum + t.analytics.completionRate, 0) / templates.length,
            totalTimeSaved: 342.5,
            costSavings: 28750,
            errorReduction: 87.2,
            adoptionRate: 68.4,
            efficiency: 92.1,
        },
        performance: {
            topPerformers: templates
                .sort((a, b) => b.analytics.performanceScore - a.analytics.performanceScore)
                .slice(0, 5)
                .map(t => ({
                    id: t.id,
                    name: t.name,
                    category: t.category || 'Other',
                    usageCount: t.usageCount,
                    completionRate: t.analytics.completionRate,
                    avgCompletionTime: t.analytics.averageCompletionTime,
                    trend: 'up' as const,
                    trendValue: 12.5,
                })),
            underPerformers: templates
                .filter(t => t.analytics.performanceScore < 80)
                .map(t => ({
                    id: t.id,
                    name: t.name,
                    category: t.category || 'Other',
                    usageCount: t.usageCount,
                    completionRate: t.analytics.completionRate,
                    issues: t.analytics.optimizationOpportunities,
                    recommendations: ["Simplify workflow", "Add field validation", "Improve instructions"],
                })),
            trends: [
                { metric: "Template Usage", value: 1247, change: 18.5, period: "vs last month", direction: 'up' as const },
                { metric: "Completion Rate", value: 91.3, change: 3.2, period: "vs last month", direction: 'up' as const },
                { metric: "Avg. Completion Time", value: 2.4, change: -12.8, period: "vs last month", direction: 'down' as const },
                { metric: "New Templates", value: 7, change: 40.0, period: "vs last month", direction: 'up' as const },
            ],
        },
        usage: {
            byCategory: [
                { category: "HR", count: 156, percentage: 32.5, trend: 15.2, avgCompletionTime: 2.3, completionRate: 94.2 },
                { category: "Legal", count: 234, percentage: 48.8, trend: 8.7, avgCompletionTime: 1.8, completionRate: 96.1 },
                { category: "Sales", count: 89, percentage: 18.5, trend: -3.2, avgCompletionTime: 3.7, completionRate: 84.2 },
                { category: "Finance", count: 45, percentage: 9.4, trend: 22.1, avgCompletionTime: 2.1, completionRate: 91.8 },
            ],
            byTimeframe: [
                { period: "This Week", usage: 127, completions: 118, newTemplates: 2, avgCompletionTime: 2.1 },
                { period: "Last Week", usage: 98, completions: 89, newTemplates: 1, avgCompletionTime: 2.3 },
                { period: "2 Weeks Ago", usage: 156, completions: 142, newTemplates: 3, avgCompletionTime: 2.5 },
                { period: "3 Weeks Ago", usage: 134, completions: 125, newTemplates: 1, avgCompletionTime: 2.4 },
            ],
            recentActivity: [
                { id: "activity-1", templateName: "Employment Contract Template", action: "Used", user: "John Doe", timestamp: "2024-01-21T10:30:00Z", impact: "high" as const },
                { id: "activity-2", templateName: "NDA Template", action: "Shared", user: "Jane Smith", timestamp: "2024-01-21T09:15:00Z", impact: "medium" as const },
                { id: "activity-3", templateName: "Sales Agreement Template", action: "Updated", user: "Mike Johnson", timestamp: "2024-01-21T08:45:00Z", impact: "low" as const },
            ],
            heatmap: Array.from({ length: 24 }, (_, hour) =>
                Array.from({ length: 7 }, (_, day) => ({
                    hour,
                    day,
                    usage: Math.floor(Math.random() * 50) + 10
                }))
            ).flat(),
        },
        insights: {
            recommendations: [
                {
                    type: "optimization" as const,
                    title: "Optimize Sales Agreement Template",
                    description: "Reduce field count and simplify workflow to improve completion rate",
                    impact: "high" as const,
                    actionable: true,
                    estimatedSavings: 2500,
                    estimatedTimeReduction: 1.2,
                    priority: 1,
                },
                {
                    type: "usage" as const,
                    title: "Promote NDA Template Usage",
                    description: "High-performing template with low adoption rate",
                    impact: "medium" as const,
                    actionable: true,
                    estimatedSavings: 1800,
                    priority: 2,
                },
            ],
            alerts: [
                {
                    type: "warning" as const,
                    title: "Low Completion Rate",
                    description: "Sales Agreement Template has completion rate below 85%",
                    templateId: "template-2",
                    templateName: "Sales Agreement Template",
                    timestamp: "2024-01-21T08:00:00Z",
                    resolved: false,
                },
            ],
            predictions: [
                {
                    metric: "Monthly Usage",
                    currentValue: 479,
                    predictedValue: 567,
                    confidence: 87.5,
                    timeframe: "Next Month",
                    factors: ["Seasonal trends", "New template adoption", "User growth"],
                },
            ],
        },
        roi: {
            totalSavings: 28750,
            timeReduction: 342.5,
            errorReduction: 87.2,
            adoptionRate: 68.4,
            efficiency: 92.1,
            breakdown: [
                { category: "HR", savings: 12500, timeReduced: 156.2, documentsProcessed: 156, errorsPrevented: 23, roi: 425.8 },
                { category: "Legal", savings: 15200, timeReduced: 178.3, documentsProcessed: 234, errorsPrevented: 31, roi: 512.3 },
                { category: "Sales", savings: 1050, timeReduced: 8.0, documentsProcessed: 89, errorsPrevented: 5, roi: 89.2 },
            ],
            projections: {
                nextMonth: 3200,
                nextQuarter: 9800,
                nextYear: 42500,
            },
        },
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        templates,
        analytics: analyticsData,
        categories: [
            { name: "HR", count: 8, description: "Human Resources templates" },
            { name: "Legal", count: 6, description: "Legal documents and contracts" },
            { name: "Sales", count: 5, description: "Sales agreements and proposals" },
            { name: "Finance", count: 4, description: "Financial documents and invoices" },
            { name: "Procurement", count: 3, description: "Vendor and procurement templates" },
        ],
        organizationSettings: {
            allowPublicSharing: true,
            allowExternalSharing: true,
            requireApprovalForSharing: false,
            defaultPermissions: {
                canView: true,
                canUse: true,
                canDuplicate: false,
                canEdit: false,
                canShare: false,
                canDelete: false,
            },
        },
        availableUsers: [
            { id: "user-1", name: "John Doe", email: "john@example.com", avatar: "" },
            { id: "user-2", name: "Jane Smith", email: "jane@example.com", avatar: "" },
            { id: "user-3", name: "Mike Johnson", email: "mike@example.com", avatar: "" },
        ],
        availableTeams: [
            { id: "team-1", name: "Legal Team", memberCount: 5 },
            { id: "team-2", name: "HR Team", memberCount: 3 },
            { id: "team-3", name: "Sales Team", memberCount: 8 },
        ],
        filters: {
            view,
            search,
            category,
            timeframe,
        },
    });
}
export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent") as string;

    try {
        switch (intent) {
            case "create_template": {
                const templateData = JSON.parse(formData.get("templateData") as string);
                // In a real implementation, this would create the template in the database
                console.log("Creating template:", templateData);
                return json({
                    success: true,
                    message: "Template created successfully",
                    templateId: `template-${Date.now()}`
                });
            }

            case "update_template": {
                const templateId = formData.get("templateId") as string;
                const updates = JSON.parse(formData.get("updates") as string);
                // In a real implementation, this would update the template in the database
                console.log("Updating template:", templateId, updates);
                return json({
                    success: true,
                    message: "Template updated successfully"
                });
            }

            case "delete_template": {
                const templateId = formData.get("templateId") as string;
                // In a real implementation, this would delete the template from the database
                console.log("Deleting template:", templateId);
                return json({
                    success: true,
                    message: "Template deleted successfully"
                });
            }

            case "share_template": {
                const shareRequest = JSON.parse(formData.get("shareRequest") as string);
                // In a real implementation, this would create the share in the database
                console.log("Sharing template:", shareRequest);
                return json({
                    success: true,
                    message: "Template shared successfully",
                    shareId: `share-${Date.now()}`
                });
            }

            case "update_share": {
                const shareId = formData.get("shareId") as string;
                const permissions = JSON.parse(formData.get("permissions") as string);
                // In a real implementation, this would update the share permissions
                console.log("Updating share permissions:", shareId, permissions);
                return json({
                    success: true,
                    message: "Share permissions updated successfully"
                });
            }

            case "revoke_share": {
                const shareId = formData.get("shareId") as string;
                const reason = formData.get("reason") as string;
                // In a real implementation, this would revoke the share
                console.log("Revoking share:", shareId, reason);
                return json({
                    success: true,
                    message: "Share revoked successfully"
                });
            }

            case "generate_public_link": {
                const templateId = formData.get("templateId") as string;
                // In a real implementation, this would generate a secure public link
                const publicLink = `https://app.docusign-alternative.com/templates/public/${templateId}?token=${Date.now()}`;
                console.log("Generating public link for template:", templateId);
                return json({
                    success: true,
                    message: "Public link generated successfully",
                    link: publicLink
                });
            }

            case "bulk_action": {
                const action = formData.get("action") as string;
                const templateIds = JSON.parse(formData.get("templateIds") as string);
                // In a real implementation, this would perform the bulk action
                console.log("Performing bulk action:", action, templateIds);
                return json({
                    success: true,
                    message: `Bulk ${action} completed successfully`
                });
            }

            default:
                return json({
                    success: false,
                    message: "Unknown action"
                }, { status: 400 });
        }
    } catch (error) {
        console.error("Action error:", error);
        return json({
            success: false,
            message: "An error occurred while processing your request"
        }, { status: 500 });
    }
}

export default function TemplateManagementPage() {
    const {
        user,
        templates,
        analytics,
        categories,
        organizationSettings,
        availableUsers,
        availableTeams,
        filters
    } = useLoaderData<typeof loader>();

    const actionData = useActionData<typeof action>();
    const fetcher = useFetcher();
    const navigate = useNavigate();
    const { toast } = useToast();

    // State management
    const [activeView, setActiveView] = useState<'dashboard' | 'analytics' | 'sharing' | 'wizard'>(filters.view as any || 'dashboard');
    const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
    const [showCreateWizard, setShowCreateWizard] = useState(false);
    const [searchFilters, setSearchFilters] = useState({
        query: filters.search,
        category: filters.category,
        status: 'all',
        isPublic: undefined,
        isFavorite: undefined,
        sortBy: 'updatedAt',
        sortOrder: 'desc' as 'asc' | 'desc',
    });

    // Handle action responses
    useEffect(() => {
        if (actionData) {
            if (actionData.success) {
                toast({
                    title: "Success",
                    description: actionData.message,
                });

                // Handle specific success actions
                if (actionData.templateId) {
                    setShowCreateWizard(false);
                }
            } else {
                toast({
                    title: "Error",
                    description: actionData.message,
                    variant: "destructive",
                });
            }
        }
    }, [actionData, toast]);

    // Template management handlers
    const handleCreateTemplate = () => {
        setShowCreateWizard(true);
    };

    const handleTemplateAction = async (action: string, templateId: string, data?: any) => {
        const formData = new FormData();

        switch (action) {
            case 'preview':
                navigate(`/templates/${templateId}/preview`);
                break;
            case 'use':
                navigate(`/documents/create?templateId=${templateId}`);
                break;
            case 'edit':
                navigate(`/templates/${templateId}/edit`);
                break;
            case 'duplicate':
                formData.append('intent', 'create_template');
                formData.append('templateData', JSON.stringify({
                    ...data,
                    name: `${data?.name || 'Template'} (Copy)`,
                    sourceTemplateId: templateId
                }));
                fetcher.submit(formData, { method: 'post' });
                break;
            case 'delete':
                if (confirm('Are you sure you want to delete this template?')) {
                    formData.append('intent', 'delete_template');
                    formData.append('templateId', templateId);
                    fetcher.submit(formData, { method: 'post' });
                }
                break;
            case 'share':
                setSelectedTemplate(templateId);
                setActiveView('sharing');
                break;
            case 'favorite':
                formData.append('intent', 'update_template');
                formData.append('templateId', templateId);
                formData.append('updates', JSON.stringify({ isFavorite: !data?.isFavorite }));
                fetcher.submit(formData, { method: 'post' });
                break;
            default:
                console.log('Unknown template action:', action);
        }
    };

    const handleBulkAction = async (action: string, templateIds: string[]) => {
        const formData = new FormData();
        formData.append('intent', 'bulk_action');
        formData.append('action', action);
        formData.append('templateIds', JSON.stringify(templateIds));
        fetcher.submit(formData, { method: 'post' });
    };

    const handleSearch = (query: string, filters: any) => {
        setSearchFilters({ ...searchFilters, ...filters, query });
        // In a real implementation, this would trigger a new data fetch
        const url = new URL(window.location.href);
        url.searchParams.set('search', query);
        url.searchParams.set('category', filters.category || 'all');
        navigate(url.pathname + url.search, { replace: true });
    };

    // Sharing handlers
    const handleShare = async (shareRequest: any) => {
        const formData = new FormData();
        formData.append('intent', 'share_template');
        formData.append('shareRequest', JSON.stringify(shareRequest));

        return new Promise<{ success: boolean; shareId?: string; message?: string }>((resolve) => {
            fetcher.submit(formData, {
                method: 'post',
            });
            // Note: In a real implementation, you'd handle the response properly
            setTimeout(() => resolve({ success: true, shareId: `share-${Date.now()}` }), 1000);
        });
    };

    const handleUpdateShare = async (shareId: string, permissions: Record<string, boolean>) => {
        const formData = new FormData();
        formData.append('intent', 'update_share');
        formData.append('shareId', shareId);
        formData.append('permissions', JSON.stringify(permissions));

        return new Promise<{ success: boolean; message?: string }>((resolve) => {
            fetcher.submit(formData, { method: 'post' });
            setTimeout(() => resolve({ success: true }), 1000);
        });
    };

    const handleRevokeShare = async (shareId: string, reason?: string) => {
        const formData = new FormData();
        formData.append('intent', 'revoke_share');
        formData.append('shareId', shareId);
        if (reason) formData.append('reason', reason);

        return new Promise<{ success: boolean; message?: string }>((resolve) => {
            fetcher.submit(formData, { method: 'post' });
            setTimeout(() => resolve({ success: true }), 1000);
        });
    };

    const handleGeneratePublicLink = async () => {
        if (!selectedTemplate) return { success: false, message: 'No template selected' };

        const formData = new FormData();
        formData.append('intent', 'generate_public_link');
        formData.append('templateId', selectedTemplate);

        return new Promise<{ success: boolean; link?: string; message?: string }>((resolve) => {
            fetcher.submit(formData, { method: 'post' });
            setTimeout(() => resolve({
                success: true,
                link: `https://app.docusign-alternative.com/templates/public/${selectedTemplate}?token=${Date.now()}`
            }), 1000);
        });
    };

    // Analytics handlers
    const handleTimeframeChange = (timeframe: string) => {
        const url = new URL(window.location.href);
        url.searchParams.set('timeframe', timeframe);
        navigate(url.pathname + url.search, { replace: true });
    };

    const handleRefresh = () => {
        navigate(window.location.pathname + window.location.search, { replace: true });
    };

    const handleExport = (format: 'pdf' | 'csv' | 'xlsx') => {
        // In a real implementation, this would trigger an export
        toast({
            title: "Export Started",
            description: `Exporting analytics data as ${format.toUpperCase()}...`,
        });
    };

    const handleTemplateClick = (templateId: string) => {
        navigate(`/templates/${templateId}`);
    };

    // Template wizard handlers
    const handleWizardComplete = (templateData: any) => {
        const formData = new FormData();
        formData.append('intent', 'create_template');
        formData.append('templateData', JSON.stringify(templateData));
        fetcher.submit(formData, { method: 'post' });
    };

    const handleWizardCancel = () => {
        setShowCreateWizard(false);
    };

    const handleSaveDraft = (templateData: any) => {
        const formData = new FormData();
        formData.append('intent', 'create_template');
        formData.append('templateData', JSON.stringify({ ...templateData, status: 'draft' }));
        fetcher.submit(formData, { method: 'post' });
    };

    // Get current template shares for sharing manager
    const currentTemplate = selectedTemplate ? templates.find(t => t.id === selectedTemplate) : null;
    const currentShares = currentTemplate?.sharing.shares.map(share => ({
        id: share.id,
        templateId: currentTemplate.id,
        templateName: currentTemplate.name,
        shareType: share.shareType as any,
        targetId: share.shareType === 'team' ? share.id : undefined,
        targetName: share.targetName,
        targetEmail: share.targetEmail,
        permissions: share.permissions,
        sharedBy: {
            id: user.userId,
            name: 'Current User',
            email: 'user@example.com',
        },
        sharedAt: share.sharedAt,
        expiresAt: undefined,
        status: share.status as any,
        accessCount: share.accessCount,
        lastAccessed: undefined,
        shareToken: undefined,
        publicLink: undefined,
        requiresApproval: false,
        approvalStatus: undefined,
        message: undefined,
    })) || [];

    return (
        <Layout user={user}>
            <div className="container mx-auto px-4 py-8 space-y-8">
                {/* Main Navigation Tabs */}
                <Tabs value={activeView} onValueChange={(value) => setActiveView(value as any)} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                        <TabsTrigger value="analytics">Analytics</TabsTrigger>
                        <TabsTrigger value="sharing">Sharing</TabsTrigger>
                        <TabsTrigger value="wizard">Create Template</TabsTrigger>
                    </TabsList>

                    {/* Template Management Dashboard */}
                    <TabsContent value="dashboard" className="space-y-6">
                        <TemplateManagementDashboard
                            templates={templates}
                            analytics={analytics}
                            categories={categories}
                            onCreateTemplate={handleCreateTemplate}
                            onTemplateAction={handleTemplateAction}
                            onBulkAction={handleBulkAction}
                            onSearch={handleSearch}
                        />
                    </TabsContent>

                    {/* Analytics Dashboard */}
                    <TabsContent value="analytics" className="space-y-6">
                        <TemplateAnalyticsDashboard
                            analytics={analytics}
                            timeframe={filters.timeframe}
                            onTimeframeChange={handleTimeframeChange}
                            onRefresh={handleRefresh}
                            onExport={handleExport}
                            onTemplateClick={handleTemplateClick}
                            isLoading={fetcher.state === 'loading'}
                        />
                    </TabsContent>

                    {/* Sharing Management */}
                    <TabsContent value="sharing" className="space-y-6">
                        {selectedTemplate && currentTemplate ? (
                            <TemplateSharingManager
                                templateId={selectedTemplate}
                                templateName={currentTemplate.name}
                                currentShares={currentShares}
                                availableUsers={availableUsers}
                                availableTeams={availableTeams}
                                organizationSettings={organizationSettings}
                                onShare={handleShare}
                                onUpdateShare={handleUpdateShare}
                                onRevokeShare={handleRevokeShare}
                                onGeneratePublicLink={handleGeneratePublicLink}
                            />
                        ) : (
                            <div className="text-center py-12">
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No Template Selected</h3>
                                <p className="text-gray-600 mb-6">
                                    Select a template from the dashboard to manage its sharing settings.
                                </p>
                                <Button onClick={() => setActiveView('dashboard')}>
                                    Go to Dashboard
                                </Button>
                            </div>
                        )}
                    </TabsContent>

                    {/* Template Creation Wizard */}
                    <TabsContent value="wizard" className="space-y-6">
                        <div className="text-center py-12">
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Template Creation Wizard</h3>
                            <p className="text-gray-600 mb-6">
                                The enhanced template wizard will be integrated here for step-by-step template creation.
                            </p>
                            <Button onClick={handleCreateTemplate}>
                                Launch Template Wizard
                            </Button>
                        </div>
                    </TabsContent>
                </Tabs>

                {/* Template Creation Wizard Modal */}
                <Dialog open={showCreateWizard} onOpenChange={setShowCreateWizard}>
                    <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Create New Template</DialogTitle>
                            <DialogDescription>
                                Use the step-by-step wizard to create a comprehensive document template
                            </DialogDescription>
                        </DialogHeader>
                        <div className="mt-6">
                            {/* Enhanced Template Wizard would be integrated here */}
                            <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
                                <h4 className="text-lg font-medium text-gray-900 mb-2">Template Wizard Integration</h4>
                                <p className="text-gray-600 mb-6">
                                    The EnhancedTemplateWizard component will be integrated here with proper step management,
                                    field placement, recipient configuration, and workflow setup.
                                </p>
                                <div className="flex justify-center space-x-4">
                                    <Button variant="outline" onClick={handleWizardCancel}>
                                        Cancel
                                    </Button>
                                    <Button onClick={() => {
                                        // Mock template creation for demonstration
                                        handleWizardComplete({
                                            name: "New Template",
                                            description: "Created via wizard",
                                            category: "General",
                                            tags: ["new"],
                                            isPublic: false,
                                            fields: [],
                                            recipients: [],
                                            settings: {
                                                allowDuplication: true,
                                                requireApproval: false,
                                                defaultLanguage: "en",
                                                autoReminders: true,
                                                brandingEnabled: false,
                                            },
                                        });
                                    }}>
                                        Create Template (Demo)
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>
        </Layout>
    );
}