import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import { useState, useEffect } from "react";
import { requireUserSession } from "~/lib/session.server";
import {
    OnboardingWizard,
    OnboardingStep,
    useOnboardingWizard,
    FeatureTour,
    TourStep,
    useFeatureTour,
    ContextualHelp,
    HelpContent,
    ProgressiveDisclosure,
    SuccessMilestones,
    Milestone,
    useMilestones,
    Button,
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Input,
    Label,
    Textarea,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Badge,
    Avatar,
    AvatarFallback,
    AvatarImage,
    Switch
} from "@docusign-alternative/ui";
import {
    User,
    Building,
    Users,
    FileText,
    Settings,
    Zap,
    Target,
    CheckCircle,
    Upload,
    PenTool,
    Share,
    BarChart3,
    Shield,
    Rocket,
    Star,
    Trophy,
    Gift,
    Heart,
    ThumbsUp
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Welcome - DocuSign Alternative" },
        { name: "description", content: "Get started with your e-signature platform" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
    });
}

export default function Onboarding() {
    const { user } = useLoaderData<typeof loader>();
    const navigate = useNavigate();
    const wizard = useOnboardingWizard(0);
    const tour = useFeatureTour([]);
    const [showTour, setShowTour] = useState(false);
    const [onboardingData, setOnboardingData] = useState({
        profile: {
            name: '',
            role: '',
            company: '',
            avatar: ''
        },
        organization: {
            name: '',
            size: '',
            industry: '',
            useCase: ''
        },
        preferences: {
            notifications: true,
            emailUpdates: true,
            tourCompleted: false
        }
    });

    // Sample milestones for demonstration
    const initialMilestones: Milestone[] = [
        {
            id: 'complete-profile',
            title: 'Complete Your Profile',
            description: 'Add your name, role, and profile picture',
            category: 'onboarding',
            points: 50,
            requirement: {
                type: 'count',
                target: 1,
                current: 0
            },
            isCompleted: false,
            reward: {
                type: 'badge',
                value: 'profile-complete',
                description: 'Profile Complete Badge'
            }
        },
        {
            id: 'setup-organization',
            title: 'Set Up Organization',
            description: 'Configure your organization settings',
            category: 'onboarding',
            points: 75,
            requirement: {
                type: 'count',
                target: 1,
                current: 0
            },
            isCompleted: false,
            reward: {
                type: 'feature',
                value: 'advanced-templates',
                description: 'Unlock Advanced Templates'
            }
        },
        {
            id: 'first-document',
            title: 'Upload First Document',
            description: 'Upload and process your first document',
            category: 'usage',
            points: 100,
            requirement: {
                type: 'count',
                target: 1,
                current: 0
            },
            isCompleted: false,
            celebrationStyle: 'confetti'
        },
        {
            id: 'complete-tour',
            title: 'Complete Feature Tour',
            description: 'Take the guided tour of key features',
            category: 'engagement',
            points: 25,
            requirement: {
                type: 'count',
                target: 1,
                current: 0
            },
            isCompleted: false
        }
    ];

    const milestones = useMilestones(initialMilestones);

    // Onboarding steps
    const onboardingSteps: OnboardingStep[] = [
        {
            id: 'welcome',
            title: 'Welcome to DocuSign Alternative',
            description: 'Let\'s get you set up with everything you need to start signing documents',
            category: 'setup',
            estimatedTime: '2 min',
            content: (
                <div className="space-y-6">
                    <div className="text-center">
                        <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Rocket className="w-12 h-12 text-blue-600" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">
                            Welcome aboard! 🎉
                        </h2>
                        <p className="text-gray-600 max-w-md mx-auto">
                            You're about to experience the most intuitive e-signature platform.
                            Let's get you set up in just a few quick steps.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                            <User className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-blue-900">Set Up Profile</h3>
                            <p className="text-sm text-blue-700">Complete your personal information</p>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                            <Building className="w-8 h-8 text-green-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-green-900">Configure Organization</h3>
                            <p className="text-sm text-green-700">Set up your team and preferences</p>
                        </div>
                        <div className="text-center p-4 bg-purple-50 rounded-lg">
                            <Zap className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-purple-900">Explore Features</h3>
                            <p className="text-sm text-purple-700">Discover powerful capabilities</p>
                        </div>
                    </div>

                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                            <Star className="w-5 h-5 text-yellow-600 mt-0.5" />
                            <div>
                                <h4 className="font-medium text-yellow-900">Pro Tip</h4>
                                <p className="text-sm text-yellow-800">
                                    Complete all setup steps to unlock advanced features and earn achievement badges!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )
        },
        {
            id: 'profile',
            title: 'Complete Your Profile',
            description: 'Tell us about yourself to personalize your experience',
            category: 'setup',
            estimatedTime: '3 min',
            content: (
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="name">Full Name *</Label>
                                <Input
                                    id="name"
                                    value={onboardingData.profile.name}
                                    onChange={(e) => setOnboardingData(prev => ({
                                        ...prev,
                                        profile: { ...prev.profile, name: e.target.value }
                                    }))}
                                    placeholder="Enter your full name"
                                />
                            </div>
                            <div>
                                <Label htmlFor="role">Your Role</Label>
                                <Select
                                    value={onboardingData.profile.role}
                                    onValueChange={(value) => setOnboardingData(prev => ({
                                        ...prev,
                                        profile: { ...prev.profile, role: value }
                                    }))}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select your role" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="ceo">CEO/Founder</SelectItem>
                                        <SelectItem value="manager">Manager</SelectItem>
                                        <SelectItem value="legal">Legal Professional</SelectItem>
                                        <SelectItem value="hr">HR Professional</SelectItem>
                                        <SelectItem value="sales">Sales Representative</SelectItem>
                                        <SelectItem value="admin">Administrator</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="company">Company Name</Label>
                                <Input
                                    id="company"
                                    value={onboardingData.profile.company}
                                    onChange={(e) => setOnboardingData(prev => ({
                                        ...prev,
                                        profile: { ...prev.profile, company: e.target.value }
                                    }))}
                                    placeholder="Enter your company name"
                                />
                            </div>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <Label>Profile Picture</Label>
                                <div className="flex items-center gap-4">
                                    <Avatar className="w-16 h-16">
                                        <AvatarImage src={onboardingData.profile.avatar} />
                                        <AvatarFallback>
                                            {onboardingData.profile.name.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
                                        </AvatarFallback>
                                    </Avatar>
                                    <Button variant="outline" size="sm">
                                        Upload Photo
                                    </Button>
                                </div>
                            </div>
                            <div className="bg-blue-50 rounded-lg p-4">
                                <h4 className="font-medium text-blue-900 mb-2">Why we ask for this</h4>
                                <ul className="text-sm text-blue-800 space-y-1">
                                    <li>• Personalize your dashboard experience</li>
                                    <li>• Show your identity to document recipients</li>
                                    <li>• Enable team collaboration features</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            )
        },
        {
            id: 'organization',
            title: 'Set Up Your Organization',
            description: 'Configure your team and organizational preferences',
            category: 'setup',
            estimatedTime: '4 min',
            content: (
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="orgName">Organization Name *</Label>
                                <Input
                                    id="orgName"
                                    value={onboardingData.organization.name}
                                    onChange={(e) => setOnboardingData(prev => ({
                                        ...prev,
                                        organization: { ...prev.organization, name: e.target.value }
                                    }))}
                                    placeholder="Enter organization name"
                                />
                            </div>
                            <div>
                                <Label htmlFor="orgSize">Organization Size</Label>
                                <Select
                                    value={onboardingData.organization.size}
                                    onValueChange={(value) => setOnboardingData(prev => ({
                                        ...prev,
                                        organization: { ...prev.organization, size: value }
                                    }))}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select organization size" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="1-10">1-10 employees</SelectItem>
                                        <SelectItem value="11-50">11-50 employees</SelectItem>
                                        <SelectItem value="51-200">51-200 employees</SelectItem>
                                        <SelectItem value="201-1000">201-1000 employees</SelectItem>
                                        <SelectItem value="1000+">1000+ employees</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="industry">Industry</Label>
                                <Select
                                    value={onboardingData.organization.industry}
                                    onValueChange={(value) => setOnboardingData(prev => ({
                                        ...prev,
                                        organization: { ...prev.organization, industry: value }
                                    }))}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select your industry" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="technology">Technology</SelectItem>
                                        <SelectItem value="finance">Finance</SelectItem>
                                        <SelectItem value="healthcare">Healthcare</SelectItem>
                                        <SelectItem value="legal">Legal Services</SelectItem>
                                        <SelectItem value="real-estate">Real Estate</SelectItem>
                                        <SelectItem value="education">Education</SelectItem>
                                        <SelectItem value="retail">Retail</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="useCase">Primary Use Case</Label>
                                <Select
                                    value={onboardingData.organization.useCase}
                                    onValueChange={(value) => setOnboardingData(prev => ({
                                        ...prev,
                                        organization: { ...prev.organization, useCase: value }
                                    }))}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="What will you primarily use this for?" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="contracts">Contract Management</SelectItem>
                                        <SelectItem value="hr">HR Documents</SelectItem>
                                        <SelectItem value="sales">Sales Agreements</SelectItem>
                                        <SelectItem value="legal">Legal Documents</SelectItem>
                                        <SelectItem value="compliance">Compliance Forms</SelectItem>
                                        <SelectItem value="general">General Document Signing</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <ProgressiveDisclosure
                                title="Advanced Organization Settings"
                                level="intermediate"
                                helpContent={[{
                                    id: 'org-settings-help',
                                    title: 'Organization Settings',
                                    description: 'Configure advanced settings for your organization',
                                    type: 'guide',
                                    content: (
                                        <div className="space-y-2">
                                            <p>These settings help customize the platform for your organization:</p>
                                            <ul className="list-disc list-inside text-sm space-y-1">
                                                <li>Branding: Add your logo and colors</li>
                                                <li>Security: Set password policies</li>
                                                <li>Integrations: Connect with your tools</li>
                                            </ul>
                                        </div>
                                    )
                                }]}
                            >
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <Label>Enable Team Collaboration</Label>
                                            <p className="text-sm text-gray-600">Allow team members to share documents and templates</p>
                                        </div>
                                        <Switch />
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <Label>Require Two-Factor Authentication</Label>
                                            <p className="text-sm text-gray-600">Enhanced security for all team members</p>
                                        </div>
                                        <Switch />
                                    </div>
                                </div>
                            </ProgressiveDisclosure>
                        </div>
                    </div>
                </div>
            )
        },
        {
            id: 'preferences',
            title: 'Customize Your Experience',
            description: 'Set up notifications and preferences',
            category: 'setup',
            estimatedTime: '2 min',
            isOptional: true,
            content: (
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Notification Preferences</CardTitle>
                                <CardDescription>
                                    Choose how you'd like to be notified about document activity
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <Label>Email Notifications</Label>
                                        <p className="text-sm text-gray-600">Get notified when documents are signed</p>
                                    </div>
                                    <Switch
                                        checked={onboardingData.preferences.notifications}
                                        onCheckedChange={(checked) => setOnboardingData(prev => ({
                                            ...prev,
                                            preferences: { ...prev.preferences, notifications: checked }
                                        }))}
                                    />
                                </div>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <Label>Product Updates</Label>
                                        <p className="text-sm text-gray-600">Receive updates about new features</p>
                                    </div>
                                    <Switch
                                        checked={onboardingData.preferences.emailUpdates}
                                        onCheckedChange={(checked) => setOnboardingData(prev => ({
                                            ...prev,
                                            preferences: { ...prev.preferences, emailUpdates: checked }
                                        }))}
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Quick Actions</CardTitle>
                                <CardDescription>
                                    Get started with these common tasks
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <Button variant="outline" className="w-full justify-start" asChild>
                                    <a href="/upload">
                                        <Upload className="w-4 h-4 mr-2" />
                                        Upload Your First Document
                                    </a>
                                </Button>
                                <Button variant="outline" className="w-full justify-start" asChild>
                                    <a href="/templates/create">
                                        <FileText className="w-4 h-4 mr-2" />
                                        Create a Template
                                    </a>
                                </Button>
                                <Button variant="outline" className="w-full justify-start" asChild>
                                    <a href="/organization/members/invite">
                                        <Users className="w-4 h-4 mr-2" />
                                        Invite Team Members
                                    </a>
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            )
        },
        {
            id: 'completion',
            title: 'You\'re All Set!',
            description: 'Welcome to your new e-signature platform',
            category: 'completion',
            estimatedTime: '1 min',
            content: (
                <div className="space-y-6 text-center">
                    <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                        <CheckCircle className="w-12 h-12 text-green-600" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">
                            Congratulations! 🎉
                        </h2>
                        <p className="text-gray-600 max-w-md mx-auto">
                            Your account is now set up and ready to use. You can start uploading documents,
                            creating templates, and inviting team members right away.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-4 bg-blue-50 rounded-lg">
                            <PenTool className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-blue-900">Start Signing</h3>
                            <p className="text-sm text-blue-700">Upload and sign your first document</p>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                            <Share className="w-8 h-8 text-green-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-green-900">Invite Others</h3>
                            <p className="text-sm text-green-700">Add team members to collaborate</p>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-lg">
                            <BarChart3 className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                            <h3 className="font-semibold text-purple-900">Track Progress</h3>
                            <p className="text-sm text-purple-700">Monitor your document activity</p>
                        </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                        <Button onClick={() => setShowTour(true)} variant="outline">
                            Take Feature Tour
                        </Button>
                        <Button onClick={() => navigate('/dashboard')}>
                            Go to Dashboard
                        </Button>
                    </div>
                </div>
            )
        }
    ];

    // Feature tour steps
    const tourSteps: TourStep[] = [
        {
            id: 'dashboard-overview',
            title: 'Your Dashboard',
            description: 'This is your main hub where you can see all your document activity, metrics, and quick actions.',
            target: '[data-tour="dashboard"]',
            placement: 'center',
            category: 'navigation'
        },
        {
            id: 'upload-button',
            title: 'Upload Documents',
            description: 'Click here to upload new documents for signing. We support PDF, Word, and many other formats.',
            target: '[data-tour="upload"]',
            placement: 'bottom',
            category: 'action',
            action: 'click'
        },
        {
            id: 'templates',
            title: 'Document Templates',
            description: 'Create reusable templates to speed up your workflow. Perfect for contracts and forms you use regularly.',
            target: '[data-tour="templates"]',
            placement: 'bottom',
            category: 'feature'
        },
        {
            id: 'team-management',
            title: 'Team Management',
            description: 'Invite team members, manage permissions, and collaborate on documents together.',
            target: '[data-tour="team"]',
            placement: 'left',
            category: 'feature'
        },
        {
            id: 'analytics',
            title: 'Analytics & Reports',
            description: 'Track your document performance, completion rates, and team productivity with detailed analytics.',
            target: '[data-tour="analytics"]',
            placement: 'top',
            category: 'feature'
        }
    ];

    const handleStepComplete = (stepIndex: number) => {
        wizard.completeStep(stepIndex);

        // Update milestones based on completed steps
        if (stepIndex === 1) { // Profile step
            milestones.updateMilestoneProgress('complete-profile', 1);
        } else if (stepIndex === 2) { // Organization step
            milestones.updateMilestoneProgress('setup-organization', 1);
        } else if (stepIndex === 4) { // Completion step
            // Mark onboarding as complete
            setOnboardingData(prev => ({
                ...prev,
                preferences: { ...prev.preferences, tourCompleted: true }
            }));
        }
    };

    const handleWizardComplete = () => {
        // Save onboarding data (in real app, this would be an API call)
        console.log('Onboarding completed:', onboardingData);

        // Navigate to dashboard or show tour
        if (showTour) {
            tour.startTour();
        } else {
            navigate('/dashboard');
        }
    };

    const handleTourComplete = () => {
        milestones.updateMilestoneProgress('complete-tour', 1);
        setShowTour(false);
        navigate('/dashboard');
    };

    const handleMilestoneComplete = (milestone: Milestone) => {
        console.log('Milestone completed:', milestone);
        // In a real app, this would trigger analytics events, notifications, etc.
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Feature Tour */}
            <FeatureTour
                steps={tourSteps}
                isActive={showTour}
                currentStepIndex={tour.currentStepIndex}
                onStepChange={tour.goToStep}
                onComplete={handleTourComplete}
                onClose={() => setShowTour(false)}
                autoAdvance={false}
                allowSkip={true}
            />

            <div className="container mx-auto px-4 py-8">
                {/* Milestones Panel */}
                <div className="mb-8">
                    <SuccessMilestones
                        milestones={milestones.milestones}
                        userProgress={milestones.userProgress}
                        onMilestoneComplete={handleMilestoneComplete}
                        showCelebration={true}
                    />
                </div>

                {/* Main Onboarding Wizard */}
                <OnboardingWizard
                    steps={onboardingSteps}
                    currentStepIndex={wizard.currentStep}
                    onStepChange={(stepIndex) => {
                        wizard.goToStep(stepIndex);
                        handleStepComplete(stepIndex);
                    }}
                    onComplete={handleWizardComplete}
                    onSkip={() => navigate('/dashboard')}
                    showProgress={true}
                    showStepNumbers={true}
                    allowStepNavigation={true}
                    completedSteps={wizard.completedSteps}
                    userProgress={{
                        ...wizard.userProgress,
                        totalSteps: onboardingSteps.length
                    }}
                />
            </div>
        </div>
    );
}