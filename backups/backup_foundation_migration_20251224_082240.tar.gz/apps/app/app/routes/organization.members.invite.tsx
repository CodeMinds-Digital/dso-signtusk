import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasSuccess, hasError } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Textarea,
    Checkbox,
    Badge,
} from "@docusign-alternative/ui";
import {
    UserPlus,
    ArrowLeft,
    Mail,
    Users,
    Plus,
    X
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";
import { useState } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Invite Member - DocuSign Alternative" },
        { name: "description", content: "Invite new members to your organization" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "inviteMember") {
        const email = formData.get("email") as string;
        const role = formData.get("role") as string;
        const teamIds = formData.getAll("teamIds") as string[];
        const message = formData.get("message") as string;

        // Basic validation
        if (!email || !role) {
            return json({ error: "Email and role are required" }, { status: 400 });
        }

        // In real implementation, use tRPC to invite member
        try {
            // Simulate invitation
            return json({
                success: `Invitation sent to ${email}`,
                redirect: "/organization/members"
            });
        } catch (error) {
            return json({ error: "Failed to send invitation" }, { status: 500 });
        }
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function InviteMember() {
    const { user } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const [emails, setEmails] = useState<string[]>(['']);
    const [selectedTeams, setSelectedTeams] = useState<string[]>([]);

    // tRPC queries
    const teamsQuery = trpc.organization.listTeams.useQuery({
        organizationId: user.organizationId,
        limit: 50,
    });

    const teams = teamsQuery.data?.teams || [];

    const addEmailField = () => {
        setEmails([...emails, '']);
    };

    const removeEmailField = (index: number) => {
        if (emails.length > 1) {
            setEmails(emails.filter((_, i) => i !== index));
        }
    };

    const updateEmail = (index: number, value: string) => {
        const newEmails = [...emails];
        newEmails[index] = value;
        setEmails(newEmails);
    };

    const toggleTeam = (teamId: string) => {
        setSelectedTeams(prev =>
            prev.includes(teamId)
                ? prev.filter(id => id !== teamId)
                : [...prev, teamId]
        );
    };

    // Redirect on success
    if (hasSuccess(actionData) && actionData.redirect) {
        return redirect(actionData.redirect);
    }

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center space-x-4 mb-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/organization/members">
                                <ArrowLeft className="h-4 w-4 mr-2" />
                                Back to Members
                            </Link>
                        </Button>
                    </div>
                    <h1 className="text-2xl font-bold text-gray-900">Invite Members</h1>
                    <p className="text-gray-600">
                        Invite new members to join your organization
                    </p>
                </div>

                <div className="max-w-2xl">
                    {/* Success/Error Messages */}
                    {hasSuccess(actionData) && (
                        <div className="mb-6 rounded-md bg-green-50 p-4">
                            <div className="text-sm text-green-700">{actionData.success}</div>
                        </div>
                    )}

                    {hasError(actionData) && (
                        <div className="mb-6 rounded-md bg-red-50 p-4">
                            <div className="text-sm text-red-700">{actionData.error}</div>
                        </div>
                    )}

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <UserPlus className="mr-2 h-5 w-5" />
                                Invite New Members
                            </CardTitle>
                            <CardDescription>
                                Send invitations to new team members to join your organization
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Form method="post" className="space-y-6">
                                <input type="hidden" name="intent" value="inviteMember" />

                                {/* Email Addresses */}
                                <div>
                                    <Label className="text-base font-medium">Email Addresses</Label>
                                    <p className="text-sm text-gray-600 mb-3">
                                        Enter the email addresses of people you want to invite
                                    </p>
                                    <div className="space-y-3">
                                        {emails.map((email, index) => (
                                            <div key={index} className="flex items-center space-x-2">
                                                <div className="flex-1">
                                                    <Input
                                                        type="email"
                                                        name="email"
                                                        placeholder="colleague@company.com"
                                                        value={email}
                                                        onChange={(e) => updateEmail(index, e.target.value)}
                                                        required={index === 0}
                                                    />
                                                </div>
                                                {emails.length > 1 && (
                                                    <Button
                                                        type="button"
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => removeEmailField(index)}
                                                    >
                                                        <X className="h-4 w-4" />
                                                    </Button>
                                                )}
                                            </div>
                                        ))}
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            onClick={addEmailField}
                                        >
                                            <Plus className="mr-2 h-4 w-4" />
                                            Add Another Email
                                        </Button>
                                    </div>
                                </div>

                                {/* Role Selection */}
                                <div>
                                    <Label htmlFor="role">Role</Label>
                                    <Select name="role" required>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a role" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ADMIN">
                                                <div>
                                                    <div className="font-medium">Admin</div>
                                                    <div className="text-sm text-gray-600">
                                                        Can manage organization settings and members
                                                    </div>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="MEMBER">
                                                <div>
                                                    <div className="font-medium">Member</div>
                                                    <div className="text-sm text-gray-600">
                                                        Can create and manage documents
                                                    </div>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="GUEST">
                                                <div>
                                                    <div className="font-medium">Guest</div>
                                                    <div className="text-sm text-gray-600">
                                                        Limited access to specific documents
                                                    </div>
                                                </div>
                                            </SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                {/* Team Assignment */}
                                {teams.length > 0 && (
                                    <div>
                                        <Label className="text-base font-medium">Teams (Optional)</Label>
                                        <p className="text-sm text-gray-600 mb-3">
                                            Assign the new members to specific teams
                                        </p>
                                        <div className="space-y-2 max-h-48 overflow-y-auto border rounded-md p-3">
                                            {teams.map((team) => (
                                                <div key={team.id} className="flex items-center space-x-2">
                                                    <Checkbox
                                                        id={`team-${team.id}`}
                                                        checked={selectedTeams.includes(team.id)}
                                                        onCheckedChange={() => toggleTeam(team.id)}
                                                    />
                                                    <Label
                                                        htmlFor={`team-${team.id}`}
                                                        className="flex-1 cursor-pointer"
                                                    >
                                                        <div>
                                                            <div className="font-medium">{team.name}</div>
                                                            {team.description && (
                                                                <div className="text-sm text-gray-600">
                                                                    {team.description}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </Label>
                                                    <Badge variant="outline">
                                                        {team.memberCount} members
                                                    </Badge>
                                                </div>
                                            ))}
                                        </div>
                                        {/* Hidden inputs for selected teams */}
                                        {selectedTeams.map(teamId => (
                                            <input
                                                key={teamId}
                                                type="hidden"
                                                name="teamIds"
                                                value={teamId}
                                            />
                                        ))}
                                    </div>
                                )}

                                {/* Personal Message */}
                                <div>
                                    <Label htmlFor="message">Personal Message (Optional)</Label>
                                    <Textarea
                                        id="message"
                                        name="message"
                                        placeholder="Add a personal message to the invitation..."
                                        rows={4}
                                    />
                                </div>

                                {/* Preview */}
                                <div className="bg-gray-50 rounded-lg p-4">
                                    <h3 className="font-medium mb-2 flex items-center">
                                        <Mail className="mr-2 h-4 w-4" />
                                        Invitation Preview
                                    </h3>
                                    <div className="text-sm text-gray-600 space-y-2">
                                        <p>
                                            <strong>Subject:</strong> You're invited to join our organization
                                        </p>
                                        <p>
                                            <strong>Recipients:</strong> {emails.filter(e => e.trim()).length} email(s)
                                        </p>
                                        <p>
                                            <strong>Role:</strong> Will be assigned based on selection
                                        </p>
                                        {selectedTeams.length > 0 && (
                                            <p>
                                                <strong>Teams:</strong> {selectedTeams.length} team(s) selected
                                            </p>
                                        )}
                                    </div>
                                </div>

                                {/* Actions */}
                                <div className="flex items-center justify-between pt-6">
                                    <Button variant="outline" asChild>
                                        <Link to="/organization/members">
                                            Cancel
                                        </Link>
                                    </Button>
                                    <Button type="submit" disabled={isSubmitting}>
                                        <Mail className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Sending Invitations..." : "Send Invitations"}
                                    </Button>
                                </div>
                            </Form>
                        </CardContent>
                    </Card>

                    {/* Help Card */}
                    <Card className="mt-6">
                        <CardHeader>
                            <CardTitle className="text-lg">Invitation Process</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3 text-sm text-gray-600">
                                <div className="flex items-start space-x-2">
                                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-medium mt-0.5">
                                        1
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900">Invitation Sent</p>
                                        <p>Recipients will receive an email with a secure invitation link</p>
                                    </div>
                                </div>
                                <div className="flex items-start space-x-2">
                                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-medium mt-0.5">
                                        2
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900">Account Creation</p>
                                        <p>New users will create their account and set up their profile</p>
                                    </div>
                                </div>
                                <div className="flex items-start space-x-2">
                                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-medium mt-0.5">
                                        3
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900">Access Granted</p>
                                        <p>Once accepted, they'll have access based on their assigned role</p>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </Layout>
    );
}