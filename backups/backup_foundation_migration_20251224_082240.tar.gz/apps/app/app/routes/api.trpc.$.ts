import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "@docusign-alternative/trpc";
import { createTRPCContext } from "@docusign-alternative/trpc";

const handler = (request: Request) =>
    fetchRequestHandler({
        endpoint: "/api/trpc",
        req: request,
        router: appRouter,
        createContext: () => createTRPCContext({ req: request }),
    });

export const loader = ({ request }: LoaderFunctionArgs) => handler(request);
export const action = ({ request }: ActionFunctionArgs) => handler(request);