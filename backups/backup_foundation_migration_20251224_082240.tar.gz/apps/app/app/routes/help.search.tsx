import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useSearchParams } from "@remix-run/react";
import { useState, useEffect } from "react";
import { HelpSearchInterface } from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Search Help - DocuSign Alternative" },
        { name: "description", content: "Search our comprehensive help center for answers" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    return json({});
}

// Mock data for suggestions and popular searches
const mockSuggestions = [
    { id: '1', text: 'how to upload document', type: 'query' as const, count: 150 },
    { id: '2', text: 'signature field placement', type: 'query' as const, count: 120 },
    { id: '3', text: 'template creation', type: 'query' as const, count: 98 },
    { id: '4', text: 'billing questions', type: 'query' as const, count: 85 },
    { id: '5', text: 'API integration', type: 'query' as const, count: 72 },
    { id: '6', text: 'getting started', type: 'category' as const, count: 45 },
    { id: '7', text: 'documents', type: 'category' as const, count: 38 },
    { id: '8', text: 'signing', type: 'tag' as const, count: 32 },
];

const mockPopularSearches = [
    { query: 'how to upload document', count: 1250, trend: 'up' as const },
    { query: 'signature field placement', count: 890, trend: 'stable' as const },
    { query: 'template creation guide', count: 650, trend: 'up' as const },
    { query: 'billing and pricing', count: 420, trend: 'down' as const },
    { query: 'API documentation', count: 380, trend: 'up' as const },
    { query: 'mobile signing', count: 320, trend: 'stable' as const },
    { query: 'bulk operations', count: 280, trend: 'up' as const },
    { query: 'security features', count: 250, trend: 'stable' as const },
];

export default function HelpSearchPage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const [searchResults, setSearchResults] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [totalResults, setTotalResults] = useState(0);

    const initialQuery = searchParams.get('q') || '';

    // Search mutation
    const searchMutation = trpc.helpSupport.searchHelp.useMutation({
        onMutate: () => {
            setIsLoading(true);
        },
        onSuccess: (data) => {
            // Transform the results to match the expected format
            const transformedResults = [
                ...data.articles.map((article: any) => ({
                    id: article.id,
                    title: article.title,
                    content: article.content,
                    excerpt: article.content.substring(0, 200) + '...',
                    type: 'article' as const,
                    category: article.category,
                    tags: article.tags,
                    url: `/help/knowledge-base?article=${article.id}`,
                    score: 0.9, // Mock relevance score
                    views: article.views,
                    rating: article.rating,
                    lastUpdated: article.lastUpdated,
                    highlights: [
                        {
                            field: 'title',
                            fragments: [article.title.split(' ')[0]], // Simple highlighting
                        },
                    ],
                })),
                ...data.faqs.map((faq: any) => ({
                    id: faq.id,
                    title: faq.question,
                    content: faq.answer,
                    excerpt: faq.answer.substring(0, 200) + '...',
                    type: 'faq' as const,
                    category: faq.category,
                    tags: [],
                    url: `/help?faq=${faq.id}`,
                    score: 0.8,
                    views: faq.views,
                    lastUpdated: new Date(),
                    highlights: [
                        {
                            field: 'question',
                            fragments: [faq.question.split(' ')[0]],
                        },
                    ],
                })),
            ];

            setSearchResults(transformedResults);
            setTotalResults(data.totalResults);
            setIsLoading(false);
        },
        onError: () => {
            setIsLoading(false);
        },
    });

    useEffect(() => {
        if (initialQuery) {
            handleSearch(initialQuery);
        }
    }, []);

    const handleSearch = (query: string, filters?: any) => {
        if (query.trim()) {
            // Update URL
            setSearchParams({ q: query });

            // Perform search
            searchMutation.mutate({
                query,
                category: filters?.category,
                limit: 20,
            });
        }
    };

    const handleSelectResult = (result: any) => {
        // Navigate to the result URL
        window.location.href = result.url;
    };

    const handleClearSearch = () => {
        setSearchParams({});
        setSearchResults([]);
        setTotalResults(0);
    };

    // Get recent searches from localStorage
    const getRecentSearches = () => {
        try {
            const history = localStorage.getItem('helpSearchHistory');
            return history ? JSON.parse(history) : [];
        } catch {
            return [];
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <HelpSearchInterface
                searchResults={searchResults}
                suggestions={mockSuggestions}
                popularSearches={mockPopularSearches}
                recentSearches={getRecentSearches()}
                isLoading={isLoading}
                totalResults={totalResults}
                onSearch={handleSearch}
                onSelectResult={handleSelectResult}
                onClearSearch={handleClearSearch}
            />
        </div>
    );
}