import * as trpcNext from '@trpc/server/adapters/next';
import { appRouter, createContext } from '@docusign-alternative/trpc';

/**
 * tRPC API handler for Next.js application
 * Handles all tRPC requests at /api/trpc/[trpc]
 */
export default trpcNext.createNextApiHandler({
    router: appRouter,
    createContext: ({ req, res }) => createContext({ req, res }),
    onError: ({ error, path }) => {
        console.error(`tRPC Error on ${path}:`, error);
    },
    batching: {
        enabled: true,
    },
});