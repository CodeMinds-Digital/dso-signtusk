// Placeholder tRPC API route - will be implemented when tRPC package is ready
export async function GET() {
    return Response.json({ message: 'tRPC API not yet implemented' });
}

export async function POST() {
    return Response.json({ message: 'tRPC API not yet implemented' });
}