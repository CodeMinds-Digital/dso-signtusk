import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { trpc } from '../lib/trpc'
import { Navigation } from '../components/navigation'
import { Footer } from '../components/footer'
import './globals.css'

const inter = Inter({
    subsets: ['latin'],
    display: 'swap',
    variable: '--font-inter',
})

export const metadata: Metadata = {
    title: {
        default: 'DocuSign Alternative - Digital Signature Platform',
        template: '%s | DocuSign Alternative',
    },
    description: 'Secure, compliant, and user-friendly digital signature platform. Sign documents electronically with enterprise-grade security and legal compliance.',
    keywords: [
        'digital signature',
        'electronic signature',
        'e-signature',
        'document signing',
        'PDF signing',
        'secure documents',
        'legal compliance',
        'enterprise security'
    ],
    authors: [{ name: 'DocuSign Alternative Team' }],
    creator: 'DocuSign Alternative',
    publisher: 'DocuSign Alternative',
    formatDetection: {
        email: false,
        address: false,
        telephone: false,
    },
    metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'),
    alternates: {
        canonical: '/',
    },
    openGraph: {
        type: 'website',
        locale: 'en_US',
        url: '/',
        title: 'DocuSign Alternative - Digital Signature Platform',
        description: 'Secure, compliant, and user-friendly digital signature platform',
        siteName: 'DocuSign Alternative',
        images: [
            {
                url: '/og-image.jpg',
                width: 1200,
                height: 630,
                alt: 'DocuSign Alternative - Digital Signature Platform',
            },
        ],
    },
    twitter: {
        card: 'summary_large_image',
        title: 'DocuSign Alternative - Digital Signature Platform',
        description: 'Secure, compliant, and user-friendly digital signature platform',
        images: ['/og-image.jpg'],
    },
    robots: {
        index: true,
        follow: true,
        googleBot: {
            index: true,
            follow: true,
            'max-video-preview': -1,
            'max-image-preview': 'large',
            'max-snippet': -1,
        },
    },
}

export const viewport: Viewport = {
    themeColor: [
        { media: '(prefers-color-scheme: light)', color: '#ffffff' },
        { media: '(prefers-color-scheme: dark)', color: '#000000' },
    ],
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
}

function RootLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return (
        <html lang="en" className={inter.variable}>
            <body className="font-sans antialiased">
                <Navigation />
                {children}
                <Footer />
            </body>
        </html>
    )
}

export default trpc.withTRPC(RootLayout)