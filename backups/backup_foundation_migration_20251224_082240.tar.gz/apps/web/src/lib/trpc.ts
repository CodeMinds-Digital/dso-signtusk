import { httpBatchLink } from '@trpc/client';
import { createTRPCNext } from '@trpc/next';
import type { AppRouter } from '@docusign-alternative/trpc';

/**
 * Create tRPC Next.js client for marketing site
 */
export const trpc = createTRPCNext<AppRouter>({
    config() {
        return {
            links: [
                httpBatchLink({
                    url: '/api/trpc',
                    // Include credentials for session management
                    fetch(url, options) {
                        return fetch(url, {
                            ...options,
                            credentials: 'include',
                        });
                    },
                    headers() {
                        // Add authorization header if session token exists
                        const sessionToken = typeof window !== 'undefined'
                            ? localStorage.getItem('sessionToken')
                            : null;
                        return sessionToken ? {
                            authorization: `Bearer ${sessionToken}`,
                        } : {};
                    },
                }),
            ],
        };
    },
    ssr: false, // Disable SSR for client-side authentication
});