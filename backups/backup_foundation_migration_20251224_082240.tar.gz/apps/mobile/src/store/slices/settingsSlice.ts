import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface NotificationSettings {
    pushEnabled: boolean;
    emailEnabled: boolean;
    documentUpdates: boolean;
    signingReminders: boolean;
    marketingEmails: boolean;
}

interface SecuritySettings {
    biometricLogin: boolean;
    autoLock: boolean;
    autoLockTimeout: number; // in minutes
    requirePinForSigning: boolean;
}

interface AppSettings {
    theme: 'light' | 'dark' | 'system';
    language: string;
    fontSize: 'small' | 'medium' | 'large';
    offlineMode: boolean;
    autoSync: boolean;
    syncOnWifiOnly: boolean;
}

interface SettingsState {
    notifications: NotificationSettings;
    security: SecuritySettings;
    app: AppSettings;
    isLoading: boolean;
}

const initialState: SettingsState = {
    notifications: {
        pushEnabled: true,
        emailEnabled: true,
        documentUpdates: true,
        signingReminders: true,
        marketingEmails: false,
    },
    security: {
        biometricLogin: false,
        autoLock: true,
        autoLockTimeout: 5,
        requirePinForSigning: true,
    },
    app: {
        theme: 'system',
        language: 'en',
        fontSize: 'medium',
        offlineMode: true,
        autoSync: true,
        syncOnWifiOnly: false,
    },
    isLoading: false,
};

const settingsSlice = createSlice({
    name: 'settings',
    initialState,
    reducers: {
        setLoading: (state, action: PayloadAction<boolean>) => {
            state.isLoading = action.payload;
        },
        updateNotificationSettings: (state, action: PayloadAction<Partial<NotificationSettings>>) => {
            state.notifications = { ...state.notifications, ...action.payload };
        },
        updateSecuritySettings: (state, action: PayloadAction<Partial<SecuritySettings>>) => {
            state.security = { ...state.security, ...action.payload };
        },
        updateAppSettings: (state, action: PayloadAction<Partial<AppSettings>>) => {
            state.app = { ...state.app, ...action.payload };
        },
        resetSettings: (state) => {
            state.notifications = initialState.notifications;
            state.security = initialState.security;
            state.app = initialState.app;
        },
    },
});

export const {
    setLoading,
    updateNotificationSettings,
    updateSecuritySettings,
    updateAppSettings,
    resetSettings,
} = settingsSlice.actions;

export default settingsSlice.reducer;