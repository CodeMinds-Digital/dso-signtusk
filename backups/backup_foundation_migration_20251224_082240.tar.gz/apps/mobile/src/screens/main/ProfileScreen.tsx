import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { useAuth } from '../../providers/AuthProvider';
import Icon from 'react-native-vector-icons/MaterialIcons';

export const ProfileScreen: React.FC = () => {
    const { user } = useSelector((state: RootState) => state.auth);
    const { logoutUser } = useAuth();

    const handleLogout = async () => {
        await logoutUser();
    };

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <View style={styles.avatar}>
                    <Text style={styles.avatarText}>
                        {user?.name?.charAt(0).toUpperCase() || 'U'}
                    </Text>
                </View>
                <Text style={styles.name}>{user?.name || 'User'}</Text>
                <Text style={styles.email}>{user?.email || 'user@example.com'}</Text>
            </View>

            <View style={styles.section}>
                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="person" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>Edit Profile</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="security" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>Security Settings</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="notifications" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>Notifications</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="settings" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>Settings</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>
            </View>

            <View style={styles.section}>
                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="help" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>Help & Support</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.menuItem}>
                    <Icon name="info" size={24} color="#007AFF" />
                    <Text style={styles.menuText}>About</Text>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                <Icon name="logout" size={24} color="#FF3B30" />
                <Text style={styles.logoutText}>Sign Out</Text>
            </TouchableOpacity>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F2F2F7',
    },
    header: {
        backgroundColor: '#ffffff',
        alignItems: 'center',
        paddingVertical: 32,
        marginBottom: 24,
    },
    avatar: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: '#007AFF',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
    },
    avatarText: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#ffffff',
    },
    name: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333333',
        marginBottom: 4,
    },
    email: {
        fontSize: 16,
        color: '#666666',
    },
    section: {
        backgroundColor: '#ffffff',
        marginBottom: 24,
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#F2F2F7',
    },
    menuText: {
        flex: 1,
        fontSize: 16,
        color: '#333333',
        marginLeft: 12,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        paddingHorizontal: 16,
        paddingVertical: 16,
        marginBottom: 32,
    },
    logoutText: {
        fontSize: 16,
        color: '#FF3B30',
        marginLeft: 12,
        fontWeight: '500',
    },
});