import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const CameraCaptureScreen: React.FC = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Camera Capture</Text>
            <Text style={styles.subtitle}>Camera functionality for document scanning and signature capture will be implemented here</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F2F2F7',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333333',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 16,
        color: '#666666',
        textAlign: 'center',
        paddingHorizontal: 20,
    },
});