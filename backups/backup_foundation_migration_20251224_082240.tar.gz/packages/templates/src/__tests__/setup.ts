// Test setup file for templates package
import { beforeAll, afterAll } from 'vitest';

beforeAll(async () => {
    // Global test setup
});

afterAll(async () => {
    // Global test cleanup
});