import i18n from 'i18next';
import Backend from 'i18next-http-backend';
import LanguageDetector from 'i18next-browser-languagedetector';
import ICU from 'i18next-icu';
import { initReactI18next } from 'react-i18next';
import { SupportedLanguage, TranslationNamespace } from './types';
import { LANGUAGE_METADATA } from './languages';

// Default configuration
export const DEFAULT_LANGUAGE: SupportedLanguage = 'en';
export const DEFAULT_NAMESPACE: TranslationNamespace = 'common';

// Fallback languages for better user experience
export const FALLBACK_LANGUAGES: Record<SupportedLanguage, SupportedLanguage[]> = {
    'en': [],
    'es': ['en'],
    'fr': ['en'],
    'de': ['en'],
    'it': ['en'],
    'pt': ['en'],
    'nl': ['en'],
    'sv': ['en'],
    'da': ['en'],
    'no': ['en'],
    'fi': ['en'],
    'pl': ['en'],
    'cs': ['en'],
    'sk': ['en'],
    'hu': ['en'],
    'ro': ['en'],
    'bg': ['en'],
    'hr': ['en'],
    'sl': ['en'],
    'et': ['en'],
    'lv': ['en'],
    'lt': ['en'],
    'ru': ['en'],
    'uk': ['en'],
    'be': ['en'],
    'mk': ['en'],
    'sr': ['en'],
    'bs': ['en'],
    'me': ['en'],
    'sq': ['en'],
    'el': ['en'],
    'tr': ['en'],
    'ar': ['en'],
    'he': ['en'],
    'fa': ['en'],
    'ur': ['en'],
    'hi': ['en'],
    'bn': ['en'],
    'ta': ['en'],
    'te': ['en'],
    'ml': ['en'],
    'kn': ['en'],
    'gu': ['en'],
    'pa': ['en'],
    'or': ['en'],
    'as': ['en'],
    'ne': ['en'],
    'si': ['en'],
    'my': ['en'],
    'km': ['en'],
    'lo': ['en'],
    'th': ['en'],
    'vi': ['en'],
    'id': ['en'],
    'ms': ['en'],
    'tl': ['en'],
    'zh': ['en'],
    'zh-TW': ['zh', 'en'],
    'ja': ['en'],
    'ko': ['en'],
    'mn': ['en'],
    'kk': ['en'],
    'ky': ['en'],
    'uz': ['en'],
    'tg': ['en'],
    'tk': ['en'],
    'az': ['en'],
    'ka': ['en'],
    'hy': ['en'],
    'am': ['en'],
    'sw': ['en'],
    'zu': ['en'],
    'xh': ['en'],
    'af': ['en'],
};

// i18next configuration
export interface I18nConfig {
    defaultLanguage: SupportedLanguage;
    supportedLanguages: SupportedLanguage[];
    defaultNamespace: TranslationNamespace;
    namespaces: TranslationNamespace[];
    fallbackLanguages: Record<SupportedLanguage, SupportedLanguage[]>;
    backend?: {
        loadPath: string;
        addPath?: string;
        allowMultiLoading?: boolean;
    };
    detection?: {
        order: string[];
        caches: string[];
        lookupQuerystring?: string;
        lookupCookie?: string;
        lookupLocalStorage?: string;
        lookupSessionStorage?: string;
    };
    interpolation?: {
        escapeValue: boolean;
        format?: (value: any, format: string, lng: string) => string;
    };
    debug?: boolean;
}

export const defaultI18nConfig: I18nConfig = {
    defaultLanguage: DEFAULT_LANGUAGE,
    supportedLanguages: Object.keys(LANGUAGE_METADATA) as SupportedLanguage[],
    defaultNamespace: DEFAULT_NAMESPACE,
    namespaces: [
        'common',
        'auth',
        'dashboard',
        'documents',
        'templates',
        'signatures',
        'organizations',
        'users',
        'billing',
        'settings',
        'notifications',
        'errors',
        'validation',
        'emails',
        'legal',
        'help',
        'onboarding',
        'analytics',
        'integrations',
        'api',
        'mobile',
    ],
    fallbackLanguages: FALLBACK_LANGUAGES,
    backend: {
        loadPath: '/locales/{{lng}}/{{ns}}.json',
        allowMultiLoading: false,
    },
    detection: {
        order: ['querystring', 'cookie', 'localStorage', 'sessionStorage', 'navigator', 'htmlTag'],
        caches: ['localStorage', 'cookie'],
        lookupQuerystring: 'lng',
        lookupCookie: 'i18next',
        lookupLocalStorage: 'i18nextLng',
        lookupSessionStorage: 'i18nextLng',
    },
    interpolation: {
        escapeValue: false, // React already escapes values
    },
    debug: process.env.NODE_ENV === 'development',
};

// Initialize i18next
export async function initializeI18n(config: Partial<I18nConfig> = {}): Promise<typeof i18n> {
    const finalConfig = { ...defaultI18nConfig, ...config };

    await i18n
        .use(Backend)
        .use(LanguageDetector)
        .use(ICU)
        .use(initReactI18next)
        .init({
            lng: finalConfig.defaultLanguage,
            fallbackLng: finalConfig.fallbackLanguages,
            supportedLngs: finalConfig.supportedLanguages,

            defaultNS: finalConfig.defaultNamespace,
            ns: finalConfig.namespaces,

            backend: finalConfig.backend,
            detection: finalConfig.detection,
            interpolation: finalConfig.interpolation,

            debug: finalConfig.debug,

            // Additional options
            load: 'languageOnly', // Don't load country-specific variants unless explicitly defined
            cleanCode: true,

            // React-specific options
            react: {
                useSuspense: false, // We'll handle loading states manually
                bindI18n: 'languageChanged loaded',
                bindI18nStore: 'added removed',
                transEmptyNodeValue: '',
                transSupportBasicHtmlNodes: true,
                transKeepBasicHtmlNodesFor: ['br', 'strong', 'i', 'em', 'span'],
            },

            // ICU message format options
            icu: {
                memoize: true,
                memoizeFallback: true,
            },
        });

    return i18n;
}

// Server-side initialization (without browser-specific features)
export async function initializeServerI18n(config: Partial<I18nConfig> = {}): Promise<typeof i18n> {
    const finalConfig = { ...defaultI18nConfig, ...config };

    await i18n
        .use(ICU)
        .init({
            lng: finalConfig.defaultLanguage,
            fallbackLng: finalConfig.fallbackLanguages,
            supportedLngs: finalConfig.supportedLanguages,

            defaultNS: finalConfig.defaultNamespace,
            ns: finalConfig.namespaces,

            interpolation: finalConfig.interpolation,

            debug: finalConfig.debug,

            // Server-specific options
            load: 'languageOnly',
            cleanCode: true,

            // ICU message format options
            icu: {
                memoize: true,
                memoizeFallback: true,
            },

            // Preload resources for server-side rendering
            preload: finalConfig.supportedLanguages,

            // Resources can be loaded synchronously on server
            resources: {}, // Will be populated by the translation loader
        });

    return i18n;
}

export { i18n };
export default i18n;