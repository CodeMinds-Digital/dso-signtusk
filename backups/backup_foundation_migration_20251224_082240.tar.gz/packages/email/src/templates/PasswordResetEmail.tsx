import React from 'react';
import { Layout } from './components/Layout';
import { Button } from './components/Button';
import type { EmailTemplateProps, EmailI18nContext } from '../types';

interface PasswordResetEmailProps extends EmailTemplateProps {
    userName: string;
    resetUrl: string;
    expiresIn: string;
    i18n: EmailI18nContext;
}

export const PasswordResetEmail: React.FC<PasswordResetEmailProps> = ({
    userName,
    resetUrl,
    expiresIn,
    i18n,
    ...layoutProps
}) => {
    return (
        <Layout
            i18n={i18n}
            previewText={i18n.t('auth.resetPassword')}
            {...layoutProps}
        >
            <h1 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#111827',
                marginBottom: '16px'
            }}>
                {i18n.t('auth.resetPassword')}
            </h1>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('common.greeting')} {userName},
            </p>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('auth.resetPasswordMessage')}
            </p>

            <div style={{
                textAlign: 'center',
                marginBottom: '24px'
            }}>
                <Button href={resetUrl}>
                    {i18n.t('auth.resetPasswordButton')}
                </Button>
            </div>

            <div style={{
                backgroundColor: '#fefce8',
                padding: '16px',
                borderRadius: '8px',
                marginBottom: '24px'
            }}>
                <p style={{
                    fontSize: '14px',
                    color: '#92400e'
                }}>
                    <strong>{i18n.t('auth.important')}:</strong> {i18n.t('auth.resetPasswordExpiry', { expiresIn })}
                </p>
            </div>

            <p style={{
                fontSize: '14px',
                color: '#6b7280',
                marginBottom: '16px'
            }}>
                {i18n.t('auth.resetPasswordHelp')}
            </p>

            <p style={{
                fontSize: '14px',
                color: '#6b7280'
            }}>
                {i18n.t('common.regards')},<br />
                {i18n.t('team.signature')}
            </p>
        </Layout>
    );
};