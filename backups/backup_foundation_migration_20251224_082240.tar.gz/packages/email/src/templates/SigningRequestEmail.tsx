import React from 'react';
import { Layout } from './components/Layout';
import { Button } from './components/Button';
import type { EmailTemplateProps, EmailI18nContext } from '../types';

interface SigningRequestEmailProps extends EmailTemplateProps {
    recipientName: string;
    senderName: string;
    documentName: string;
    signingUrl: string;
    dueDate?: string;
    message?: string;
    i18n: EmailI18nContext;
}

export const SigningRequestEmail: React.FC<SigningRequestEmailProps> = ({
    recipientName,
    senderName,
    documentName,
    signingUrl,
    dueDate,
    message,
    i18n,
    ...layoutProps
}) => {
    return (
        <Layout
            i18n={i18n}
            previewText={i18n.t('document.signRequest')}
            {...layoutProps}
        >
            <h1 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#111827',
                marginBottom: '16px'
            }}>
                {i18n.t('document.signRequest')}
            </h1>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('common.greeting')} {recipientName},
            </p>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('document.signRequestMessage', {
                    senderName,
                    documentName
                })}
            </p>

            {message && (
                <div style={{
                    backgroundColor: '#f9fafb',
                    padding: '16px',
                    borderRadius: '8px',
                    marginBottom: '24px'
                }}>
                    <p style={{
                        fontSize: '14px',
                        fontWeight: '500',
                        color: '#1f2937',
                        marginBottom: '8px'
                    }}>
                        {i18n.t('document.personalMessage')}:
                    </p>
                    <p style={{
                        color: '#374151',
                        fontStyle: 'italic'
                    }}>
                        "{message}"
                    </p>
                </div>
            )}

            <div style={{
                backgroundColor: '#eff6ff',
                padding: '16px',
                borderRadius: '8px',
                marginBottom: '24px'
            }}>
                <p style={{
                    fontWeight: '500',
                    color: '#1f2937',
                    marginBottom: '8px'
                }}>
                    {i18n.t('document.details')}:
                </p>
                <p style={{
                    color: '#374151',
                    marginBottom: '4px'
                }}>
                    <strong>{i18n.t('document.name')}:</strong> {documentName}
                </p>
                <p style={{
                    color: '#374151',
                    marginBottom: '4px'
                }}>
                    <strong>{i18n.t('document.from')}:</strong> {senderName}
                </p>
                {dueDate && (
                    <p style={{
                        color: '#374151'
                    }}>
                        <strong>{i18n.t('document.dueDate')}:</strong> {dueDate}
                    </p>
                )}
            </div>

            <div style={{
                textAlign: 'center',
                marginBottom: '24px'
            }}>
                <Button href={signingUrl}>
                    {i18n.t('document.signNow')}
                </Button>
            </div>

            <p style={{
                fontSize: '14px',
                color: '#6b7280',
                marginBottom: '16px'
            }}>
                {i18n.t('document.signInstructions')}
            </p>

            <p style={{
                fontSize: '14px',
                color: '#6b7280'
            }}>
                {i18n.t('common.regards')},<br />
                {i18n.t('team.signature')}
            </p>
        </Layout>
    );
};