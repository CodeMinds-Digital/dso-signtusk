import React from 'react';
import type { EmailI18nContext } from '../../types';

interface LayoutProps {
    children: React.ReactNode;
    i18n: EmailI18nContext;
    previewText?: string;
    logoUrl?: string;
    companyName?: string;
    supportEmail?: string;
    unsubscribeUrl?: string;
}

export const Layout: React.FC<LayoutProps> = ({
    children,
    i18n,
    previewText,
    logoUrl = 'https://your-domain.com/logo.png',
    companyName = 'DocuSign Alternative',
    supportEmail = 'support@your-domain.com',
    unsubscribeUrl,
}) => {
    return (
        <html>
            <head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <title>{previewText || 'Email'}</title>
            </head>
            <body style={{
                fontFamily: 'Arial, sans-serif',
                backgroundColor: '#f9fafb',
                margin: 0,
                padding: 0
            }}>
                {previewText && (
                    <div style={{ display: 'none', overflow: 'hidden', lineHeight: '1px', opacity: 0 }}>
                        {previewText}
                    </div>
                )}

                <div style={{
                    maxWidth: '600px',
                    margin: '0 auto',
                    padding: '32px 16px'
                }}>
                    {/* Header */}
                    <div style={{
                        backgroundColor: 'white',
                        borderTopLeftRadius: '8px',
                        borderTopRightRadius: '8px',
                        padding: '24px',
                        borderBottom: '1px solid #e5e7eb'
                    }}>
                        <img
                            src={logoUrl}
                            alt={companyName}
                            style={{ height: '32px', marginBottom: '16px' }}
                        />
                    </div>

                    {/* Main Content */}
                    <div style={{
                        backgroundColor: 'white',
                        padding: '24px'
                    }}>
                        {children}
                    </div>

                    {/* Footer */}
                    <div style={{
                        backgroundColor: '#f3f4f6',
                        borderBottomLeftRadius: '8px',
                        borderBottomRightRadius: '8px',
                        padding: '24px',
                        textAlign: 'center'
                    }}>
                        <p style={{
                            fontSize: '14px',
                            color: '#4b5563',
                            marginBottom: '16px'
                        }}>
                            {i18n.t('common.thanks')} - {companyName}
                        </p>

                        <hr style={{
                            margin: '16px 0',
                            border: 'none',
                            borderTop: '1px solid #d1d5db'
                        }} />

                        <p style={{
                            fontSize: '12px',
                            color: '#6b7280',
                            marginBottom: '8px'
                        }}>
                            {i18n.t('footer.questions').replace('{{supportEmail}}', supportEmail)}
                        </p>

                        {unsubscribeUrl && (
                            <p style={{
                                fontSize: '12px',
                                color: '#6b7280'
                            }}>
                                <a href={unsubscribeUrl} style={{
                                    color: '#6b7280',
                                    textDecoration: 'underline'
                                }}>
                                    {i18n.t('footer.unsubscribe')}
                                </a>
                            </p>
                        )}
                    </div>
                </div>
            </body>
        </html>
    );
};