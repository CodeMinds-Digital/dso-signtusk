import { z } from 'zod';

// Email provider types
export type EmailProvider = 'resend' | 'sendgrid' | 'smtp';

// Email configuration schemas
export const EmailConfigSchema = z.object({
    provider: z.enum(['resend', 'sendgrid', 'smtp']),
    from: z.string().email(),
    replyTo: z.string().email().optional(),
});

export const ResendConfigSchema = EmailConfigSchema.extend({
    provider: z.literal('resend'),
    apiKey: z.string(),
});

export const SendGridConfigSchema = EmailConfigSchema.extend({
    provider: z.literal('sendgrid'),
    apiKey: z.string(),
});

export const SMTPConfigSchema = EmailConfigSchema.extend({
    provider: z.literal('smtp'),
    host: z.string(),
    port: z.number(),
    secure: z.boolean().default(true),
    auth: z.object({
        user: z.string(),
        pass: z.string(),
    }),
});

export type EmailConfig = z.infer<typeof EmailConfigSchema>;
export type ResendConfig = z.infer<typeof ResendConfigSchema>;
export type SendGridConfig = z.infer<typeof SendGridConfigSchema>;
export type SMTPConfig = z.infer<typeof SMTPConfigSchema>;

// Email message types
export const EmailAttachmentSchema = z.object({
    filename: z.string(),
    content: z.union([z.string(), z.instanceof(Buffer)]),
    contentType: z.string().optional(),
    encoding: z.string().optional(),
});

export const EmailMessageSchema = z.object({
    to: z.union([z.string().email(), z.array(z.string().email())]),
    cc: z.union([z.string().email(), z.array(z.string().email())]).optional(),
    bcc: z.union([z.string().email(), z.array(z.string().email())]).optional(),
    subject: z.string(),
    html: z.string(),
    text: z.string().optional(),
    attachments: z.array(EmailAttachmentSchema).optional(),
    headers: z.record(z.string()).optional(),
    tags: z.array(z.string()).optional(),
    metadata: z.record(z.any()).optional(),
});

export type EmailAttachment = z.infer<typeof EmailAttachmentSchema>;
export type EmailMessage = z.infer<typeof EmailMessageSchema>;

// Email template types
export interface EmailTemplateProps {
    [key: string]: any;
}

export interface EmailTemplate {
    name: string;
    subject: string;
    component: React.ComponentType<any>;
    defaultProps?: EmailTemplateProps;
    description?: string;
    category?: string;
}

// Email delivery result
export interface EmailDeliveryResult {
    success: boolean;
    messageId?: string;
    error?: string;
    provider: EmailProvider;
    timestamp: Date;
}

// Email service interface
export interface EmailService {
    send(message: EmailMessage): Promise<EmailDeliveryResult>;
    sendTemplate(
        templateName: string,
        to: string | string[],
        props: EmailTemplateProps,
        options?: Partial<EmailMessage>
    ): Promise<EmailDeliveryResult>;
    renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{ html: string; text?: string; subject: string }>;
    validateConfig(): Promise<boolean>;
    getProvider(): EmailProvider;
}

// Internationalization types
export type SupportedLocale = 'en' | 'es' | 'fr' | 'de' | 'it' | 'pt' | 'ja' | 'ko' | 'zh';

export interface LocalizedContent {
    [key: string]: {
        [locale in SupportedLocale]?: string;
    };
}

export interface EmailI18nContext {
    locale: SupportedLocale;
    t: (key: string, params?: Record<string, any>) => string;
}

// Email analytics and tracking
export interface EmailAnalytics {
    sent: number;
    delivered: number;
    opened: number;
    clicked: number;
    bounced: number;
    complained: number;
    unsubscribed: number;
}

export interface EmailEvent {
    type: 'sent' | 'delivered' | 'opened' | 'clicked' | 'bounced' | 'complained' | 'unsubscribed';
    messageId: string;
    email: string;
    timestamp: Date;
    metadata?: Record<string, any>;
}