import { Resend } from 'resend';
import { pino } from 'pino';
import type {
    EmailService,
    EmailMessage,
    EmailDeliveryResult,
    EmailTemplateProps,
    ResendConfig,
} from '../types';
import { EmailTemplateRegistry } from '../templates/registry';

const logger = pino({ name: 'email-resend' });

export class ResendEmailService implements EmailService {
    private client: Resend;
    private config: ResendConfig;
    private templateRegistry: EmailTemplateRegistry;

    constructor(config: ResendConfig, templateRegistry: EmailTemplateRegistry) {
        this.config = config;
        this.client = new Resend(config.apiKey);
        this.templateRegistry = templateRegistry;
    }

    async send(message: EmailMessage): Promise<EmailDeliveryResult> {
        try {
            logger.info({ to: message.to, subject: message.subject }, 'Sending email via Resend');

            const result = await this.client.emails.send({
                from: this.config.from,
                to: Array.isArray(message.to) ? message.to : [message.to],
                cc: message.cc ? (Array.isArray(message.cc) ? message.cc : [message.cc]) : undefined,
                bcc: message.bcc ? (Array.isArray(message.bcc) ? message.bcc : [message.bcc]) : undefined,
                subject: message.subject,
                html: message.html,
                text: message.text,
                reply_to: this.config.replyTo,
                attachments: message.attachments?.map(att => ({
                    filename: att.filename,
                    content: att.content,
                    content_type: att.contentType,
                })),
                headers: message.headers,
                tags: message.tags?.map(tag => ({ name: 'category', value: tag })),
            });

            if (result.error) {
                logger.error({ error: result.error }, 'Failed to send email via Resend');
                return {
                    success: false,
                    error: result.error.message,
                    provider: 'resend',
                    timestamp: new Date(),
                };
            }

            logger.info({ messageId: result.data?.id }, 'Email sent successfully via Resend');
            return {
                success: true,
                messageId: result.data?.id,
                provider: 'resend',
                timestamp: new Date(),
            };
        } catch (error) {
            logger.error({ error }, 'Error sending email via Resend');
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error',
                provider: 'resend',
                timestamp: new Date(),
            };
        }
    }

    async sendTemplate(
        templateName: string,
        to: string | string[],
        props: EmailTemplateProps,
        options?: Partial<EmailMessage>
    ): Promise<EmailDeliveryResult> {
        try {
            const rendered = await this.renderTemplate(templateName, props);

            const message: EmailMessage = {
                to,
                subject: rendered.subject,
                html: rendered.html,
                text: rendered.text,
                ...options,
            };

            return await this.send(message);
        } catch (error) {
            logger.error({ error, templateName }, 'Error sending template email via Resend');
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Template rendering failed',
                provider: 'resend',
                timestamp: new Date(),
            };
        }
    }

    async renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{ html: string; text?: string; subject: string }> {
        return await this.templateRegistry.render(templateName, props);
    }

    async validateConfig(): Promise<boolean> {
        try {
            // Test the API key by making a simple request
            const result = await this.client.domains.list();
            return !result.error;
        } catch (error) {
            logger.error({ error }, 'Resend configuration validation failed');
            return false;
        }
    }

    getProvider(): 'resend' {
        return 'resend';
    }
}