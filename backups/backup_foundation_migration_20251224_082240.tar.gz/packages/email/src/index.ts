// Main exports
export { EmailServiceFactory, createEmailServiceFromEnv } from './service';
export { EmailTemplateRegistry } from './templates/registry';
export { EmailI18n, defaultI18n, detectLocale } from './i18n';
export { MockEmailService, EmailPreviewService } from './testing';

// Provider exports
export { ResendEmailService } from './providers/resend';
export { SendGridEmailService } from './providers/sendgrid';
export { SMTPEmailService } from './providers/smtp';

// Template exports
export { WelcomeEmail } from './templates/WelcomeEmail';
export { SigningRequestEmail } from './templates/SigningRequestEmail';
export { DocumentCompletedEmail } from './templates/DocumentCompletedEmail';
export { PasswordResetEmail } from './templates/PasswordResetEmail';
export { SigningReminderEmail } from './templates/SigningReminderEmail';
export { EscalationNotificationEmail } from './templates/EscalationNotificationEmail';
export { Layout } from './templates/components/Layout';
export { Button } from './templates/components/Button';

// Type exports
export type {
    EmailProvider,
    EmailConfig,
    ResendConfig,
    SendGridConfig,
    SMTPConfig,
    EmailMessage,
    EmailAttachment,
    EmailTemplate,
    EmailTemplateProps,
    EmailService,
    EmailDeliveryResult,
    SupportedLocale,
    LocalizedContent,
    EmailI18nContext,
    EmailAnalytics,
    EmailEvent,
} from './types';

// Schema exports for validation
export {
    EmailConfigSchema,
    ResendConfigSchema,
    SendGridConfigSchema,
    SMTPConfigSchema,
    EmailMessageSchema,
    EmailAttachmentSchema,
} from './types';