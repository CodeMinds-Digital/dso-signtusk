# `@documenso/pdf-sign-darwin-arm64`

This is the **aarch64-apple-darwin** binary for `@documenso/pdf-sign`
