module.exports = {
    presets: ['@react-native/babel-preset'],
    plugins: [
        'react-native-reanimated/plugin',
        [
            'module-resolver',
            {
                root: ['./src'],
                alias: {
                    '@': './src',
                    '@docusign-alternative/lib': '../../packages/lib/src',
                    '@docusign-alternative/ui': '../../packages/ui/src',
                    '@docusign-alternative/auth': '../../packages/auth/src',
                    '@docusign-alternative/api': '../../packages/api/src',
                    '@docusign-alternative/trpc': '../../packages/trpc/src',
                },
            },
        ],
    ],
};