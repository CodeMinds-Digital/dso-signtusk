import '@testing-library/jest-dom';
import { vi } from 'vitest';

// Mock React Native modules
vi.mock('react-native', () => ({
    Platform: {
        OS: 'ios',
    },
    Dimensions: {
        get: () => ({
            width: 375,
            height: 812,
        }),
    },
    StatusBar: {
        currentHeight: 0,
    },
    Alert: {
        alert: vi.fn(),
    },
    AppRegistry: {
        registerComponent: vi.fn(),
    },
}));

// Mock navigation
vi.mock('@react-navigation/native', () => ({
    NavigationContainer: ({ children }: any) => children,
    useNavigation: () => ({
        navigate: vi.fn(),
        goBack: vi.fn(),
    }),
    useRoute: () => ({
        params: {},
    }),
}));

// Mock async storage
vi.mock('@react-native-async-storage/async-storage', () => ({
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
}));

// Mock keychain
vi.mock('react-native-keychain', () => ({
    setInternetCredentials: vi.fn(),
    getInternetCredentials: vi.fn(),
    resetInternetCredentials: vi.fn(),
    getSupportedBiometryType: vi.fn(),
    ACCESS_CONTROL: {
        BIOMETRY_ANY: 'BiometryAny',
    },
    AUTHENTICATION_TYPE: {
        DEVICE_PASSCODE_OR_BIOMETRICS: 'DevicePasscodeOrBiometrics',
    },
}));

// Mock NetInfo
vi.mock('@react-native-community/netinfo', () => ({
    addEventListener: vi.fn(),
    fetch: vi.fn(() => Promise.resolve({
        isConnected: true,
        isInternetReachable: true,
    })),
}));

// Mock push notifications
vi.mock('react-native-push-notification', () => ({
    configure: vi.fn(),
    localNotification: vi.fn(),
    cancelAllLocalNotifications: vi.fn(),
    createChannel: vi.fn(),
}));

// Mock vector icons
vi.mock('react-native-vector-icons/MaterialIcons', () => 'Icon');