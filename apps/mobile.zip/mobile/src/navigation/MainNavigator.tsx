import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { DashboardScreen } from '../screens/main/DashboardScreen';
import { DocumentsScreen } from '../screens/main/DocumentsScreen';
import { SigningScreen } from '../screens/main/SigningScreen';
import { ProfileScreen } from '../screens/main/ProfileScreen';
import { DocumentViewerScreen } from '../screens/document/DocumentViewerScreen';
import { SigningFlowScreen } from '../screens/signing/SigningFlowScreen';
import { CameraCaptureScreen } from '../screens/camera/CameraCaptureScreen';
import { SettingsScreen } from '../screens/settings/SettingsScreen';
import { NotificationsScreen } from '../screens/notifications/NotificationsScreen';

export type MainTabParamList = {
    Dashboard: undefined;
    Documents: undefined;
    Signing: undefined;
    Profile: undefined;
};

export type MainStackParamList = {
    MainTabs: undefined;
    DocumentViewer: { documentId: string };
    SigningFlow: { documentId: string; recipientId: string };
    CameraCapture: { type: 'signature' | 'document' };
    Settings: undefined;
    Notifications: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();
const Stack = createStackNavigator<MainStackParamList>();

const MainTabs: React.FC = () => {
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName: string;

                    switch (route.name) {
                        case 'Dashboard':
                            iconName = 'dashboard';
                            break;
                        case 'Documents':
                            iconName = 'folder';
                            break;
                        case 'Signing':
                            iconName = 'edit';
                            break;
                        case 'Profile':
                            iconName = 'person';
                            break;
                        default:
                            iconName = 'help';
                    }

                    return <Icon name={iconName} size={size} color={color} />;
                },
                tabBarActiveTintColor: '#007AFF',
                tabBarInactiveTintColor: '#8E8E93',
                headerShown: false,
            })}>
            <Tab.Screen name="Dashboard" component={DashboardScreen} />
            <Tab.Screen name="Documents" component={DocumentsScreen} />
            <Tab.Screen name="Signing" component={SigningScreen} />
            <Tab.Screen name="Profile" component={ProfileScreen} />
        </Tab.Navigator>
    );
};

export const MainNavigator: React.FC = () => {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="MainTabs" component={MainTabs} />
            <Stack.Screen
                name="DocumentViewer"
                component={DocumentViewerScreen}
                options={{ headerShown: true, title: 'Document' }}
            />
            <Stack.Screen
                name="SigningFlow"
                component={SigningFlowScreen}
                options={{ headerShown: true, title: 'Sign Document' }}
            />
            <Stack.Screen
                name="CameraCapture"
                component={CameraCaptureScreen}
                options={{ headerShown: true, title: 'Capture' }}
            />
            <Stack.Screen
                name="Settings"
                component={SettingsScreen}
                options={{ headerShown: true, title: 'Settings' }}
            />
            <Stack.Screen
                name="Notifications"
                component={NotificationsScreen}
                options={{ headerShown: true, title: 'Notifications' }}
            />
        </Stack.Navigator>
    );
};