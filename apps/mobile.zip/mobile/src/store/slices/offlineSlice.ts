import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface OfflineAction {
    id: string;
    type: 'upload' | 'sign' | 'update' | 'delete';
    data: any;
    timestamp: number;
    retryCount: number;
}

interface OfflineState {
    isOnline: boolean;
    pendingActions: OfflineAction[];
    syncInProgress: boolean;
    lastSyncTime: number | null;
    offlineDocuments: string[];
}

const initialState: OfflineState = {
    isOnline: true,
    pendingActions: [],
    syncInProgress: false,
    lastSyncTime: null,
    offlineDocuments: [],
};

const offlineSlice = createSlice({
    name: 'offline',
    initialState,
    reducers: {
        setOnlineStatus: (state, action: PayloadAction<boolean>) => {
            state.isOnline = action.payload;
        },
        addPendingAction: (state, action: PayloadAction<Omit<OfflineAction, 'id' | 'timestamp' | 'retryCount'>>) => {
            const newAction: OfflineAction = {
                ...action.payload,
                id: Date.now().toString(),
                timestamp: Date.now(),
                retryCount: 0,
            };
            state.pendingActions.push(newAction);
        },
        removePendingAction: (state, action: PayloadAction<string>) => {
            state.pendingActions = state.pendingActions.filter(action => action.id !== action.payload);
        },
        incrementRetryCount: (state, action: PayloadAction<string>) => {
            const actionIndex = state.pendingActions.findIndex(a => a.id === action.payload);
            if (actionIndex !== -1) {
                state.pendingActions[actionIndex].retryCount += 1;
            }
        },
        setSyncInProgress: (state, action: PayloadAction<boolean>) => {
            state.syncInProgress = action.payload;
        },
        setLastSyncTime: (state, action: PayloadAction<number>) => {
            state.lastSyncTime = action.payload;
        },
        addOfflineDocument: (state, action: PayloadAction<string>) => {
            if (!state.offlineDocuments.includes(action.payload)) {
                state.offlineDocuments.push(action.payload);
            }
        },
        removeOfflineDocument: (state, action: PayloadAction<string>) => {
            state.offlineDocuments = state.offlineDocuments.filter(id => id !== action.payload);
        },
        clearPendingActions: (state) => {
            state.pendingActions = [];
        },
    },
});

export const {
    setOnlineStatus,
    addPendingAction,
    removePendingAction,
    incrementRetryCount,
    setSyncInProgress,
    setLastSyncTime,
    addOfflineDocument,
    removeOfflineDocument,
    clearPendingActions,
} = offlineSlice.actions;

export default offlineSlice.reducer;