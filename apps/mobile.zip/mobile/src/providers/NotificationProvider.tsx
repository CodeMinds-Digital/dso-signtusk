import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { Platform, PermissionsAndroid } from 'react-native';
import PushNotification from 'react-native-push-notification';
import { useSelector } from 'react-redux';
import { RootState } from '../store';

interface NotificationContextType {
    requestPermissions: () => Promise<boolean>;
    scheduleLocalNotification: (title: string, message: string, date?: Date) => void;
    cancelAllNotifications: () => void;
    registerForPushNotifications: () => Promise<string | null>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

interface NotificationProviderProps {
    children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
    const { notifications } = useSelector((state: RootState) => state.settings);

    useEffect(() => {
        initializeNotifications();
    }, []);

    const initializeNotifications = () => {
        PushNotification.configure({
            onRegister: function (token) {
                console.log('Push notification token:', token);
                // Send token to server
            },

            onNotification: function (notification) {
                console.log('Notification received:', notification);

                // Handle notification tap
                if (notification.userInteraction) {
                    // Navigate to appropriate screen based on notification data
                    handleNotificationTap(notification);
                }
            },

            onAction: function (notification) {
                console.log('Notification action:', notification.action);
            },

            onRegistrationError: function (err) {
                console.error('Push notification registration error:', err);
            },

            permissions: {
                alert: true,
                badge: true,
                sound: true,
            },

            popInitialNotification: true,
            requestPermissions: Platform.OS === 'ios',
        });

        // Create notification channels for Android
        if (Platform.OS === 'android') {
            PushNotification.createChannel(
                {
                    channelId: 'document-updates',
                    channelName: 'Document Updates',
                    channelDescription: 'Notifications for document status changes',
                    playSound: true,
                    soundName: 'default',
                    importance: 4,
                    vibrate: true,
                },
                (created) => console.log(`Channel created: ${created}`)
            );

            PushNotification.createChannel(
                {
                    channelId: 'signing-reminders',
                    channelName: 'Signing Reminders',
                    channelDescription: 'Reminders to sign pending documents',
                    playSound: true,
                    soundName: 'default',
                    importance: 4,
                    vibrate: true,
                },
                (created) => console.log(`Channel created: ${created}`)
            );
        }
    };

    const handleNotificationTap = (notification: any) => {
        // Handle deep linking based on notification data
        if (notification.data) {
            const { type, documentId, recipientId } = notification.data;

            switch (type) {
                case 'document_ready':
                    // Navigate to document viewer
                    break;
                case 'signing_reminder':
                    // Navigate to signing flow
                    break;
                case 'document_completed':
                    // Navigate to completed documents
                    break;
            }
        }
    };

    const requestPermissions = async (): Promise<boolean> => {
        if (Platform.OS === 'android') {
            try {
                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
                );
                return granted === PermissionsAndroid.RESULTS.GRANTED;
            } catch (error) {
                console.error('Permission request error:', error);
                return false;
            }
        }

        // iOS permissions are handled automatically by react-native-push-notification
        return true;
    };

    const scheduleLocalNotification = (title: string, message: string, date?: Date) => {
        if (!notifications.pushEnabled) {
            return;
        }

        PushNotification.localNotification({
            title,
            message,
            date,
            playSound: true,
            soundName: 'default',
            channelId: 'document-updates',
        });
    };

    const cancelAllNotifications = () => {
        PushNotification.cancelAllLocalNotifications();
    };

    const registerForPushNotifications = async (): Promise<string | null> => {
        return new Promise((resolve) => {
            PushNotification.configure({
                onRegister: function (token) {
                    resolve(token.token);
                },
                onRegistrationError: function (err) {
                    console.error('Push registration error:', err);
                    resolve(null);
                },
            });
        });
    };

    const contextValue: NotificationContextType = {
        requestPermissions,
        scheduleLocalNotification,
        cancelAllNotifications,
        registerForPushNotifications,
    };

    return (
        <NotificationContext.Provider value={contextValue}>
            {children}
        </NotificationContext.Provider>
    );
};

export const useNotifications = (): NotificationContextType => {
    const context = useContext(NotificationContext);
    if (!context) {
        throw new Error('useNotifications must be used within a NotificationProvider');
    }
    return context;
};