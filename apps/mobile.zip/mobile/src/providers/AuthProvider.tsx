import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Keychain from 'react-native-keychain';
import { RootState } from '../store';
import { loginSuccess, logout, setLoading, setBiometricEnabled } from '../store/slices/authSlice';
import { trpc } from '../utils/trpc';

interface AuthContextType {
    login: (email: string, password: string) => Promise<void>;
    loginWithBiometric: () => Promise<void>;
    logoutUser: () => Promise<void>;
    refreshToken: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
    children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
    const dispatch = useDispatch();
    const { token, biometricEnabled } = useSelector((state: RootState) => state.auth);
    const loginMutation = trpc.auth.login.useMutation();
    const refreshMutation = trpc.auth.refresh.useMutation();

    useEffect(() => {
        initializeAuth();
    }, []);

    const initializeAuth = async () => {
        try {
            dispatch(setLoading(true));

            // Check for stored token
            const storedToken = await AsyncStorage.getItem('auth_token');
            if (storedToken) {
                // Validate token with server
                try {
                    const result = await refreshMutation.mutateAsync({ token: storedToken });
                    dispatch(loginSuccess({
                        user: result.user,
                        token: result.token,
                    }));
                } catch (error) {
                    // Token invalid, clear storage
                    await AsyncStorage.removeItem('auth_token');
                    await Keychain.resetInternetCredentials('docusign_alternative');
                }
            }

            // Check biometric availability
            const biometricType = await Keychain.getSupportedBiometryType();
            if (biometricType) {
                dispatch(setBiometricEnabled(true));
            }
        } catch (error) {
            console.error('Auth initialization error:', error);
        } finally {
            dispatch(setLoading(false));
        }
    };

    const login = async (email: string, password: string) => {
        try {
            dispatch(setLoading(true));

            const result = await loginMutation.mutateAsync({ email, password });

            // Store token
            await AsyncStorage.setItem('auth_token', result.token);

            // Store credentials for biometric login if enabled
            if (biometricEnabled) {
                await Keychain.setInternetCredentials(
                    'docusign_alternative',
                    email,
                    password,
                    {
                        accessControl: Keychain.ACCESS_CONTROL.BIOMETRY_ANY,
                        authenticationType: Keychain.AUTHENTICATION_TYPE.DEVICE_PASSCODE_OR_BIOMETRICS,
                    }
                );
            }

            dispatch(loginSuccess({
                user: result.user,
                token: result.token,
            }));
        } catch (error) {
            throw error;
        } finally {
            dispatch(setLoading(false));
        }
    };

    const loginWithBiometric = async () => {
        try {
            dispatch(setLoading(true));

            const credentials = await Keychain.getInternetCredentials('docusign_alternative');
            if (credentials && credentials.username && credentials.password) {
                await login(credentials.username, credentials.password);
            } else {
                throw new Error('No biometric credentials found');
            }
        } catch (error) {
            throw error;
        } finally {
            dispatch(setLoading(false));
        }
    };

    const logoutUser = async () => {
        try {
            // Clear stored data
            await AsyncStorage.removeItem('auth_token');
            await Keychain.resetInternetCredentials('docusign_alternative');

            dispatch(logout());
        } catch (error) {
            console.error('Logout error:', error);
        }
    };

    const refreshToken = async () => {
        if (!token) return;

        try {
            const result = await refreshMutation.mutateAsync({ token });
            await AsyncStorage.setItem('auth_token', result.token);

            dispatch(loginSuccess({
                user: result.user,
                token: result.token,
            }));
        } catch (error) {
            // Token refresh failed, logout user
            await logoutUser();
        }
    };

    const contextValue: AuthContextType = {
        login,
        loginWithBiometric,
        logoutUser,
        refreshToken,
    };

    return (
        <AuthContext.Provider value={contextValue}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};