import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch } from 'react-redux';
import { setBiometricEnabled } from '../../store/slices/authSlice';

export const BiometricSetupScreen: React.FC = () => {
    const dispatch = useDispatch();

    const handleEnableBiometric = () => {
        dispatch(setBiometricEnabled(true));
        // Navigate to main app
    };

    const handleSkip = () => {
        // Navigate to main app without enabling biometric
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Enable Biometric Login</Text>
            <Text style={styles.subtitle}>
                Use your fingerprint or face to quickly and securely access your account
            </Text>

            <TouchableOpacity style={styles.button} onPress={handleEnableBiometric}>
                <Text style={styles.buttonText}>Enable Biometric Login</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
                <Text style={styles.skipButtonText}>Skip for now</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: 24,
        backgroundColor: '#ffffff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#333333',
        textAlign: 'center',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 16,
        color: '#666666',
        textAlign: 'center',
        marginBottom: 48,
        lineHeight: 24,
    },
    button: {
        backgroundColor: '#007AFF',
        borderRadius: 8,
        paddingVertical: 16,
        marginBottom: 16,
    },
    buttonText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '600',
        textAlign: 'center',
    },
    skipButton: {
        paddingVertical: 16,
    },
    skipButtonText: {
        color: '#666666',
        fontSize: 16,
        textAlign: 'center',
    },
});