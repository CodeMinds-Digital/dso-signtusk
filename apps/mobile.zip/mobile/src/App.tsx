import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { QueryClient, QueryClientProvider } from 'react-query';
import { trpc } from './utils/trpc';
import { store, persistor } from './store';
import { AppNavigator } from './navigation/AppNavigator';
import { AuthProvider } from './providers/AuthProvider';
import { OfflineProvider } from './providers/OfflineProvider';
import { NotificationProvider } from './providers/NotificationProvider';
import { LoadingScreen } from './components/LoadingScreen';
import { ErrorBoundary } from './components/ErrorBoundary';

const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            retry: 3,
            staleTime: 5 * 60 * 1000, // 5 minutes
            cacheTime: 10 * 60 * 1000, // 10 minutes
        },
    },
});

const trpcClient = trpc.createClient({
    url: process.env.REACT_NATIVE_API_URL || 'http://localhost:3002/trpc',
});

const App: React.FC = () => {
    return (
        <ErrorBoundary>
            <GestureHandlerRootView style={{ flex: 1 }}>
                <SafeAreaProvider>
                    <Provider store={store}>
                        <PersistGate loading={<LoadingScreen />} persistor={persistor}>
                            <trpc.Provider client={trpcClient} queryClient={queryClient}>
                                <QueryClientProvider client={queryClient}>
                                    <AuthProvider>
                                        <OfflineProvider>
                                            <NotificationProvider>
                                                <NavigationContainer>
                                                    <StatusBar
                                                        barStyle="dark-content"
                                                        backgroundColor="transparent"
                                                        translucent
                                                    />
                                                    <AppNavigator />
                                                </NavigationContainer>
                                            </NotificationProvider>
                                        </OfflineProvider>
                                    </AuthProvider>
                                </QueryClientProvider>
                            </trpc.Provider>
                        </PersistGate>
                    </Provider>
                </SafeAreaProvider>
            </GestureHandlerRootView>
        </ErrorBoundary>
    );
};

export default App;