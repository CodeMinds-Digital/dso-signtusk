const { getDefaultConfig, mergeConfig } = require('@react-native/metro-config');
const path = require('path');

const config = {
    watchFolders: [
        path.resolve(__dirname, '../../packages'),
    ],
    resolver: {
        alias: {
            '@docusign-alternative/lib': path.resolve(__dirname, '../../packages/lib/src'),
            '@docusign-alternative/ui': path.resolve(__dirname, '../../packages/ui/src'),
            '@docusign-alternative/auth': path.resolve(__dirname, '../../packages/auth/src'),
            '@docusign-alternative/api': path.resolve(__dirname, '../../packages/api/src'),
            '@docusign-alternative/trpc': path.resolve(__dirname, '../../packages/trpc/src'),
        },
        nodeModulesPaths: [
            path.resolve(__dirname, 'node_modules'),
            path.resolve(__dirname, '../../node_modules'),
        ],
    },
    transformer: {
        getTransformOptions: async () => ({
            transform: {
                experimentalImportSupport: false,
                inlineRequires: true,
            },
        }),
    },
};

module.exports = mergeConfig(getDefaultConfig(__dirname), config);