/**
 * @type {import('@types/eslint').Linter.BaseConfig}
 */
module.exports = {
    extends: [
        "@remix-run/eslint-config",
        "@remix-run/eslint-config/node",
        "../../packages/eslint-config"
    ],
    parserOptions: {
        project: './tsconfig.json',
        tsconfigRootDir: __dirname,
    },
};