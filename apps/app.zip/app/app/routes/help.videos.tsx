import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useSearchParams } from "@remix-run/react";
import { useState, useEffect } from "react";
import { VideoTutorialGallery } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Video Tutorials - DocuSign Alternative" },
        { name: "description", content: "Learn with our comprehensive video tutorials and guides" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    return json({});
}

// Mock video data - in a real implementation, this would come from your API
const mockVideos = [
    {
        id: '1',
        title: 'Getting Started with Document Signing',
        description: 'Learn the basics of uploading, preparing, and sending documents for signature in this comprehensive tutorial.',
        thumbnail: '/api/placeholder/320/180',
        videoUrl: 'https://example.com/video1.mp4',
        duration: 480, // 8 minutes
        views: 1250,
        rating: 4.8,
        ratingCount: 45,
        category: 'getting-started',
        tags: ['basics', 'documents', 'signing'],
        difficulty: 'beginner' as const,
        publishedAt: new Date('2024-01-15'),
        updatedAt: new Date('2024-01-15'),
        instructor: {
            name: 'Sarah Johnson',
            avatar: '/api/placeholder/40/40',
            title: 'Product Specialist',
        },
        chapters: [
            { id: '1', title: 'Introduction', startTime: 0, duration: 60 },
            { id: '2', title: 'Uploading Documents', startTime: 60, duration: 120 },
            { id: '3', title: 'Adding Fields', startTime: 180, duration: 180 },
            { id: '4', title: 'Sending for Signature', startTime: 360, duration: 120 },
        ],
        relatedVideos: ['2', '3'],
        transcript: 'Welcome to this tutorial on getting started with document signing...',
    },
    {
        id: '2',
        title: 'Advanced Field Placement Techniques',
        description: 'Master the art of precise field placement with advanced techniques and best practices.',
        thumbnail: '/api/placeholder/320/180',
        videoUrl: 'https://example.com/video2.mp4',
        duration: 720, // 12 minutes
        views: 890,
        rating: 4.9,
        ratingCount: 32,
        category: 'documents',
        tags: ['fields', 'advanced', 'placement'],
        difficulty: 'advanced' as const,
        publishedAt: new Date('2024-01-10'),
        updatedAt: new Date('2024-01-10'),
        instructor: {
            name: 'Mike Chen',
            avatar: '/api/placeholder/40/40',
            title: 'Senior Developer',
        },
        chapters: [
            { id: '1', title: 'Field Types Overview', startTime: 0, duration: 180 },
            { id: '2', title: 'Precision Placement', startTime: 180, duration: 240 },
            { id: '3', title: 'Conditional Logic', startTime: 420, duration: 300 },
        ],
        relatedVideos: ['1', '4'],
    },
    {
        id: '3',
        title: 'Creating Reusable Templates',
        description: 'Learn how to create and manage templates to streamline your document workflows.',
        thumbnail: '/api/placeholder/320/180',
        videoUrl: 'https://example.com/video3.mp4',
        duration: 600, // 10 minutes
        views: 650,
        rating: 4.6,
        ratingCount: 28,
        category: 'templates',
        tags: ['templates', 'workflow', 'efficiency'],
        difficulty: 'intermediate' as const,
        publishedAt: new Date('2024-01-08'),
        updatedAt: new Date('2024-01-08'),
        instructor: {
            name: 'Lisa Rodriguez',
            avatar: '/api/placeholder/40/40',
            title: 'UX Designer',
        },
        chapters: [
            { id: '1', title: 'Template Basics', startTime: 0, duration: 120 },
            { id: '2', title: 'Creating Templates', startTime: 120, duration: 300 },
            { id: '3', title: 'Sharing Templates', startTime: 420, duration: 180 },
        ],
        relatedVideos: ['1', '2'],
    },
    {
        id: '4',
        title: 'API Integration Walkthrough',
        description: 'Complete guide to integrating our API into your applications with code examples.',
        thumbnail: '/api/placeholder/320/180',
        videoUrl: 'https://example.com/video4.mp4',
        duration: 900, // 15 minutes
        views: 420,
        rating: 4.9,
        ratingCount: 18,
        category: 'api',
        tags: ['api', 'integration', 'development'],
        difficulty: 'advanced' as const,
        publishedAt: new Date('2024-01-12'),
        updatedAt: new Date('2024-01-12'),
        instructor: {
            name: 'Alex Thompson',
            avatar: '/api/placeholder/40/40',
            title: 'Lead Developer',
        },
        chapters: [
            { id: '1', title: 'API Overview', startTime: 0, duration: 180 },
            { id: '2', title: 'Authentication', startTime: 180, duration: 240 },
            { id: '3', title: 'Document Operations', startTime: 420, duration: 300 },
            { id: '4', title: 'Webhooks', startTime: 720, duration: 180 },
        ],
        relatedVideos: ['2'],
    },
];

const mockCategories = [
    {
        id: 'getting-started',
        name: 'Getting Started',
        description: 'Essential tutorials for new users',
        videoCount: 8,
        icon: 'play-circle',
    },
    {
        id: 'documents',
        name: 'Document Management',
        description: 'Learn document handling and processing',
        videoCount: 12,
        icon: 'file-text',
    },
    {
        id: 'templates',
        name: 'Templates',
        description: 'Create and manage reusable templates',
        videoCount: 7,
        icon: 'copy',
    },
    {
        id: 'api',
        name: 'API & Integration',
        description: 'Developer resources and guides',
        videoCount: 9,
        icon: 'code',
    },
];

export default function VideoTutorialsPage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const [selectedVideoId, setSelectedVideoId] = useState<string | null>(
        searchParams.get('video')
    );
    const [currentTime, setCurrentTime] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [filteredVideos, setFilteredVideos] = useState(mockVideos);

    useEffect(() => {
        const videoId = searchParams.get('video');
        setSelectedVideoId(videoId);
    }, [searchParams]);

    const handleSelectVideo = (videoId: string) => {
        if (videoId) {
            setSelectedVideoId(videoId);
            setSearchParams({ video: videoId });
            setCurrentTime(0);
            setIsPlaying(false);
        } else {
            setSelectedVideoId(null);
            setSearchParams({});
        }
    };

    const handleSearch = (query: string, filters?: any) => {
        let filtered = mockVideos;

        // Filter by search query
        if (query) {
            filtered = filtered.filter(video =>
                video.title.toLowerCase().includes(query.toLowerCase()) ||
                video.description.toLowerCase().includes(query.toLowerCase()) ||
                video.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
            );
        }

        // Filter by category
        if (filters?.category && filters.category !== 'all') {
            filtered = filtered.filter(video => video.category === filters.category);
        }

        // Filter by difficulty
        if (filters?.difficulty && filters.difficulty !== 'all') {
            filtered = filtered.filter(video => video.difficulty === filters.difficulty);
        }

        // Sort by criteria
        if (filters?.sortBy) {
            switch (filters.sortBy) {
                case 'recent':
                    filtered.sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
                    break;
                case 'rating':
                    filtered.sort((a, b) => b.rating - a.rating);
                    break;
                case 'duration':
                    filtered.sort((a, b) => a.duration - b.duration);
                    break;
                case 'title':
                    filtered.sort((a, b) => a.title.localeCompare(b.title));
                    break;
                default: // popular
                    filtered.sort((a, b) => b.views - a.views);
            }
        }

        setFilteredVideos(filtered);
    };

    const handlePlay = () => {
        setIsPlaying(true);
    };

    const handlePause = () => {
        setIsPlaying(false);
    };

    const handleSeek = (time: number) => {
        setCurrentTime(time);
    };

    const handleRateVideo = (videoId: string, rating: number) => {
        console.log('Rate video:', videoId, rating);
    };

    const handleBookmarkVideo = (videoId: string) => {
        console.log('Bookmark video:', videoId);
    };

    const handleShareVideo = (videoId: string) => {
        const url = `${window.location.origin}/help/videos?video=${videoId}`;
        navigator.clipboard.writeText(url);
    };

    const selectedVideo = selectedVideoId
        ? mockVideos.find(v => v.id === selectedVideoId) || null
        : null;

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <VideoTutorialGallery
                videos={filteredVideos}
                categories={mockCategories}
                selectedVideo={selectedVideo}
                currentTime={currentTime}
                isPlaying={isPlaying}
                onSelectVideo={handleSelectVideo}
                onSearch={handleSearch}
                onPlay={handlePlay}
                onPause={handlePause}
                onSeek={handleSeek}
                onRateVideo={handleRateVideo}
                onBookmarkVideo={handleBookmarkVideo}
                onShareVideo={handleShareVideo}
            />
        </div>
    );
}