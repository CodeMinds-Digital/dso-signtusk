import { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, XCircle, Search, Filter, Download } from 'lucide-react';

export default function AdminSecurity() {
    const [events] = useState([
        {
            id: 'sec_1',
            timestamp: new Date(Date.now() - 30 * 60 * 1000),
            type: 'MULTIPLE_FAILED_ATTEMPTS',
            severity: 'HIGH',
            description: 'Multiple failed login attempts detected',
            userId: 'user_5',
            userName: 'Alice Johnson',
            ipAddress: '192.168.1.100',
            resolved: false,
        },
        {
            id: 'sec_2',
            timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
            type: 'SUSPICIOUS_LOGIN',
            severity: 'MEDIUM',
            description: 'Login from unusual location',
            userId: 'user_12',
            userName: 'Bob Smith',
            ipAddress: '203.0.113.45',
            resolved: true,
            resolvedAt: new Date(Date.now() - 60 * 60 * 1000),
        },
        {
            id: 'sec_3',
            timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
            type: 'ACCOUNT_LOCKED',
            severity: 'CRITICAL',
            description: 'Account locked due to brute force attempt',
            userId: 'user_8',
            userName: 'Charlie Brown',
            ipAddress: '198.51.100.23',
            resolved: true,
            resolvedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
        },
    ]);

    const [searchTerm, setSearchTerm] = useState('');
    const [severityFilter, setSeverityFilter] = useState('all');
    const [statusFilter, setStatusFilter] = useState('all');

    const getSeverityColor = (severity: string) => {
        switch (severity) {
            case 'CRITICAL':
                return 'bg-red-100 text-red-800';
            case 'HIGH':
                return 'bg-orange-100 text-orange-800';
            case 'MEDIUM':
                return 'bg-yellow-100 text-yellow-800';
            case 'LOW':
                return 'bg-blue-100 text-blue-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    const filteredEvents = events.filter(event => {
        const matchesSearch = event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
            event.userName?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesSeverity = severityFilter === 'all' || event.severity === severityFilter;
        const matchesStatus = statusFilter === 'all' ||
            (statusFilter === 'resolved' && event.resolved) ||
            (statusFilter === 'unresolved' && !event.resolved);
        return matchesSearch && matchesSeverity && matchesStatus;
    });

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Security Events</h1>
                    <p className="text-gray-600">Monitor and respond to security threats</p>
                </div>
                <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
                    <Download className="h-4 w-4" />
                    <span>Export</span>
                </button>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Total Events</p>
                            <p className="text-2xl font-bold text-gray-900">{events.length}</p>
                        </div>
                        <Shield className="h-8 w-8 text-blue-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Critical</p>
                            <p className="text-2xl font-bold text-red-600">
                                {events.filter(e => e.severity === 'CRITICAL').length}
                            </p>
                        </div>
                        <AlertTriangle className="h-8 w-8 text-red-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Unresolved</p>
                            <p className="text-2xl font-bold text-orange-600">
                                {events.filter(e => !e.resolved).length}
                            </p>
                        </div>
                        <XCircle className="h-8 w-8 text-orange-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Resolved</p>
                            <p className="text-2xl font-bold text-green-600">
                                {events.filter(e => e.resolved).length}
                            </p>
                        </div>
                        <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg shadow p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search events..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                            />
                        </div>
                    </div>
                    <select
                        value={severityFilter}
                        onChange={(e) => setSeverityFilter(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                        <option value="all">All Severities</option>
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="MEDIUM">Medium</option>
                        <option value="LOW">Low</option>
                    </select>
                    <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                        <option value="all">All Status</option>
                        <option value="resolved">Resolved</option>
                        <option value="unresolved">Unresolved</option>
                    </select>
                </div>
            </div>

            {/* Events List */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Timestamp</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Severity</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">IP Address</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredEvents.map((event) => (
                                <tr key={event.id} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {event.timestamp.toLocaleString()}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {event.type.replace(/_/g, ' ')}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(event.severity)}`}>
                                            {event.severity}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-900">{event.description}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{event.userName || 'N/A'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{event.ipAddress}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        {event.resolved ? (
                                            <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                                                Resolved
                                            </span>
                                        ) : (
                                            <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                                                Unresolved
                                            </span>
                                        )}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        {!event.resolved && (
                                            <button className="text-red-600 hover:text-red-900">
                                                Resolve
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}