import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link, Form, useActionData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasSuccess } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Progress,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from "@docusign-alternative/ui";
import {
    CreditCard,
    Download,
    TrendingUp,
    Users,
    FileText,
    HardDrive,
    ArrowLeft,
    Calendar,
    DollarSign,
    AlertTriangle,
    CheckCircle,
    ExternalLink
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Organization Billing - DocuSign Alternative" },
        { name: "description", content: "Manage your organization billing and subscription" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "updatePlan") {
        const planId = formData.get("planId") as string;
        const billingCycle = formData.get("billingCycle") as string;
        // In real implementation, update billing via tRPC
        return json({ success: `Plan updated to ${planId}` });
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function OrganizationBilling() {
    const { user } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    // tRPC queries
    const billingQuery = trpc.organization.getBilling.useQuery({
        organizationId: user.organizationId,
    });

    const billing = billingQuery.data?.billing;

    if (!billing) {
        return (
            <Layout user={user}>
                <div className="p-6">
                    <div className="text-center py-8">
                        <CreditCard className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">Loading billing information...</h3>
                    </div>
                </div>
            </Layout>
        );
    }

    const usagePercentages = {
        documents: Math.round((billing.usage.documentsThisMonth / billing.usage.documentsLimit) * 100),
        members: Math.round((billing.usage.membersCount / billing.usage.membersLimit) * 100),
        storage: Math.round((billing.usage.storageUsed / billing.usage.storageLimit) * 100),
    };

    const planFeatures = {
        professional: [
            "Up to 100 documents per month",
            "Up to 25 team members",
            "10 GB storage",
            "Advanced templates",
            "Email support",
            "API access",
        ],
        enterprise: [
            "Unlimited documents",
            "Unlimited team members",
            "100 GB storage",
            "Custom branding",
            "Priority support",
            "Advanced integrations",
            "SSO & SAML",
            "Advanced analytics",
        ],
    };

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center space-x-4 mb-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/organization">
                                <ArrowLeft className="h-4 w-4 mr-2" />
                                Back to Organization
                            </Link>
                        </Button>
                    </div>
                    <h1 className="text-2xl font-bold text-gray-900">Billing & Usage</h1>
                    <p className="text-gray-600">
                        Manage your subscription and monitor usage
                    </p>
                </div>

                {/* Success Message */}
                {hasSuccess(actionData) && (
                    <div className="mb-6 rounded-md bg-green-50 p-4">
                        <div className="text-sm text-green-700">{actionData.success}</div>
                    </div>
                )}

                <Tabs defaultValue="overview" className="space-y-6">
                    <TabsList>
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="usage">Usage</TabsTrigger>
                        <TabsTrigger value="invoices">Invoices</TabsTrigger>
                        <TabsTrigger value="plans">Plans</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                        {/* Current Plan */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <CreditCard className="mr-2 h-5 w-5" />
                                        Current Plan
                                    </div>
                                    <Badge variant="default">
                                        {billing.subscription.status}
                                    </Badge>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    <div>
                                        <p className="text-sm font-medium text-gray-600">Plan</p>
                                        <p className="text-2xl font-bold">{billing.subscription.planName}</p>
                                        <p className="text-sm text-gray-600 capitalize">
                                            {billing.subscription.billingCycle}ly billing
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-medium text-gray-600">Next Billing Date</p>
                                        <p className="text-lg font-semibold">
                                            {new Date(billing.subscription.currentPeriodEnd).toLocaleDateString()}
                                        </p>
                                        <p className="text-sm text-gray-600">
                                            {billing.subscription.cancelAtPeriodEnd ? 'Cancels at period end' : 'Auto-renews'}
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-medium text-gray-600">Payment Method</p>
                                        <div className="flex items-center space-x-2">
                                            <CreditCard className="h-4 w-4" />
                                            <span className="capitalize">{billing.paymentMethod.brand}</span>
                                            <span>•••• {billing.paymentMethod.last4}</span>
                                        </div>
                                        <p className="text-sm text-gray-600">
                                            Expires {billing.paymentMethod.expiryMonth}/{billing.paymentMethod.expiryYear}
                                        </p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Usage Overview */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <Card>
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center">
                                            <FileText className="h-8 w-8 text-blue-600 mr-3" />
                                            <div>
                                                <p className="text-sm font-medium text-gray-600">Documents</p>
                                                <p className="text-2xl font-bold">
                                                    {billing.usage.documentsThisMonth}
                                                </p>
                                            </div>
                                        </div>
                                        <Badge variant={usagePercentages.documents > 80 ? "destructive" : "secondary"}>
                                            {usagePercentages.documents}%
                                        </Badge>
                                    </div>
                                    <Progress value={usagePercentages.documents} className="mb-2" />
                                    <p className="text-sm text-gray-600">
                                        {billing.usage.documentsThisMonth} of {billing.usage.documentsLimit} used
                                    </p>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center">
                                            <Users className="h-8 w-8 text-green-600 mr-3" />
                                            <div>
                                                <p className="text-sm font-medium text-gray-600">Members</p>
                                                <p className="text-2xl font-bold">
                                                    {billing.usage.membersCount}
                                                </p>
                                            </div>
                                        </div>
                                        <Badge variant={usagePercentages.members > 80 ? "destructive" : "secondary"}>
                                            {usagePercentages.members}%
                                        </Badge>
                                    </div>
                                    <Progress value={usagePercentages.members} className="mb-2" />
                                    <p className="text-sm text-gray-600">
                                        {billing.usage.membersCount} of {billing.usage.membersLimit} used
                                    </p>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center">
                                            <HardDrive className="h-8 w-8 text-purple-600 mr-3" />
                                            <div>
                                                <p className="text-sm font-medium text-gray-600">Storage</p>
                                                <p className="text-2xl font-bold">
                                                    {billing.usage.storageUsed} GB
                                                </p>
                                            </div>
                                        </div>
                                        <Badge variant={usagePercentages.storage > 80 ? "destructive" : "secondary"}>
                                            {usagePercentages.storage}%
                                        </Badge>
                                    </div>
                                    <Progress value={usagePercentages.storage} className="mb-2" />
                                    <p className="text-sm text-gray-600">
                                        {billing.usage.storageUsed} of {billing.usage.storageLimit} GB used
                                    </p>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Quick Actions */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Quick Actions</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <Button variant="outline" className="justify-start">
                                        <Download className="mr-2 h-4 w-4" />
                                        Download Latest Invoice
                                    </Button>
                                    <Button variant="outline" className="justify-start">
                                        <CreditCard className="mr-2 h-4 w-4" />
                                        Update Payment Method
                                    </Button>
                                    <Button variant="outline" className="justify-start">
                                        <TrendingUp className="mr-2 h-4 w-4" />
                                        Upgrade Plan
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="usage" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Usage Details</CardTitle>
                                <CardDescription>
                                    Detailed breakdown of your current usage
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-6">
                                    {/* Documents Usage */}
                                    <div>
                                        <div className="flex items-center justify-between mb-2">
                                            <h3 className="font-medium">Documents This Month</h3>
                                            <span className="text-sm text-gray-600">
                                                {billing.usage.documentsThisMonth} / {billing.usage.documentsLimit}
                                            </span>
                                        </div>
                                        <Progress value={usagePercentages.documents} className="mb-2" />
                                        {usagePercentages.documents > 80 && (
                                            <div className="flex items-center text-sm text-amber-600">
                                                <AlertTriangle className="h-4 w-4 mr-1" />
                                                Approaching limit - consider upgrading your plan
                                            </div>
                                        )}
                                    </div>

                                    {/* Members Usage */}
                                    <div>
                                        <div className="flex items-center justify-between mb-2">
                                            <h3 className="font-medium">Team Members</h3>
                                            <span className="text-sm text-gray-600">
                                                {billing.usage.membersCount} / {billing.usage.membersLimit}
                                            </span>
                                        </div>
                                        <Progress value={usagePercentages.members} className="mb-2" />
                                        {usagePercentages.members > 80 && (
                                            <div className="flex items-center text-sm text-amber-600">
                                                <AlertTriangle className="h-4 w-4 mr-1" />
                                                Approaching member limit
                                            </div>
                                        )}
                                    </div>

                                    {/* Storage Usage */}
                                    <div>
                                        <div className="flex items-center justify-between mb-2">
                                            <h3 className="font-medium">Storage</h3>
                                            <span className="text-sm text-gray-600">
                                                {billing.usage.storageUsed} GB / {billing.usage.storageLimit} GB
                                            </span>
                                        </div>
                                        <Progress value={usagePercentages.storage} className="mb-2" />
                                        {usagePercentages.storage > 80 && (
                                            <div className="flex items-center text-sm text-amber-600">
                                                <AlertTriangle className="h-4 w-4 mr-1" />
                                                Storage almost full
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="invoices" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Invoice History</CardTitle>
                                <CardDescription>
                                    View and download your past invoices
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Invoice</TableHead>
                                            <TableHead>Date</TableHead>
                                            <TableHead>Amount</TableHead>
                                            <TableHead>Status</TableHead>
                                            <TableHead className="w-[100px]">Actions</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {billing.invoices.map((invoice) => (
                                            <TableRow key={invoice.id}>
                                                <TableCell className="font-medium">
                                                    {invoice.id}
                                                </TableCell>
                                                <TableCell>
                                                    {new Date(invoice.date).toLocaleDateString()}
                                                </TableCell>
                                                <TableCell>
                                                    ${(invoice.amount / 100).toFixed(2)} {invoice.currency.toUpperCase()}
                                                </TableCell>
                                                <TableCell>
                                                    <Badge variant={invoice.status === 'PAID' ? 'default' : 'secondary'}>
                                                        {invoice.status}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <Button variant="ghost" size="sm" asChild>
                                                        <a href={invoice.downloadUrl} target="_blank" rel="noopener noreferrer">
                                                            <Download className="h-4 w-4" />
                                                        </a>
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="plans" className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <Card className="relative">
                                <CardHeader>
                                    <CardTitle className="flex items-center justify-between">
                                        Professional
                                        {billing.subscription.planId === 'professional' && (
                                            <Badge variant="default">Current Plan</Badge>
                                        )}
                                    </CardTitle>
                                    <CardDescription>
                                        Perfect for growing teams
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="mb-4">
                                        <span className="text-3xl font-bold">$29</span>
                                        <span className="text-gray-600">/month</span>
                                    </div>
                                    <ul className="space-y-2 mb-6">
                                        {planFeatures.professional.map((feature, index) => (
                                            <li key={index} className="flex items-center text-sm">
                                                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                                                {feature}
                                            </li>
                                        ))}
                                    </ul>
                                    {billing.subscription.planId !== 'professional' && (
                                        <Form method="post">
                                            <input type="hidden" name="intent" value="updatePlan" />
                                            <input type="hidden" name="planId" value="professional" />
                                            <input type="hidden" name="billingCycle" value="monthly" />
                                            <Button className="w-full" disabled={isSubmitting}>
                                                {isSubmitting ? "Updating..." : "Upgrade to Professional"}
                                            </Button>
                                        </Form>
                                    )}
                                </CardContent>
                            </Card>

                            <Card className="relative">
                                <CardHeader>
                                    <CardTitle className="flex items-center justify-between">
                                        Enterprise
                                        {billing.subscription.planId === 'enterprise' && (
                                            <Badge variant="default">Current Plan</Badge>
                                        )}
                                    </CardTitle>
                                    <CardDescription>
                                        For large organizations
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="mb-4">
                                        <span className="text-3xl font-bold">$99</span>
                                        <span className="text-gray-600">/month</span>
                                    </div>
                                    <ul className="space-y-2 mb-6">
                                        {planFeatures.enterprise.map((feature, index) => (
                                            <li key={index} className="flex items-center text-sm">
                                                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                                                {feature}
                                            </li>
                                        ))}
                                    </ul>
                                    {billing.subscription.planId !== 'enterprise' && (
                                        <Form method="post">
                                            <input type="hidden" name="intent" value="updatePlan" />
                                            <input type="hidden" name="planId" value="enterprise" />
                                            <input type="hidden" name="billingCycle" value="monthly" />
                                            <Button className="w-full" disabled={isSubmitting}>
                                                {isSubmitting ? "Updating..." : "Upgrade to Enterprise"}
                                            </Button>
                                        </Form>
                                    )}
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}