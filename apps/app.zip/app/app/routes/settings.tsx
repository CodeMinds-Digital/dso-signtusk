import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasSuccess } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Switch,
    Separator,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Badge,
    SecuritySettings,
} from "@docusign-alternative/ui";
import {
    Settings as SettingsIcon,
    Globe,
    Palette,
    Shield,
    Users,
    Building,
    CreditCard,
    Download,
    Upload,
    Trash2,
    AlertTriangle
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Settings - DocuSign Alternative" },
        { name: "description", content: "Manage your account and application settings" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    // Mock settings data - in real implementation, fetch from database
    const settings = {
        general: {
            language: "en",
            timezone: "America/Los_Angeles",
            dateFormat: "MM/DD/YYYY",
            theme: "light",
        },
        notifications: {
            documentSigned: true,
            documentExpired: true,
            reminderEmails: true,
            weeklyDigest: false,
            marketingEmails: false,
        },
        organization: {
            name: "Acme Corporation",
            domain: "acme.com",
            allowPublicTemplates: true,
            requireTwoFactor: false,
            sessionTimeout: 30,
        },
        billing: {
            plan: "Professional",
            documentsUsed: 245,
            documentsLimit: 500,
            nextBillingDate: "2024-02-15",
            amount: "$49.99",
        },
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        settings,
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "updateGeneral") {
        // In real implementation, update general settings
        return json({ success: "General settings updated successfully" });
    }

    if (intent === "updateNotifications") {
        // In real implementation, update notification settings
        return json({ success: "Notification settings updated successfully" });
    }

    if (intent === "updateOrganization") {
        // In real implementation, update organization settings
        return json({ success: "Organization settings updated successfully" });
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function Settings() {
    const { user, settings } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const usagePercentage = Math.round((settings.billing.documentsUsed / settings.billing.documentsLimit) * 100);

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
                    <p className="text-gray-600">Manage your account and application preferences</p>
                </div>

                <Tabs defaultValue="general" className="space-y-6">
                    <TabsList>
                        <TabsTrigger value="general">General</TabsTrigger>
                        <TabsTrigger value="notifications">Notifications</TabsTrigger>
                        <TabsTrigger value="security">Security</TabsTrigger>
                        <TabsTrigger value="organization">Organization</TabsTrigger>
                        <TabsTrigger value="billing">Billing</TabsTrigger>
                        <TabsTrigger value="data">Data & Privacy</TabsTrigger>
                    </TabsList>

                    <TabsContent value="general" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <SettingsIcon className="mr-2 h-5 w-5" />
                                    General Settings
                                </CardTitle>
                                <CardDescription>
                                    Configure your basic application preferences
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateGeneral" />

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="language">Language</Label>
                                            <Select name="language" defaultValue={settings.general.language}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="en">English</SelectItem>
                                                    <SelectItem value="es">Spanish</SelectItem>
                                                    <SelectItem value="fr">French</SelectItem>
                                                    <SelectItem value="de">German</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div>
                                            <Label htmlFor="timezone">Timezone</Label>
                                            <Select name="timezone" defaultValue={settings.general.timezone}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                                                    <SelectItem value="America/Denver">Mountain Time</SelectItem>
                                                    <SelectItem value="America/Chicago">Central Time</SelectItem>
                                                    <SelectItem value="America/New_York">Eastern Time</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="dateFormat">Date Format</Label>
                                            <Select name="dateFormat" defaultValue={settings.general.dateFormat}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                                    <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                                    <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div>
                                            <Label htmlFor="theme">Theme</Label>
                                            <Select name="theme" defaultValue={settings.general.theme}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="light">Light</SelectItem>
                                                    <SelectItem value="dark">Dark</SelectItem>
                                                    <SelectItem value="system">System</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    {hasSuccess(actionData) && (
                                        <div className="rounded-md bg-green-50 p-4">
                                            <div className="text-sm text-green-700">{actionData.success}</div>
                                        </div>
                                    )}

                                    <Button type="submit" disabled={isSubmitting}>
                                        {isSubmitting ? "Saving..." : "Save Changes"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="security" className="space-y-6">
                        <SecuritySettings
                            settings={{
                                twoFactorEnabled: true, // Enhanced to show enabled state
                                loginNotifications: true,
                                suspiciousActivityAlerts: true,
                                emailOnNewDevice: true,
                                emailOnLocationChange: true,
                                sessionTimeout: 60,
                                maxFailedAttempts: 5,
                                lockoutDuration: 900,
                                requireStrongPassword: true,
                                allowedIpRanges: [],
                            }}
                            sessions={[
                                {
                                    id: "1",
                                    deviceName: "MacBook Pro",
                                    deviceType: "desktop",
                                    browser: "Chrome",
                                    os: "macOS",
                                    ipAddress: "192.168.1.100",
                                    location: "San Francisco, CA",
                                    lastActivity: new Date(),
                                    isCurrent: true,
                                },
                                {
                                    id: "2",
                                    deviceName: "iPhone 15",
                                    deviceType: "mobile",
                                    browser: "Safari",
                                    os: "iOS",
                                    ipAddress: "192.168.1.101",
                                    location: "San Francisco, CA",
                                    lastActivity: new Date(Date.now() - 3600000),
                                    isCurrent: false,
                                },
                            ]}
                            trustedDevices={[
                                {
                                    id: "1",
                                    name: "MacBook Pro",
                                    type: "desktop",
                                    addedAt: new Date(Date.now() - 86400000 * 30),
                                    lastUsed: new Date(),
                                },
                            ]}
                            loginHistory={[
                                {
                                    id: "1",
                                    timestamp: new Date(),
                                    ipAddress: "192.168.1.100",
                                    location: "San Francisco, CA",
                                    device: "MacBook Pro - Chrome",
                                    success: true,
                                    method: "2fa", // Enhanced to show 2FA usage
                                },
                                {
                                    id: "2",
                                    timestamp: new Date(Date.now() - 3600000),
                                    ipAddress: "192.168.1.101",
                                    location: "San Francisco, CA",
                                    device: "iPhone 15 - Safari",
                                    success: true,
                                    method: "2fa",
                                },
                                {
                                    id: "3",
                                    timestamp: new Date(Date.now() - 7200000),
                                    ipAddress: "10.0.0.1",
                                    location: "Unknown",
                                    device: "Unknown Device",
                                    success: false,
                                    method: "password",
                                },
                            ]}
                            onUpdateSettings={async (settings) => {
                                console.log("Update settings:", settings);
                            }}
                            onRevokeSession={async (sessionId) => {
                                console.log("Revoke session:", sessionId);
                            }}
                            onRemoveTrustedDevice={async (deviceId) => {
                                console.log("Remove trusted device:", deviceId);
                            }}
                            onEnable2FA={() => {
                                window.location.href = "/setup-2fa";
                            }}
                            onDisable2FA={() => {
                                console.log("Disable 2FA");
                            }}
                            onRegenerateBackupCodes={() => {
                                console.log("Regenerate backup codes");
                            }}
                            onChangePassword={() => {
                                console.log("Change password");
                            }}
                        />
                    </TabsContent>

                    <TabsContent value="notifications" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Notification Preferences</CardTitle>
                                <CardDescription>
                                    Choose which notifications you want to receive
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateNotifications" />

                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Document Signed</p>
                                                <p className="text-sm text-gray-600">
                                                    Get notified when someone signs your document
                                                </p>
                                            </div>
                                            <Switch
                                                name="documentSigned"
                                                defaultChecked={settings.notifications.documentSigned}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Document Expired</p>
                                                <p className="text-sm text-gray-600">
                                                    Get notified when a document expires
                                                </p>
                                            </div>
                                            <Switch
                                                name="documentExpired"
                                                defaultChecked={settings.notifications.documentExpired}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Reminder Emails</p>
                                                <p className="text-sm text-gray-600">
                                                    Send reminder emails to signers
                                                </p>
                                            </div>
                                            <Switch
                                                name="reminderEmails"
                                                defaultChecked={settings.notifications.reminderEmails}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Weekly Digest</p>
                                                <p className="text-sm text-gray-600">
                                                    Receive a weekly summary of activity
                                                </p>
                                            </div>
                                            <Switch
                                                name="weeklyDigest"
                                                defaultChecked={settings.notifications.weeklyDigest}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Marketing Emails</p>
                                                <p className="text-sm text-gray-600">
                                                    Receive product updates and tips
                                                </p>
                                            </div>
                                            <Switch
                                                name="marketingEmails"
                                                defaultChecked={settings.notifications.marketingEmails}
                                            />
                                        </div>
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        {isSubmitting ? "Saving..." : "Save Preferences"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="organization" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Building className="mr-2 h-5 w-5" />
                                    Organization Settings
                                </CardTitle>
                                <CardDescription>
                                    Manage settings for your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateOrganization" />

                                    <div>
                                        <Label htmlFor="orgName">Organization Name</Label>
                                        <Input
                                            id="orgName"
                                            name="orgName"
                                            defaultValue={settings.organization.name}
                                        />
                                    </div>

                                    <div>
                                        <Label htmlFor="domain">Domain</Label>
                                        <Input
                                            id="domain"
                                            name="domain"
                                            defaultValue={settings.organization.domain}
                                        />
                                    </div>

                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Allow Public Templates</p>
                                                <p className="text-sm text-gray-600">
                                                    Allow users to create public templates
                                                </p>
                                            </div>
                                            <Switch
                                                name="allowPublicTemplates"
                                                defaultChecked={settings.organization.allowPublicTemplates}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Require Two-Factor Authentication</p>
                                                <p className="text-sm text-gray-600">
                                                    Require all users to enable 2FA
                                                </p>
                                            </div>
                                            <Switch
                                                name="requireTwoFactor"
                                                defaultChecked={settings.organization.requireTwoFactor}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                                        <Input
                                            id="sessionTimeout"
                                            name="sessionTimeout"
                                            type="number"
                                            defaultValue={settings.organization.sessionTimeout}
                                        />
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        {isSubmitting ? "Saving..." : "Save Settings"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="billing" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <CreditCard className="mr-2 h-5 w-5" />
                                    Billing & Usage
                                </CardTitle>
                                <CardDescription>
                                    Manage your subscription and view usage
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <p className="text-sm font-medium text-gray-600">Current Plan</p>
                                        <div className="flex items-center space-x-2">
                                            <p className="text-2xl font-bold">{settings.billing.plan}</p>
                                            <Badge variant="default">Active</Badge>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-sm font-medium text-gray-600">Next Billing Date</p>
                                        <p className="text-2xl font-bold">{settings.billing.nextBillingDate}</p>
                                        <p className="text-sm text-gray-600">{settings.billing.amount}</p>
                                    </div>
                                </div>

                                <Separator />

                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <p className="font-medium">Document Usage</p>
                                        <p className="text-sm text-gray-600">
                                            {settings.billing.documentsUsed} / {settings.billing.documentsLimit}
                                        </p>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2">
                                        <div
                                            className={`h-2 rounded-full ${usagePercentage > 80 ? 'bg-red-600' :
                                                usagePercentage > 60 ? 'bg-yellow-600' : 'bg-green-600'
                                                }`}
                                            style={{ width: `${usagePercentage}%` }}
                                        />
                                    </div>
                                    <p className="text-sm text-gray-600 mt-1">
                                        {usagePercentage}% of monthly limit used
                                    </p>
                                </div>

                                <div className="flex gap-4">
                                    <Button variant="outline">
                                        View Invoices
                                    </Button>
                                    <Button>
                                        Upgrade Plan
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="data" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Shield className="mr-2 h-5 w-5" />
                                    Data & Privacy
                                </CardTitle>
                                <CardDescription>
                                    Manage your data and privacy settings
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Export Data</p>
                                            <p className="text-sm text-gray-600">
                                                Download a copy of your account data
                                            </p>
                                        </div>
                                        <Button variant="outline">
                                            <Download className="mr-2 h-4 w-4" />
                                            Export
                                        </Button>
                                    </div>

                                    <Separator />

                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Import Data</p>
                                            <p className="text-sm text-gray-600">
                                                Import data from another service
                                            </p>
                                        </div>
                                        <Button variant="outline">
                                            <Upload className="mr-2 h-4 w-4" />
                                            Import
                                        </Button>
                                    </div>

                                    <Separator />

                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium text-red-600">Delete Account</p>
                                            <p className="text-sm text-gray-600">
                                                Permanently delete your account and all data
                                            </p>
                                        </div>
                                        <Button variant="destructive">
                                            <Trash2 className="mr-2 h-4 w-4" />
                                            Delete
                                        </Button>
                                    </div>
                                </div>

                                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                                    <div className="flex">
                                        <AlertTriangle className="h-5 w-5 text-yellow-400" />
                                        <div className="ml-3">
                                            <h3 className="text-sm font-medium text-yellow-800">
                                                Data Retention Policy
                                            </h3>
                                            <div className="mt-2 text-sm text-yellow-700">
                                                <p>
                                                    We retain your data for 90 days after account deletion.
                                                    After this period, all data is permanently removed from our systems.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}