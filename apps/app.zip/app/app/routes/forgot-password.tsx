import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useActionData, useNavigation } from "@remix-run/react";
import { PasswordResetForm, Card, CardContent, CardDescription, CardHeader, CardTitle } from "@docusign-alternative/ui";
import { hasError, hasSuccess } from "~/lib/utils";

export const meta: MetaFunction = () => {
    return [
        { title: "Forgot Password - DocuSign Alternative" },
        { name: "description", content: "Reset your password" },
    ];
};

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const email = formData.get("email");

    if (typeof email !== "string" || !email) {
        return json(
            { error: "Email is required" },
            { status: 400 }
        );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return json(
            { error: "Please enter a valid email address" },
            { status: 400 }
        );
    }

    try {
        // In a real implementation, you would send a password reset email here
        // For now, we'll just return a success message
        return json({
            success: "If an account with that email exists, we've sent you a password reset link."
        });
    } catch (error) {
        return json(
            { error: "Failed to send reset email. Please try again." },
            { status: 500 }
        );
    }
}

export default function ForgotPassword() {
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const handleSubmit = async (email: string) => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const emailInput = document.createElement('input');
        emailInput.name = 'email';
        emailInput.value = email;
        form.appendChild(emailInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleBack = () => {
        window.location.href = '/login';
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full">
                <PasswordResetForm
                    onSubmit={handleSubmit}
                    onBack={handleBack}
                    isLoading={isSubmitting}
                    error={hasError(actionData) ? actionData.error : undefined}
                    success={hasSuccess(actionData)}
                    successMessage={hasSuccess(actionData) ? actionData.success : undefined}
                />
            </div>
        </div>
    );
}