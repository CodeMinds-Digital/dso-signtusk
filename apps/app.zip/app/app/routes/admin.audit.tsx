import { useState } from 'react';
import { Database, Search, Filter, Download, Calendar, User, FileText } from 'lucide-react';

export default function AdminAudit() {
    const [auditLogs] = useState([
        {
            id: 'audit_1',
            timestamp: new Date(Date.now() - 15 * 60 * 1000),
            userId: 'user_1',
            userName: 'John Doe',
            organizationName: 'Acme Corp',
            entityType: 'document',
            entityId: 'doc_123',
            action: 'create',
            details: { name: 'Contract.pdf', size: '2.5MB' },
            ipAddress: '192.168.1.50',
        },
        {
            id: 'audit_2',
            timestamp: new Date(Date.now() - 45 * 60 * 1000),
            userId: 'user_2',
            userName: 'Jane Smith',
            organizationName: 'Tech Solutions',
            entityType: 'template',
            entityId: 'tpl_456',
            action: 'share',
            details: { shareType: 'public', permissions: 'view' },
            ipAddress: '10.0.0.25',
        },
        {
            id: 'audit_3',
            timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
            userId: 'user_3',
            userName: 'Bob Wilson',
            organizationName: 'Innovation Labs',
            entityType: 'signing_request',
            entityId: 'req_789',
            action: 'complete',
            details: { recipients: 3, completionTime: '2.5 hours' },
            ipAddress: '172.16.0.10',
        },
        {
            id: 'audit_4',
            timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
            userId: 'admin_1',
            userName: 'Admin User',
            organizationName: 'System',
            entityType: 'user',
            entityId: 'user_15',
            action: 'suspend',
            details: { reason: 'Policy violation', duration: 'permanent' },
            ipAddress: '192.168.1.1',
        },
    ]);

    const [searchTerm, setSearchTerm] = useState('');
    const [entityTypeFilter, setEntityTypeFilter] = useState('all');
    const [actionFilter, setActionFilter] = useState('all');
    const [dateRange, setDateRange] = useState('today');

    const getActionColor = (action: string) => {
        switch (action) {
            case 'create':
                return 'bg-green-100 text-green-800';
            case 'update':
                return 'bg-blue-100 text-blue-800';
            case 'delete':
                return 'bg-red-100 text-red-800';
            case 'share':
                return 'bg-purple-100 text-purple-800';
            case 'sign':
                return 'bg-orange-100 text-orange-800';
            case 'suspend':
                return 'bg-yellow-100 text-yellow-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    const getEntityIcon = (entityType: string) => {
        switch (entityType) {
            case 'document':
                return <FileText className="h-4 w-4" />;
            case 'user':
                return <User className="h-4 w-4" />;
            default:
                return <Database className="h-4 w-4" />;
        }
    };

    const filteredLogs = auditLogs.filter(log => {
        const matchesSearch = log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.entityType.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesEntityType = entityTypeFilter === 'all' || log.entityType === entityTypeFilter;
        const matchesAction = actionFilter === 'all' || log.action === actionFilter;
        return matchesSearch && matchesEntityType && matchesAction;
    });

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Audit Logs</h1>
                    <p className="text-gray-600">Complete audit trail of system activities</p>
                </div>
                <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
                    <Download className="h-4 w-4" />
                    <span>Export Logs</span>
                </button>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Total Events</p>
                            <p className="text-2xl font-bold text-gray-900">{auditLogs.length}</p>
                        </div>
                        <Database className="h-8 w-8 text-blue-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Unique Users</p>
                            <p className="text-2xl font-bold text-gray-900">
                                {new Set(auditLogs.map(log => log.userId)).size}
                            </p>
                        </div>
                        <User className="h-8 w-8 text-green-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Organizations</p>
                            <p className="text-2xl font-bold text-gray-900">
                                {new Set(auditLogs.map(log => log.organizationName)).size}
                            </p>
                        </div>
                        <FileText className="h-8 w-8 text-purple-600" />
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-600">Today's Events</p>
                            <p className="text-2xl font-bold text-gray-900">
                                {auditLogs.filter(log =>
                                    log.timestamp.toDateString() === new Date().toDateString()
                                ).length}
                            </p>
                        </div>
                        <Calendar className="h-8 w-8 text-orange-600" />
                    </div>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg shadow p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search logs..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                        />
                    </div>
                    <select
                        value={entityTypeFilter}
                        onChange={(e) => setEntityTypeFilter(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                        <option value="all">All Entity Types</option>
                        <option value="document">Documents</option>
                        <option value="template">Templates</option>
                        <option value="user">Users</option>
                        <option value="organization">Organizations</option>
                        <option value="signing_request">Signing Requests</option>
                    </select>
                    <select
                        value={actionFilter}
                        onChange={(e) => setActionFilter(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                        <option value="all">All Actions</option>
                        <option value="create">Create</option>
                        <option value="update">Update</option>
                        <option value="delete">Delete</option>
                        <option value="share">Share</option>
                        <option value="sign">Sign</option>
                        <option value="view">View</option>
                    </select>
                    <select
                        value={dateRange}
                        onChange={(e) => setDateRange(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month">This Month</option>
                        <option value="all">All Time</option>
                    </select>
                </div>
            </div>

            {/* Audit Logs Table */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Timestamp</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Organization</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Entity</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">IP Address</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredLogs.map((log) => (
                                <tr key={log.id} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {log.timestamp.toLocaleString()}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-gray-900">{log.userName}</div>
                                        <div className="text-sm text-gray-500">{log.userId}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {log.organizationName}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center space-x-2">
                                            {getEntityIcon(log.entityType)}
                                            <div>
                                                <div className="text-sm font-medium text-gray-900">{log.entityType}</div>
                                                <div className="text-sm text-gray-500">{log.entityId}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getActionColor(log.action)}`}>
                                            {log.action}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-500">
                                        {Object.entries(log.details).map(([key, value]) => (
                                            <div key={key}>
                                                <span className="font-medium">{key}:</span> {String(value)}
                                            </div>
                                        ))}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {log.ipAddress}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                    <div className="flex-1 flex justify-between sm:hidden">
                        <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            Previous
                        </button>
                        <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            Next
                        </button>
                    </div>
                    <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                        <div>
                            <p className="text-sm text-gray-700">
                                Showing <span className="font-medium">1</span> to <span className="font-medium">{filteredLogs.length}</span> of{' '}
                                <span className="font-medium">{filteredLogs.length}</span> results
                            </p>
                        </div>
                        <div>
                            <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                                <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                    Previous
                                </button>
                                <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                                    1
                                </button>
                                <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                    Next
                                </button>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}