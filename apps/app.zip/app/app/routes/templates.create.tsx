import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, useActionData, Form, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    TemplateWizard,
    DocumentSelectionStep,
    FieldPlacementStep,
    RecipientSetupStep,
    WorkflowConfigurationStep,
    SettingsReviewStep,
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Textarea,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Checkbox,
    Switch,
    Badge,
    Alert,
    AlertDescription,
    useToast,
} from "@docusign-alternative/ui";
import {
    Upload,
    FileText,
    Users,
    Settings,
    CheckCircle,
    AlertCircle,
    ArrowLeft,
    Plus,
    Trash2,
    Edit,
    Eye,
} from "@docusign-alternative/ui";
import { useState, useEffect } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Create Template - DocuSign Alternative" },
        { name: "description", content: "Create a new document template with step-by-step guidance" },
    ];
};

interface TemplateWizardStep {
    id: string;
    title: string;
    description: string;
    component: React.ComponentType<any>;
    isCompleted: boolean;
    isValid: boolean;
    errors?: string[];
}

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    // Mock documents available for template creation
    const documents = [
        {
            id: "doc-1",
            name: "Employment Contract Base.pdf",
            size: "245 KB",
            pages: 3,
            uploadedAt: "2024-01-15T10:30:00Z",
            status: "processed",
        },
        {
            id: "doc-2",
            name: "NDA Template.docx",
            size: "128 KB",
            pages: 2,
            uploadedAt: "2024-01-14T14:20:00Z",
            status: "processed",
        },
        {
            id: "doc-3",
            name: "Service Agreement.pdf",
            size: "312 KB",
            pages: 5,
            uploadedAt: "2024-01-13T09:15:00Z",
            status: "processed",
        },
    ];

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        documents,
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const action = formData.get("action");

    if (action === "create-template") {
        try {
            // Handle template creation
            const templateData = {
                name: formData.get("name"),
                description: formData.get("description"),
                documentId: formData.get("documentId"),
                category: formData.get("category"),
                tags: formData.get("tags")?.toString().split(",").map(tag => tag.trim()),
                isPublic: formData.get("isPublic") === "true",
                fields: JSON.parse(formData.get("fields")?.toString() || "[]"),
                recipients: JSON.parse(formData.get("recipients")?.toString() || "[]"),
                workflow: JSON.parse(formData.get("workflow")?.toString() || "{}"),
                settings: JSON.parse(formData.get("settings")?.toString() || "{}"),
            };

            // Validate template data
            const errors: string[] = [];
            if (!templateData.name) errors.push("Template name is required");
            if (!templateData.documentId) errors.push("Document selection is required");
            if (!templateData.fields.length) errors.push("At least one field is required");
            if (!templateData.recipients.length) errors.push("At least one recipient is required");

            if (errors.length > 0) {
                return json({ success: false, errors }, { status: 400 });
            }

            // Create template (mock implementation)
            const templateId = `template-${Date.now()}`;

            return redirect(`/templates/${templateId}?created=true`);
        } catch (error) {
            return json({
                success: false,
                errors: ["Failed to create template. Please try again."]
            }, { status: 500 });
        }
    }

    return json({ success: false, errors: ["Invalid action"] }, { status: 400 });
}

export default function CreateTemplate() {
    const { user, documents } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const { toast } = useToast();

    const [currentStepIndex, setCurrentStepIndex] = useState(0);
    const [templateData, setTemplateData] = useState({
        name: "",
        description: "",
        documentId: "",
        category: "",
        tags: [] as string[],
        isPublic: false,
        fields: [] as any[],
        recipients: [] as any[],
        workflow: {},
        settings: {},
    });

    const isLoading = navigation.state === "submitting";

    // Define wizard steps
    const steps: TemplateWizardStep[] = [
        {
            id: "document-selection",
            title: "Select Document",
            description: "Choose the document for your template",
            component: DocumentSelectionStepComponent,
            isCompleted: !!templateData.documentId,
            isValid: !!templateData.documentId,
            errors: !templateData.documentId ? ["Please select a document"] : [],
        },
        {
            id: "template-info",
            title: "Template Information",
            description: "Provide basic template details",
            component: TemplateInfoStepComponent,
            isCompleted: !!(templateData.name && templateData.category),
            isValid: !!(templateData.name && templateData.category),
            errors: [
                ...(!templateData.name ? ["Template name is required"] : []),
                ...(!templateData.category ? ["Category is required"] : []),
            ],
        },
        {
            id: "field-placement",
            title: "Place Fields",
            description: "Add signature and form fields",
            component: FieldPlacementStepComponent,
            isCompleted: templateData.fields.length > 0,
            isValid: templateData.fields.length > 0,
            errors: templateData.fields.length === 0 ? ["At least one field is required"] : [],
        },
        {
            id: "recipient-setup",
            title: "Setup Recipients",
            description: "Define recipient roles and order",
            component: RecipientSetupStepComponent,
            isCompleted: templateData.recipients.length > 0,
            isValid: templateData.recipients.length > 0,
            errors: templateData.recipients.length === 0 ? ["At least one recipient is required"] : [],
        },
        {
            id: "workflow-config",
            title: "Configure Workflow",
            description: "Set up signing workflow and automation",
            component: WorkflowConfigurationStepComponent,
            isCompleted: true, // Optional step
            isValid: true,
            errors: [],
        },
        {
            id: "review-settings",
            title: "Review & Create",
            description: "Review settings and create template",
            component: SettingsReviewStepComponent,
            isCompleted: false,
            isValid: true,
            errors: [],
        },
    ];

    const handleStepChange = (stepIndex: number) => {
        setCurrentStepIndex(stepIndex);
    };

    const handleComplete = async () => {
        try {
            const formData = new FormData();
            formData.append("action", "create-template");
            formData.append("name", templateData.name);
            formData.append("description", templateData.description);
            formData.append("documentId", templateData.documentId);
            formData.append("category", templateData.category);
            formData.append("tags", templateData.tags.join(","));
            formData.append("isPublic", templateData.isPublic.toString());
            formData.append("fields", JSON.stringify(templateData.fields));
            formData.append("recipients", JSON.stringify(templateData.recipients));
            formData.append("workflow", JSON.stringify(templateData.workflow));
            formData.append("settings", JSON.stringify(templateData.settings));

            // Submit form programmatically
            const form = document.createElement("form");
            form.method = "POST";
            form.style.display = "none";

            for (const [key, value] of formData.entries()) {
                const input = document.createElement("input");
                input.name = key;
                input.value = value.toString();
                form.appendChild(input);
            }

            document.body.appendChild(form);
            form.submit();
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to create template. Please try again.",
                variant: "destructive",
            });
        }
    };

    const handleCancel = () => {
        window.history.back();
    };

    // Show errors from action
    useEffect(() => {
        if (actionData && !actionData.success && actionData.errors) {
            toast({
                title: "Error creating template",
                description: actionData.errors.join(", "),
                variant: "destructive",
            });
        }
    }, [actionData, toast]);

    return (
        <Layout user={user}>
            <div className="p-6">
                <TemplateWizard
                    steps={steps}
                    currentStepIndex={currentStepIndex}
                    onStepChange={handleStepChange}
                    onComplete={handleComplete}
                    onCancel={handleCancel}
                    isLoading={isLoading}
                />
            </div>
        </Layout>
    );

    // Step Components
    function DocumentSelectionStepComponent() {
        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Select Document</h3>
                    <p className="text-gray-600 mb-6">
                        Choose an existing document to use as the foundation for your template, or upload a new one.
                    </p>
                </div>

                {/* Upload New Document */}
                <Card className="border-dashed border-2 border-gray-300 hover:border-gray-400 transition-colors">
                    <CardContent className="p-8 text-center">
                        <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h4 className="text-lg font-medium text-gray-900 mb-2">Upload New Document</h4>
                        <p className="text-gray-600 mb-4">
                            Upload a PDF, DOCX, or other supported document format
                        </p>
                        <Button variant="outline">
                            <Upload className="mr-2 h-4 w-4" />
                            Choose File
                        </Button>
                    </CardContent>
                </Card>

                {/* Existing Documents */}
                <div>
                    <h4 className="text-lg font-medium text-gray-900 mb-4">Or Select Existing Document</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {documents.map((document) => (
                            <Card
                                key={document.id}
                                className={`cursor-pointer transition-all hover:shadow-md ${templateData.documentId === document.id
                                        ? 'ring-2 ring-blue-500 bg-blue-50'
                                        : ''
                                    }`}
                                onClick={() => setTemplateData({ ...templateData, documentId: document.id })}
                            >
                                <CardContent className="p-4">
                                    <div className="flex items-start space-x-3">
                                        <FileText className="h-8 w-8 text-blue-600 mt-1" />
                                        <div className="flex-1 min-w-0">
                                            <h5 className="font-medium text-gray-900 truncate">
                                                {document.name}
                                            </h5>
                                            <div className="text-sm text-gray-600 space-y-1">
                                                <div>{document.size} • {document.pages} pages</div>
                                                <div>
                                                    Uploaded {new Date(document.uploadedAt).toLocaleDateString()}
                                                </div>
                                            </div>
                                            <Badge
                                                variant="outline"
                                                className="mt-2 bg-green-50 text-green-700 border-green-200"
                                            >
                                                {document.status}
                                            </Badge>
                                        </div>
                                        {templateData.documentId === document.id && (
                                            <CheckCircle className="h-5 w-5 text-blue-600" />
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    function TemplateInfoStepComponent() {
        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Template Information</h3>
                    <p className="text-gray-600 mb-6">
                        Provide basic information about your template to help organize and identify it.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="template-name">Template Name *</Label>
                            <Input
                                id="template-name"
                                placeholder="Enter template name..."
                                value={templateData.name}
                                onChange={(e) => setTemplateData({ ...templateData, name: e.target.value })}
                            />
                        </div>

                        <div>
                            <Label htmlFor="template-category">Category *</Label>
                            <Select
                                value={templateData.category}
                                onValueChange={(value) => setTemplateData({ ...templateData, category: value })}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="hr">HR</SelectItem>
                                    <SelectItem value="legal">Legal</SelectItem>
                                    <SelectItem value="sales">Sales</SelectItem>
                                    <SelectItem value="procurement">Procurement</SelectItem>
                                    <SelectItem value="finance">Finance</SelectItem>
                                    <SelectItem value="operations">Operations</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <Label htmlFor="template-tags">Tags</Label>
                            <Input
                                id="template-tags"
                                placeholder="Enter tags separated by commas..."
                                value={templateData.tags.join(", ")}
                                onChange={(e) => setTemplateData({
                                    ...templateData,
                                    tags: e.target.value.split(",").map(tag => tag.trim()).filter(Boolean)
                                })}
                            />
                            <p className="text-sm text-gray-500 mt-1">
                                Tags help categorize and search for templates
                            </p>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="template-description">Description</Label>
                            <Textarea
                                id="template-description"
                                placeholder="Describe what this template is used for..."
                                rows={4}
                                value={templateData.description}
                                onChange={(e) => setTemplateData({ ...templateData, description: e.target.value })}
                            />
                        </div>

                        <div className="flex items-center space-x-2">
                            <Switch
                                id="is-public"
                                checked={templateData.isPublic}
                                onCheckedChange={(checked) => setTemplateData({ ...templateData, isPublic: checked })}
                            />
                            <Label htmlFor="is-public">Make template public</Label>
                        </div>
                        <p className="text-sm text-gray-500">
                            Public templates can be discovered and used by other users in your organization
                        </p>
                    </div>
                </div>
            </div>
        );
    }

    function FieldPlacementStepComponent() {
        const [fields, setFields] = useState(templateData.fields);

        const addField = (type: string) => {
            const newField = {
                id: `field-${Date.now()}`,
                type,
                name: `${type}-${fields.length + 1}`,
                page: 1,
                x: 100,
                y: 100,
                width: 200,
                height: 40,
                isRequired: true,
                recipientRole: "",
            };
            const updatedFields = [...fields, newField];
            setFields(updatedFields);
            setTemplateData({ ...templateData, fields: updatedFields });
        };

        const removeField = (fieldId: string) => {
            const updatedFields = fields.filter(f => f.id !== fieldId);
            setFields(updatedFields);
            setTemplateData({ ...templateData, fields: updatedFields });
        };

        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Place Fields</h3>
                    <p className="text-gray-600 mb-6">
                        Add signature fields, text fields, and other form elements to your document.
                    </p>
                </div>

                {/* Field Types */}
                <div>
                    <h4 className="font-medium text-gray-900 mb-3">Add Fields</h4>
                    <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" onClick={() => addField("signature")}>
                            <Edit className="mr-2 h-4 w-4" />
                            Signature
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => addField("text")}>
                            <FileText className="mr-2 h-4 w-4" />
                            Text
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => addField("date")}>
                            Date
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => addField("checkbox")}>
                            Checkbox
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => addField("dropdown")}>
                            Dropdown
                        </Button>
                    </div>
                </div>

                {/* Field List */}
                <div>
                    <h4 className="font-medium text-gray-900 mb-3">
                        Fields ({fields.length})
                    </h4>
                    {fields.length === 0 ? (
                        <Card className="border-dashed">
                            <CardContent className="p-8 text-center">
                                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                                <p className="text-gray-600">
                                    No fields added yet. Add fields using the buttons above.
                                </p>
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="space-y-3">
                            {fields.map((field) => (
                                <Card key={field.id}>
                                    <CardContent className="p-4">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center space-x-3">
                                                <Badge variant="outline">{field.type}</Badge>
                                                <div>
                                                    <div className="font-medium">{field.name}</div>
                                                    <div className="text-sm text-gray-600">
                                                        Page {field.page} • Position ({field.x}, {field.y})
                                                        {field.isRequired && " • Required"}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                <Button variant="ghost" size="sm">
                                                    <Edit className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    onClick={() => removeField(field.id)}
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        );
    }

    function RecipientSetupStepComponent() {
        const [recipients, setRecipients] = useState(templateData.recipients);

        const addRecipient = () => {
            const newRecipient = {
                id: `recipient-${Date.now()}`,
                role: `Recipient ${recipients.length + 1}`,
                name: "",
                email: "",
                order: recipients.length + 1,
                authMethod: "email",
                isRequired: true,
            };
            const updatedRecipients = [...recipients, newRecipient];
            setRecipients(updatedRecipients);
            setTemplateData({ ...templateData, recipients: updatedRecipients });
        };

        const removeRecipient = (recipientId: string) => {
            const updatedRecipients = recipients.filter(r => r.id !== recipientId);
            setRecipients(updatedRecipients);
            setTemplateData({ ...templateData, recipients: updatedRecipients });
        };

        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Setup Recipients</h3>
                    <p className="text-gray-600 mb-6">
                        Define the roles and order of people who will interact with documents created from this template.
                    </p>
                </div>

                <div className="flex justify-between items-center">
                    <h4 className="font-medium text-gray-900">
                        Recipients ({recipients.length})
                    </h4>
                    <Button onClick={addRecipient}>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Recipient
                    </Button>
                </div>

                {recipients.length === 0 ? (
                    <Card className="border-dashed">
                        <CardContent className="p-8 text-center">
                            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-600 mb-4">
                                No recipients added yet. Add recipients to define the signing workflow.
                            </p>
                            <Button onClick={addRecipient}>
                                <Plus className="mr-2 h-4 w-4" />
                                Add First Recipient
                            </Button>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="space-y-4">
                        {recipients.map((recipient, index) => (
                            <Card key={recipient.id}>
                                <CardContent className="p-4">
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <div>
                                                <Label>Role Name</Label>
                                                <Input
                                                    placeholder="e.g., Employee, Manager, HR"
                                                    value={recipient.role}
                                                    onChange={(e) => {
                                                        const updated = recipients.map(r =>
                                                            r.id === recipient.id
                                                                ? { ...r, role: e.target.value }
                                                                : r
                                                        );
                                                        setRecipients(updated);
                                                        setTemplateData({ ...templateData, recipients: updated });
                                                    }}
                                                />
                                            </div>
                                            <div>
                                                <Label>Signing Order</Label>
                                                <Select
                                                    value={recipient.order.toString()}
                                                    onValueChange={(value) => {
                                                        const updated = recipients.map(r =>
                                                            r.id === recipient.id
                                                                ? { ...r, order: parseInt(value) }
                                                                : r
                                                        );
                                                        setRecipients(updated);
                                                        setTemplateData({ ...templateData, recipients: updated });
                                                    }}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {Array.from({ length: recipients.length }, (_, i) => (
                                                            <SelectItem key={i + 1} value={(i + 1).toString()}>
                                                                {i + 1}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div>
                                                <Label>Authentication</Label>
                                                <Select
                                                    value={recipient.authMethod}
                                                    onValueChange={(value) => {
                                                        const updated = recipients.map(r =>
                                                            r.id === recipient.id
                                                                ? { ...r, authMethod: value }
                                                                : r
                                                        );
                                                        setRecipients(updated);
                                                        setTemplateData({ ...templateData, recipients: updated });
                                                    }}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="email">Email</SelectItem>
                                                        <SelectItem value="sms">SMS</SelectItem>
                                                        <SelectItem value="phone">Phone Call</SelectItem>
                                                        <SelectItem value="none">None</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => removeRecipient(recipient.id)}
                                            className="ml-4"
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
        );
    }

    function WorkflowConfigurationStepComponent() {
        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Configure Workflow</h3>
                    <p className="text-gray-600 mb-6">
                        Set up the signing workflow, including conditional logic and automation rules.
                    </p>
                </div>

                <Alert>
                    <Settings className="h-4 w-4" />
                    <AlertDescription>
                        Workflow configuration is optional. You can configure advanced workflow settings after creating the template.
                    </AlertDescription>
                </Alert>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Signing Order</CardTitle>
                            <CardDescription>
                                Configure how recipients sign the document
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center space-x-2">
                                <Checkbox id="sequential" defaultChecked />
                                <Label htmlFor="sequential">Sequential signing (one at a time)</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                                <Checkbox id="parallel" />
                                <Label htmlFor="parallel">Parallel signing (all at once)</Label>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Automation</CardTitle>
                            <CardDescription>
                                Configure automatic reminders and notifications
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center space-x-2">
                                <Switch id="reminders" defaultChecked />
                                <Label htmlFor="reminders">Send automatic reminders</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                                <Switch id="notifications" defaultChecked />
                                <Label htmlFor="notifications">Email notifications</Label>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        );
    }

    function SettingsReviewStepComponent() {
        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Review & Create</h3>
                    <p className="text-gray-600 mb-6">
                        Review your template configuration before creating it.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Template Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Name</Label>
                                <p className="text-gray-900">{templateData.name || "Not specified"}</p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Category</Label>
                                <p className="text-gray-900">{templateData.category || "Not specified"}</p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Description</Label>
                                <p className="text-gray-900">{templateData.description || "No description"}</p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Tags</Label>
                                <div className="flex flex-wrap gap-1 mt-1">
                                    {templateData.tags.length > 0 ? (
                                        templateData.tags.map(tag => (
                                            <Badge key={tag} variant="outline">{tag}</Badge>
                                        ))
                                    ) : (
                                        <p className="text-gray-500">No tags</p>
                                    )}
                                </div>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Visibility</Label>
                                <p className="text-gray-900">
                                    {templateData.isPublic ? "Public" : "Private"}
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Configuration Summary</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Document</Label>
                                <p className="text-gray-900">
                                    {documents.find(d => d.id === templateData.documentId)?.name || "Not selected"}
                                </p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Fields</Label>
                                <p className="text-gray-900">{templateData.fields.length} fields configured</p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Recipients</Label>
                                <p className="text-gray-900">{templateData.recipients.length} recipients defined</p>
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-600">Workflow</Label>
                                <p className="text-gray-900">Sequential signing</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Validation Summary */}
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Validation Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            {steps.slice(0, -1).map((step, index) => (
                                <div key={step.id} className="flex items-center space-x-2">
                                    {step.isValid ? (
                                        <CheckCircle className="h-5 w-5 text-green-600" />
                                    ) : (
                                        <AlertCircle className="h-5 w-5 text-red-600" />
                                    )}
                                    <span className={step.isValid ? "text-gray-900" : "text-red-600"}>
                                        {step.title}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }
}