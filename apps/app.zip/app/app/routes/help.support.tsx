import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { useState } from "react";
import { SupportTicketInterface } from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Support Tickets - DocuSign Alternative" },
        { name: "description", content: "Manage your support requests and get help from our team" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    // In a real implementation, you might want to check authentication here
    return json({});
}

export default function SupportPage() {
    const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

    // Fetch tickets using tRPC
    const { data: tickets, refetch: refetchTickets } = trpc.helpSupport.getMyTickets.useQuery({
        status: 'all',
        limit: 50,
    });

    // Fetch selected ticket details
    const { data: selectedTicket } = trpc.helpSupport.getTicket.useQuery(
        { ticketId: selectedTicketId! },
        { enabled: !!selectedTicketId }
    );

    // Mutations
    const createTicketMutation = trpc.helpSupport.createTicket.useMutation({
        onSuccess: (data) => {
            refetchTickets();
            setSelectedTicketId(data.id);
        },
    });

    const updateTicketMutation = trpc.helpSupport.updateTicket.useMutation({
        onSuccess: () => {
            // Refetch ticket details
            if (selectedTicketId) {
                // In a real implementation, you'd refetch the specific ticket
                refetchTickets();
            }
        },
    });

    const handleCreateTicket = (ticketData: {
        subject: string;
        description: string;
        category: string;
        priority: string;
        attachments?: string[];
    }) => {
        createTicketMutation.mutate({
            subject: ticketData.subject,
            description: ticketData.description,
            category: ticketData.category as any,
            priority: ticketData.priority as any,
            attachments: ticketData.attachments,
        });
    };

    const handleSelectTicket = (ticketId: string) => {
        setSelectedTicketId(ticketId);
    };

    const handleSendMessage = (ticketId: string, message: string, attachments?: string[]) => {
        updateTicketMutation.mutate({
            ticketId,
            message,
            attachments,
        });
    };

    const handleCloseTicket = (ticketId: string) => {
        // In a real implementation, you'd have a separate mutation for closing tickets
        console.log('Close ticket:', ticketId);
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <SupportTicketInterface
                tickets={tickets || []}
                selectedTicket={selectedTicket || null}
                onCreateTicket={handleCreateTicket}
                onSelectTicket={handleSelectTicket}
                onSendMessage={handleSendMessage}
                onCloseTicket={handleCloseTicket}
            />
        </div>
    );
}