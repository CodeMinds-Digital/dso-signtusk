import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    StatisticCard,
    MetricsGrid,
    ProgressMetric,
    StatusMetric,
    BarChart,
    LineChart,
    DataTable
} from "@docusign-alternative/ui";
import {
    FileText,
    Users,
    Clock,
    TrendingUp,
    Upload,
    Plus,
    Settings,
    MoreHorizontal,
    Bell,
    Activity,
    CheckCircle,
    AlertCircle,
    Calendar,
    Download,
    Share,
    Edit,
    Trash2,
    Filter,
    RefreshCw,
    Grid3X3,
    List,
    Eye,
    BarChart3,
    PieChart,
    Rocket
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";
import { useState, useEffect } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Dashboard - DocuSign Alternative" },
        { name: "description", content: "Your document signing dashboard" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
    });
}

export default function Dashboard() {
    const { user } = useLoaderData<typeof loader>();
    const [dashboardLayout, setDashboardLayout] = useState('grid');
    const [selectedTimeRange, setSelectedTimeRange] = useState('7d');
    const [refreshing, setRefreshing] = useState(false);

    // Real tRPC queries
    const userQuery = trpc.user.getProfile.useQuery();
    const authQuery = trpc.auth.getSession.useQuery();

    // Enhanced dashboard metrics with real-time updates
    const dashboardMetrics = [
        {
            title: "Total Documents",
            value: 1247,
            change: { value: 12.5, type: 'increase' as const, period: 'last month' },
            icon: <FileText />,
            description: 'Documents processed this month',
            trend: [
                { date: '2024-01-01', value: 1100 },
                { date: '2024-01-02', value: 1150 },
                { date: '2024-01-03', value: 1180 },
                { date: '2024-01-04', value: 1200 },
                { date: '2024-01-05', value: 1220 },
                { date: '2024-01-06', value: 1235 },
                { date: '2024-01-07', value: 1247 }
            ]
        },
        {
            title: "Pending Signatures",
            value: 23,
            change: { value: -8.2, type: 'decrease' as const, period: 'last week' },
            icon: <Clock />,
            description: 'Awaiting signatures',
            trend: [
                { date: '2024-01-01', value: 35 },
                { date: '2024-01-02', value: 32 },
                { date: '2024-01-03', value: 28 },
                { date: '2024-01-04', value: 25 },
                { date: '2024-01-05', value: 24 },
                { date: '2024-01-06', value: 23 },
                { date: '2024-01-07', value: 23 }
            ]
        },
        {
            title: "Team Members",
            value: 47,
            change: { value: 6.4, type: 'increase' as const, period: 'last month' },
            icon: <Users />,
            description: 'Active team members',
            trend: [
                { date: '2024-01-01', value: 42 },
                { date: '2024-01-02', value: 43 },
                { date: '2024-01-03', value: 44 },
                { date: '2024-01-04', value: 45 },
                { date: '2024-01-05', value: 46 },
                { date: '2024-01-06', value: 47 },
                { date: '2024-01-07', value: 47 }
            ]
        },
        {
            title: "Completion Rate",
            value: '94.8%',
            change: { value: 2.1, type: 'increase' as const, period: 'last week' },
            icon: <TrendingUp />,
            description: 'Document completion success rate',
            trend: [
                { date: '2024-01-01', value: 92.5 },
                { date: '2024-01-02', value: 93.1 },
                { date: '2024-01-03', value: 93.8 },
                { date: '2024-01-04', value: 94.2 },
                { date: '2024-01-05', value: 94.5 },
                { date: '2024-01-06', value: 94.7 },
                { date: '2024-01-07', value: 94.8 }
            ]
        }
    ];

    // Recent activity data
    const recentActivities = [
        {
            id: '1',
            type: 'document_signed',
            title: 'Contract Agreement signed',
            description: 'John Doe completed signature on Contract-2024-001.pdf',
            timestamp: '2 minutes ago',
            status: 'success',
            avatar: 'JD'
        },
        {
            id: '2',
            type: 'document_uploaded',
            title: 'New document uploaded',
            description: 'Sarah Wilson uploaded NDA-Template-v2.pdf',
            timestamp: '15 minutes ago',
            status: 'info',
            avatar: 'SW'
        },
        {
            id: '3',
            type: 'reminder_sent',
            title: 'Reminder sent',
            description: 'Signature reminder sent to mike@company.com',
            timestamp: '1 hour ago',
            status: 'warning',
            avatar: 'SY'
        },
        {
            id: '4',
            type: 'template_created',
            title: 'Template created',
            description: 'New template "Employee Onboarding" created',
            timestamp: '2 hours ago',
            status: 'success',
            avatar: 'AL'
        },
        {
            id: '5',
            type: 'user_invited',
            title: 'Team member invited',
            description: 'Invitation sent to alex@company.com',
            timestamp: '3 hours ago',
            status: 'info',
            avatar: 'HR'
        }
    ];

    // Chart data for analytics
    const documentTypeData = [
        { label: 'Contracts', value: 450, color: '#3b82f6' },
        { label: 'NDAs', value: 320, color: '#ef4444' },
        { label: 'Agreements', value: 280, color: '#10b981' },
        { label: 'Forms', value: 197, color: '#f59e0b' }
    ];

    const weeklySignatureData = [
        { date: '2024-01-01', value: 45 },
        { date: '2024-01-02', value: 52 },
        { date: '2024-01-03', value: 48 },
        { date: '2024-01-04', value: 61 },
        { date: '2024-01-05', value: 55 },
        { date: '2024-01-06', value: 67 },
        { date: '2024-01-07', value: 73 }
    ];

    // Recent documents table data
    const recentDocuments = [
        {
            id: 1,
            name: 'Contract-2024-001.pdf',
            status: 'Completed',
            signers: 3,
            created: '2024-01-15',
            lastActivity: '2 min ago'
        },
        {
            id: 2,
            name: 'NDA-Template-v2.pdf',
            status: 'Pending',
            signers: 2,
            created: '2024-01-14',
            lastActivity: '15 min ago'
        },
        {
            id: 3,
            name: 'Employee-Onboarding.pdf',
            status: 'In Progress',
            signers: 4,
            created: '2024-01-13',
            lastActivity: '1 hour ago'
        }
    ];

    const documentColumns = [
        { key: 'name', title: 'Document Name', sortable: true },
        {
            key: 'status',
            title: 'Status',
            render: (value: string) => (
                <Badge variant={
                    value === 'Completed' ? 'default' :
                        value === 'Pending' ? 'secondary' : 'outline'
                }>
                    {value}
                </Badge>
            )
        },
        { key: 'signers', title: 'Signers', sortable: true },
        { key: 'created', title: 'Created', sortable: true },
        { key: 'lastActivity', title: 'Last Activity', sortable: true }
    ];

    // Quick actions with contextual menus
    const quickActions = [
        {
            title: 'Upload Document',
            description: 'Upload a new document for signing',
            icon: <Upload className="h-5 w-5" />,
            href: '/upload',
            color: 'bg-blue-500 hover:bg-blue-600'
        },
        {
            title: 'Create Template',
            description: 'Create a reusable document template',
            icon: <Plus className="h-5 w-5" />,
            href: '/templates/create',
            color: 'bg-green-500 hover:bg-green-600'
        },
        {
            title: 'Invite Team Member',
            description: 'Add a new member to your team',
            icon: <Users className="h-5 w-5" />,
            href: '/organization/members/invite',
            color: 'bg-purple-500 hover:bg-purple-600'
        },
        {
            title: 'View Analytics',
            description: 'See detailed analytics and reports',
            icon: <BarChart3 className="h-5 w-5" />,
            href: '/analytics',
            color: 'bg-orange-500 hover:bg-orange-600'
        }
    ];

    const handleRefresh = async () => {
        setRefreshing(true);
        // Simulate API refresh
        await new Promise(resolve => setTimeout(resolve, 1000));
        setRefreshing(false);
    };

    const getActivityIcon = (type: string) => {
        switch (type) {
            case 'document_signed':
                return <CheckCircle className="h-4 w-4 text-green-600" />;
            case 'document_uploaded':
                return <Upload className="h-4 w-4 text-blue-600" />;
            case 'reminder_sent':
                return <Bell className="h-4 w-4 text-yellow-600" />;
            case 'template_created':
                return <Plus className="h-4 w-4 text-purple-600" />;
            case 'user_invited':
                return <Users className="h-4 w-4 text-indigo-600" />;
            default:
                return <Activity className="h-4 w-4 text-gray-600" />;
        }
    };

    return (
        <Layout user={user}>
            <div className="p-6 space-y-6" data-tour="dashboard">
                {/* Enhanced Header with Controls */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                        <p className="text-gray-600 mt-1">
                            Welcome back! Here's what's happening with your documents.
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={handleRefresh}
                            disabled={refreshing}
                        >
                            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                            Refresh
                        </Button>
                        <Button variant="outline" size="sm">
                            <Filter className="h-4 w-4 mr-2" />
                            Filter
                        </Button>
                        <Button variant="outline" size="sm">
                            <Settings className="h-4 w-4 mr-2" />
                            Customize
                        </Button>
                        <Button variant="ghost" size="sm" asChild>
                            <a href="/onboarding">
                                <Rocket className="h-4 w-4 mr-2" />
                                Onboarding
                            </a>
                        </Button>
                    </div>
                </div>

                {/* Enhanced Metrics Grid */}
                <MetricsGrid metrics={dashboardMetrics} columns={4} />

                {/* Quick Actions Grid */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Activity className="h-5 w-5" />
                            Quick Actions
                        </CardTitle>
                        <CardDescription>
                            Get started with common tasks and workflows
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            {quickActions.map((action, index) => (
                                <Button
                                    key={index}
                                    variant="outline"
                                    className="h-auto p-4 flex flex-col items-start gap-2 hover:shadow-md transition-shadow"
                                    asChild
                                    data-tour={
                                        action.href === '/upload' ? 'upload' :
                                            action.href === '/templates/create' ? 'templates' :
                                                action.href === '/organization/members/invite' ? 'team' :
                                                    action.href === '/analytics' ? 'analytics' : undefined
                                    }
                                >
                                    <a href={action.href}>
                                        <div className={`p-2 rounded-lg text-white ${action.color}`}>
                                            {action.icon}
                                        </div>
                                        <div className="text-left">
                                            <div className="font-medium text-gray-900">{action.title}</div>
                                            <div className="text-sm text-gray-500">{action.description}</div>
                                        </div>
                                    </a>
                                </Button>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Analytics and Activity Row */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Document Analytics */}
                    <div className="lg:col-span-2 space-y-6">
                        <BarChart
                            data={documentTypeData}
                            title="Document Types"
                            height={300}
                            showValues={true}
                        />

                        <LineChart
                            data={weeklySignatureData}
                            title="Weekly Signature Activity"
                            height={250}
                            color="#10b981"
                            showDots={true}
                        />
                    </div>

                    {/* Recent Activity Feed */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center justify-between">
                                <span className="flex items-center gap-2">
                                    <Bell className="h-5 w-5" />
                                    Recent Activity
                                </span>
                                <Button variant="ghost" size="sm">
                                    <Eye className="h-4 w-4" />
                                </Button>
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {recentActivities.map((activity) => (
                                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                                    <div className="flex-shrink-0">
                                        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium">
                                            {activity.avatar}
                                        </div>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                            {getActivityIcon(activity.type)}
                                            <p className="text-sm font-medium text-gray-900 truncate">
                                                {activity.title}
                                            </p>
                                        </div>
                                        <p className="text-xs text-gray-600 mb-1">
                                            {activity.description}
                                        </p>
                                        <p className="text-xs text-gray-400">
                                            {activity.timestamp}
                                        </p>
                                    </div>
                                </div>
                            ))}
                            <Button variant="outline" className="w-full" size="sm">
                                View All Activity
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                {/* Progress Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <ProgressMetric
                        title="Monthly Document Goal"
                        current={1247}
                        target={1500}
                        unit="documents"
                        color="blue"
                        showPercentage={true}
                    />
                    <StatusMetric
                        title="System Health"
                        status="success"
                        value="99.2%"
                        description="Uptime this month"
                    />
                    <StatusMetric
                        title="Processing Queue"
                        status="warning"
                        value={12}
                        description="Documents in queue"
                    />
                </div>

                {/* Recent Documents Table */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                            <span className="flex items-center gap-2">
                                <FileText className="h-5 w-5" />
                                Recent Documents
                            </span>
                            <Button variant="outline" size="sm" asChild>
                                <a href="/documents">
                                    View All
                                </a>
                            </Button>
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <DataTable
                            columns={documentColumns}
                            data={recentDocuments}
                            pagination={{
                                current: 1,
                                pageSize: 5,
                                total: recentDocuments.length,
                                showSizeChanger: false
                            }}
                            size="small"
                        />
                    </CardContent>
                </Card>

                {/* System Status */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Activity className="h-5 w-5" />
                            System Status
                        </CardTitle>
                        <CardDescription>
                            API integration and service status
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-4">
                                <div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium">User Profile Service</span>
                                        <Badge variant={userQuery.isError ? "destructive" : userQuery.isLoading ? "secondary" : "default"}>
                                            {userQuery.isLoading ? 'Loading' : userQuery.isError ? 'Error' : 'Connected'}
                                        </Badge>
                                    </div>
                                    {userQuery.error && (
                                        <p className="text-sm text-red-600 mt-1">
                                            Mock error for demonstration
                                        </p>
                                    )}
                                </div>

                                <div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium">Authentication Service</span>
                                        <Badge variant={authQuery.isError ? "destructive" : authQuery.isLoading ? "secondary" : "default"}>
                                            {authQuery.isLoading ? 'Loading' : authQuery.isError ? 'Error' : 'Connected'}
                                        </Badge>
                                    </div>
                                    {authQuery.error && (
                                        <p className="text-sm text-red-600 mt-1">
                                            Mock error for demonstration
                                        </p>
                                    )}
                                </div>
                            </div>

                            <div className="space-y-3">
                                <div>
                                    <dt className="text-sm font-medium text-gray-500">User ID</dt>
                                    <dd className="text-sm text-gray-900">{user.userId}</dd>
                                </div>
                                <div>
                                    <dt className="text-sm font-medium text-gray-500">Organization</dt>
                                    <dd className="text-sm text-gray-900">
                                        {user.organizationId || 'Personal Account'}
                                    </dd>
                                </div>
                                <div>
                                    <dt className="text-sm font-medium text-gray-500">Roles</dt>
                                    <dd className="flex gap-1 flex-wrap">
                                        {user.roles.length > 0 ? (
                                            user.roles.map((role) => (
                                                <Badge key={role} variant="secondary">
                                                    {role}
                                                </Badge>
                                            ))
                                        ) : (
                                            <span className="text-sm text-gray-500">No roles assigned</span>
                                        )}
                                    </dd>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </Layout>
    );
}