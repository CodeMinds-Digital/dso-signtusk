import { useState } from "react";
import {
    ErrorPage,
    InlineError,
    EmptyState,
    CompactEmptyState,
    ListEmptyState,
    OfflineIndicator,
    SyncStatus,
    OfflineBanner,
    useNetworkStatus,
    type ErrorType,
    type EmptyStateType,
    type ConnectionStatus
} from "@docusign-alternative/ui";

export default function ErrorStatesDemo() {
    const [selectedErrorType, setSelectedErrorType] = useState<ErrorType>("404");
    const [selectedEmptyType, setSelectedEmptyType] = useState<EmptyStateType>("documents");
    const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("online");
    const [showOfflineBanner, setShowOfflineBanner] = useState(false);
    const { isOnline } = useNetworkStatus();

    const errorTypes: ErrorType[] = ["404", "403", "500", "network", "offline", "timeout", "validation", "generic"];
    const emptyTypes: EmptyStateType[] = ["documents", "folders", "templates", "search", "notifications", "team-members", "signatures"];
    const connectionStatuses: ConnectionStatus[] = ["online", "offline", "reconnecting", "syncing", "error"];

    return (
        <div className="min-h-screen bg-background">
            {/* Offline Banner Demo */}
            {showOfflineBanner && (
                <OfflineBanner
                    show={showOfflineBanner}
                    onRetry={() => setShowOfflineBanner(false)}
                    position="top"
                />
            )}

            <div className="container mx-auto py-8 space-y-12">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-foreground mb-2">
                        Error & Empty States Demo
                    </h1>
                    <p className="text-muted-foreground">
                        Comprehensive error handling and empty state components for the e-signature platform
                    </p>
                </div>

                {/* Network Status */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Network Status</h2>
                    <div className="space-y-4">
                        <div className="flex items-center gap-4">
                            <span className="text-sm font-medium">Actual Status:</span>
                            <OfflineIndicator
                                status={isOnline ? "online" : "offline"}
                                variant="minimal"
                            />
                        </div>

                        <div className="flex items-center gap-4">
                            <span className="text-sm font-medium">Demo Status:</span>
                            <div className="flex gap-2">
                                {connectionStatuses.map((status) => (
                                    <button
                                        key={status}
                                        onClick={() => setConnectionStatus(status)}
                                        className={`px-3 py-1 rounded text-sm ${connectionStatus === status
                                                ? "bg-primary text-primary-foreground"
                                                : "bg-muted text-muted-foreground hover:bg-muted/80"
                                            }`}
                                    >
                                        {status}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <OfflineIndicator
                            status={connectionStatus}
                            onRetry={() => setConnectionStatus("online")}
                        />

                        <SyncStatus
                            status={connectionStatus === "syncing" ? "syncing" : connectionStatus === "online" ? "synced" : "error"}
                            lastSyncTime={new Date(Date.now() - 2 * 60 * 1000)}
                            pendingChanges={connectionStatus === "offline" ? 3 : 0}
                            onSync={() => setConnectionStatus("syncing")}
                        />

                        <button
                            onClick={() => setShowOfflineBanner(!showOfflineBanner)}
                            className="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600"
                        >
                            {showOfflineBanner ? "Hide" : "Show"} Offline Banner
                        </button>
                    </div>
                </div>

                {/* Error Pages */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Error Pages</h2>

                    <div className="space-y-4">
                        <div className="flex gap-2 flex-wrap">
                            {errorTypes.map((type) => (
                                <button
                                    key={type}
                                    onClick={() => setSelectedErrorType(type)}
                                    className={`px-3 py-1 rounded text-sm ${selectedErrorType === type
                                            ? "bg-primary text-primary-foreground"
                                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                                        }`}
                                >
                                    {type}
                                </button>
                            ))}
                        </div>

                        <div className="border rounded-lg p-4 bg-background">
                            <ErrorPage
                                type={selectedErrorType}
                                variant="card"
                                size="md"
                                errorCode={selectedErrorType === "500" ? "ERR_500_001" : undefined}
                                errorId={selectedErrorType === "500" ? "error-123456789" : undefined}
                                onRetry={() => alert("Retry clicked")}
                                onGoHome={() => alert("Go Home clicked")}
                                onGoBack={() => alert("Go Back clicked")}
                            />
                        </div>
                    </div>
                </div>

                {/* Inline Errors */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Inline Errors</h2>

                    <div className="space-y-4 max-w-md">
                        <InlineError
                            type="validation"
                            title="Validation Error"
                            description="Please check the required fields and try again."
                            onRetry={() => alert("Retry clicked")}
                            onDismiss={() => alert("Dismissed")}
                        />

                        <InlineError
                            type="network"
                            description="Unable to save changes. Please check your connection."
                            onRetry={() => alert("Retry clicked")}
                        />

                        <InlineError
                            type="403"
                            description="You don't have permission to perform this action."
                        />
                    </div>
                </div>

                {/* Empty States */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Empty States</h2>

                    <div className="space-y-4">
                        <div className="flex gap-2 flex-wrap">
                            {emptyTypes.map((type) => (
                                <button
                                    key={type}
                                    onClick={() => setSelectedEmptyType(type)}
                                    className={`px-3 py-1 rounded text-sm ${selectedEmptyType === type
                                            ? "bg-primary text-primary-foreground"
                                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                                        }`}
                                >
                                    {type.replace("-", " ")}
                                </button>
                            ))}
                        </div>

                        <div className="border rounded-lg p-4 bg-background">
                            <EmptyState
                                type={selectedEmptyType}
                                variant="card"
                                size="md"
                                onPrimaryAction={() => alert("Primary action clicked")}
                                onSecondaryAction={() => alert("Secondary action clicked")}
                            />
                        </div>
                    </div>
                </div>

                {/* Compact Empty States */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Compact Empty States</h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div className="border rounded-lg">
                            <CompactEmptyState
                                type="notifications"
                                onAction={() => alert("Action clicked")}
                            />
                        </div>

                        <div className="border rounded-lg">
                            <CompactEmptyState
                                type="search"
                                title="No matches"
                                description="Try different keywords"
                                onAction={() => alert("Clear search clicked")}
                                actionLabel="Clear Search"
                            />
                        </div>

                        <div className="border rounded-lg">
                            <CompactEmptyState
                                type="favorites"
                                onAction={() => alert("Browse clicked")}
                                actionLabel="Browse Documents"
                            />
                        </div>
                    </div>
                </div>

                {/* List Empty States */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">List Empty States</h2>

                    <div className="space-y-4">
                        <ListEmptyState
                            type="documents"
                            onAction={() => alert("Upload document clicked")}
                        />

                        <ListEmptyState
                            type="search"
                            showBorder={false}
                            onAction={() => alert("Clear filters clicked")}
                        />
                    </div>
                </div>

                {/* Interactive Examples */}
                <div className="bg-card border rounded-lg p-6">
                    <h2 className="text-xl font-semibold mb-4">Interactive Examples</h2>

                    <div className="space-y-6">
                        <div>
                            <h3 className="font-medium mb-2">Document List Simulation</h3>
                            <DocumentListExample />
                        </div>

                        <div>
                            <h3 className="font-medium mb-2">Error Recovery Simulation</h3>
                            <ErrorRecoveryExample />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

// Interactive component examples
function DocumentListExample() {
    const [documents, setDocuments] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);

    const addDocument = () => {
        setLoading(true);
        setTimeout(() => {
            setDocuments(prev => [...prev, `Document ${prev.length + 1}.pdf`]);
            setLoading(false);
        }, 1000);
    };

    const clearDocuments = () => {
        setDocuments([]);
    };

    if (loading) {
        return (
            <div className="border rounded-lg p-8 text-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-muted-foreground">Uploading document...</p>
            </div>
        );
    }

    if (documents.length === 0) {
        return (
            <ListEmptyState
                type="documents"
                onAction={addDocument}
            />
        );
    }

    return (
        <div className="border rounded-lg">
            <div className="p-4 border-b flex justify-between items-center">
                <h4 className="font-medium">Documents ({documents.length})</h4>
                <div className="flex gap-2">
                    <button
                        onClick={addDocument}
                        className="px-3 py-1 bg-primary text-primary-foreground rounded text-sm hover:bg-primary/90"
                    >
                        Add Document
                    </button>
                    <button
                        onClick={clearDocuments}
                        className="px-3 py-1 bg-muted text-muted-foreground rounded text-sm hover:bg-muted/80"
                    >
                        Clear All
                    </button>
                </div>
            </div>
            <div className="divide-y">
                {documents.map((doc, index) => (
                    <div key={index} className="p-3 flex items-center justify-between">
                        <span>{doc}</span>
                        <button
                            onClick={() => setDocuments(prev => prev.filter((_, i) => i !== index))}
                            className="text-red-500 hover:text-red-700 text-sm"
                        >
                            Delete
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
}

function ErrorRecoveryExample() {
    const [errorState, setErrorState] = useState<"none" | "network" | "500" | "recovered">("none");

    const simulateError = (type: "network" | "500") => {
        setErrorState(type);
    };

    const recover = () => {
        setErrorState("recovered");
        setTimeout(() => setErrorState("none"), 2000);
    };

    if (errorState === "none") {
        return (
            <div className="border rounded-lg p-6 text-center">
                <h4 className="font-medium mb-2">Application Running Normally</h4>
                <p className="text-muted-foreground mb-4">Click a button to simulate an error</p>
                <div className="flex gap-2 justify-center">
                    <button
                        onClick={() => simulateError("network")}
                        className="px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600"
                    >
                        Simulate Network Error
                    </button>
                    <button
                        onClick={() => simulateError("500")}
                        className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                    >
                        Simulate Server Error
                    </button>
                </div>
            </div>
        );
    }

    if (errorState === "recovered") {
        return (
            <div className="border rounded-lg p-6 text-center bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800">
                <div className="text-green-600 dark:text-green-400 mb-2">✓</div>
                <h4 className="font-medium text-green-700 dark:text-green-400">Recovered Successfully!</h4>
                <p className="text-green-600 dark:text-green-500 text-sm">The application is working normally again.</p>
            </div>
        );
    }

    return (
        <ErrorPage
            type={errorState}
            variant="card"
            size="sm"
            onRetry={recover}
            onGoHome={() => setErrorState("none")}
        />
    );
}