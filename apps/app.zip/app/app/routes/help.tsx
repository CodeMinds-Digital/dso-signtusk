import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import { useState } from "react";
import { HelpCenter } from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Help Center - DocuSign Alternative" },
        { name: "description", content: "Find answers to your questions and get help with our platform" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    // In a real implementation, you might want to fetch initial data here
    // For now, we'll use the tRPC client on the frontend
    return json({});
}

export default function HelpPage() {
    const navigate = useNavigate();
    const [searchResults, setSearchResults] = useState<any>({
        articles: [],
        faqs: [],
        totalResults: 0,
    });

    // Fetch help data using tRPC
    const { data: categories } = trpc.helpSupport.getCategories.useQuery();
    const { data: popularArticles } = trpc.helpSupport.getPopularArticles.useQuery();
    const { data: faqs } = trpc.helpSupport.getFAQs.useQuery({ limit: 10 });

    // Search mutation
    const searchMutation = trpc.helpSupport.searchHelp.useMutation({
        onSuccess: (data) => {
            setSearchResults(data);
        },
    });

    // Rate article mutation
    const rateArticleMutation = trpc.helpSupport.rateArticle.useMutation();

    const handleSearch = (query: string, category?: string) => {
        searchMutation.mutate({
            query,
            category: category as any,
            limit: 20,
        });
    };

    const handleArticleRate = (articleId: string, rating: number, feedback?: string) => {
        rateArticleMutation.mutate({
            articleId,
            rating,
            feedback,
        });
    };

    const handleCreateTicket = () => {
        navigate('/help/support');
    };

    // Combine search results with default data
    const articles = searchResults.articles.length > 0 ? searchResults.articles : (popularArticles || []);
    const faqItems = searchResults.faqs.length > 0 ? searchResults.faqs : (faqs || []);

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <HelpCenter
                articles={articles}
                faqs={faqItems}
                categories={categories || []}
                onSearch={handleSearch}
                onArticleRate={handleArticleRate}
                onCreateTicket={handleCreateTicket}
            />
        </div>
    );
}