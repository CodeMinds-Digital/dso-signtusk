import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useActionData, useSearchParams, useNavigation } from "@remix-run/react";
import { TwoFactorVerify } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Two-Factor Authentication - DocuSign Alternative" },
        { name: "description", content: "Enter your two-factor authentication code" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    // Check if user has a pending 2FA session
    // In a real implementation, check for 2FA token in session
    return json({});
}

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const code = formData.get("code");
    const method = formData.get("method");
    const redirectTo = formData.get("redirectTo") || "/dashboard";

    if (typeof code !== "string" || !code) {
        return json(
            { error: "Verification code is required" },
            { status: 400 }
        );
    }

    try {
        // In a real implementation, verify the 2FA code
        if (method === "totp" && code === "123456") {
            // Mock successful verification
            return redirect(typeof redirectTo === "string" ? redirectTo : "/dashboard");
        } else if (method === "backup" && code === "12345678") {
            // Mock successful backup code verification
            return redirect(typeof redirectTo === "string" ? redirectTo : "/dashboard");
        } else {
            return json(
                { error: "Invalid verification code. Please try again." },
                { status: 400 }
            );
        }
    } catch (error) {
        return json(
            { error: "Verification failed. Please try again." },
            { status: 500 }
        );
    }
}

export default function Verify2FA() {
    const actionData = useActionData<typeof action>();
    const [searchParams] = useSearchParams();
    const navigation = useNavigation();
    const redirectTo = searchParams.get("redirectTo") || "/dashboard";
    const isLoading = navigation.state === "submitting";

    const handleVerify = async (code: string, method: "totp" | "backup") => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const codeInput = document.createElement('input');
        codeInput.name = 'code';
        codeInput.value = code;
        form.appendChild(codeInput);

        const methodInput = document.createElement('input');
        methodInput.name = 'method';
        methodInput.value = method;
        form.appendChild(methodInput);

        const redirectInput = document.createElement('input');
        redirectInput.name = 'redirectTo';
        redirectInput.value = redirectTo;
        form.appendChild(redirectInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleBack = () => {
        window.location.href = '/login';
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full">
                <TwoFactorVerify
                    onVerify={handleVerify}
                    onBack={handleBack}
                    isLoading={isLoading}
                    error={actionData?.error}
                />
            </div>
        </div>
    );
}