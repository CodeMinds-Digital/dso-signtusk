import React, { useState } from 'react';
import { json, type LoaderFunctionArgs, type MetaFunction } from '@remix-run/node';
import { useLoaderData, useNavigate } from '@remix-run/react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Container,
    Grid,
    DataTable,
} from "@docusign-alternative/ui";
import {
    Plus,
    Download,
    Share,
    Edit,
    Trash2,
    Calendar,
    BarChart3,
    FileText,
    Clock,
} from "@docusign-alternative/ui";
import { trpc } from '~/lib/trpc';
import { requireAuth } from '~/lib/session.server';
import CustomReportBuilder, { type ReportConfig } from '~/components/custom-report-builder';
import { format } from 'date-fns';

export const meta: MetaFunction = () => {
    return [
        { title: "Custom Reports - DocuSign Alternative" },
        { name: "description", content: "Create and manage custom analytics reports" },
    ];
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
    const user = await requireAuth(request);
    return json({ user });
};

interface SavedReport {
    id: string;
    name: string;
    description?: string;
    reportType: string;
    createdAt: string;
    lastRun?: string;
    status: 'draft' | 'active' | 'archived';
    config: ReportConfig;
}

export default function CustomReports() {
    const { user } = useLoaderData<typeof loader>();
    const navigate = useNavigate();

    const [activeTab, setActiveTab] = useState('builder');
    const [selectedReport, setSelectedReport] = useState<SavedReport | null>(null);
    const [isBuilderOpen, setIsBuilderOpen] = useState(false);

    // Mock saved reports - in real implementation, this would come from the database
    const [savedReports] = useState<SavedReport[]>([
        {
            id: 'report-1',
            name: 'Monthly Usage Summary',
            description: 'Comprehensive monthly usage analytics',
            reportType: 'usage',
            createdAt: '2024-01-15T10:30:00Z',
            lastRun: '2024-01-20T09:15:00Z',
            status: 'active',
            config: {
                name: 'Monthly Usage Summary',
                reportType: 'usage',
                timeRange: {
                    startDate: '2024-01-01T00:00:00Z',
                    endDate: '2024-01-31T23:59:59Z',
                },
                filters: {},
                groupBy: 'day',
                metrics: ['documents_created', 'documents_completed', 'active_users'],
                visualizations: [
                    { type: 'line', metric: 'documents_created', title: 'Documents Created Over Time' },
                    { type: 'bar', metric: 'active_users', title: 'Daily Active Users' },
                ],
            },
        },
        {
            id: 'report-2',
            name: 'Team Performance Report',
            description: 'Weekly team performance metrics',
            reportType: 'performance',
            createdAt: '2024-01-10T14:20:00Z',
            lastRun: '2024-01-18T16:45:00Z',
            status: 'active',
            config: {
                name: 'Team Performance Report',
                reportType: 'performance',
                timeRange: {
                    startDate: '2024-01-01T00:00:00Z',
                    endDate: '2024-01-31T23:59:59Z',
                },
                filters: {},
                groupBy: 'team',
                metrics: ['completion_rate', 'average_completion_time'],
                visualizations: [
                    { type: 'bar', metric: 'completion_rate', title: 'Team Completion Rates' },
                ],
            },
        },
        {
            id: 'report-3',
            name: 'Cost Analysis Q1',
            description: 'Quarterly cost breakdown and projections',
            reportType: 'cost',
            createdAt: '2024-01-05T11:00:00Z',
            status: 'draft',
            config: {
                name: 'Cost Analysis Q1',
                reportType: 'cost',
                timeRange: {
                    startDate: '2024-01-01T00:00:00Z',
                    endDate: '2024-03-31T23:59:59Z',
                },
                filters: {},
                groupBy: 'month',
                metrics: ['total_cost', 'cost_per_user'],
                visualizations: [
                    { type: 'pie', metric: 'total_cost', title: 'Cost Distribution' },
                ],
            },
        },
    ]);

    // tRPC mutations
    const generateReportMutation = trpc.analytics.getCustomReport.useMutation({
        onSuccess: (data) => {
            console.log('Report generated:', data);
            // Handle successful report generation
        },
    });

    const exportMutation = trpc.analytics.exportData.useMutation({
        onSuccess: (data) => {
            console.log('Export started:', data);
            // Handle export success
        },
    });

    const handleSaveReport = (config: ReportConfig) => {
        console.log('Saving report:', config);
        // In real implementation, save to database
        setIsBuilderOpen(false);
    };

    const handleGenerateReport = (config: ReportConfig) => {
        generateReportMutation.mutate({
            reportType: config.reportType,
            timeRange: config.timeRange,
            filters: config.filters,
            groupBy: config.groupBy,
        });
        setIsBuilderOpen(false);
    };

    const handleRunReport = (report: SavedReport) => {
        generateReportMutation.mutate({
            reportType: report.config.reportType,
            timeRange: report.config.timeRange,
            filters: report.config.filters,
            groupBy: report.config.groupBy,
        });
    };

    const handleExportReport = (reportId: string, format: 'csv' | 'xlsx' | 'pdf') => {
        const report = savedReports.find(r => r.id === reportId);
        if (report) {
            exportMutation.mutate({
                reportType: 'custom',
                format,
                timeRange: report.config.timeRange,
                includeCharts: format === 'pdf',
            });
        }
    };

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'active':
                return <Badge className="bg-green-100 text-green-800">Active</Badge>;
            case 'draft':
                return <Badge variant="outline">Draft</Badge>;
            case 'archived':
                return <Badge variant="secondary">Archived</Badge>;
            default:
                return <Badge variant="outline">{status}</Badge>;
        }
    };

    const getReportTypeIcon = (type: string) => {
        switch (type) {
            case 'usage':
                return <BarChart3 className="h-5 w-5 text-blue-600" />;
            case 'performance':
                return <Clock className="h-5 w-5 text-green-600" />;
            case 'compliance':
                return <FileText className="h-5 w-5 text-purple-600" />;
            case 'cost':
                return <Calendar className="h-5 w-5 text-orange-600" />;
            default:
                return <BarChart3 className="h-5 w-5 text-gray-600" />;
        }
    };

    return (
        <Container className="py-6">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Custom Reports</h1>
                        <p className="text-gray-600 mt-1">
                            Create, manage, and generate custom analytics reports
                        </p>
                    </div>
                    <Button onClick={() => setIsBuilderOpen(true)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Report
                    </Button>
                </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                <TabsList>
                    <TabsTrigger value="builder">Report Builder</TabsTrigger>
                    <TabsTrigger value="saved">Saved Reports</TabsTrigger>
                    <TabsTrigger value="templates">Templates</TabsTrigger>
                </TabsList>

                {/* Report Builder Tab */}
                <TabsContent value="builder">
                    {isBuilderOpen ? (
                        <CustomReportBuilder
                            onSave={handleSaveReport}
                            onGenerate={handleGenerateReport}
                            initialConfig={selectedReport?.config}
                        />
                    ) : (
                        <Card>
                            <CardContent className="flex flex-col items-center justify-center py-12">
                                <BarChart3 className="h-12 w-12 text-gray-400 mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">
                                    Create Custom Reports
                                </h3>
                                <p className="text-gray-600 text-center mb-6 max-w-md">
                                    Use our intuitive report builder to create custom analytics reports
                                    with advanced filtering and visualization options.
                                </p>
                                <Button onClick={() => setIsBuilderOpen(true)}>
                                    <Plus className="h-4 w-4 mr-2" />
                                    Start Building
                                </Button>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                {/* Saved Reports Tab */}
                <TabsContent value="saved" className="space-y-6">
                    <div className="grid gap-6">
                        {savedReports.map((report) => (
                            <Card key={report.id}>
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-start gap-3">
                                            {getReportTypeIcon(report.reportType)}
                                            <div>
                                                <CardTitle className="text-lg">{report.name}</CardTitle>
                                                {report.description && (
                                                    <CardDescription className="mt-1">
                                                        {report.description}
                                                    </CardDescription>
                                                )}
                                                <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                                                    <span>Created: {format(new Date(report.createdAt), 'MMM dd, yyyy')}</span>
                                                    {report.lastRun && (
                                                        <span>Last run: {format(new Date(report.lastRun), 'MMM dd, yyyy')}</span>
                                                    )}
                                                    <span className="capitalize">{report.reportType} Report</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {getStatusBadge(report.status)}
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-4 text-sm text-gray-600">
                                            <span>{report.config.metrics.length} metrics</span>
                                            <span>{report.config.visualizations.length} visualizations</span>
                                            <span className="capitalize">Grouped by {report.config.groupBy}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() => handleRunReport(report)}
                                                disabled={generateReportMutation.isPending}
                                            >
                                                <BarChart3 className="h-4 w-4 mr-2" />
                                                Run Report
                                            </Button>
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() => {
                                                    setSelectedReport(report);
                                                    setActiveTab('builder');
                                                    setIsBuilderOpen(true);
                                                }}
                                            >
                                                <Edit className="h-4 w-4 mr-2" />
                                                Edit
                                            </Button>
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() => handleExportReport(report.id, 'pdf')}
                                                disabled={exportMutation.isPending}
                                            >
                                                <Download className="h-4 w-4 mr-2" />
                                                Export
                                            </Button>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    {savedReports.length === 0 && (
                        <Card>
                            <CardContent className="flex flex-col items-center justify-center py-12">
                                <FileText className="h-12 w-12 text-gray-400 mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">
                                    No saved reports
                                </h3>
                                <p className="text-gray-600 text-center mb-6">
                                    Create your first custom report to get started
                                </p>
                                <Button onClick={() => {
                                    setActiveTab('builder');
                                    setIsBuilderOpen(true);
                                }}>
                                    <Plus className="h-4 w-4 mr-2" />
                                    Create Report
                                </Button>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                {/* Templates Tab */}
                <TabsContent value="templates" className="space-y-6">
                    <Grid cols={2} gap={6}>
                        {[
                            {
                                name: 'Monthly Usage Summary',
                                description: 'Comprehensive monthly usage analytics with key metrics',
                                type: 'usage',
                                metrics: ['Documents Created', 'Active Users', 'Completion Rate'],
                            },
                            {
                                name: 'Team Performance Dashboard',
                                description: 'Team-based performance metrics and comparisons',
                                type: 'performance',
                                metrics: ['Completion Rate', 'Average Time', 'Team Rankings'],
                            },
                            {
                                name: 'Compliance Audit Report',
                                description: 'Regulatory compliance and audit trail analysis',
                                type: 'compliance',
                                metrics: ['Audit Completeness', 'Signature Validity', 'Access Logs'],
                            },
                            {
                                name: 'Cost Analysis Report',
                                description: 'Detailed cost breakdown and budget analysis',
                                type: 'cost',
                                metrics: ['Total Costs', 'Per-User Costs', 'Overage Analysis'],
                            },
                        ].map((template, index) => (
                            <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                                <CardHeader>
                                    <div className="flex items-start gap-3">
                                        {getReportTypeIcon(template.type)}
                                        <div className="flex-1">
                                            <CardTitle className="text-lg">{template.name}</CardTitle>
                                            <CardDescription className="mt-1">
                                                {template.description}
                                            </CardDescription>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        <div>
                                            <p className="text-sm font-medium text-gray-700 mb-2">Included Metrics:</p>
                                            <div className="flex flex-wrap gap-2">
                                                {template.metrics.map((metric) => (
                                                    <Badge key={metric} variant="outline" className="text-xs">
                                                        {metric}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <Button
                                            className="w-full"
                                            onClick={() => {
                                                // Load template into builder
                                                setActiveTab('builder');
                                                setIsBuilderOpen(true);
                                            }}
                                        >
                                            Use Template
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </Grid>
                </TabsContent>
            </Tabs>
        </Container>
    );
}