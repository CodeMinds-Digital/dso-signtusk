import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, useActionData, Form, useNavigation, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Textarea,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Switch,
    Badge,
    Alert,
    AlertDescription,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Separator,
    Avatar,
    AvatarFallback,
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    useToast,
} from "@docusign-alternative/ui";
import {
    Share,
    Users,
    Globe,
    Lock,
    Mail,
    Copy,
    Eye,
    Edit,
    Trash2,
    Plus,
    ArrowLeft,
    Calendar,
    Clock,
    Shield,
    ExternalLink,
    UserPlus,
    Settings,
    CheckCircle,
    XCircle,
    AlertCircle,
    Info,
} from "@docusign-alternative/ui";
import { useState, useEffect } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Share Template - DocuSign Alternative" },
        { name: "description", content: "Manage template sharing and permissions" },
    ];
};

interface TemplateShare {
    id: string;
    shareType: 'internal' | 'external' | 'public';
    targetType: 'user' | 'team' | 'organization' | 'email';
    targetId?: string;
    targetName: string;
    targetEmail?: string;
    permissions: {
        canView: boolean;
        canUse: boolean;
        canDuplicate: boolean;
        canEdit: boolean;
        canShare: boolean;
    };
    status: 'active' | 'pending' | 'expired' | 'revoked';
    createdAt: string;
    expiresAt?: string;
    lastUsed?: string;
    usageCount: number;
    shareToken?: string;
    publicUrl?: string;
}

interface Template {
    id: string;
    name: string;
    description?: string;
    category: string;
    isPublic: boolean;
    createdBy: string;
    createdAt: string;
    permissions: {
        canView: boolean;
        canEdit: boolean;
        canDelete: boolean;
        canShare: boolean;
    };
}

export async function loader({ request, params }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const templateId = params.templateId;

    if (!templateId) {
        throw new Response("Template not found", { status: 404 });
    }

    // Mock template data
    const template: Template = {
        id: templateId,
        name: "Employment Contract Template",
        description: "Comprehensive employment contract with signature fields for HR department",
        category: "HR",
        isPublic: false,
        createdBy: "HR Team",
        createdAt: "2024-01-10T10:30:00Z",
        permissions: {
            canView: true,
            canEdit: true,
            canDelete: true,
            canShare: true,
        },
    };

    // Mock existing shares
    const shares: TemplateShare[] = [
        {
            id: "share-1",
            shareType: 'internal',
            targetType: 'user',
            targetId: "user-1",
            targetName: "Sarah Johnson",
            targetEmail: "sarah.johnson@company.com",
            permissions: {
                canView: true,
                canUse: true,
                canDuplicate: true,
                canEdit: false,
                canShare: false,
            },
            status: 'active',
            createdAt: "2024-01-15T10:30:00Z",
            lastUsed: "2024-01-18T14:20:00Z",
            usageCount: 5,
        },
        {
            id: "share-2",
            shareType: 'internal',
            targetType: 'team',
            targetId: "team-1",
            targetName: "Legal Team",
            permissions: {
                canView: true,
                canUse: true,
                canDuplicate: false,
                canEdit: false,
                canShare: false,
            },
            status: 'active',
            createdAt: "2024-01-12T09:15:00Z",
            lastUsed: "2024-01-17T11:45:00Z",
            usageCount: 12,
        },
        {
            id: "share-3",
            shareType: 'external',
            targetType: 'email',
            targetName: "John Doe",
            targetEmail: "john.doe@external.com",
            permissions: {
                canView: true,
                canUse: true,
                canDuplicate: false,
                canEdit: false,
                canShare: false,
            },
            status: 'pending',
            createdAt: "2024-01-19T16:30:00Z",
            expiresAt: "2024-02-19T16:30:00Z",
            usageCount: 0,
            shareToken: "abc123def456",
        },
        {
            id: "share-4",
            shareType: 'public',
            targetType: 'organization',
            targetName: "Public Access",
            permissions: {
                canView: true,
                canUse: true,
                canDuplicate: true,
                canEdit: false,
                canShare: false,
            },
            status: 'active',
            createdAt: "2024-01-08T12:00:00Z",
            usageCount: 28,
            publicUrl: "https://app.example.com/templates/public/template-1",
        },
    ];

    // Mock available users and teams for sharing
    const availableTargets = {
        users: [
            { id: "user-2", name: "Mike Chen", email: "mike.chen@company.com", role: "Manager" },
            { id: "user-3", name: "Lisa Wang", email: "lisa.wang@company.com", role: "Developer" },
            { id: "user-4", name: "Tom Wilson", email: "tom.wilson@company.com", role: "Designer" },
        ],
        teams: [
            { id: "team-2", name: "Sales Team", memberCount: 8 },
            { id: "team-3", name: "Finance Team", memberCount: 5 },
            { id: "team-4", name: "Operations Team", memberCount: 12 },
        ],
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        template,
        shares,
        availableTargets,
    });
}

export async function action({ request, params }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const templateId = params.templateId;
    const formData = await request.formData();
    const action = formData.get("action");

    try {
        switch (action) {
            case "create-share":
                // Handle creating new share
                const shareData = {
                    shareType: formData.get("shareType"),
                    targetType: formData.get("targetType"),
                    targetId: formData.get("targetId"),
                    targetEmail: formData.get("targetEmail"),
                    permissions: JSON.parse(formData.get("permissions")?.toString() || "{}"),
                    expiresAt: formData.get("expiresAt"),
                    message: formData.get("message"),
                };

                // Validate share data
                const errors: string[] = [];
                if (!shareData.shareType) errors.push("Share type is required");
                if (!shareData.targetType) errors.push("Target type is required");
                if (shareData.targetType === 'email' && !shareData.targetEmail) {
                    errors.push("Email address is required");
                }

                if (errors.length > 0) {
                    return json({ success: false, errors }, { status: 400 });
                }

                return json({
                    success: true,
                    message: "Template shared successfully",
                    shareId: `share-${Date.now()}`,
                });

            case "update-share":
                const shareId = formData.get("shareId");
                const updatedPermissions = JSON.parse(formData.get("permissions")?.toString() || "{}");

                return json({
                    success: true,
                    message: "Share permissions updated successfully",
                });

            case "revoke-share":
                const revokeShareId = formData.get("shareId");

                return json({
                    success: true,
                    message: "Share access revoked successfully",
                });

            case "copy-link":
                const copyShareId = formData.get("shareId");

                return json({
                    success: true,
                    message: "Share link copied to clipboard",
                });

            default:
                return json({ success: false, errors: ["Invalid action"] }, { status: 400 });
        }
    } catch (error) {
        return json({
            success: false,
            errors: ["An error occurred while processing your request"]
        }, { status: 500 });
    }
}

export default function ShareTemplate() {
    const { user, template, shares, availableTargets } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const { toast } = useToast();

    const [showNewShareDialog, setShowNewShareDialog] = useState(false);
    const [shareType, setShareType] = useState<'internal' | 'external' | 'public'>('internal');
    const [targetType, setTargetType] = useState<'user' | 'team' | 'email'>('user');
    const [selectedTarget, setSelectedTarget] = useState<string>('');
    const [externalEmail, setExternalEmail] = useState('');
    const [permissions, setPermissions] = useState({
        canView: true,
        canUse: true,
        canDuplicate: false,
        canEdit: false,
        canShare: false,
    });
    const [expiresAt, setExpiresAt] = useState('');
    const [message, setMessage] = useState('');

    const isLoading = navigation.state === "submitting";

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
        });
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'active':
                return 'bg-green-100 text-green-800 border-green-200';
            case 'pending':
                return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'expired':
                return 'bg-gray-100 text-gray-800 border-gray-200';
            case 'revoked':
                return 'bg-red-100 text-red-800 border-red-200';
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'active':
                return <CheckCircle className="h-4 w-4" />;
            case 'pending':
                return <Clock className="h-4 w-4" />;
            case 'expired':
                return <XCircle className="h-4 w-4" />;
            case 'revoked':
                return <XCircle className="h-4 w-4" />;
            default:
                return <AlertCircle className="h-4 w-4" />;
        }
    };

    const handleCreateShare = async () => {
        const formData = new FormData();
        formData.append("action", "create-share");
        formData.append("shareType", shareType);
        formData.append("targetType", targetType);

        if (targetType === 'email') {
            formData.append("targetEmail", externalEmail);
        } else {
            formData.append("targetId", selectedTarget);
        }

        formData.append("permissions", JSON.stringify(permissions));
        formData.append("expiresAt", expiresAt);
        formData.append("message", message);

        // Submit form programmatically
        const form = document.createElement("form");
        form.method = "POST";
        form.style.display = "none";

        for (const [key, value] of formData.entries()) {
            const input = document.createElement("input");
            input.name = key;
            input.value = value.toString();
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
    };

    const handleRevokeShare = async (shareId: string) => {
        const formData = new FormData();
        formData.append("action", "revoke-share");
        formData.append("shareId", shareId);

        // Submit form programmatically
        const form = document.createElement("form");
        form.method = "POST";
        form.style.display = "none";

        for (const [key, value] of formData.entries()) {
            const input = document.createElement("input");
            input.name = key;
            input.value = value.toString();
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
    };

    const copyToClipboard = async (text: string) => {
        try {
            await navigator.clipboard.writeText(text);
            toast({
                title: "Copied to clipboard",
                description: "The share link has been copied to your clipboard.",
            });
        } catch (error) {
            toast({
                title: "Failed to copy",
                description: "Could not copy the link to clipboard.",
                variant: "destructive",
            });
        }
    };

    // Show success/error messages from action
    useEffect(() => {
        if (actionData) {
            if (actionData.success) {
                toast({
                    title: "Success",
                    description: 'message' in actionData ? actionData.message : "Operation completed successfully",
                });
                if ('shareId' in actionData && actionData.shareId) {
                    setShowNewShareDialog(false);
                    // Reset form
                    setSelectedTarget('');
                    setExternalEmail('');
                    setMessage('');
                    setExpiresAt('');
                }
            } else if ('errors' in actionData && actionData.errors) {
                toast({
                    title: "Error",
                    description: actionData.errors.join(", "),
                    variant: "destructive",
                });
            }
        }
    }, [actionData, toast]);

    return (
        <Layout user={user}>
            <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center space-x-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to={`/templates/${template.id}`}>
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to Template
                            </Link>
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">Share Template</h1>
                            <p className="text-gray-600 mt-1">Manage sharing and permissions for "{template.name}"</p>
                        </div>
                    </div>
                    <div className="mt-4 sm:mt-0">
                        <Button onClick={() => setShowNewShareDialog(true)}>
                            <Share className="mr-2 h-4 w-4" />
                            New Share
                        </Button>
                    </div>
                </div>

                {/* Template Info */}
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-4">
                                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <Share className="h-6 w-6 text-blue-600" />
                                </div>
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-900">{template.name}</h3>
                                    <p className="text-gray-600">{template.description}</p>
                                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                                        <span>Category: {template.category}</span>
                                        <span>Created: {formatDate(template.createdAt)}</span>
                                        <span>By: {template.createdBy}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center space-x-2">
                                {template.isPublic ? (
                                    <Badge className="bg-green-100 text-green-800 border-green-200">
                                        <Globe className="mr-1 h-3 w-3" />
                                        Public
                                    </Badge>
                                ) : (
                                    <Badge variant="outline">
                                        <Lock className="mr-1 h-3 w-3" />
                                        Private
                                    </Badge>
                                )}
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Sharing Overview */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
                    <Card>
                        <CardContent className="p-6 text-center">
                            <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900">{shares.length}</div>
                            <div className="text-sm text-gray-600">Total Shares</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6 text-center">
                            <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900">
                                {shares.filter(s => s.status === 'active').length}
                            </div>
                            <div className="text-sm text-gray-600">Active Shares</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6 text-center">
                            <Clock className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900">
                                {shares.filter(s => s.status === 'pending').length}
                            </div>
                            <div className="text-sm text-gray-600">Pending</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6 text-center">
                            <Eye className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900">
                                {shares.reduce((sum, s) => sum + s.usageCount, 0)}
                            </div>
                            <div className="text-sm text-gray-600">Total Usage</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Shares List */}
                <Card>
                    <CardHeader>
                        <CardTitle>Current Shares</CardTitle>
                        <CardDescription>
                            Manage who has access to this template and their permissions
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {shares.length === 0 ? (
                            <div className="text-center py-8">
                                <Share className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No shares yet</h3>
                                <p className="text-gray-600 mb-4">
                                    Share this template with team members or external users to collaborate.
                                </p>
                                <Button onClick={() => setShowNewShareDialog(true)}>
                                    <Share className="mr-2 h-4 w-4" />
                                    Create First Share
                                </Button>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {shares.map((share) => (
                                    <div key={share.id} className="p-4 border rounded-lg">
                                        <div className="flex items-start justify-between">
                                            <div className="flex items-start space-x-3">
                                                <Avatar className="w-10 h-10">
                                                    <AvatarFallback>
                                                        {share.targetName.charAt(0).toUpperCase()}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <div className="flex-1">
                                                    <div className="flex items-center space-x-2 mb-1">
                                                        <h4 className="font-medium text-gray-900">{share.targetName}</h4>
                                                        <Badge className={getStatusColor(share.status)}>
                                                            {getStatusIcon(share.status)}
                                                            <span className="ml-1">{share.status}</span>
                                                        </Badge>
                                                        <Badge variant="outline">
                                                            {share.shareType}
                                                        </Badge>
                                                    </div>
                                                    {share.targetEmail && (
                                                        <p className="text-sm text-gray-600 mb-2">{share.targetEmail}</p>
                                                    )}
                                                    <div className="flex flex-wrap gap-1 mb-2">
                                                        {share.permissions.canView && <Badge variant="outline" className="text-xs">View</Badge>}
                                                        {share.permissions.canUse && <Badge variant="outline" className="text-xs">Use</Badge>}
                                                        {share.permissions.canDuplicate && <Badge variant="outline" className="text-xs">Duplicate</Badge>}
                                                        {share.permissions.canEdit && <Badge variant="outline" className="text-xs">Edit</Badge>}
                                                        {share.permissions.canShare && <Badge variant="outline" className="text-xs">Share</Badge>}
                                                    </div>
                                                    <div className="text-xs text-gray-500 space-y-1">
                                                        <div>Created: {formatDate(share.createdAt)}</div>
                                                        {share.lastUsed && <div>Last used: {formatDate(share.lastUsed)}</div>}
                                                        {share.expiresAt && <div>Expires: {formatDate(share.expiresAt)}</div>}
                                                        <div>Usage: {share.usageCount} times</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                {share.shareToken && (
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        onClick={() => copyToClipboard(`https://app.example.com/templates/shared/${share.shareToken}`)}
                                                    >
                                                        <Copy className="h-4 w-4" />
                                                    </Button>
                                                )}
                                                {share.publicUrl && (
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        onClick={() => copyToClipboard(share.publicUrl!)}
                                                    >
                                                        <ExternalLink className="h-4 w-4" />
                                                    </Button>
                                                )}
                                                <Button variant="outline" size="sm">
                                                    <Edit className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleRevokeShare(share.id)}
                                                    className="text-red-600 hover:text-red-700"
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* New Share Dialog */}
                <Dialog open={showNewShareDialog} onOpenChange={setShowNewShareDialog}>
                    <DialogContent className="max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Share Template</DialogTitle>
                            <DialogDescription>
                                Configure sharing permissions and access controls for this template.
                            </DialogDescription>
                        </DialogHeader>

                        <div className="space-y-6">
                            {/* Share Type */}
                            <Tabs value={shareType} onValueChange={(value) => setShareType(value as any)}>
                                <TabsList className="grid w-full grid-cols-3">
                                    <TabsTrigger value="internal">Internal</TabsTrigger>
                                    <TabsTrigger value="external">External</TabsTrigger>
                                    <TabsTrigger value="public">Public</TabsTrigger>
                                </TabsList>

                                <TabsContent value="internal" className="space-y-4">
                                    <div>
                                        <Label>Share with</Label>
                                        <Select value={targetType} onValueChange={(value) => setTargetType(value as any)}>
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="user">Individual User</SelectItem>
                                                <SelectItem value="team">Team</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    {targetType === 'user' && (
                                        <div>
                                            <Label>Select User</Label>
                                            <Select value={selectedTarget} onValueChange={setSelectedTarget}>
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Choose a user..." />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {availableTargets.users.map((user) => (
                                                        <SelectItem key={user.id} value={user.id}>
                                                            {user.name} ({user.email})
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    )}

                                    {targetType === 'team' && (
                                        <div>
                                            <Label>Select Team</Label>
                                            <Select value={selectedTarget} onValueChange={setSelectedTarget}>
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Choose a team..." />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {availableTargets.teams.map((team) => (
                                                        <SelectItem key={team.id} value={team.id}>
                                                            {team.name} ({team.memberCount} members)
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    )}
                                </TabsContent>

                                <TabsContent value="external" className="space-y-4">
                                    <div>
                                        <Label htmlFor="external-email">Email Address</Label>
                                        <Input
                                            id="external-email"
                                            type="email"
                                            placeholder="Enter email address..."
                                            value={externalEmail}
                                            onChange={(e) => setExternalEmail(e.target.value)}
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="expiration">Expiration Date (Optional)</Label>
                                        <Input
                                            id="expiration"
                                            type="datetime-local"
                                            value={expiresAt}
                                            onChange={(e) => setExpiresAt(e.target.value)}
                                        />
                                    </div>
                                </TabsContent>

                                <TabsContent value="public" className="space-y-4">
                                    <Alert>
                                        <Info className="h-4 w-4" />
                                        <AlertDescription>
                                            Making this template public will allow anyone with the link to view and use it.
                                            This will override the template's private setting.
                                        </AlertDescription>
                                    </Alert>
                                </TabsContent>
                            </Tabs>

                            {/* Permissions */}
                            <div className="space-y-4">
                                <Label>Permissions</Label>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="can-view"
                                            checked={permissions.canView}
                                            onCheckedChange={(checked) => setPermissions({ ...permissions, canView: checked })}
                                        />
                                        <Label htmlFor="can-view">Can View</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="can-use"
                                            checked={permissions.canUse}
                                            onCheckedChange={(checked) => setPermissions({ ...permissions, canUse: checked })}
                                        />
                                        <Label htmlFor="can-use">Can Use</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="can-duplicate"
                                            checked={permissions.canDuplicate}
                                            onCheckedChange={(checked) => setPermissions({ ...permissions, canDuplicate: checked })}
                                        />
                                        <Label htmlFor="can-duplicate">Can Duplicate</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="can-edit"
                                            checked={permissions.canEdit}
                                            onCheckedChange={(checked) => setPermissions({ ...permissions, canEdit: checked })}
                                        />
                                        <Label htmlFor="can-edit">Can Edit</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            id="can-share"
                                            checked={permissions.canShare}
                                            onCheckedChange={(checked) => setPermissions({ ...permissions, canShare: checked })}
                                        />
                                        <Label htmlFor="can-share">Can Share</Label>
                                    </div>
                                </div>
                            </div>

                            {/* Message */}
                            <div>
                                <Label htmlFor="share-message">Message (Optional)</Label>
                                <Textarea
                                    id="share-message"
                                    placeholder="Add a message for the recipients..."
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                />
                            </div>

                            {/* Actions */}
                            <div className="flex justify-end space-x-2">
                                <Button variant="outline" onClick={() => setShowNewShareDialog(false)}>
                                    Cancel
                                </Button>
                                <Button onClick={handleCreateShare} disabled={isLoading}>
                                    {isLoading ? "Sharing..." : "Share Template"}
                                </Button>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>
        </Layout>
    );
}