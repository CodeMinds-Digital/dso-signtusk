import { useState, useEffect } from 'react';
import {
    Activity,
    Users,
    FileText,
    Shield,
    Server,
    Database,
    Mail,
    HardDrive,
    TrendingUp,
    AlertTriangle,
    CheckCircle,
    Clock
} from 'lucide-react';

export default function AdminDashboard() {
    const [systemHealth, setSystemHealth] = useState<any>(null);
    const [metrics, setMetrics] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulate API calls
        const fetchData = async () => {
            // Simulate system health data
            setSystemHealth({
                status: 'healthy',
                uptime: 7 * 24 * 60 * 60, // 7 days in seconds
                version: '1.0.0',
                lastDeployment: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
                services: {
                    database: {
                        status: 'healthy',
                        responseTime: 15,
                        connections: 25,
                        maxConnections: 100,
                    },
                    redis: {
                        status: 'healthy',
                        responseTime: 2,
                        memory: 128 * 1024 * 1024,
                        maxMemory: 512 * 1024 * 1024,
                    },
                    storage: {
                        status: 'healthy',
                        used: 50 * 1024 * 1024 * 1024,
                        available: 200 * 1024 * 1024 * 1024,
                    },
                    email: {
                        status: 'healthy',
                        queueSize: 5,
                        sentToday: 1250,
                        failedToday: 3,
                    },
                },
                metrics: {
                    activeUsers: 145,
                    documentsProcessed: 1250,
                    signingRequestsCompleted: 875,
                    apiRequestsPerHour: 2500,
                    errorRate: 0.02,
                },
            });

            setMetrics({
                users: {
                    total: 1250,
                    active: 145,
                    newToday: 12,
                    growth: 8.5,
                },
                documents: {
                    total: 15420,
                    processedToday: 89,
                    storage: 125.5, // GB
                    growth: 12.3,
                },
                signingRequests: {
                    total: 8750,
                    completedToday: 45,
                    completionRate: 87.5,
                    growth: 15.2,
                },
                security: {
                    eventsToday: 23,
                    criticalEvents: 2,
                    resolvedEvents: 21,
                    threatLevel: 'low',
                },
            });

            setLoading(false);
        };

        fetchData();
    }, []);

    const formatUptime = (seconds: number) => {
        const days = Math.floor(seconds / (24 * 60 * 60));
        const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
        const minutes = Math.floor((seconds % (60 * 60)) / 60);
        return `${days}d ${hours}h ${minutes}m`;
    };

    const formatBytes = (bytes: number) => {
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes === 0) return '0 Bytes';
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'healthy':
                return 'text-green-600 bg-green-100';
            case 'warning':
                return 'text-yellow-600 bg-yellow-100';
            case 'error':
                return 'text-red-600 bg-red-100';
            default:
                return 'text-gray-600 bg-gray-100';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* System Status Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center">
                        <div className="flex-shrink-0">
                            <CheckCircle className="h-8 w-8 text-green-600" />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm font-medium text-gray-600">System Status</p>
                            <p className={`text-lg font-semibold capitalize ${getStatusColor(systemHealth.status)}`}>
                                {systemHealth.status}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center">
                        <div className="flex-shrink-0">
                            <Clock className="h-8 w-8 text-blue-600" />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm font-medium text-gray-600">Uptime</p>
                            <p className="text-lg font-semibold text-gray-900">
                                {formatUptime(systemHealth.uptime)}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center">
                        <div className="flex-shrink-0">
                            <Users className="h-8 w-8 text-purple-600" />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm font-medium text-gray-600">Active Users</p>
                            <p className="text-lg font-semibold text-gray-900">
                                {systemHealth.metrics.activeUsers}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center">
                        <div className="flex-shrink-0">
                            <Activity className="h-8 w-8 text-orange-600" />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm font-medium text-gray-600">API Requests/Hour</p>
                            <p className="text-lg font-semibold text-gray-900">
                                {systemHealth.metrics.apiRequestsPerHour.toLocaleString()}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-medium text-gray-600">Total Users</p>
                            <p className="text-2xl font-bold text-gray-900">{metrics.users.total.toLocaleString()}</p>
                            <p className="text-sm text-green-600 flex items-center mt-1">
                                <TrendingUp className="h-4 w-4 mr-1" />
                                +{metrics.users.growth}% this month
                            </p>
                        </div>
                        <Users className="h-8 w-8 text-blue-600" />
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-medium text-gray-600">Documents</p>
                            <p className="text-2xl font-bold text-gray-900">{metrics.documents.total.toLocaleString()}</p>
                            <p className="text-sm text-green-600 flex items-center mt-1">
                                <TrendingUp className="h-4 w-4 mr-1" />
                                +{metrics.documents.growth}% this month
                            </p>
                        </div>
                        <FileText className="h-8 w-8 text-green-600" />
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-medium text-gray-600">Signing Requests</p>
                            <p className="text-2xl font-bold text-gray-900">{metrics.signingRequests.total.toLocaleString()}</p>
                            <p className="text-sm text-green-600 flex items-center mt-1">
                                <TrendingUp className="h-4 w-4 mr-1" />
                                +{metrics.signingRequests.growth}% this month
                            </p>
                        </div>
                        <Shield className="h-8 w-8 text-purple-600" />
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-medium text-gray-600">Security Events</p>
                            <p className="text-2xl font-bold text-gray-900">{metrics.security.eventsToday}</p>
                            <p className="text-sm text-yellow-600 flex items-center mt-1">
                                <AlertTriangle className="h-4 w-4 mr-1" />
                                {metrics.security.criticalEvents} critical
                            </p>
                        </div>
                        <AlertTriangle className="h-8 w-8 text-red-600" />
                    </div>
                </div>
            </div>

            {/* Service Health */}
            <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900">Service Health</h3>
                </div>
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {/* Database */}
                        <div className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center space-x-2">
                                    <Database className="h-5 w-5 text-blue-600" />
                                    <span className="font-medium">Database</span>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(systemHealth.services.database.status)}`}>
                                    {systemHealth.services.database.status}
                                </span>
                            </div>
                            <div className="space-y-2 text-sm text-gray-600">
                                <div className="flex justify-between">
                                    <span>Response Time:</span>
                                    <span>{systemHealth.services.database.responseTime}ms</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Connections:</span>
                                    <span>{systemHealth.services.database.connections}/{systemHealth.services.database.maxConnections}</span>
                                </div>
                            </div>
                        </div>

                        {/* Redis */}
                        <div className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center space-x-2">
                                    <Server className="h-5 w-5 text-red-600" />
                                    <span className="font-medium">Redis</span>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(systemHealth.services.redis.status)}`}>
                                    {systemHealth.services.redis.status}
                                </span>
                            </div>
                            <div className="space-y-2 text-sm text-gray-600">
                                <div className="flex justify-between">
                                    <span>Response Time:</span>
                                    <span>{systemHealth.services.redis.responseTime}ms</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Memory:</span>
                                    <span>{formatBytes(systemHealth.services.redis.memory)}</span>
                                </div>
                            </div>
                        </div>

                        {/* Storage */}
                        <div className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center space-x-2">
                                    <HardDrive className="h-5 w-5 text-green-600" />
                                    <span className="font-medium">Storage</span>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(systemHealth.services.storage.status)}`}>
                                    {systemHealth.services.storage.status}
                                </span>
                            </div>
                            <div className="space-y-2 text-sm text-gray-600">
                                <div className="flex justify-between">
                                    <span>Used:</span>
                                    <span>{formatBytes(systemHealth.services.storage.used)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Available:</span>
                                    <span>{formatBytes(systemHealth.services.storage.available)}</span>
                                </div>
                            </div>
                        </div>

                        {/* Email */}
                        <div className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center space-x-2">
                                    <Mail className="h-5 w-5 text-purple-600" />
                                    <span className="font-medium">Email</span>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(systemHealth.services.email.status)}`}>
                                    {systemHealth.services.email.status}
                                </span>
                            </div>
                            <div className="space-y-2 text-sm text-gray-600">
                                <div className="flex justify-between">
                                    <span>Queue Size:</span>
                                    <span>{systemHealth.services.email.queueSize}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Sent Today:</span>
                                    <span>{systemHealth.services.email.sentToday}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Recent Activity Summary */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow">
                    <div className="px-6 py-4 border-b border-gray-200">
                        <h3 className="text-lg font-medium text-gray-900">Today's Activity</h3>
                    </div>
                    <div className="p-6">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">New Users</span>
                                <span className="font-medium">{metrics.users.newToday}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Documents Processed</span>
                                <span className="font-medium">{metrics.documents.processedToday}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Signing Requests Completed</span>
                                <span className="font-medium">{metrics.signingRequests.completedToday}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Security Events</span>
                                <span className="font-medium">{metrics.security.eventsToday}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow">
                    <div className="px-6 py-4 border-b border-gray-200">
                        <h3 className="text-lg font-medium text-gray-900">System Information</h3>
                    </div>
                    <div className="p-6">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Version</span>
                                <span className="font-medium">{systemHealth.version}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Last Deployment</span>
                                <span className="font-medium">
                                    {systemHealth.lastDeployment.toLocaleDateString()}
                                </span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Error Rate</span>
                                <span className="font-medium">{(systemHealth.metrics.errorRate * 100).toFixed(2)}%</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Completion Rate</span>
                                <span className="font-medium">{metrics.signingRequests.completionRate}%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}