import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { Link, useActionData, useNavigation } from "@remix-run/react";
import { getUserSession, createUserSession } from "~/lib/session.server";
import { RegistrationForm, RegistrationFormData, Card, CardContent, CardDescription, CardHeader, CardTitle, defaultProviders } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Register - DocuSign Alternative" },
        { name: "description", content: "Create your account" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await getUserSession(request);
    if (userSession) {
        return redirect("/dashboard");
    }
    return json({});
}

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const intent = formData.get("intent");

    // Handle OAuth provider registration
    if (intent === "oauth") {
        const provider = formData.get("provider");

        if (typeof provider !== "string") {
            return json(
                { error: "Invalid OAuth provider" },
                { status: 400 }
            );
        }

        try {
            // In a real implementation, redirect to OAuth provider
            // For now, we'll simulate OAuth success
            const mockUserId = `oauth-${provider}-${Date.now()}`;

            return await createUserSession({
                request,
                userId: mockUserId,
                remember: false,
                redirectTo: "/dashboard",
            });
        } catch (error) {
            return json(
                { error: `Failed to register with ${provider}` },
                { status: 400 }
            );
        }
    }

    // Handle regular email/password registration
    const email = formData.get("email");
    const password = formData.get("password");
    const confirmPassword = formData.get("confirmPassword");
    const firstName = formData.get("firstName");
    const lastName = formData.get("lastName");

    if (
        typeof email !== "string" ||
        typeof password !== "string" ||
        typeof confirmPassword !== "string" ||
        typeof firstName !== "string" ||
        typeof lastName !== "string"
    ) {
        return json(
            { error: "All fields are required" },
            { status: 400 }
        );
    }

    if (!email || !password || !confirmPassword || !firstName || !lastName) {
        return json(
            { error: "All fields are required" },
            { status: 400 }
        );
    }

    if (password !== confirmPassword) {
        return json(
            { error: "Passwords do not match" },
            { status: 400 }
        );
    }

    // Password strength validation is now handled by the form component
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return json(
            { error: "Please enter a valid email address" },
            { status: 400 }
        );
    }

    try {
        // In a real implementation, you would create the user here
        // For now, we'll create a mock user session
        const mockUserId = `user-${Date.now()}`; // This should come from actual user creation

        return await createUserSession({
            request,
            userId: mockUserId,
            remember: false,
            redirectTo: "/dashboard",
        });
    } catch (error) {
        return json(
            { error: "Failed to create account. Please try again." },
            { status: 500 }
        );
    }
}

export default function Register() {
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    // OAuth providers configuration
    const oauthProviders = [
        defaultProviders.google,
        defaultProviders.microsoft,
        defaultProviders.github,
    ];

    const handleRegister = async (data: RegistrationFormData) => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        // Add form data
        Object.entries(data).forEach(([key, value]) => {
            const input = document.createElement('input');
            input.name = key;
            input.value = value;
            form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
    };

    const handleOAuthProvider = async (providerId: string) => {
        // Create a form and submit it for OAuth
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const intentInput = document.createElement('input');
        intentInput.name = 'intent';
        intentInput.value = 'oauth';
        form.appendChild(intentInput);

        const providerInput = document.createElement('input');
        providerInput.name = 'provider';
        providerInput.value = providerId;
        form.appendChild(providerInput);

        document.body.appendChild(form);
        form.submit();
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full">
                <Card>
                    <CardHeader className="text-center">
                        <CardTitle className="text-2xl font-bold">Create your account</CardTitle>
                        <CardDescription>
                            Already have an account?{" "}
                            <Link
                                to="/login"
                                className="font-medium text-blue-600 hover:text-blue-500"
                            >
                                Sign in
                            </Link>
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <RegistrationForm
                            onSubmit={handleRegister}
                            onOAuthProvider={handleOAuthProvider}
                            error={actionData?.error}
                            isLoading={isSubmitting}
                            oauthProviders={oauthProviders}
                            oauthLoading={isSubmitting}
                        />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}