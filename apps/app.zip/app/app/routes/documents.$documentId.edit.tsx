import type { LoaderFunctionArgs, ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, useNavigate, useActionData, Form } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { trpc } from "~/lib/trpc";
import { useState, useCallback, useEffect, useRef } from "react";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Input,
    Label,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    Separator,
    ScrollArea,
    Toast,
    useToast,
    PDFViewer,
    FieldConfiguration,
    RecipientRoleManager,
    Alert,
    AlertDescription,
    Switch,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Textarea,
} from "@docusign-alternative/ui";
import {
    Save,
    Send,
    Eye,
    Settings,
    Users,
    FileText,
    ArrowLeft,
    MoreHorizontal,
    Download,
    Share,
    Copy,
    Trash2,
    AlertCircle,
    CheckCircle,
    Clock,
    PenTool,
    Type,
    Calendar,
    CheckSquare,
    Hash,
    Paperclip,
    MousePointer,
    Undo,
    Redo,
    ZoomIn,
    ZoomOut,
    RotateCw,
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Edit Document - DocuSign Alternative" },
        { name: "description", content: "Edit document fields and recipients" },
    ];
};

export async function loader({ request, params }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const { documentId } = params;

    if (!documentId) {
        throw new Response("Document ID is required", { status: 400 });
    }

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        documentId,
    });
}

export async function action({ request, params }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const { documentId } = params;
    const formData = await request.formData();
    const action = formData.get("_action");

    // Handle different actions (save, send, etc.)
    switch (action) {
        case "save":
            // Save document changes
            return json({ success: true, message: "Document saved successfully" });
        case "send":
            // Send document for signing
            return json({ success: true, message: "Document sent for signing" });
        case "preview":
            // Generate preview
            return json({ success: true, message: "Preview generated" });
        default:
            return json({ error: "Invalid action" }, { status: 400 });
    }
}

interface DocumentField {
    id: string;
    type: "signature" | "text" | "date" | "checkbox" | "initial" | "number";
    x: number;
    y: number;
    width: number;
    height: number;
    page: number;
    required?: boolean;
    placeholder?: string;
    value?: string;
    recipientId?: string;
    recipientRole?: string;
    properties?: Record<string, any>;
}

interface RecipientRole {
    id: string;
    role: string;
    name?: string;
    email?: string;
    order: number;
    authMethod: string;
    isRequired: boolean;
    permissions: {
        canSign: boolean;
        canApprove: boolean;
        canReview: boolean;
        canDelegate: boolean;
        mustAuthenticate: boolean;
    };
    color?: string;
    description?: string;
}

export default function DocumentEditor() {
    const { user, documentId } = useLoaderData<typeof loader>();
    const navigate = useNavigate();
    const actionData = useActionData<typeof action>();
    const { toast } = useToast();

    // Document state
    const [document, setDocument] = useState<any>(null);
    const [fields, setFields] = useState<DocumentField[]>([]);
    const [recipients, setRecipients] = useState<RecipientRole[]>([]);
    const [selectedField, setSelectedField] = useState<DocumentField | null>(null);
    const [activeTab, setActiveTab] = useState("fields");

    // PDF viewer state
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [zoom, setZoom] = useState(1.0);
    const [rotation, setRotation] = useState(0);
    const [isFieldPlacementMode, setIsFieldPlacementMode] = useState(false);
    const [selectedFieldType, setSelectedFieldType] = useState<DocumentField["type"]>("signature");

    // Document settings state
    const [documentSettings, setDocumentSettings] = useState({
        title: "",
        description: "",
        expirationDate: "",
        reminderInterval: "3",
        requireAllRecipients: true,
        allowDelegation: false,
        requireAuthentication: false,
        enableAuditTrail: true,
    });

    // UI state
    const [isSaving, setIsSaving] = useState(false);
    const [showPreview, setShowPreview] = useState(false);
    const [showSendDialog, setShowSendDialog] = useState(false);
    const [sidebarWidth, setSidebarWidth] = useState(400);
    const [isResizing, setIsResizing] = useState(false);

    // tRPC queries and mutations
    const { data: documentData, isLoading: documentLoading, error: documentError } =
        trpc.document.get.useQuery({
            documentId,
            includeFields: true,
            includeRecipients: true,
        });

    const { mutate: saveDocument } = trpc.document.update.useMutation({
        onSuccess: () => {
            toast({
                title: "Document saved",
                description: "Your changes have been saved successfully",
            });
            setIsSaving(false);
        },
        onError: (error) => {
            toast({
                title: "Save failed",
                description: error.message,
                variant: "destructive",
            });
            setIsSaving(false);
        },
    });

    const { mutate: sendForSigning } = trpc.document.sendForSigning.useMutation({
        onSuccess: () => {
            toast({
                title: "Document sent",
                description: "Document has been sent for signing",
            });
            navigate("/documents");
        },
        onError: (error) => {
            toast({
                title: "Send failed",
                description: error.message,
                variant: "destructive",
            });
        },
    });

    // Initialize document data
    useEffect(() => {
        if (documentData) {
            setDocument(documentData);
            setFields(documentData.fields || []);
            setRecipients(documentData.recipients || []);
            setTotalPages(documentData.pageCount || 1);
            setDocumentSettings({
                title: documentData.title || "",
                description: documentData.description || "",
                expirationDate: documentData.expirationDate || "",
                reminderInterval: documentData.reminderInterval?.toString() || "3",
                requireAllRecipients: documentData.requireAllRecipients ?? true,
                allowDelegation: documentData.allowDelegation ?? false,
                requireAuthentication: documentData.requireAuthentication ?? false,
                enableAuditTrail: documentData.enableAuditTrail ?? true,
            });
        }
    }, [documentData]);

    // Handle field operations
    const handleFieldAdd = useCallback((field: Omit<DocumentField, "id">) => {
        const newField: DocumentField = {
            ...field,
            id: `field_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        };
        setFields(prev => [...prev, newField]);
        setSelectedField(newField);
    }, []);

    const handleFieldUpdate = useCallback((fieldId: string, updates: Partial<DocumentField>) => {
        setFields(prev => prev.map(field =>
            field.id === fieldId ? { ...field, ...updates } : field
        ));
        if (selectedField?.id === fieldId) {
            setSelectedField(prev => prev ? { ...prev, ...updates } : null);
        }
    }, [selectedField]);

    const handleFieldDelete = useCallback((fieldId: string) => {
        setFields(prev => prev.filter(field => field.id !== fieldId));
        if (selectedField?.id === fieldId) {
            setSelectedField(null);
        }
    }, [selectedField]);

    const handleFieldSelect = useCallback((field: DocumentField) => {
        setSelectedField(field);
        setActiveTab("fields");
    }, []);

    // Handle recipient operations
    const handleRecipientsUpdate = useCallback((updatedRecipients: RecipientRole[]) => {
        setRecipients(updatedRecipients);
    }, []);

    // Handle document save
    const handleSave = useCallback(async () => {
        setIsSaving(true);
        saveDocument({
            documentId,
            updates: {
                fields,
                recipients,
                settings: documentSettings,
            },
        });
    }, [documentId, fields, recipients, documentSettings, saveDocument]);

    // Handle document send
    const handleSend = useCallback(() => {
        if (recipients.length === 0) {
            toast({
                title: "No recipients",
                description: "Please add at least one recipient before sending",
                variant: "destructive",
            });
            return;
        }

        if (fields.length === 0) {
            toast({
                title: "No fields",
                description: "Please add at least one field before sending",
                variant: "destructive",
            });
            return;
        }

        setShowSendDialog(true);
    }, [recipients, fields, toast]);

    const confirmSend = useCallback(() => {
        sendForSigning({
            documentId,
            recipients: recipients.map(r => ({
                ...r,
                fields: fields.filter(f => f.recipientRole === r.role),
            })),
            settings: documentSettings,
        });
        setShowSendDialog(false);
    }, [documentId, recipients, fields, documentSettings, sendForSigning]);

    // Field type tools
    const fieldTypes = [
        { type: "signature" as const, label: "Signature", icon: PenTool },
        { type: "initial" as const, label: "Initial", icon: PenTool },
        { type: "text" as const, label: "Text", icon: Type },
        { type: "date" as const, label: "Date", icon: Calendar },
        { type: "checkbox" as const, label: "Checkbox", icon: CheckSquare },
        { type: "number" as const, label: "Number", icon: Hash },
    ];

    // Sidebar resize handler
    const handleMouseDown = useCallback((e: React.MouseEvent) => {
        setIsResizing(true);
        e.preventDefault();
    }, []);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!isResizing) return;
        const newWidth = Math.max(300, Math.min(600, e.clientX));
        setSidebarWidth(newWidth);
    }, [isResizing]);

    const handleMouseUp = useCallback(() => {
        setIsResizing(false);
    }, []);

    useEffect(() => {
        if (isResizing) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
            return () => {
                document.removeEventListener('mousemove', handleMouseMove);
                document.removeEventListener('mouseup', handleMouseUp);
            };
        }
    }, [isResizing, handleMouseMove, handleMouseUp]);

    if (documentLoading) {
        return (
            <Layout user={user}>
                <div className="flex items-center justify-center h-screen">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
            </Layout>
        );
    }

    if (documentError || !document) {
        return (
            <Layout user={user}>
                <div className="flex items-center justify-center h-screen">
                    <Card className="w-96">
                        <CardContent className="p-6 text-center">
                            <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Document not found</h3>
                            <p className="text-gray-600 mb-4">
                                The document you're looking for doesn't exist or you don't have permission to access it.
                            </p>
                            <Button onClick={() => navigate("/documents")}>
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to Documents
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </Layout>
        );
    }

    return (
        <Layout user={user}>
            <div className="flex h-screen overflow-hidden">
                {/* Main Content Area */}
                <div className="flex-1 flex flex-col">
                    {/* Header */}
                    <div className="border-b bg-white px-6 py-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => navigate("/documents")}
                                >
                                    <ArrowLeft className="h-4 w-4 mr-2" />
                                    Back
                                </Button>
                                <div>
                                    <h1 className="text-xl font-semibold text-gray-900">
                                        {document.title || "Untitled Document"}
                                    </h1>
                                    <p className="text-sm text-gray-600">
                                        {fields.length} fields • {recipients.length} recipients
                                    </p>
                                </div>
                            </div>

                            <div className="flex items-center space-x-2">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setShowPreview(true)}
                                >
                                    <Eye className="h-4 w-4 mr-2" />
                                    Preview
                                </Button>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={handleSave}
                                    disabled={isSaving}
                                >
                                    <Save className="h-4 w-4 mr-2" />
                                    {isSaving ? "Saving..." : "Save"}
                                </Button>
                                <Button
                                    onClick={handleSend}
                                    disabled={recipients.length === 0 || fields.length === 0}
                                >
                                    <Send className="h-4 w-4 mr-2" />
                                    Send for Signing
                                </Button>
                            </div>
                        </div>

                        {/* Field Placement Toolbar */}
                        <div className="mt-4 flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                                <Button
                                    variant={isFieldPlacementMode ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => setIsFieldPlacementMode(!isFieldPlacementMode)}
                                >
                                    <MousePointer className="h-4 w-4 mr-2" />
                                    {isFieldPlacementMode ? "Exit Field Mode" : "Add Fields"}
                                </Button>

                                {isFieldPlacementMode && (
                                    <>
                                        <Separator orientation="vertical" className="h-6" />
                                        <div className="flex items-center space-x-1">
                                            {fieldTypes.map(({ type, label, icon: Icon }) => (
                                                <Button
                                                    key={type}
                                                    variant={selectedFieldType === type ? "default" : "ghost"}
                                                    size="sm"
                                                    onClick={() => setSelectedFieldType(type)}
                                                    className="flex items-center space-x-1"
                                                >
                                                    <Icon className="h-4 w-4" />
                                                    <span className="hidden sm:inline">{label}</span>
                                                </Button>
                                            ))}
                                        </div>
                                    </>
                                )}
                            </div>

                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                                <span>Page {currentPage} of {totalPages}</span>
                                <Separator orientation="vertical" className="h-4" />
                                <span>{Math.round(zoom * 100)}%</span>
                            </div>
                        </div>
                    </div>

                    {/* PDF Viewer */}
                    <div className="flex-1 bg-gray-100">
                        <PDFViewer
                            documentUrl={document.fileUrl}
                            currentPage={currentPage}
                            totalPages={totalPages}
                            zoom={zoom}
                            rotation={rotation}
                            fields={fields}
                            isFieldPlacementMode={isFieldPlacementMode}
                            selectedFieldType={selectedFieldType}
                            onPageChange={setCurrentPage}
                            onZoomChange={setZoom}
                            onRotationChange={setRotation}
                            onFieldAdd={handleFieldAdd}
                            onFieldSelect={handleFieldSelect}
                            onFieldUpdate={handleFieldUpdate}
                            onFieldDelete={handleFieldDelete}
                            className="h-full"
                        />
                    </div>
                </div>

                {/* Sidebar */}
                <div
                    className="border-l bg-white flex flex-col"
                    style={{ width: sidebarWidth }}
                >
                    {/* Resize Handle */}
                    <div
                        className="absolute left-0 top-0 bottom-0 w-1 cursor-col-resize bg-gray-200 hover:bg-gray-300 transition-colors"
                        onMouseDown={handleMouseDown}
                        style={{ marginLeft: -2 }}
                    />

                    <div className="p-4 border-b">
                        <Tabs value={activeTab} onValueChange={setActiveTab}>
                            <TabsList className="grid w-full grid-cols-3">
                                <TabsTrigger value="fields">Fields</TabsTrigger>
                                <TabsTrigger value="recipients">Recipients</TabsTrigger>
                                <TabsTrigger value="settings">Settings</TabsTrigger>
                            </TabsList>
                        </Tabs>
                    </div>

                    <ScrollArea className="flex-1">
                        <div className="p-4">
                            <Tabs value={activeTab} onValueChange={setActiveTab}>
                                <TabsContent value="fields" className="mt-0 space-y-4">
                                    <div>
                                        <h3 className="text-lg font-medium mb-2">Document Fields</h3>
                                        <p className="text-sm text-gray-600 mb-4">
                                            Configure field properties and assign them to recipients.
                                        </p>
                                    </div>

                                    {selectedField ? (
                                        <FieldConfiguration
                                            field={{
                                                id: selectedField.id,
                                                type: selectedField.type.toUpperCase() as any,
                                                name: selectedField.placeholder || `${selectedField.type} field`,
                                                page: selectedField.page,
                                                x: selectedField.x,
                                                y: selectedField.y,
                                                width: selectedField.width,
                                                height: selectedField.height,
                                                properties: selectedField.properties || {},
                                                isRequired: selectedField.required || false,
                                                recipientRole: selectedField.recipientRole,
                                            }}
                                            availableRecipients={recipients.map(r => ({
                                                role: r.role,
                                                name: r.name,
                                                color: r.color,
                                            }))}
                                            onUpdate={(updatedField) => {
                                                handleFieldUpdate(selectedField.id, {
                                                    type: updatedField.type.toLowerCase() as any,
                                                    placeholder: updatedField.name,
                                                    page: updatedField.page,
                                                    x: updatedField.x,
                                                    y: updatedField.y,
                                                    width: updatedField.width,
                                                    height: updatedField.height,
                                                    properties: updatedField.properties,
                                                    required: updatedField.isRequired,
                                                    recipientRole: updatedField.recipientRole,
                                                });
                                            }}
                                            onDelete={() => handleFieldDelete(selectedField.id)}
                                            onDuplicate={(field) => {
                                                handleFieldAdd({
                                                    type: field.type.toLowerCase() as any,
                                                    x: field.x + 10,
                                                    y: field.y + 10,
                                                    width: field.width,
                                                    height: field.height,
                                                    page: field.page,
                                                    placeholder: field.name,
                                                    properties: field.properties,
                                                    required: field.isRequired,
                                                    recipientRole: field.recipientRole,
                                                });
                                            }}
                                        />
                                    ) : (
                                        <Card>
                                            <CardContent className="p-6 text-center">
                                                <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                                                <p className="text-sm text-gray-600">
                                                    Select a field to configure its properties
                                                </p>
                                            </CardContent>
                                        </Card>
                                    )}

                                    {fields.length > 0 && (
                                        <div>
                                            <h4 className="font-medium mb-2">All Fields ({fields.length})</h4>
                                            <div className="space-y-2">
                                                {fields.map((field) => (
                                                    <Card
                                                        key={field.id}
                                                        className={`cursor-pointer transition-colors ${selectedField?.id === field.id
                                                            ? "ring-2 ring-blue-500"
                                                            : "hover:bg-gray-50"
                                                            }`}
                                                        onClick={() => setSelectedField(field)}
                                                    >
                                                        <CardContent className="p-3">
                                                            <div className="flex items-center justify-between">
                                                                <div className="flex items-center space-x-2">
                                                                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                                                                    <span className="text-sm font-medium">
                                                                        {field.placeholder || `${field.type} field`}
                                                                    </span>
                                                                </div>
                                                                <Badge variant="outline" className="text-xs">
                                                                    Page {field.page}
                                                                </Badge>
                                                            </div>
                                                            {field.recipientRole && (
                                                                <p className="text-xs text-gray-500 mt-1">
                                                                    Assigned to: {field.recipientRole}
                                                                </p>
                                                            )}
                                                        </CardContent>
                                                    </Card>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </TabsContent>

                                <TabsContent value="recipients" className="mt-0">
                                    <RecipientRoleManager
                                        recipients={recipients}
                                        onUpdate={handleRecipientsUpdate}
                                        maxRecipients={10}
                                    />
                                </TabsContent>

                                <TabsContent value="settings" className="mt-0 space-y-6">
                                    <div>
                                        <h3 className="text-lg font-medium mb-2">Document Settings</h3>
                                        <p className="text-sm text-gray-600 mb-4">
                                            Configure document behavior and workflow settings.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        <div>
                                            <Label htmlFor="title">Document Title</Label>
                                            <Input
                                                id="title"
                                                value={documentSettings.title}
                                                onChange={(e) => setDocumentSettings(prev => ({
                                                    ...prev,
                                                    title: e.target.value
                                                }))}
                                                placeholder="Enter document title"
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="description">Description</Label>
                                            <Textarea
                                                id="description"
                                                value={documentSettings.description}
                                                onChange={(e) => setDocumentSettings(prev => ({
                                                    ...prev,
                                                    description: e.target.value
                                                }))}
                                                placeholder="Enter document description"
                                                rows={3}
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="expirationDate">Expiration Date</Label>
                                            <Input
                                                id="expirationDate"
                                                type="date"
                                                value={documentSettings.expirationDate}
                                                onChange={(e) => setDocumentSettings(prev => ({
                                                    ...prev,
                                                    expirationDate: e.target.value
                                                }))}
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="reminderInterval">Reminder Interval (days)</Label>
                                            <Select
                                                value={documentSettings.reminderInterval}
                                                onValueChange={(value) => setDocumentSettings(prev => ({
                                                    ...prev,
                                                    reminderInterval: value
                                                }))}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="1">Daily</SelectItem>
                                                    <SelectItem value="3">Every 3 days</SelectItem>
                                                    <SelectItem value="7">Weekly</SelectItem>
                                                    <SelectItem value="14">Bi-weekly</SelectItem>
                                                    <SelectItem value="30">Monthly</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <Separator />

                                        <div className="space-y-4">
                                            <h4 className="font-medium">Workflow Options</h4>

                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <Label htmlFor="requireAllRecipients">Require All Recipients</Label>
                                                    <p className="text-sm text-gray-600">
                                                        All recipients must complete their actions
                                                    </p>
                                                </div>
                                                <Switch
                                                    id="requireAllRecipients"
                                                    checked={documentSettings.requireAllRecipients}
                                                    onCheckedChange={(checked) => setDocumentSettings(prev => ({
                                                        ...prev,
                                                        requireAllRecipients: checked
                                                    }))}
                                                />
                                            </div>

                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <Label htmlFor="allowDelegation">Allow Delegation</Label>
                                                    <p className="text-sm text-gray-600">
                                                        Recipients can delegate to others
                                                    </p>
                                                </div>
                                                <Switch
                                                    id="allowDelegation"
                                                    checked={documentSettings.allowDelegation}
                                                    onCheckedChange={(checked) => setDocumentSettings(prev => ({
                                                        ...prev,
                                                        allowDelegation: checked
                                                    }))}
                                                />
                                            </div>

                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <Label htmlFor="requireAuthentication">Require Authentication</Label>
                                                    <p className="text-sm text-gray-600">
                                                        Recipients must authenticate before signing
                                                    </p>
                                                </div>
                                                <Switch
                                                    id="requireAuthentication"
                                                    checked={documentSettings.requireAuthentication}
                                                    onCheckedChange={(checked) => setDocumentSettings(prev => ({
                                                        ...prev,
                                                        requireAuthentication: checked
                                                    }))}
                                                />
                                            </div>

                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <Label htmlFor="enableAuditTrail">Enable Audit Trail</Label>
                                                    <p className="text-sm text-gray-600">
                                                        Track all document activities
                                                    </p>
                                                </div>
                                                <Switch
                                                    id="enableAuditTrail"
                                                    checked={documentSettings.enableAuditTrail}
                                                    onCheckedChange={(checked) => setDocumentSettings(prev => ({
                                                        ...prev,
                                                        enableAuditTrail: checked
                                                    }))}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </TabsContent>
                            </Tabs>
                        </div>
                    </ScrollArea>
                </div>
            </div>

            {/* Send Confirmation Dialog */}
            <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Send Document for Signing</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to send this document to {recipients.length} recipient{recipients.length !== 1 ? 's' : ''}?
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-medium mb-2">Recipients:</h4>
                            <ul className="space-y-1">
                                {recipients.map((recipient) => (
                                    <li key={recipient.id} className="text-sm">
                                        {recipient.order}. {recipient.role}
                                        {recipient.name && ` (${recipient.name})`}
                                        {recipient.email && ` - ${recipient.email}`}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className="bg-blue-50 p-4 rounded-lg">
                            <p className="text-sm text-blue-800">
                                <CheckCircle className="inline h-4 w-4 mr-1" />
                                {fields.length} fields configured
                            </p>
                        </div>
                    </div>
                    <div className="flex justify-end space-x-2 mt-6">
                        <Button variant="outline" onClick={() => setShowSendDialog(false)}>
                            Cancel
                        </Button>
                        <Button onClick={confirmSend}>
                            Send Document
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </Layout>
    );
}