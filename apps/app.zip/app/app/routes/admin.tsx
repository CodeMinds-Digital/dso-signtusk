import { Outlet } from '@remix-run/react';
import { Shield, Users, Settings, Activity, AlertTriangle, Database } from 'lucide-react';
import { NavLink } from '@remix-run/react';

export default function AdminLayout() {
    const navigation = [
        {
            name: 'Dashboard',
            href: '/admin',
            icon: Activity,
            description: 'System overview and health monitoring',
        },
        {
            name: 'System Settings',
            href: '/admin/settings',
            icon: Settings,
            description: 'Configure system-wide settings',
        },
        {
            name: 'User Management',
            href: '/admin/users',
            icon: Users,
            description: 'Manage users and organizations',
        },
        {
            name: 'Security Events',
            href: '/admin/security',
            icon: Shield,
            description: 'Monitor security events and threats',
        },
        {
            name: 'Audit Logs',
            href: '/admin/audit',
            icon: Database,
            description: 'View system audit trail',
        },
    ];

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="bg-white shadow-sm border-b">
                <div className="px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                            <Shield className="h-8 w-8 text-red-600" />
                            <div>
                                <h1 className="text-2xl font-bold text-gray-900">System Administration</h1>
                                <p className="text-sm text-gray-600">Manage system settings, users, and security</p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <div className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                <span>System Healthy</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex">
                {/* Sidebar Navigation */}
                <div className="w-64 bg-white shadow-sm min-h-screen">
                    <nav className="p-4 space-y-2">
                        {navigation.map((item) => (
                            <NavLink
                                key={item.name}
                                to={item.href}
                                end={item.href === '/admin'}
                                className={({ isActive }) =>
                                    `flex items-start space-x-3 p-3 rounded-lg transition-colors ${isActive
                                        ? 'bg-red-50 text-red-700 border border-red-200'
                                        : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                                    }`
                                }
                            >
                                <item.icon className="h-5 w-5 mt-0.5 flex-shrink-0" />
                                <div>
                                    <div className="font-medium">{item.name}</div>
                                    <div className="text-xs text-gray-500 mt-1">{item.description}</div>
                                </div>
                            </NavLink>
                        ))}
                    </nav>
                </div>

                {/* Main Content */}
                <div className="flex-1 p-6">
                    <Outlet />
                </div>
            </div>
        </div>
    );
}