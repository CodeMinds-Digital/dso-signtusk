import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Input,
    Label,
} from "@docusign-alternative/ui";
import {
    Users,
    Plus,
    Search,
    ArrowLeft,
    Settings,
    UserPlus
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Organization Teams - DocuSign Alternative" },
        { name: "description", content: "Manage your organization teams" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
    });
}

export default function OrganizationTeams() {
    const { user } = useLoaderData<typeof loader>();

    // tRPC queries
    const teamsQuery = trpc.organization.listTeams.useQuery({
        organizationId: user.organizationId,
        limit: 50,
    });

    const teams = teamsQuery.data?.teams || [];
    const total = teamsQuery.data?.total || 0;

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center space-x-4 mb-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/organization">
                                <ArrowLeft className="h-4 w-4 mr-2" />
                                Back to Organization
                            </Link>
                        </Button>
                    </div>
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">Teams</h1>
                            <p className="text-gray-600">
                                Organize your members into teams for better collaboration
                            </p>
                        </div>
                        <Button asChild>
                            <Link to="/organization/teams/create">
                                <Plus className="mr-2 h-4 w-4" />
                                Create Team
                            </Link>
                        </Button>
                    </div>
                </div>

                {/* Search */}
                <Card className="mb-6">
                    <CardContent className="p-6">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                                placeholder="Search teams..."
                                className="pl-10"
                            />
                        </div>
                    </CardContent>
                </Card>

                {/* Teams Grid */}
                {teams.length === 0 ? (
                    <Card>
                        <CardContent className="p-12">
                            <div className="text-center">
                                <Users className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No teams yet</h3>
                                <p className="text-gray-600 mb-4">
                                    Create your first team to organize your members
                                </p>
                                <Button asChild>
                                    <Link to="/organization/teams/create">
                                        <Plus className="mr-2 h-4 w-4" />
                                        Create Team
                                    </Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {teams.map((team) => (
                            <Card key={team.id} className="hover:shadow-md transition-shadow">
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <CardTitle className="text-lg">{team.name}</CardTitle>
                                        <Badge variant="outline">
                                            {team.memberCount} members
                                        </Badge>
                                    </div>
                                    <CardDescription>
                                        {team.description || "No description provided"}
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        <div className="flex items-center justify-between text-sm">
                                            <span className="text-gray-600">Permission Level</span>
                                            <Badge variant="secondary">
                                                {team.permissions.level}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between text-sm">
                                            <span className="text-gray-600">Created</span>
                                            <span>{new Date(team.createdAt).toLocaleDateString()}</span>
                                        </div>
                                        <div className="flex gap-2 pt-2">
                                            <Button variant="outline" size="sm" className="flex-1" asChild>
                                                <Link to={`/organization/teams/${team.id}`}>
                                                    <Users className="mr-2 h-4 w-4" />
                                                    View
                                                </Link>
                                            </Button>
                                            <Button variant="outline" size="sm" asChild>
                                                <Link to={`/organization/teams/${team.id}/settings`}>
                                                    <Settings className="h-4 w-4" />
                                                </Link>
                                            </Button>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}

                {/* Summary */}
                {teams.length > 0 && (
                    <Card className="mt-8">
                        <CardHeader>
                            <CardTitle>Teams Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-blue-600">{total}</div>
                                    <div className="text-sm text-gray-600">Total Teams</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-green-600">
                                        {teams.reduce((sum, team) => sum + team.memberCount, 0)}
                                    </div>
                                    <div className="text-sm text-gray-600">Total Team Members</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-purple-600">
                                        {Math.round(teams.reduce((sum, team) => sum + team.memberCount, 0) / teams.length)}
                                    </div>
                                    <div className="text-sm text-gray-600">Avg Members per Team</div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </Layout>
    );
}