import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link, Form, useActionData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasSuccess } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Badge,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@docusign-alternative/ui";
import {
    Users,
    Plus,
    Search,
    Filter,
    MoreHorizontal,
    Mail,
    Shield,
    UserX,
    ArrowLeft,
    Edit,
    Trash2,
    UserPlus
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";
import { useState } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Organization Members - DocuSign Alternative" },
        { name: "description", content: "Manage your organization members and their roles" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const url = new URL(request.url);
    const search = url.searchParams.get("search") || "";
    const role = url.searchParams.get("role") || "";
    const status = url.searchParams.get("status") || "";

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
        filters: { search, role, status },
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "updateRole") {
        const userId = formData.get("userId") as string;
        const role = formData.get("role") as string;
        // In real implementation, update member role via tRPC
        return json({ success: `Member role updated to ${role}` });
    }

    if (intent === "removeMember") {
        const userId = formData.get("userId") as string;
        // In real implementation, remove member via tRPC
        return json({ success: "Member removed from organization" });
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function OrganizationMembers() {
    const { user, filters } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const [selectedMember, setSelectedMember] = useState<any>(null);

    // tRPC queries
    const membersQuery = trpc.organization.listMembers.useQuery({
        organizationId: user.organizationId,
        limit: 50,
        search: filters.search || undefined,
        role: filters.role as any || undefined,
        status: filters.status as any || undefined,
    });

    const members = membersQuery.data?.members || [];
    const total = membersQuery.data?.total || 0;

    const roleColors = {
        OWNER: "bg-purple-100 text-purple-800",
        ADMIN: "bg-red-100 text-red-800",
        MEMBER: "bg-blue-100 text-blue-800",
        GUEST: "bg-gray-100 text-gray-800",
    };

    const statusColors = {
        ACTIVE: "bg-green-100 text-green-800",
        INVITED: "bg-yellow-100 text-yellow-800",
        SUSPENDED: "bg-red-100 text-red-800",
    };

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center space-x-4 mb-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/organization">
                                <ArrowLeft className="h-4 w-4 mr-2" />
                                Back to Organization
                            </Link>
                        </Button>
                    </div>
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">Organization Members</h1>
                            <p className="text-gray-600">
                                Manage members and their roles in your organization
                            </p>
                        </div>
                        <Button asChild>
                            <Link to="/organization/members/invite">
                                <Plus className="mr-2 h-4 w-4" />
                                Invite Member
                            </Link>
                        </Button>
                    </div>
                </div>

                {/* Success Message */}
                {hasSuccess(actionData) && (
                    <div className="mb-6 rounded-md bg-green-50 p-4">
                        <div className="text-sm text-green-700">{actionData.success}</div>
                    </div>
                )}

                {/* Filters */}
                <Card className="mb-6">
                    <CardContent className="p-6">
                        <Form method="get" className="flex flex-col sm:flex-row gap-4">
                            <div className="flex-1">
                                <Label htmlFor="search" className="sr-only">Search</Label>
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        id="search"
                                        name="search"
                                        placeholder="Search members..."
                                        defaultValue={filters.search}
                                        className="pl-10"
                                    />
                                </div>
                            </div>
                            <div className="w-full sm:w-48">
                                <Select name="role" defaultValue={filters.role}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Filter by role" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="">All Roles</SelectItem>
                                        <SelectItem value="OWNER">Owner</SelectItem>
                                        <SelectItem value="ADMIN">Admin</SelectItem>
                                        <SelectItem value="MEMBER">Member</SelectItem>
                                        <SelectItem value="GUEST">Guest</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="w-full sm:w-48">
                                <Select name="status" defaultValue={filters.status}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Filter by status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="">All Status</SelectItem>
                                        <SelectItem value="ACTIVE">Active</SelectItem>
                                        <SelectItem value="INVITED">Invited</SelectItem>
                                        <SelectItem value="SUSPENDED">Suspended</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <Button type="submit" variant="outline">
                                <Filter className="mr-2 h-4 w-4" />
                                Filter
                            </Button>
                        </Form>
                    </CardContent>
                </Card>

                {/* Members Table */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center">
                            <Users className="mr-2 h-5 w-5" />
                            Members ({total})
                        </CardTitle>
                        <CardDescription>
                            Manage your organization members and their permissions
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {members.length === 0 ? (
                            <div className="text-center py-8">
                                <Users className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No members found</h3>
                                <p className="text-gray-600 mb-4">
                                    {filters.search || filters.role || filters.status
                                        ? "Try adjusting your filters"
                                        : "Start by inviting your first team member"}
                                </p>
                                <Button asChild>
                                    <Link to="/organization/members/invite">
                                        <UserPlus className="mr-2 h-4 w-4" />
                                        Invite Member
                                    </Link>
                                </Button>
                            </div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Member</TableHead>
                                        <TableHead>Role</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Joined</TableHead>
                                        <TableHead>Last Active</TableHead>
                                        <TableHead className="w-[50px]"></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {members.map((member) => (
                                        <TableRow key={member.id}>
                                            <TableCell>
                                                <div className="flex items-center space-x-3">
                                                    <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center">
                                                        <span className="text-sm font-medium">
                                                            {member.name.split(' ').map(n => n[0]).join('')}
                                                        </span>
                                                    </div>
                                                    <div>
                                                        <p className="font-medium">{member.name}</p>
                                                        <p className="text-sm text-gray-600">{member.email}</p>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge className={roleColors[member.role as keyof typeof roleColors]}>
                                                    {member.role}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <Badge className={statusColors[member.status as keyof typeof statusColors]}>
                                                    {member.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                {new Date(member.joinedAt).toLocaleDateString()}
                                            </TableCell>
                                            <TableCell>
                                                {member.lastActiveAt ? new Date(member.lastActiveAt).toLocaleDateString() : 'Never'}
                                            </TableCell>
                                            <TableCell>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="sm">
                                                            <MoreHorizontal className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem asChild>
                                                            <Link to={`/organization/members/${member.id}`}>
                                                                <Edit className="mr-2 h-4 w-4" />
                                                                View Details
                                                            </Link>
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem
                                                            onClick={() => setSelectedMember(member)}
                                                        >
                                                            <Shield className="mr-2 h-4 w-4" />
                                                            Change Role
                                                        </DropdownMenuItem>
                                                        {member.status === 'INVITED' && (
                                                            <DropdownMenuItem>
                                                                <Mail className="mr-2 h-4 w-4" />
                                                                Resend Invitation
                                                            </DropdownMenuItem>
                                                        )}
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="text-red-600">
                                                            <UserX className="mr-2 h-4 w-4" />
                                                            Remove Member
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>

                {/* Change Role Dialog */}
                <Dialog open={!!selectedMember} onOpenChange={() => setSelectedMember(null)}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Change Member Role</DialogTitle>
                            <DialogDescription>
                                Update the role for {selectedMember?.name}
                            </DialogDescription>
                        </DialogHeader>
                        <Form method="post">
                            <input type="hidden" name="intent" value="updateRole" />
                            <input type="hidden" name="userId" value={selectedMember?.id} />
                            <div className="space-y-4">
                                <div>
                                    <Label htmlFor="role">New Role</Label>
                                    <Select name="role" defaultValue={selectedMember?.role}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ADMIN">Admin</SelectItem>
                                            <SelectItem value="MEMBER">Member</SelectItem>
                                            <SelectItem value="GUEST">Guest</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <DialogFooter className="mt-6">
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => setSelectedMember(null)}
                                >
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={isSubmitting}>
                                    {isSubmitting ? "Updating..." : "Update Role"}
                                </Button>
                            </DialogFooter>
                        </Form>
                    </DialogContent>
                </Dialog>
            </div>
        </Layout>
    );
}