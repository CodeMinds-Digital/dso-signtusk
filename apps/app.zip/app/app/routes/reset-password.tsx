import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import { NewPasswordForm, NewPasswordFormData } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Reset Password - DocuSign Alternative" },
        { name: "description", content: "Set a new password for your account" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const url = new URL(request.url);
    const token = url.searchParams.get("token");

    if (!token) {
        throw new Response("Invalid reset link", { status: 400 });
    }

    // In a real implementation, validate the token
    // For now, we'll just pass it through
    return json({ token });
}

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const password = formData.get("password");
    const confirmPassword = formData.get("confirmPassword");
    const token = formData.get("token");

    if (typeof password !== "string" || typeof confirmPassword !== "string" || typeof token !== "string") {
        return json(
            { error: "All fields are required" },
            { status: 400 }
        );
    }

    if (!password || !confirmPassword || !token) {
        return json(
            { error: "All fields are required" },
            { status: 400 }
        );
    }

    if (password !== confirmPassword) {
        return json(
            { error: "Passwords do not match" },
            { status: 400 }
        );
    }

    // Password strength validation is handled by the form component

    try {
        // In a real implementation, validate token and update password
        // For now, we'll just simulate success
        return redirect("/login?message=password-reset-success");
    } catch (error) {
        return json(
            { error: "Failed to reset password. Please try again or request a new reset link." },
            { status: 500 }
        );
    }
}

export default function ResetPassword() {
    const { token } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isLoading = navigation.state === "submitting";

    const handleSubmit = async (data: NewPasswordFormData) => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        // Add form data
        Object.entries(data).forEach(([key, value]) => {
            if (value !== undefined) {
                const input = document.createElement('input');
                input.name = key;
                input.value = value;
                form.appendChild(input);
            }
        });

        document.body.appendChild(form);
        form.submit();
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full">
                <NewPasswordForm
                    onSubmit={handleSubmit}
                    token={token}
                    isLoading={isLoading}
                    error={actionData?.error}
                />
            </div>
        </div>
    );
}