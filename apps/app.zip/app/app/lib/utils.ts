/**
 * Type guard utilities for action data
 */

export function hasError(actionData: any): actionData is { error: string } {
    return actionData && typeof actionData === 'object' && 'error' in actionData;
}

export function hasSuccess(actionData: any): actionData is { success: string } {
    return actionData && typeof actionData === 'object' && 'success' in actionData;
}

export function hasRedirectTo(actionData: any): actionData is { redirectTo: string } {
    return actionData && typeof actionData === 'object' && 'redirectTo' in actionData;
}