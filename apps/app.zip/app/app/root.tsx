import {
    Links,
    Meta,
    Outlet,
    Scripts,
    ScrollRestoration,
    useLoaderData,
    useRouteError,
    isRouteErrorResponse,
} from "@remix-run/react";
import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import { useState } from "react";
import { getUserSession } from "~/lib/session.server";
import { trpc } from "~/lib/trpc";
import { ErrorBoundaryFallback } from "@docusign-alternative/ui";
// CSS will be handled by Vite

export function links() {
    return [];
}

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await getUserSession(request);

    return json({
        user: userSession ? {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        } : null,
        ENV: {
            NODE_ENV: process.env.NODE_ENV,
        },
    });
}

export default function App() {
    const data = useLoaderData<typeof loader>();

    const [queryClient] = useState(() => new QueryClient({
        defaultOptions: {
            queries: {
                staleTime: 60 * 1000, // 1 minute
                retry: (failureCount, error: any) => {
                    // Don't retry on 401/403 errors
                    if (error?.status === 401 || error?.status === 403) {
                        return false;
                    }
                    return failureCount < 3;
                },
            },
        },
    }));

    const [trpcClient] = useState(() =>
        trpc.createClient({
            links: [
                httpBatchLink({
                    url: '/api/trpc',
                }),
            ],
        })
    );

    return (
        <html lang="en">
            <head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <Meta />
                <Links />
            </head>
            <body>
                <trpc.Provider client={trpcClient} queryClient={queryClient}>
                    <QueryClientProvider client={queryClient}>
                        <Outlet />
                        <ScrollRestoration />
                        <Scripts />
                        <script
                            dangerouslySetInnerHTML={{
                                __html: `window.ENV = ${JSON.stringify(data.ENV)}`,
                            }}
                        />
                    </QueryClientProvider>
                </trpc.Provider>
            </body>
        </html>
    );
}

// Global error boundary
export function ErrorBoundary() {
    const error = useRouteError();

    // Generate a unique error ID for tracking
    const errorId = `error-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Log error for monitoring (in production, send to error tracking service)
    console.error('Application Error:', error, { errorId });

    let errorMessage = "An unexpected error occurred";
    let errorCode: string | undefined;

    if (isRouteErrorResponse(error)) {
        errorCode = error.status.toString();
        errorMessage = error.statusText || errorMessage;
    } else if (error instanceof Error) {
        errorMessage = error.message;
    }

    return (
        <html lang="en">
            <head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <title>Something went wrong</title>
                <Links />
            </head>
            <body>
                <ErrorBoundaryFallback
                    error={error instanceof Error ? error : new Error(errorMessage)}
                    resetError={() => window.location.reload()}
                    errorId={errorId}
                />
                <Scripts />
            </body>
        </html>
    );
}