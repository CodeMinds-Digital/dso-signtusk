import { Form, Link, useLocation } from "@remix-run/react";
import {
    Button,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
    Avatar,
    AvatarFallback,
    Badge
} from "@docusign-alternative/ui";
import {
    User,
    Settings,
    FileText,
    Folder,
    Upload,
    Users,
    BarChart3,
    Bell,
    Search,
    Menu,
    X,
    Building
} from "@docusign-alternative/ui";
import { useState } from "react";

interface LayoutProps {
    children: React.ReactNode;
    user: {
        userId: string;
        organizationId?: string;
        roles: string[];
    };
}

interface NavItem {
    name: string;
    href: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
}

const navigation: NavItem[] = [
    { name: "Dashboard", href: "/dashboard", icon: BarChart3 },
    { name: "Documents", href: "/documents", icon: FileText },
    { name: "Templates", href: "/templates", icon: Folder },
    { name: "Upload", href: "/upload", icon: Upload },
    { name: "Team", href: "/team", icon: Users },
    { name: "Organization", href: "/organization", icon: Building },
];

export function Layout({ children, user }: LayoutProps) {
    const location = useLocation();
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const getUserInitials = (userId: string) => {
        // Extract initials from user ID or use default
        return userId.slice(0, 2).toUpperCase();
    };

    const isCurrentPath = (href: string) => {
        return location.pathname === href || location.pathname.startsWith(href + "/");
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Top Navigation */}
            <nav className="bg-white shadow-sm border-b">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16">
                        {/* Left side */}
                        <div className="flex items-center">
                            {/* Mobile menu button */}
                            <button
                                type="button"
                                className="md:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
                                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                            >
                                {mobileMenuOpen ? (
                                    <X className="h-6 w-6" />
                                ) : (
                                    <Menu className="h-6 w-6" />
                                )}
                            </button>

                            {/* Logo */}
                            <Link to="/dashboard" className="flex items-center">
                                <div className="flex-shrink-0 flex items-center ml-4 md:ml-0">
                                    <FileText className="h-8 w-8 text-blue-600" />
                                    <span className="ml-2 text-xl font-semibold text-gray-900">
                                        DocuSign Alternative
                                    </span>
                                </div>
                            </Link>
                        </div>

                        {/* Center - Search (hidden on mobile) */}
                        <div className="hidden md:flex flex-1 justify-center px-6 lg:px-8">
                            <div className="max-w-lg w-full">
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <Search className="h-5 w-5 text-gray-400" />
                                    </div>
                                    <input
                                        type="search"
                                        placeholder="Search documents, templates..."
                                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Right side */}
                        <div className="flex items-center space-x-4">
                            {/* Notifications */}
                            <button className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-md">
                                <Bell className="h-6 w-6" />
                            </button>

                            {/* User menu */}
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                                        <Avatar className="h-8 w-8">
                                            <AvatarFallback>
                                                {getUserInitials(user.userId)}
                                            </AvatarFallback>
                                        </Avatar>
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent className="w-56" align="end" forceMount>
                                    <div className="flex items-center justify-start gap-2 p-2">
                                        <div className="flex flex-col space-y-1 leading-none">
                                            <p className="font-medium">User {user.userId}</p>
                                            {user.organizationId && (
                                                <p className="text-xs text-muted-foreground">
                                                    Org: {user.organizationId}
                                                </p>
                                            )}
                                            {user.roles.length > 0 && (
                                                <div className="flex gap-1">
                                                    {user.roles.map((role) => (
                                                        <Badge key={role} variant="secondary" className="text-xs">
                                                            {role}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem asChild>
                                        <Link to="/profile">
                                            <User className="mr-2 h-4 w-4" />
                                            Profile
                                        </Link>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem asChild>
                                        <Link to="/settings">
                                            <Settings className="mr-2 h-4 w-4" />
                                            Settings
                                        </Link>
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem asChild>
                                        <Form action="/logout" method="post">
                                            <button type="submit" className="w-full text-left">
                                                Sign out
                                            </button>
                                        </Form>
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                    </div>
                </div>

                {/* Mobile menu */}
                {mobileMenuOpen && (
                    <div className="md:hidden">
                        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t">
                            {navigation.map((item) => {
                                const Icon = item.icon;
                                return (
                                    <Link
                                        key={item.name}
                                        to={item.href}
                                        className={`${isCurrentPath(item.href)
                                            ? "bg-blue-50 border-blue-500 text-blue-700"
                                            : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"
                                            } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}
                                        onClick={() => setMobileMenuOpen(false)}
                                    >
                                        <div className="flex items-center">
                                            <Icon className="mr-3 h-5 w-5" />
                                            {item.name}
                                            {item.badge && (
                                                <Badge variant="secondary" className="ml-auto">
                                                    {item.badge}
                                                </Badge>
                                            )}
                                        </div>
                                    </Link>
                                );
                            })}
                        </div>
                    </div>
                )}
            </nav>

            <div className="flex">
                {/* Sidebar - Desktop */}
                <div className="hidden md:flex md:w-64 md:flex-col">
                    <div className="flex flex-col flex-grow pt-5 bg-white overflow-y-auto border-r">
                        <div className="flex flex-col flex-grow">
                            <nav className="flex-1 px-2 pb-4 space-y-1">
                                {navigation.map((item) => {
                                    const Icon = item.icon;
                                    return (
                                        <Link
                                            key={item.name}
                                            to={item.href}
                                            className={`${isCurrentPath(item.href)
                                                ? "bg-blue-50 border-r-2 border-blue-500 text-blue-700"
                                                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                                                } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                                        >
                                            <Icon className="mr-3 h-5 w-5" />
                                            {item.name}
                                            {item.badge && (
                                                <Badge variant="secondary" className="ml-auto">
                                                    {item.badge}
                                                </Badge>
                                            )}
                                        </Link>
                                    );
                                })}
                            </nav>
                        </div>
                    </div>
                </div>

                {/* Main content */}
                <div className="flex flex-col flex-1">
                    <main className="flex-1">
                        {children}
                    </main>
                </div>
            </div>
        </div>
    );
}