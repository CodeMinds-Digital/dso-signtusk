import React, { useState } from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    StatisticCard,
    BarChart,
    LineChart,
    PieChart,
    AreaChart,
    DataTable
} from "@docusign-alternative/ui";
import {
    Settings,
    MoreHorizontal,
    X,
    Maximize2,
    Minimize2,
    RefreshCw,
    Download,
    Share,
    Filter,
    Calendar,
    TrendingUp,
    Users,
    FileText,
    Clock,
    Activity,
    BarChart3,
    PieChart as PieChartIcon,
    List,
    Grid3X3
} from "@docusign-alternative/ui";

export interface DashboardWidget {
    id: string;
    type: 'metric' | 'chart' | 'table' | 'activity' | 'progress';
    title: string;
    size: 'small' | 'medium' | 'large';
    position: { x: number; y: number };
    data?: any;
    config?: any;
    refreshable?: boolean;
    exportable?: boolean;
    filterable?: boolean;
}

export interface WidgetContainerProps {
    widget: DashboardWidget;
    onRemove?: (id: string) => void;
    onResize?: (id: string, size: 'small' | 'medium' | 'large') => void;
    onRefresh?: (id: string) => void;
    onExport?: (id: string) => void;
    onConfigure?: (id: string) => void;
    children: React.ReactNode;
}

export const WidgetContainer: React.FC<WidgetContainerProps> = ({
    widget,
    onRemove,
    onResize,
    onRefresh,
    onExport,
    onConfigure,
    children
}) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const handleRefresh = async () => {
        if (!onRefresh) return;
        setIsLoading(true);
        await onRefresh(widget.id);
        setIsLoading(false);
    };

    const sizeClasses = {
        small: 'col-span-1',
        medium: 'col-span-2',
        large: 'col-span-3'
    };

    return (
        <Card className={`${sizeClasses[widget.size]} ${isExpanded ? 'fixed inset-4 z-50' : ''} transition-all duration-200`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{widget.title}</CardTitle>
                <div className="flex items-center gap-1">
                    {widget.refreshable && (
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={handleRefresh}
                            disabled={isLoading}
                        >
                            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                        </Button>
                    )}
                    {widget.exportable && (
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onExport?.(widget.id)}
                        >
                            <Download className="h-4 w-4" />
                        </Button>
                    )}
                    {widget.filterable && (
                        <Button variant="ghost" size="sm">
                            <Filter className="h-4 w-4" />
                        </Button>
                    )}
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsExpanded(!isExpanded)}
                    >
                        {isExpanded ? (
                            <Minimize2 className="h-4 w-4" />
                        ) : (
                            <Maximize2 className="h-4 w-4" />
                        )}
                    </Button>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onConfigure?.(widget.id)}
                    >
                        <Settings className="h-4 w-4" />
                    </Button>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemove?.(widget.id)}
                    >
                        <X className="h-4 w-4" />
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {children}
            </CardContent>
        </Card>
    );
};

export interface MetricWidgetProps {
    title: string;
    value: string | number;
    change?: {
        value: number;
        type: 'increase' | 'decrease' | 'neutral';
        period?: string;
    };
    icon?: React.ReactNode;
    trend?: Array<{ date: string; value: number }>;
}

export const MetricWidget: React.FC<MetricWidgetProps> = ({
    title,
    value,
    change,
    icon,
    trend
}) => {
    return (
        <StatisticCard
            title={title}
            value={value}
            change={change}
            icon={icon}
            trend={trend}
            className="border-0 shadow-none"
        />
    );
};

export interface ChartWidgetProps {
    type: 'bar' | 'line' | 'pie' | 'area';
    data: any[];
    title?: string;
    height?: number;
    color?: string;
    showLegend?: boolean;
}

export const ChartWidget: React.FC<ChartWidgetProps> = ({
    type,
    data,
    title,
    height = 200,
    color,
    showLegend = true
}) => {
    const renderChart = () => {
        switch (type) {
            case 'bar':
                return (
                    <BarChart
                        data={data}
                        title={title}
                        height={height}
                        className="border-0 shadow-none"
                    />
                );
            case 'line':
                return (
                    <LineChart
                        data={data}
                        title={title}
                        height={height}
                        color={color}
                        className="border-0 shadow-none"
                    />
                );
            case 'pie':
                return (
                    <PieChart
                        data={data}
                        title={title}
                        showLegend={showLegend}
                        className="border-0 shadow-none"
                    />
                );
            case 'area':
                return (
                    <AreaChart
                        data={data}
                        title={title}
                        height={height}
                        color={color}
                        className="border-0 shadow-none"
                    />
                );
            default:
                return null;
        }
    };

    return <div>{renderChart()}</div>;
};

export interface ActivityWidgetProps {
    activities: Array<{
        id: string;
        type: string;
        title: string;
        description: string;
        timestamp: string;
        status: 'success' | 'warning' | 'error' | 'info';
        avatar?: string;
    }>;
    maxItems?: number;
}

export const ActivityWidget: React.FC<ActivityWidgetProps> = ({
    activities,
    maxItems = 5
}) => {
    const getActivityIcon = (type: string) => {
        switch (type) {
            case 'document_signed':
                return <FileText className="h-4 w-4 text-green-600" />;
            case 'document_uploaded':
                return <Upload className="h-4 w-4 text-blue-600" />;
            case 'reminder_sent':
                return <Clock className="h-4 w-4 text-yellow-600" />;
            case 'template_created':
                return <Plus className="h-4 w-4 text-purple-600" />;
            case 'user_invited':
                return <Users className="h-4 w-4 text-indigo-600" />;
            default:
                return <Activity className="h-4 w-4 text-gray-600" />;
        }
    };

    const displayActivities = activities.slice(0, maxItems);

    return (
        <div className="space-y-3">
            {displayActivities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex-shrink-0">
                        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium">
                            {activity.avatar || activity.type.charAt(0).toUpperCase()}
                        </div>
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                            {getActivityIcon(activity.type)}
                            <p className="text-sm font-medium text-gray-900 truncate">
                                {activity.title}
                            </p>
                        </div>
                        <p className="text-xs text-gray-600 mb-1">
                            {activity.description}
                        </p>
                        <p className="text-xs text-gray-400">
                            {activity.timestamp}
                        </p>
                    </div>
                </div>
            ))}
            {activities.length > maxItems && (
                <Button variant="outline" size="sm" className="w-full">
                    View {activities.length - maxItems} more
                </Button>
            )}
        </div>
    );
};

export interface TableWidgetProps {
    columns: Array<{
        key: string;
        title: string;
        sortable?: boolean;
        render?: (value: any, record: any) => React.ReactNode;
    }>;
    data: any[];
    maxRows?: number;
    showPagination?: boolean;
}

export const TableWidget: React.FC<TableWidgetProps> = ({
    columns,
    data,
    maxRows = 5,
    showPagination = false
}) => {
    const displayData = showPagination ? data : data.slice(0, maxRows);

    return (
        <DataTable
            columns={columns}
            data={displayData}
            size="small"
            pagination={showPagination ? {
                current: 1,
                pageSize: maxRows,
                total: data.length,
                showSizeChanger: false
            } : undefined}
        />
    );
};

export interface DashboardCustomizerProps {
    availableWidgets: Array<{
        type: string;
        title: string;
        description: string;
        icon: React.ReactNode;
        defaultSize: 'small' | 'medium' | 'large';
    }>;
    onAddWidget: (type: string) => void;
    onClose: () => void;
}

export const DashboardCustomizer: React.FC<DashboardCustomizerProps> = ({
    availableWidgets,
    onAddWidget,
    onClose
}) => {
    return (
        <Card className="w-80">
            <CardHeader>
                <CardTitle className="flex items-center justify-between">
                    Add Widget
                    <Button variant="ghost" size="sm" onClick={onClose}>
                        <X className="h-4 w-4" />
                    </Button>
                </CardTitle>
                <CardDescription>
                    Choose a widget to add to your dashboard
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
                {availableWidgets.map((widget) => (
                    <Button
                        key={widget.type}
                        variant="outline"
                        className="w-full justify-start h-auto p-3"
                        onClick={() => onAddWidget(widget.type)}
                    >
                        <div className="flex items-center gap-3">
                            <div className="flex-shrink-0">
                                {widget.icon}
                            </div>
                            <div className="text-left">
                                <div className="font-medium">{widget.title}</div>
                                <div className="text-sm text-gray-500">{widget.description}</div>
                            </div>
                        </div>
                    </Button>
                ))}
            </CardContent>
        </Card>
    );
};

export const availableWidgetTypes = [
    {
        type: 'metric',
        title: 'Metric Card',
        description: 'Display key performance indicators',
        icon: <TrendingUp className="h-5 w-5" />,
        defaultSize: 'small' as const
    },
    {
        type: 'bar-chart',
        title: 'Bar Chart',
        description: 'Compare values across categories',
        icon: <BarChart3 className="h-5 w-5" />,
        defaultSize: 'medium' as const
    },
    {
        type: 'line-chart',
        title: 'Line Chart',
        description: 'Show trends over time',
        icon: <Activity className="h-5 w-5" />,
        defaultSize: 'medium' as const
    },
    {
        type: 'pie-chart',
        title: 'Pie Chart',
        description: 'Show proportional data',
        icon: <PieChartIcon className="h-5 w-5" />,
        defaultSize: 'medium' as const
    },
    {
        type: 'activity-feed',
        title: 'Activity Feed',
        description: 'Recent system activities',
        icon: <Activity className="h-5 w-5" />,
        defaultSize: 'medium' as const
    },
    {
        type: 'data-table',
        title: 'Data Table',
        description: 'Tabular data display',
        icon: <List className="h-5 w-5" />,
        defaultSize: 'large' as const
    }
];

export default {
    WidgetContainer,
    MetricWidget,
    ChartWidget,
    ActivityWidget,
    TableWidget,
    DashboardCustomizer,
    availableWidgetTypes
};