import EnvelopeEditorPage from './documents.$id.edit';

export default EnvelopeEditorPage;
