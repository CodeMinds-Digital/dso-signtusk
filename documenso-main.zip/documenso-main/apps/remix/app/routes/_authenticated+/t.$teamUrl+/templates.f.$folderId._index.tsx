import TemplatesPage, { meta } from './templates._index';

export { meta };

export default TemplatesPage;
