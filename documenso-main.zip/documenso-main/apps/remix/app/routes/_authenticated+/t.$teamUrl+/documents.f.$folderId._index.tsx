import DocumentPage, { meta } from './documents._index';

export { meta };

export default DocumentPage;
