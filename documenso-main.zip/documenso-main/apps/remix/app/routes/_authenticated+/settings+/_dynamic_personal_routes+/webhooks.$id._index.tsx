import WebhookPage, { meta } from '../../t.$teamUrl+/settings.webhooks.$id._index';

export { meta };

export default WebhookPage;
