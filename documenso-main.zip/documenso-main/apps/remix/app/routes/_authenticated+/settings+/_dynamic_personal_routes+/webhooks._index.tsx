import WebhookPage, { meta } from '../../t.$teamUrl+/settings.webhooks._index';

export { meta };

export default WebhookPage;
