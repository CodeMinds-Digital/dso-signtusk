import DocumentPage, { loader, meta } from '../../o.$orgUrl.settings.document';

export { meta, loader };

export default DocumentPage;
