import EmailPage, { meta } from '../../o.$orgUrl.settings.email';

export { meta };

export default EmailPage;
