import TokensPage, { meta } from '../../t.$teamUrl+/settings.tokens';

export { meta };

export default TokensPage;
