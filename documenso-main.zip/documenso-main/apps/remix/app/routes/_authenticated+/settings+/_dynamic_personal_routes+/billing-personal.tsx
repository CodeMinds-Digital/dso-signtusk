import BillingPage, { meta } from '../../o.$orgUrl.settings.billing';

export { meta };

export default BillingPage;
