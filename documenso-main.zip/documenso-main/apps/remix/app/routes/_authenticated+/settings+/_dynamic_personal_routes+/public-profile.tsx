import PublicProfilePage, { loader, meta } from '../../t.$teamUrl+/settings.public-profile';

export { meta, loader };

export default PublicProfilePage;
