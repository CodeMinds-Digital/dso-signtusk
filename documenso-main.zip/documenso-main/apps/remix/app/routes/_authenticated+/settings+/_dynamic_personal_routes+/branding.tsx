import BrandingPage, { meta } from '../../o.$orgUrl.settings.branding';

export { meta };

export default BrandingPage;
