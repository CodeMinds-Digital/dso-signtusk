export default {
  index: 'Get Started',
  react: 'React Integration',
  vue: 'Vue Integration',
  svelte: 'Svelte Integration',
  solid: 'Solid Integration',
  preact: 'Preact Integration',
  angular: 'Angular Integration',
  'css-variables': 'CSS Variables',
  authoring: 'Authoring',
};
