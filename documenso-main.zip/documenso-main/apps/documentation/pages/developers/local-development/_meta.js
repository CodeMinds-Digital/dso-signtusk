export default {
  index: 'Get Started',
  quickstart: 'Developer Quickstart',
  manual: 'Manual Setup',
  gitpod: 'Gitpod',
  'signing-certificate': 'Signing Certificate',
  translations: 'Translations',
};
