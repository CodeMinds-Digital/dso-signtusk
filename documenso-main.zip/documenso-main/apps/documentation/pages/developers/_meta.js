export default {
  index: 'Introduction',
  '-- Development & Deployment': {
    type: 'separator',
    title: 'Development & Deployment',
  },
  'local-development': 'Local Development',
  'developer-mode': 'Developer Mode',
  'self-hosting': 'Self Hosting',
  contributing: 'Contributing',
  '-- API & Integration Guides': {
    type: 'separator',
    title: 'API & Integration Guides',
  },
  'public-api': 'Public API',
  embedding: 'Embedding',
  webhooks: 'Webhooks',
};
