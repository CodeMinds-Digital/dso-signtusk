export default {
  index: 'Getting Started',
  'signing-certificate': 'Signing Certificate',
  'how-to': 'How To',
  'setting-up-oauth-providers': 'Setting up OAuth Providers',
  telemetry: 'Telemetry',
  'ai-features': 'AI Recipient & Field Detection',
};
