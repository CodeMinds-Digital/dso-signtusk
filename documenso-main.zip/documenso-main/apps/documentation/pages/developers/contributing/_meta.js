export default {
  index: 'Getting Started',
  'contributing-translations': 'Contributing Translations',
};
