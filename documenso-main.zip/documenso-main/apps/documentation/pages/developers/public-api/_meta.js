export default {
  index: 'Get Started',
  authentication: 'Authentication',
  'rate-limits': 'Rate Limits',
  versioning: 'Versioning',
};
