export default {
  'signature-levels': 'Signature Levels',
  'standards-and-regulations': 'Standards and Regulations',
};
