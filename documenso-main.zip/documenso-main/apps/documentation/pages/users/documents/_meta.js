export default {
  'sending-documents': 'Sending Documents',
  'document-preferences': 'Document Preferences',
  'document-visibility': 'Document Visibility',
  fields: 'Document Fields',
  'email-preferences': 'Email Preferences',
  'ai-detection': 'AI Recipient & Field Detection',
};
