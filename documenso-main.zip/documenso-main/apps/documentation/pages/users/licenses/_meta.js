export default {
  index: 'Overview',
  'community-edition': 'Community Edition',
  'enterprise-edition': 'Enterprise Edition',
};
