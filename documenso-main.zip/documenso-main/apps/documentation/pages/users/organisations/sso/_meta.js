export default {
  index: 'Configuration',
  'microsoft-entra-id': 'Microsoft Entra ID',
};
