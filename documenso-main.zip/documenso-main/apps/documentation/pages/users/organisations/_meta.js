export default {
  index: 'Introduction',
  members: 'Members',
  groups: 'Groups',
  teams: 'Teams',
  sso: 'SSO',
  billing: 'Billing',
};
