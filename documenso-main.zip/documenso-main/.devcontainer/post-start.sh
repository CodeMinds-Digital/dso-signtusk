#!/usr/bin/env bash

npm run dev
