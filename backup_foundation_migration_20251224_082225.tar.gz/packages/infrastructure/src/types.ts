import { z } from 'zod';
import { CacheConfigSchema } from '@docusign-alternative/cache';
import { StorageConfigSchema } from '@docusign-alternative/storage';
import { PerformanceConfigSchema } from '@docusign-alternative/performance';
import { DisasterRecoveryConfigSchema } from './disaster-recovery/types';

export const InfrastructureConfigSchema = z.object({
    auth: z.object({
        jwtSecret: z.string(),
        sessionTimeout: z.number().default(24 * 60 * 60 * 1000), // 24 hours in ms
    }),
    cache: CacheConfigSchema,
    storage: StorageConfigSchema,
    jobs: z.object({
        appId: z.string().default('docusign-alternative'),
    }),
    performance: PerformanceConfigSchema.optional(),
    disasterRecovery: DisasterRecoveryConfigSchema.optional(),
});

export type InfrastructureConfig = z.infer<typeof InfrastructureConfigSchema>;

export interface InfrastructureServices {
    auth: import('@docusign-alternative/auth').AuthenticationService;
    cache: import('@docusign-alternative/cache').CacheService;
    storage: import('@docusign-alternative/storage').StorageService;
    jobs: import('@docusign-alternative/jobs').JobService;
    performance?: import('@docusign-alternative/performance').PerformanceMonitoringService;
    disasterRecovery?: import('./disaster-recovery/types').DisasterRecoveryService;
}

export interface InfrastructureManager {
    initialize(config: InfrastructureConfig): Promise<void>;
    getServices(): InfrastructureServices;
    shutdown(): Promise<void>;
    healthCheck(): Promise<HealthCheckResult>;
}

export interface HealthCheckResult {
    status: 'healthy' | 'unhealthy' | 'degraded';
    services: {
        auth: ServiceHealth;
        cache: ServiceHealth;
        storage: ServiceHealth;
        jobs: ServiceHealth;
        performance?: ServiceHealth;
        disasterRecovery?: ServiceHealth;
    };
    timestamp: Date;
}

export interface ServiceHealth {
    status: 'healthy' | 'unhealthy';
    responseTime?: number;
    error?: string;
}