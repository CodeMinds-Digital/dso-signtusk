import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';
import { InfrastructureManagerImpl } from '../manager';
import { InfrastructureConfig } from '../types';
import { InMemoryCacheService } from '@docusign-alternative/cache';
import { InMemoryJobService } from '@docusign-alternative/jobs';

/**
 * **Feature: docusign-alternative-comprehensive, Property 3: Core Infrastructure Functionality**
 * **Validates: Requirements 1.3**
 * 
 * Property: For any system initialization, all core infrastructure components 
 * (authentication, caching, job processing, file storage) should initialize 
 * properly and provide expected functionality
 */

describe('Core Infrastructure Functionality Property Tests', () => {
    let infrastructureManager: InfrastructureManagerImpl;

    beforeEach(() => {
        infrastructureManager = new InfrastructureManagerImpl();
    });

    afterEach(async () => {
        try {
            await infrastructureManager.shutdown();
        } catch {
            // Ignore shutdown errors in tests
        }
    });

    it('should initialize all core infrastructure components correctly', async () => {
        await fc.assert(
            fc.asyncProperty(
                // Generate valid infrastructure configurations using in-memory services
                fc.record({
                    auth: fc.record({
                        jwtSecret: fc.string({ minLength: 32 }),
                        sessionTimeout: fc.integer({ min: 60000, max: 86400000 }),
                    }),
                    cache: fc.record({
                        host: fc.constant('localhost'),
                        port: fc.constant(6379),
                    }),
                    storage: fc.record({
                        provider: fc.constant('local' as const),
                        local: fc.record({
                            basePath: fc.string({ minLength: 1 }).map(s => `/tmp/test-storage-${s}-${Date.now()}`),
                            createDirectories: fc.constant(true),
                        }),
                    }),
                    jobs: fc.record({
                        appId: fc.string({ minLength: 1, maxLength: 50 }),
                    }),
                }),
                async (config: InfrastructureConfig) => {
                    // Initialize infrastructure with generated config
                    await infrastructureManager.initialize(config);

                    // Get services
                    const services = infrastructureManager.getServices();

                    // Verify all services are available
                    expect(services.auth).toBeDefined();
                    expect(services.cache).toBeDefined();
                    expect(services.storage).toBeDefined();
                    expect(services.jobs).toBeDefined();

                    // Test authentication service functionality
                    const testUser = await services.auth.register({
                        email: `test-${Date.now()}@example.com`,
                        password: 'test-password-123',
                        name: 'Test User',
                    });
                    expect(testUser.id).toBeDefined();
                    expect(testUser.email).toContain('@example.com');

                    // Test authentication
                    const authResult = await services.auth.authenticate({
                        email: testUser.email,
                        password: 'test-password-123',
                    });
                    expect(authResult.success).toBe(true);
                    expect(authResult.sessionToken).toBeDefined();

                    // Test session validation
                    if (authResult.sessionToken) {
                        const sessionData = await services.auth.validateSession(authResult.sessionToken);
                        expect(sessionData.userId).toBe(testUser.id);
                    }

                    // Test cache functionality (will use in-memory fallback)
                    const cacheKey = `test-key-${Date.now()}`;
                    const cacheValue = { test: 'data', timestamp: Date.now() };

                    await services.cache.set(cacheKey, cacheValue, { ttl: 60 });
                    const retrievedValue = await services.cache.get(cacheKey);
                    expect(retrievedValue).toEqual(cacheValue);

                    const exists = await services.cache.exists(cacheKey);
                    expect(exists).toBe(true);

                    await services.cache.del(cacheKey);
                    const deletedValue = await services.cache.get(cacheKey);
                    expect(deletedValue).toBeNull();

                    // Test storage functionality
                    const storageKey = `test-file-${Date.now()}.txt`;
                    const testData = Buffer.from(`Test data: ${Math.random()}`);

                    const uploadResult = await services.storage.upload(storageKey, testData, {
                        mimeType: 'text/plain',
                    });
                    expect(uploadResult.key).toBe(storageKey);
                    expect(uploadResult.size).toBe(testData.length);

                    const storageExists = await services.storage.exists(storageKey);
                    expect(storageExists).toBe(true);

                    const downloadedData = await services.storage.download(storageKey);
                    expect(downloadedData).toEqual(testData);

                    const metadata = await services.storage.getMetadata(storageKey);
                    expect(metadata.key).toBe(storageKey);
                    expect(metadata.mimeType).toBe('text/plain');

                    await services.storage.delete(storageKey);
                    const deletedExists = await services.storage.exists(storageKey);
                    expect(deletedExists).toBe(false);

                    // Test job processing functionality (will use in-memory fallback)
                    services.jobs.defineJob({
                        name: 'test-job',
                        handler: async (payload) => {
                            return { success: true, data: payload };
                        },
                    });

                    const testJobData = { message: 'test job', timestamp: Date.now() };
                    const jobId = await services.jobs.enqueue('test-job', testJobData);
                    expect(jobId).toBeDefined();

                    // Wait for job to process (simplified for test)
                    await new Promise(resolve => setTimeout(resolve, 200));

                    const jobStatus = await services.jobs.getJobStatus(jobId);
                    expect(jobStatus).toBeDefined();
                    expect(jobStatus?.name).toBe('test-job');

                    // Perform health check
                    const healthCheck = await infrastructureManager.healthCheck();
                    expect(healthCheck.status).toMatch(/^(healthy|degraded)$/);
                    expect(healthCheck.services.auth.status).toBe('healthy');
                    expect(['healthy', 'unhealthy']).toContain(healthCheck.services.cache.status);
                    expect(healthCheck.services.storage.status).toBe('healthy');
                    expect(healthCheck.services.jobs.status).toBe('healthy');
                    expect(healthCheck.timestamp).toBeInstanceOf(Date);
                }
            ),
            { numRuns: 3, timeout: 10000 }
        );
    }, 15000);

    it('should handle service failures gracefully', async () => {
        // Test with a simple configuration that should work with fallbacks
        const config: InfrastructureConfig = {
            auth: {
                jwtSecret: 'test-secret-that-is-long-enough-for-jwt-validation-requirements',
            },
            cache: {
                host: 'invalid-host', // This will fail and fallback to in-memory
                port: 6379,
            },
            storage: {
                provider: 'local' as const,
                local: {
                    basePath: `/tmp/test-storage-${Date.now()}`,
                    createDirectories: true,
                },
            },
            jobs: {
                appId: 'test-app',
            },
        };

        // This should still initialize successfully with fallback services
        await infrastructureManager.initialize(config);

        const services = infrastructureManager.getServices();

        // All services should be available (with fallbacks)
        expect(services.auth).toBeDefined();
        expect(services.cache).toBeDefined();
        expect(services.storage).toBeDefined();
        expect(services.jobs).toBeDefined();

        // Health check should show degraded status for failed services
        const healthCheck = await infrastructureManager.healthCheck();
        expect(['healthy', 'degraded', 'unhealthy']).toContain(healthCheck.status);
    }, 10000);

    it('should maintain service isolation and independence', async () => {
        const config: InfrastructureConfig = {
            auth: {
                jwtSecret: 'test-secret-that-is-long-enough-for-jwt-validation-requirements',
            },
            cache: {
                host: 'localhost',
                port: 6379,
            },
            storage: {
                provider: 'local' as const,
                local: {
                    basePath: `/tmp/test-storage-${Date.now()}`,
                    createDirectories: true,
                },
            },
            jobs: {
                appId: 'test-app',
            },
        };

        await infrastructureManager.initialize(config);
        const services = infrastructureManager.getServices();

        // Test that services operate independently
        // Create data in each service
        const userId = 'test-user-' + Date.now();
        const cacheKey = 'test-cache-' + Date.now();
        const storageKey = 'test-storage-' + Date.now();

        // Auth service
        const user = await services.auth.register({
            email: `${userId}@test.com`,
            password: 'password123',
            name: 'Test User',
        });

        // Cache service (will use fallback if Redis unavailable)
        await services.cache.set(cacheKey, { userId: user.id });

        // Storage service
        await services.storage.upload(storageKey, Buffer.from('test data'));

        // Job service
        services.jobs.defineJob({
            name: 'isolation-test',
            handler: async (payload) => ({ success: true, data: payload }),
        });

        // Verify each service maintains its own data
        const authResult = await services.auth.authenticate({
            email: user.email,
            password: 'password123',
        });
        expect(authResult.success).toBe(true);

        const cachedData = await services.cache.get(cacheKey);
        expect(cachedData).toEqual({ userId: user.id });

        const storageExists = await services.storage.exists(storageKey);
        expect(storageExists).toBe(true);

        const jobId = await services.jobs.enqueue('isolation-test', { test: true });
        expect(jobId).toBeDefined();

        // Services should not interfere with each other
        await services.cache.flush();
        const flushedData = await services.cache.get(cacheKey);
        expect(flushedData).toBeNull();

        // But other services should be unaffected
        const authStillWorks = await services.auth.authenticate({
            email: user.email,
            password: 'password123',
        });
        expect(authStillWorks.success).toBe(true);

        const storageStillExists = await services.storage.exists(storageKey);
        expect(storageStillExists).toBe(true);
    }, 10000);

    it('should demonstrate core infrastructure functionality with in-memory services', async () => {
        // Create a custom infrastructure manager that uses in-memory services directly
        class TestInfrastructureManager extends InfrastructureManagerImpl {
            async initialize(config: InfrastructureConfig): Promise<void> {
                this.config = config;

                // Use in-memory services directly to avoid external dependencies
                const authService = new (await import('@docusign-alternative/auth')).AuthenticationServiceImpl(config.auth.jwtSecret);
                const cacheService = new InMemoryCacheService();
                const storageService = new (await import('@docusign-alternative/storage')).LocalStorageService(config.storage);
                const jobService = new InMemoryJobService();

                this.services = {
                    auth: authService,
                    cache: cacheService,
                    storage: storageService,
                    jobs: jobService,
                };

                await jobService.start();
            }
        }

        const testManager = new TestInfrastructureManager();

        const config: InfrastructureConfig = {
            auth: {
                jwtSecret: 'test-secret-that-is-long-enough-for-jwt-validation-requirements',
            },
            cache: {
                host: 'localhost',
                port: 6379,
            },
            storage: {
                provider: 'local' as const,
                local: {
                    basePath: `/tmp/test-storage-${Date.now()}`,
                    createDirectories: true,
                },
            },
            jobs: {
                appId: 'test-app',
            },
        };

        await testManager.initialize(config);
        const services = testManager.getServices();

        // Test all core functionality
        expect(services.auth).toBeDefined();
        expect(services.cache).toBeDefined();
        expect(services.storage).toBeDefined();
        expect(services.jobs).toBeDefined();

        // Test authentication
        const user = await services.auth.register({
            email: 'test@example.com',
            password: 'password123',
            name: 'Test User',
        });
        expect(user.id).toBeDefined();

        // Test cache
        await services.cache.set('test', 'value');
        const value = await services.cache.get('test');
        expect(value).toBe('value');

        // Test storage
        await services.storage.upload('test.txt', Buffer.from('test'));
        const exists = await services.storage.exists('test.txt');
        expect(exists).toBe(true);

        // Test jobs
        services.jobs.defineJob({
            name: 'test-job',
            handler: async () => ({ success: true }),
        });
        const jobId = await services.jobs.enqueue('test-job', {});
        expect(jobId).toBeDefined();

        await testManager.shutdown();
    }, 5000);
});