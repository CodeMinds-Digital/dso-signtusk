export * from './types';
export * from './manager';
export * from './disaster-recovery';

// Re-export commonly used types from dependencies
export type { AuthenticationService, User, AuthResult } from '@docusign-alternative/auth';
export type { CacheService, CacheOptions } from '@docusign-alternative/cache';
export type { StorageService, FileMetadata, UploadOptions } from '@docusign-alternative/storage';
export type { JobService, JobDefinition, JobPayload } from '@docusign-alternative/jobs';

// Re-export performance monitoring types
export type {
    PerformanceMonitoringService,
    PerformanceConfig,
    PerformanceMetrics,
    DatabaseOptimizer,
    CacheOptimizer
} from '@docusign-alternative/performance';