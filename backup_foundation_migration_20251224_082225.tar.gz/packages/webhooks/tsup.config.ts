import { defineConfig } from 'tsup';

export default defineConfig({
    entry: ['src/index.ts'],
    format: ['cjs', 'esm'],
    dts: false, // Disable DTS generation for now due to monorepo path issues
    clean: true,
    external: [
        '@docusign-alternative/database',
        '@docusign-alternative/lib',
        '@docusign-alternative/jobs',
    ],
});