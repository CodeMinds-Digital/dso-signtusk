/**
 * Example usage of the @docusign-alternative/email package
 * 
 * This file demonstrates how to use the email system with different providers
 * and templates.
 */

import {
    EmailServiceFactory,
    createEmailServiceFromEnv,
    MockEmailService,
    EmailPreviewService
} from './src';
import type { SMTPConfig, ResendConfig } from './src';

// Example 1: Create email service with SMTP configuration
async function exampleSMTPService() {
    const smtpConfig: SMTPConfig = {
        provider: 'smtp',
        from: 'noreply@example.com',
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
            user: 'your-email@gmail.com',
            pass: 'your-app-password',
        },
    };

    const emailService = EmailServiceFactory.create(smtpConfig);

    // Send a basic email
    const result = await emailService.send({
        to: 'user@example.com',
        subject: 'Welcome to our platform!',
        html: '<h1>Welcome!</h1><p>Thank you for joining us.</p>',
        text: 'Welcome! Thank you for joining us.',
    });

    console.log('Email sent:', result);
}

// Example 2: Create email service with Resend
async function exampleResendService() {
    const resendConfig: ResendConfig = {
        provider: 'resend',
        from: 'noreply@yourdomain.com',
        apiKey: 'your-resend-api-key',
    };

    const emailService = EmailServiceFactory.create(resendConfig);

    // Send welcome email using template
    const result = await emailService.sendTemplate(
        'welcome',
        'newuser@example.com',
        {
            userName: 'John Doe',
            verificationUrl: 'https://yourapp.com/verify/abc123',
            locale: 'en',
        }
    );

    console.log('Welcome email sent:', result);
}

// Example 3: Send signing request email
async function exampleSigningRequest() {
    // Using environment variables (recommended for production)
    const emailService = createEmailServiceFromEnv();

    const result = await emailService.sendTemplate(
        'signing-request',
        'signer@example.com',
        {
            recipientName: 'Jane Smith',
            senderName: 'John Doe',
            documentName: 'Service Agreement.pdf',
            signingUrl: 'https://yourapp.com/sign/xyz789',
            dueDate: 'December 31, 2024',
            message: 'Please review and sign this service agreement at your earliest convenience.',
            locale: 'en',
        }
    );

    console.log('Signing request sent:', result);
}

// Example 4: Using MockEmailService for testing
async function exampleTesting() {
    const templateRegistry = EmailServiceFactory.getTemplateRegistry();
    const mockService = new MockEmailService(templateRegistry);

    // Send test emails
    await mockService.sendTemplate('welcome', 'test@example.com', {
        userName: 'Test User',
        verificationUrl: 'https://test.com/verify',
        locale: 'en',
    });

    // Check sent emails
    const sentEmails = mockService.getSentEmails();
    console.log(`Sent ${sentEmails.length} emails in test`);

    const lastEmail = mockService.getLastSentEmail();
    console.log('Last email subject:', lastEmail.message.subject);
}

// Example 5: Preview email templates
async function examplePreview() {
    const templateRegistry = EmailServiceFactory.getTemplateRegistry();
    const previewService = new EmailPreviewService(templateRegistry);

    // Preview a specific template
    const welcomePreview = await previewService.previewTemplate('welcome', {
        userName: 'Preview User',
        verificationUrl: 'https://example.com/verify',
        locale: 'en',
    });

    console.log('Welcome email preview:');
    console.log('Subject:', welcomePreview.subject);
    console.log('HTML length:', welcomePreview.html.length);

    // Generate preview HTML for all templates
    const allPreviews = await previewService.previewAllTemplates();
    const previewHtml = previewService.generatePreviewHtml(allPreviews);

    // You can save this HTML to a file and open it in a browser
    console.log('Generated preview HTML for', allPreviews.length, 'templates');
}

// Example 6: Internationalization
async function exampleI18n() {
    const emailService = createEmailServiceFromEnv();

    // Send welcome email in Spanish
    await emailService.sendTemplate('welcome', 'usuario@ejemplo.com', {
        userName: 'Juan Pérez',
        verificationUrl: 'https://tuapp.com/verificar/abc123',
        locale: 'es', // Spanish locale
    });

    // Send welcome email in French
    await emailService.sendTemplate('welcome', 'utilisateur@exemple.com', {
        userName: 'Marie Dubois',
        verificationUrl: 'https://votreapp.com/verifier/abc123',
        locale: 'fr', // French locale
    });
}

// Example 7: Custom email with attachments
async function exampleWithAttachments() {
    const emailService = createEmailServiceFromEnv();

    const result = await emailService.send({
        to: 'recipient@example.com',
        subject: 'Document Package',
        html: '<p>Please find the attached documents.</p>',
        attachments: [
            {
                filename: 'contract.pdf',
                content: Buffer.from('PDF content here'), // In real usage, load from file
                contentType: 'application/pdf',
            },
            {
                filename: 'terms.txt',
                content: 'Terms and conditions text...',
                contentType: 'text/plain',
            },
        ],
    });

    console.log('Email with attachments sent:', result);
}

// Run examples (uncomment to test)
// Note: Make sure to set up proper environment variables or configurations

async function runExamples() {
    console.log('Email System Examples');
    console.log('====================');

    try {
        // Uncomment the examples you want to run:

        // await exampleTesting();
        // await examplePreview();
        // await exampleI18n();

        console.log('Examples completed successfully!');
    } catch (error) {
        console.error('Example failed:', error);
    }
}

// Export for use in other files
export {
    exampleSMTPService,
    exampleResendService,
    exampleSigningRequest,
    exampleTesting,
    examplePreview,
    exampleI18n,
    exampleWithAttachments,
    runExamples,
};

// Run if this file is executed directly
if (require.main === module) {
    runExamples();
}