# @docusign-alternative/email

A comprehensive email system with React Email templates, multiple provider support, and internationalization for the DocuSign Alternative platform.

## Features

- **Multiple Email Providers**: Support for Resend, SendGrid, and SMTP
- **React Email Templates**: Pre-built templates for common e-signature workflows
- **Internationalization**: Support for 9 languages (EN, ES, FR, DE, IT, PT, JA, KO, ZH)
- **Template System**: Extensible template registry with custom templates
- **Testing Support**: Mock email service and preview functionality
- **TypeScript**: Full TypeScript support with comprehensive type definitions

## Installation

```bash
npm install @docusign-alternative/email
```

## Quick Start

### Environment Configuration

Set up your environment variables:

```bash
# Choose your email provider
EMAIL_PROVIDER=resend  # or 'sendgrid' or 'smtp'
EMAIL_FROM=noreply@yourdomain.com
EMAIL_REPLY_TO=support@yourdomain.com

# Provider-specific configuration
# For Resend:
RESEND_API_KEY=your_resend_api_key

# For SendGrid:
SENDGRID_API_KEY=your_sendgrid_api_key

# For SMTP:
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
```

### Basic Usage

```typescript
import { createEmailServiceFromEnv } from '@docusign-alternative/email';

// Create email service from environment variables
const emailService = createEmailServiceFromEnv();

// Send a basic email
await emailService.send({
  to: 'user@example.com',
  subject: 'Welcome!',
  html: '<h1>Welcome to our platform!</h1>',
  text: 'Welcome to our platform!',
});

// Send using a template
await emailService.sendTemplate('welcome', 'user@example.com', {
  userName: 'John Doe',
  verificationUrl: 'https://yourapp.com/verify/abc123',
  locale: 'en',
});
```

## Email Templates

### Built-in Templates

The package includes these pre-built templates:

1. **welcome** - Welcome email for new users
2. **signing-request** - Document signing request
3. **document-completed** - Document completion notification
4. **password-reset** - Password reset email

### Template Usage

```typescript
// Welcome email
await emailService.sendTemplate('welcome', 'user@example.com', {
  userName: 'John Doe',
  verificationUrl: 'https://yourapp.com/verify/abc123',
  locale: 'en',
});

// Signing request
await emailService.sendTemplate('signing-request', 'signer@example.com', {
  recipientName: 'Jane Smith',
  senderName: 'John Doe',
  documentName: 'Contract.pdf',
  signingUrl: 'https://yourapp.com/sign/xyz789',
  dueDate: 'December 31, 2024',
  message: 'Please review and sign this contract.',
  locale: 'en',
});

// Document completed
await emailService.sendTemplate('document-completed', 'user@example.com', {
  recipientName: 'John Doe',
  documentName: 'Contract.pdf',
  completedDate: 'December 15, 2024',
  downloadUrl: 'https://yourapp.com/download/abc123',
  signers: [
    { name: 'John Doe', signedAt: '2024-12-15 10:30 AM' },
    { name: 'Jane Smith', signedAt: '2024-12-15 2:45 PM' },
  ],
  locale: 'en',
});
```

## Provider Configuration

### Manual Configuration

```typescript
import { EmailServiceFactory } from '@docusign-alternative/email';

// Resend
const resendService = EmailServiceFactory.create({
  provider: 'resend',
  from: 'noreply@yourdomain.com',
  apiKey: 'your_resend_api_key',
});

// SendGrid
const sendgridService = EmailServiceFactory.create({
  provider: 'sendgrid',
  from: 'noreply@yourdomain.com',
  apiKey: 'your_sendgrid_api_key',
});

// SMTP
const smtpService = EmailServiceFactory.create({
  provider: 'smtp',
  from: 'noreply@yourdomain.com',
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: {
    user: 'your_email@gmail.com',
    pass: 'your_app_password',
  },
});
```

## Internationalization

The email system supports 9 languages with automatic locale detection:

```typescript
// Supported locales: 'en', 'es', 'fr', 'de', 'it', 'pt', 'ja', 'ko', 'zh'

// Explicit locale
await emailService.sendTemplate('welcome', 'usuario@ejemplo.com', {
  userName: 'Juan Pérez',
  verificationUrl: 'https://tuapp.com/verificar/abc123',
  locale: 'es', // Spanish
});

// Locale detection from Accept-Language header
await emailService.sendTemplate('welcome', 'user@example.com', {
  userName: 'User Name',
  verificationUrl: 'https://app.com/verify/123',
  acceptLanguage: 'fr-FR,fr;q=0.9,en;q=0.8', // Will use French
});
```

### Custom Translations

```typescript
import { EmailI18n, EmailServiceFactory } from '@docusign-alternative/email';

const customI18n = new EmailI18n({
  'custom.message': {
    en: 'Custom message in English',
    es: 'Mensaje personalizado en español',
  },
});

// Initialize with custom translations
EmailServiceFactory.initialize(customI18n);
```

## Testing

### Mock Email Service

```typescript
import { MockEmailService, EmailServiceFactory } from '@docusign-alternative/email';

const templateRegistry = EmailServiceFactory.getTemplateRegistry();
const mockService = new MockEmailService(templateRegistry);

// Send test emails
await mockService.sendTemplate('welcome', 'test@example.com', {
  userName: 'Test User',
  verificationUrl: 'https://test.com/verify',
  locale: 'en',
});

// Inspect sent emails
const sentEmails = mockService.getSentEmails();
const lastEmail = mockService.getLastSentEmail();
const userEmails = mockService.findEmailsByRecipient('test@example.com');

// Control mock behavior
mockService.setShouldFail(true, 'Network error');
```

### Email Preview

```typescript
import { EmailPreviewService, EmailServiceFactory } from '@docusign-alternative/email';

const templateRegistry = EmailServiceFactory.getTemplateRegistry();
const previewService = new EmailPreviewService(templateRegistry);

// Preview a specific template
const preview = await previewService.previewTemplate('welcome', {
  userName: 'Preview User',
  verificationUrl: 'https://example.com/verify',
  locale: 'en',
});

console.log('Subject:', preview.subject);
console.log('HTML:', preview.html);
console.log('Text:', preview.text);

// Generate HTML preview for all templates
const allPreviews = await previewService.previewAllTemplates();
const previewHtml = previewService.generatePreviewHtml(allPreviews);

// Save to file and open in browser for visual inspection
```

## Custom Templates

### Creating Custom Templates

```typescript
import React from 'react';
import { Layout, Button } from '@docusign-alternative/email';

interface CustomEmailProps {
  userName: string;
  customData: string;
  i18n: EmailI18nContext;
}

const CustomEmail: React.FC<CustomEmailProps> = ({ userName, customData, i18n }) => {
  return (
    <Layout i18n={i18n} previewText="Custom email">
      <h1>Hello {userName}!</h1>
      <p>Your custom data: {customData}</p>
      <Button href="https://example.com/action">
        Take Action
      </Button>
    </Layout>
  );
};

// Register the template
const templateRegistry = EmailServiceFactory.getTemplateRegistry();
templateRegistry.register({
  name: 'custom-email',
  subject: 'Custom Email Subject',
  component: CustomEmail,
  category: 'custom',
  description: 'A custom email template',
});
```

## Advanced Features

### Email with Attachments

```typescript
await emailService.send({
  to: 'recipient@example.com',
  subject: 'Document Package',
  html: '<p>Please find the attached documents.</p>',
  attachments: [
    {
      filename: 'contract.pdf',
      content: fs.readFileSync('path/to/contract.pdf'),
      contentType: 'application/pdf',
    },
  ],
});
```

### Bulk Operations

```typescript
// Send to multiple recipients
await emailService.send({
  to: ['user1@example.com', 'user2@example.com'],
  cc: ['manager@example.com'],
  bcc: ['admin@example.com'],
  subject: 'Bulk Email',
  html: '<p>This email goes to multiple recipients.</p>',
});
```

### Email Validation

```typescript
// Validate configuration
const isValid = await emailService.validateConfig();
if (!isValid) {
  console.error('Email service configuration is invalid');
}
```

## API Reference

### EmailService Interface

```typescript
interface EmailService {
  send(message: EmailMessage): Promise<EmailDeliveryResult>;
  sendTemplate(
    templateName: string,
    to: string | string[],
    props: EmailTemplateProps,
    options?: Partial<EmailMessage>
  ): Promise<EmailDeliveryResult>;
  renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{
    html: string;
    text?: string;
    subject: string;
  }>;
  validateConfig(): Promise<boolean>;
  getProvider(): EmailProvider;
}
```

### EmailMessage Type

```typescript
interface EmailMessage {
  to: string | string[];
  cc?: string | string[];
  bcc?: string | string[];
  subject: string;
  html: string;
  text?: string;
  attachments?: EmailAttachment[];
  headers?: Record<string, string>;
  tags?: string[];
  metadata?: Record<string, any>;
}
```

## Error Handling

```typescript
try {
  const result = await emailService.send(message);
  if (!result.success) {
    console.error('Email failed:', result.error);
  }
} catch (error) {
  console.error('Email service error:', error);
}
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.