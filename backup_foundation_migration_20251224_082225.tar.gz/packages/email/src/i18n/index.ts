import type { SupportedLocale, LocalizedContent, EmailI18nContext } from '../types';

// Default translations for common email content
const defaultTranslations: LocalizedContent = {
    'common.greeting': {
        en: 'Hello',
        es: 'Hola',
        fr: 'Bonjour',
        de: 'Hallo',
        it: 'Ciao',
        pt: 'Olá',
        ja: 'こんにちは',
        ko: '안녕하세요',
        zh: '您好',
    },
    'common.thanks': {
        en: 'Thank you',
        es: 'Gracias',
        fr: 'Merci',
        de: 'Danke',
        it: 'Grazie',
        pt: 'Obrigado',
        ja: 'ありがとうございます',
        ko: '감사합니다',
        zh: '谢谢',
    },
    'common.regards': {
        en: 'Best regards',
        es: 'Saludos cordiales',
        fr: 'Cordialement',
        de: 'Mit freundlichen Grüßen',
        it: 'Cordiali saluti',
        pt: 'Atenciosamente',
        ja: 'よろしくお願いします',
        ko: '감사합니다',
        zh: '此致敬礼',
    },
    'document.signRequest': {
        en: 'Please sign the document',
        es: 'Por favor firme el documento',
        fr: 'Veuillez signer le document',
        de: 'Bitte unterschreiben Sie das Dokument',
        it: 'Si prega di firmare il documento',
        pt: 'Por favor, assine o documento',
        ja: '文書に署名してください',
        ko: '문서에 서명해 주세요',
        zh: '请签署文件',
    },
    'document.completed': {
        en: 'Document has been completed',
        es: 'El documento ha sido completado',
        fr: 'Le document a été complété',
        de: 'Das Dokument wurde abgeschlossen',
        it: 'Il documento è stato completato',
        pt: 'O documento foi concluído',
        ja: '文書が完了しました',
        ko: '문서가 완료되었습니다',
        zh: '文件已完成',
    },
    'auth.welcome': {
        en: 'Welcome to DocuSign Alternative',
        es: 'Bienvenido a DocuSign Alternative',
        fr: 'Bienvenue sur DocuSign Alternative',
        de: 'Willkommen bei DocuSign Alternative',
        it: 'Benvenuto in DocuSign Alternative',
        pt: 'Bem-vindo ao DocuSign Alternative',
        ja: 'DocuSign Alternativeへようこそ',
        ko: 'DocuSign Alternative에 오신 것을 환영합니다',
        zh: '欢迎使用DocuSign Alternative',
    },
    'auth.verifyEmail': {
        en: 'Please verify your email address',
        es: 'Por favor verifique su dirección de correo electrónico',
        fr: 'Veuillez vérifier votre adresse e-mail',
        de: 'Bitte bestätigen Sie Ihre E-Mail-Adresse',
        it: 'Si prega di verificare il proprio indirizzo email',
        pt: 'Por favor, verifique seu endereço de e-mail',
        ja: 'メールアドレスを確認してください',
        ko: '이메일 주소를 확인해 주세요',
        zh: '请验证您的电子邮件地址',
    },
    'auth.resetPassword': {
        en: 'Reset your password',
        es: 'Restablecer su contraseña',
        fr: 'Réinitialiser votre mot de passe',
        de: 'Passwort zurücksetzen',
        it: 'Reimposta la password',
        pt: 'Redefinir sua senha',
        ja: 'パスワードをリセット',
        ko: '비밀번호 재설정',
        zh: '重置密码',
    },
};

export class EmailI18n {
    private translations: LocalizedContent;
    private fallbackLocale: SupportedLocale = 'en';

    constructor(customTranslations: LocalizedContent = {}) {
        this.translations = { ...defaultTranslations, ...customTranslations };
    }

    createContext(locale: SupportedLocale): EmailI18nContext {
        return {
            locale,
            t: (key: string, params?: Record<string, any>) => this.translate(key, locale, params),
        };
    }

    translate(key: string, locale: SupportedLocale, params?: Record<string, any>): string {
        const translation = this.translations[key]?.[locale] ||
            this.translations[key]?.[this.fallbackLocale] ||
            key;

        if (!params) {
            return translation;
        }

        // Simple parameter substitution
        return Object.entries(params).reduce((text, [param, value]) => {
            return text.replace(new RegExp(`{{\\s*${param}\\s*}}`, 'g'), String(value));
        }, translation);
    }

    addTranslations(translations: LocalizedContent): void {
        this.translations = { ...this.translations, ...translations };
    }

    getSupportedLocales(): SupportedLocale[] {
        return ['en', 'es', 'fr', 'de', 'it', 'pt', 'ja', 'ko', 'zh'];
    }

    setFallbackLocale(locale: SupportedLocale): void {
        this.fallbackLocale = locale;
    }
}

// Default i18n instance
export const defaultI18n = new EmailI18n();

// Utility function to detect locale from email or user preferences
export function detectLocale(
    userLocale?: string,
    acceptLanguage?: string,
    defaultLocale: SupportedLocale = 'en'
): SupportedLocale {
    const supportedLocales: SupportedLocale[] = ['en', 'es', 'fr', 'de', 'it', 'pt', 'ja', 'ko', 'zh'];

    // Check user preference first
    if (userLocale && supportedLocales.includes(userLocale as SupportedLocale)) {
        return userLocale as SupportedLocale;
    }

    // Parse Accept-Language header
    if (acceptLanguage) {
        const languages = acceptLanguage
            .split(',')
            .map(lang => lang.split(';')[0].trim().toLowerCase())
            .map(lang => lang.split('-')[0]); // Extract language code only

        for (const lang of languages) {
            if (supportedLocales.includes(lang as SupportedLocale)) {
                return lang as SupportedLocale;
            }
        }
    }

    return defaultLocale;
}
// Additional translations for email templates
const additionalTranslations: LocalizedContent = {
    'auth.verifyEmailButton': {
        en: 'Verify Email Address',
        es: 'Verificar Dirección de Correo',
        fr: 'Vérifier l\'Adresse Email',
        de: 'E-Mail-Adresse Bestätigen',
        it: 'Verifica Indirizzo Email',
        pt: 'Verificar Endereço de Email',
        ja: 'メールアドレスを確認',
        ko: '이메일 주소 확인',
        zh: '验证电子邮件地址',
    },
    'auth.verifyEmailHelp': {
        en: 'If you didn\'t create an account, you can safely ignore this email.',
        es: 'Si no creaste una cuenta, puedes ignorar este correo de forma segura.',
        fr: 'Si vous n\'avez pas créé de compte, vous pouvez ignorer cet email en toute sécurité.',
        de: 'Wenn Sie kein Konto erstellt haben, können Sie diese E-Mail sicher ignorieren.',
        it: 'Se non hai creato un account, puoi ignorare questa email in sicurezza.',
        pt: 'Se você não criou uma conta, pode ignorar este email com segurança.',
        ja: 'アカウントを作成していない場合は、このメールを無視してください。',
        ko: '계정을 만들지 않았다면 이 이메일을 무시하셔도 됩니다.',
        zh: '如果您没有创建账户，可以安全地忽略此邮件。',
    },
    'auth.resetPasswordMessage': {
        en: 'We received a request to reset your password. Click the button below to create a new password.',
        es: 'Recibimos una solicitud para restablecer su contraseña. Haga clic en el botón de abajo para crear una nueva contraseña.',
        fr: 'Nous avons reçu une demande de réinitialisation de votre mot de passe. Cliquez sur le bouton ci-dessous pour créer un nouveau mot de passe.',
        de: 'Wir haben eine Anfrage zum Zurücksetzen Ihres Passworts erhalten. Klicken Sie auf die Schaltfläche unten, um ein neues Passwort zu erstellen.',
        it: 'Abbiamo ricevuto una richiesta per reimpostare la tua password. Clicca sul pulsante qui sotto per creare una nuova password.',
        pt: 'Recebemos uma solicitação para redefinir sua senha. Clique no botão abaixo para criar uma nova senha.',
        ja: 'パスワードのリセット要求を受け取りました。下のボタンをクリックして新しいパスワードを作成してください。',
        ko: '비밀번호 재설정 요청을 받았습니다. 아래 버튼을 클릭하여 새 비밀번호를 만드세요.',
        zh: '我们收到了重置您密码的请求。点击下面的按钮创建新密码。',
    },
    'auth.resetPasswordButton': {
        en: 'Reset Password',
        es: 'Restablecer Contraseña',
        fr: 'Réinitialiser le Mot de Passe',
        de: 'Passwort Zurücksetzen',
        it: 'Reimposta Password',
        pt: 'Redefinir Senha',
        ja: 'パスワードをリセット',
        ko: '비밀번호 재설정',
        zh: '重置密码',
    },
    'auth.resetPasswordExpiry': {
        en: 'This link will expire in {{expiresIn}}.',
        es: 'Este enlace expirará en {{expiresIn}}.',
        fr: 'Ce lien expirera dans {{expiresIn}}.',
        de: 'Dieser Link läuft in {{expiresIn}} ab.',
        it: 'Questo link scadrà tra {{expiresIn}}.',
        pt: 'Este link expirará em {{expiresIn}}.',
        ja: 'このリンクは{{expiresIn}}で期限切れになります。',
        ko: '이 링크는 {{expiresIn}} 후에 만료됩니다.',
        zh: '此链接将在{{expiresIn}}后过期。',
    },
    'auth.resetPasswordHelp': {
        en: 'If you didn\'t request a password reset, you can safely ignore this email.',
        es: 'Si no solicitaste un restablecimiento de contraseña, puedes ignorar este correo de forma segura.',
        fr: 'Si vous n\'avez pas demandé de réinitialisation de mot de passe, vous pouvez ignorer cet email en toute sécurité.',
        de: 'Wenn Sie keine Passwort-Zurücksetzung angefordert haben, können Sie diese E-Mail sicher ignorieren.',
        it: 'Se non hai richiesto un reset della password, puoi ignorare questa email in sicurezza.',
        pt: 'Se você não solicitou uma redefinição de senha, pode ignorar este email com segurança.',
        ja: 'パスワードのリセットを要求していない場合は、このメールを無視してください。',
        ko: '비밀번호 재설정을 요청하지 않았다면 이 이메일을 무시하셔도 됩니다.',
        zh: '如果您没有请求重置密码，可以安全地忽略此邮件。',
    },
    'auth.important': {
        en: 'Important',
        es: 'Importante',
        fr: 'Important',
        de: 'Wichtig',
        it: 'Importante',
        pt: 'Importante',
        ja: '重要',
        ko: '중요',
        zh: '重要',
    },
    'document.signRequestMessage': {
        en: '{{senderName}} has sent you "{{documentName}}" to sign.',
        es: '{{senderName}} te ha enviado "{{documentName}}" para firmar.',
        fr: '{{senderName}} vous a envoyé "{{documentName}}" à signer.',
        de: '{{senderName}} hat Ihnen "{{documentName}}" zum Unterschreiben gesendet.',
        it: '{{senderName}} ti ha inviato "{{documentName}}" da firmare.',
        pt: '{{senderName}} enviou "{{documentName}}" para você assinar.',
        ja: '{{senderName}}が署名用に「{{documentName}}」を送信しました。',
        ko: '{{senderName}}님이 서명을 위해 "{{documentName}}"을(를) 보냈습니다.',
        zh: '{{senderName}}向您发送了"{{documentName}}"以供签署。',
    },
    'document.personalMessage': {
        en: 'Personal Message',
        es: 'Mensaje Personal',
        fr: 'Message Personnel',
        de: 'Persönliche Nachricht',
        it: 'Messaggio Personale',
        pt: 'Mensagem Pessoal',
        ja: '個人メッセージ',
        ko: '개인 메시지',
        zh: '个人消息',
    },
    'document.details': {
        en: 'Document Details',
        es: 'Detalles del Documento',
        fr: 'Détails du Document',
        de: 'Dokumentdetails',
        it: 'Dettagli del Documento',
        pt: 'Detalhes do Documento',
        ja: '文書の詳細',
        ko: '문서 세부사항',
        zh: '文档详情',
    },
    'document.name': {
        en: 'Document Name',
        es: 'Nombre del Documento',
        fr: 'Nom du Document',
        de: 'Dokumentname',
        it: 'Nome del Documento',
        pt: 'Nome do Documento',
        ja: '文書名',
        ko: '문서명',
        zh: '文档名称',
    },
    'document.from': {
        en: 'From',
        es: 'De',
        fr: 'De',
        de: 'Von',
        it: 'Da',
        pt: 'De',
        ja: '送信者',
        ko: '보낸이',
        zh: '发送者',
    },
    'document.dueDate': {
        en: 'Due Date',
        es: 'Fecha de Vencimiento',
        fr: 'Date d\'Échéance',
        de: 'Fälligkeitsdatum',
        it: 'Data di Scadenza',
        pt: 'Data de Vencimento',
        ja: '期限',
        ko: '마감일',
        zh: '截止日期',
    },
    'document.signNow': {
        en: 'Sign Document',
        es: 'Firmar Documento',
        fr: 'Signer le Document',
        de: 'Dokument Unterschreiben',
        it: 'Firma il Documento',
        pt: 'Assinar Documento',
        ja: '文書に署名',
        ko: '문서 서명',
        zh: '签署文档',
    },
    'document.signInstructions': {
        en: 'Click the button above to review and sign the document. You\'ll be guided through the signing process step by step.',
        es: 'Haga clic en el botón de arriba para revisar y firmar el documento. Se le guiará paso a paso a través del proceso de firma.',
        fr: 'Cliquez sur le bouton ci-dessus pour examiner et signer le document. Vous serez guidé étape par étape dans le processus de signature.',
        de: 'Klicken Sie auf die Schaltfläche oben, um das Dokument zu überprüfen und zu unterschreiben. Sie werden Schritt für Schritt durch den Unterschriftsprozess geführt.',
        it: 'Clicca sul pulsante sopra per rivedere e firmare il documento. Sarai guidato passo dopo passo attraverso il processo di firma.',
        pt: 'Clique no botão acima para revisar e assinar o documento. Você será guiado passo a passo através do processo de assinatura.',
        ja: '上のボタンをクリックして文書を確認し、署名してください。署名プロセスを段階的にガイドします。',
        ko: '위 버튼을 클릭하여 문서를 검토하고 서명하세요. 서명 과정을 단계별로 안내해드립니다.',
        zh: '点击上面的按钮查看并签署文档。我们将逐步指导您完成签署过程。',
    },
    'document.completedMessage': {
        en: 'Great news! The document "{{documentName}}" has been completed on {{completedDate}}.',
        es: '¡Excelentes noticias! El documento "{{documentName}}" se completó el {{completedDate}}.',
        fr: 'Excellente nouvelle ! Le document "{{documentName}}" a été complété le {{completedDate}}.',
        de: 'Großartige Neuigkeiten! Das Dokument "{{documentName}}" wurde am {{completedDate}} abgeschlossen.',
        it: 'Ottime notizie! Il documento "{{documentName}}" è stato completato il {{completedDate}}.',
        pt: 'Ótimas notícias! O documento "{{documentName}}" foi concluído em {{completedDate}}.',
        ja: '素晴らしいニュースです！文書「{{documentName}}」が{{completedDate}}に完了しました。',
        ko: '좋은 소식입니다! "{{documentName}}" 문서가 {{completedDate}}에 완료되었습니다.',
        zh: '好消息！文档"{{documentName}}"已于{{completedDate}}完成。',
    },
    'document.completedOn': {
        en: 'Completed On',
        es: 'Completado el',
        fr: 'Complété le',
        de: 'Abgeschlossen am',
        it: 'Completato il',
        pt: 'Concluído em',
        ja: '完了日',
        ko: '완료일',
        zh: '完成日期',
    },
    'document.totalSigners': {
        en: 'Total Signers',
        es: 'Total de Firmantes',
        fr: 'Total des Signataires',
        de: 'Gesamtzahl der Unterzeichner',
        it: 'Totale Firmatari',
        pt: 'Total de Assinantes',
        ja: '署名者総数',
        ko: '총 서명자',
        zh: '签署者总数',
    },
    'document.signingHistory': {
        en: 'Signing History',
        es: 'Historial de Firmas',
        fr: 'Historique des Signatures',
        de: 'Unterschriftsverlauf',
        it: 'Cronologia delle Firme',
        pt: 'Histórico de Assinaturas',
        ja: '署名履歴',
        ko: '서명 이력',
        zh: '签署历史',
    },
    'document.downloadCompleted': {
        en: 'Download Completed Document',
        es: 'Descargar Documento Completado',
        fr: 'Télécharger le Document Complété',
        de: 'Abgeschlossenes Dokument Herunterladen',
        it: 'Scarica Documento Completato',
        pt: 'Baixar Documento Concluído',
        ja: '完了した文書をダウンロード',
        ko: '완료된 문서 다운로드',
        zh: '下载已完成的文档',
    },
    'document.completedNote': {
        en: 'All parties have signed the document. You can download the completed document using the button above.',
        es: 'Todas las partes han firmado el documento. Puede descargar el documento completado usando el botón de arriba.',
        fr: 'Toutes les parties ont signé le document. Vous pouvez télécharger le document complété en utilisant le bouton ci-dessus.',
        de: 'Alle Parteien haben das Dokument unterschrieben. Sie können das abgeschlossene Dokument über die Schaltfläche oben herunterladen.',
        it: 'Tutte le parti hanno firmato il documento. Puoi scaricare il documento completato usando il pulsante sopra.',
        pt: 'Todas as partes assinaram o documento. Você pode baixar o documento concluído usando o botão acima.',
        ja: 'すべての当事者が文書に署名しました。上のボタンを使用して完了した文書をダウンロードできます。',
        ko: '모든 당사자가 문서에 서명했습니다. 위 버튼을 사용하여 완료된 문서를 다운로드할 수 있습니다.',
        zh: '所有当事方都已签署文档。您可以使用上面的按钮下载已完成的文档。',
    },
    'team.signature': {
        en: 'The DocuSign Alternative Team',
        es: 'El Equipo de DocuSign Alternative',
        fr: 'L\'Équipe DocuSign Alternative',
        de: 'Das DocuSign Alternative Team',
        it: 'Il Team di DocuSign Alternative',
        pt: 'A Equipe DocuSign Alternative',
        ja: 'DocuSign Alternativeチーム',
        ko: 'DocuSign Alternative 팀',
        zh: 'DocuSign Alternative团队',
    },
    'footer.questions': {
        en: 'Questions? Contact us at {{supportEmail}}',
        es: '¿Preguntas? Contáctanos en {{supportEmail}}',
        fr: 'Des questions ? Contactez-nous à {{supportEmail}}',
        de: 'Fragen? Kontaktieren Sie uns unter {{supportEmail}}',
        it: 'Domande? Contattaci a {{supportEmail}}',
        pt: 'Dúvidas? Entre em contato conosco em {{supportEmail}}',
        ja: 'ご質問は{{supportEmail}}までお問い合わせください',
        ko: '질문이 있으시면 {{supportEmail}}로 연락주세요',
        zh: '有问题？请联系我们：{{supportEmail}}',
    },
    'footer.unsubscribe': {
        en: 'Unsubscribe from these emails',
        es: 'Cancelar suscripción a estos correos',
        fr: 'Se désabonner de ces emails',
        de: 'Von diesen E-Mails abmelden',
        it: 'Annulla l\'iscrizione a queste email',
        pt: 'Cancelar inscrição destes emails',
        ja: 'これらのメールの配信停止',
        ko: '이 이메일 구독 취소',
        zh: '取消订阅这些邮件',
    },
};

// Merge additional translations with default translations
Object.assign(defaultTranslations, additionalTranslations);