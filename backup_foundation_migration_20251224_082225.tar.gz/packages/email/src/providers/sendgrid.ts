import sgMail from '@sendgrid/mail';
import { pino } from 'pino';
import type {
    EmailService,
    EmailMessage,
    EmailDeliveryResult,
    EmailTemplateProps,
    SendGridConfig,
} from '../types';
import { EmailTemplateRegistry } from '../templates/registry';

const logger = pino({ name: 'email-sendgrid' });

export class SendGridEmailService implements EmailService {
    private config: SendGridConfig;
    private templateRegistry: EmailTemplateRegistry;

    constructor(config: SendGridConfig, templateRegistry: EmailTemplateRegistry) {
        this.config = config;
        sgMail.setApiKey(config.apiKey);
        this.templateRegistry = templateRegistry;
    }

    async send(message: EmailMessage): Promise<EmailDeliveryResult> {
        try {
            logger.info({ to: message.to, subject: message.subject }, 'Sending email via SendGrid');

            const msg = {
                from: this.config.from,
                to: message.to,
                cc: message.cc,
                bcc: message.bcc,
                subject: message.subject,
                html: message.html,
                text: message.text,
                replyTo: this.config.replyTo,
                attachments: message.attachments?.map(att => ({
                    filename: att.filename,
                    content: typeof att.content === 'string' ? att.content : att.content.toString('base64'),
                    type: att.contentType,
                    disposition: 'attachment',
                })),
                headers: message.headers,
                categories: message.tags,
                customArgs: message.metadata,
            };

            const result = await sgMail.send(msg);
            const messageId = result[0]?.headers?.['x-message-id'] || 'unknown';

            logger.info({ messageId }, 'Email sent successfully via SendGrid');
            return {
                success: true,
                messageId,
                provider: 'sendgrid',
                timestamp: new Date(),
            };
        } catch (error: any) {
            logger.error({ error }, 'Error sending email via SendGrid');

            let errorMessage = 'Unknown error';
            if (error.response?.body?.errors) {
                errorMessage = error.response.body.errors.map((e: any) => e.message).join(', ');
            } else if (error.message) {
                errorMessage = error.message;
            }

            return {
                success: false,
                error: errorMessage,
                provider: 'sendgrid',
                timestamp: new Date(),
            };
        }
    }

    async sendTemplate(
        templateName: string,
        to: string | string[],
        props: EmailTemplateProps,
        options?: Partial<EmailMessage>
    ): Promise<EmailDeliveryResult> {
        try {
            const rendered = await this.renderTemplate(templateName, props);

            const message: EmailMessage = {
                to,
                subject: rendered.subject,
                html: rendered.html,
                text: rendered.text,
                ...options,
            };

            return await this.send(message);
        } catch (error) {
            logger.error({ error, templateName }, 'Error sending template email via SendGrid');
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Template rendering failed',
                provider: 'sendgrid',
                timestamp: new Date(),
            };
        }
    }

    async renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{ html: string; text?: string; subject: string }> {
        return await this.templateRegistry.render(templateName, props);
    }

    async validateConfig(): Promise<boolean> {
        try {
            // Test the API key by making a simple request
            await sgMail.send({
                from: this.config.from,
                to: this.config.from, // Send to self for validation
                subject: 'SendGrid Configuration Test',
                text: 'This is a test email to validate SendGrid configuration.',
            }, false); // false = don't actually send, just validate

            return true;
        } catch (error) {
            logger.error({ error }, 'SendGrid configuration validation failed');
            return false;
        }
    }

    getProvider(): 'sendgrid' {
        return 'sendgrid';
    }
}