import nodemailer from 'nodemailer';
import { pino } from 'pino';
import type {
    EmailService,
    EmailMessage,
    EmailDeliveryResult,
    EmailTemplateProps,
    SMTPConfig,
} from '../types';
import { EmailTemplateRegistry } from '../templates/registry';

const logger = pino({ name: 'email-smtp' });

export class SMTPEmailService implements EmailService {
    private transporter: nodemailer.Transporter;
    private config: SMTPConfig;
    private templateRegistry: EmailTemplateRegistry;

    constructor(config: SMTPConfig, templateRegistry: EmailTemplateRegistry) {
        this.config = config;
        this.templateRegistry = templateRegistry;

        this.transporter = nodemailer.createTransport({
            host: config.host,
            port: config.port,
            secure: config.secure,
            auth: config.auth,
        });
    }

    async send(message: EmailMessage): Promise<EmailDeliveryResult> {
        try {
            logger.info({ to: message.to, subject: message.subject }, 'Sending email via SMTP');

            const mailOptions = {
                from: this.config.from,
                to: Array.isArray(message.to) ? message.to.join(', ') : message.to,
                cc: message.cc ? (Array.isArray(message.cc) ? message.cc.join(', ') : message.cc) : undefined,
                bcc: message.bcc ? (Array.isArray(message.bcc) ? message.bcc.join(', ') : message.bcc) : undefined,
                subject: message.subject,
                html: message.html,
                text: message.text,
                replyTo: this.config.replyTo,
                attachments: message.attachments?.map(att => ({
                    filename: att.filename,
                    content: att.content,
                    contentType: att.contentType,
                    encoding: att.encoding as any,
                })),
                headers: message.headers,
            };

            const result = await this.transporter.sendMail(mailOptions);

            logger.info({ messageId: result.messageId }, 'Email sent successfully via SMTP');
            return {
                success: true,
                messageId: result.messageId,
                provider: 'smtp',
                timestamp: new Date(),
            };
        } catch (error) {
            logger.error({ error }, 'Error sending email via SMTP');
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error',
                provider: 'smtp',
                timestamp: new Date(),
            };
        }
    }

    async sendTemplate(
        templateName: string,
        to: string | string[],
        props: EmailTemplateProps,
        options?: Partial<EmailMessage>
    ): Promise<EmailDeliveryResult> {
        try {
            const rendered = await this.renderTemplate(templateName, props);

            const message: EmailMessage = {
                to,
                subject: rendered.subject,
                html: rendered.html,
                text: rendered.text,
                ...options,
            };

            return await this.send(message);
        } catch (error) {
            logger.error({ error, templateName }, 'Error sending template email via SMTP');
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Template rendering failed',
                provider: 'smtp',
                timestamp: new Date(),
            };
        }
    }

    async renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{ html: string; text?: string; subject: string }> {
        return await this.templateRegistry.render(templateName, props);
    }

    async validateConfig(): Promise<boolean> {
        try {
            // Verify the SMTP connection
            await this.transporter.verify();
            return true;
        } catch (error) {
            logger.error({ error }, 'SMTP configuration validation failed');
            return false;
        }
    }

    getProvider(): 'smtp' {
        return 'smtp';
    }
}