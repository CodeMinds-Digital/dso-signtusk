import { pino } from 'pino';
import type {
    EmailService,
    EmailProvider,
    EmailConfig,
    ResendConfig,
    SendGridConfig,
    SMTPConfig,
} from './types';
import { ResendEmailService } from './providers/resend';
import { SendGridEmailService } from './providers/sendgrid';
import { SMTPEmailService } from './providers/smtp';
import { EmailTemplateRegistry } from './templates/registry';
import { EmailI18n, defaultI18n } from './i18n';

// Import templates
import { WelcomeEmail } from './templates/WelcomeEmail';
import { SigningRequestEmail } from './templates/SigningRequestEmail';
import { DocumentCompletedEmail } from './templates/DocumentCompletedEmail';
import { PasswordResetEmail } from './templates/PasswordResetEmail';
import { EmailVerificationEmail } from './templates/EmailVerificationEmail';

const logger = pino({ name: 'email-service' });

export class EmailServiceFactory {
    private static templateRegistry: EmailTemplateRegistry;
    private static i18n: EmailI18n;

    static initialize(customI18n?: EmailI18n): void {
        this.i18n = customI18n || defaultI18n;
        this.templateRegistry = new EmailTemplateRegistry(this.i18n);

        // Register default templates
        this.registerDefaultTemplates();
    }

    static create(config: EmailConfig): EmailService {
        if (!this.templateRegistry) {
            this.initialize();
        }

        switch (config.provider) {
            case 'resend':
                return new ResendEmailService(config as ResendConfig, this.templateRegistry);

            case 'sendgrid':
                return new SendGridEmailService(config as SendGridConfig, this.templateRegistry);

            case 'smtp':
                return new SMTPEmailService(config as SMTPConfig, this.templateRegistry);

            default:
                throw new Error(`Unsupported email provider: ${(config as any).provider}`);
        }
    }

    static getTemplateRegistry(): EmailTemplateRegistry {
        if (!this.templateRegistry) {
            this.initialize();
        }
        return this.templateRegistry;
    }

    static getI18n(): EmailI18n {
        if (!this.i18n) {
            this.initialize();
        }
        return this.i18n;
    }

    private static registerDefaultTemplates(): void {
        const templates = [
            {
                name: 'welcome',
                subject: 'auth.welcome',
                component: WelcomeEmail,
                category: 'authentication',
                description: 'Welcome email sent to new users',
            },
            {
                name: 'email-verification',
                subject: 'auth.verifyEmail',
                component: EmailVerificationEmail,
                category: 'authentication',
                description: 'Email verification email sent to new users',
            },
            {
                name: 'signing-request',
                subject: 'document.signRequest',
                component: SigningRequestEmail,
                category: 'documents',
                description: 'Email sent to request document signature',
            },
            {
                name: 'document-completed',
                subject: 'document.completed',
                component: DocumentCompletedEmail,
                category: 'documents',
                description: 'Email sent when document signing is completed',
            },
            {
                name: 'password-reset',
                subject: 'auth.resetPassword',
                component: PasswordResetEmail,
                category: 'authentication',
                description: 'Password reset email',
            },
        ];

        this.templateRegistry.registerMultiple(templates);
        logger.info({ count: templates.length }, 'Registered default email templates');
    }
}

// Convenience function to create email service from environment variables
export function createEmailServiceFromEnv(): EmailService {
    const provider = process.env.EMAIL_PROVIDER as EmailProvider;

    if (!provider) {
        throw new Error('EMAIL_PROVIDER environment variable is required');
    }

    const baseConfig = {
        provider,
        from: process.env.EMAIL_FROM || 'noreply@example.com',
        replyTo: process.env.EMAIL_REPLY_TO,
    };

    switch (provider) {
        case 'resend':
            return EmailServiceFactory.create({
                ...baseConfig,
                provider: 'resend',
                apiKey: process.env.RESEND_API_KEY || '',
            } as ResendConfig);

        case 'sendgrid':
            return EmailServiceFactory.create({
                ...baseConfig,
                provider: 'sendgrid',
                apiKey: process.env.SENDGRID_API_KEY || '',
            } as SendGridConfig);

        case 'smtp':
            return EmailServiceFactory.create({
                ...baseConfig,
                provider: 'smtp',
                host: process.env.SMTP_HOST || 'localhost',
                port: parseInt(process.env.SMTP_PORT || '587'),
                secure: process.env.SMTP_SECURE === 'true',
                auth: {
                    user: process.env.SMTP_USER || '',
                    pass: process.env.SMTP_PASS || '',
                },
            } as SMTPConfig);

        default:
            throw new Error(`Unsupported email provider: ${provider}`);
    }
}