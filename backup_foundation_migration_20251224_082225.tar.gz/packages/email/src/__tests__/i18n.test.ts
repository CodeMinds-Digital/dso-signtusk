import { describe, it, expect } from 'vitest';
import { EmailI18n, detectLocale } from '../i18n';
import type { SupportedLocale } from '../types';

describe('EmailI18n', () => {
    let i18n: EmailI18n;

    beforeEach(() => {
        i18n = new EmailI18n();
    });

    describe('Translation', () => {
        it('should translate basic keys', () => {
            const context = i18n.createContext('en');
            expect(context.t('common.greeting')).toBe('Hello');
            expect(context.t('common.thanks')).toBe('Thank you');
        });

        it('should translate with different locales', () => {
            const enContext = i18n.createContext('en');
            const esContext = i18n.createContext('es');
            const frContext = i18n.createContext('fr');

            expect(enContext.t('common.greeting')).toBe('Hello');
            expect(esContext.t('common.greeting')).toBe('Hola');
            expect(frContext.t('common.greeting')).toBe('Bonjour');
        });

        it('should handle parameter substitution', () => {
            const context = i18n.createContext('en');
            const result = context.t('document.signRequestMessage', {
                senderName: 'John Doe',
                documentName: 'Contract.pdf',
            });

            expect(result).toContain('John Doe');
            expect(result).toContain('Contract.pdf');
        });

        it('should fallback to English for missing translations', () => {
            const context = i18n.createContext('zh');
            // Assuming some key doesn't exist in Chinese
            const result = context.t('some.missing.key');
            expect(result).toBe('some.missing.key'); // Should return the key itself
        });

        it('should return key if translation not found', () => {
            const context = i18n.createContext('en');
            const result = context.t('non.existent.key');
            expect(result).toBe('non.existent.key');
        });
    });

    describe('Custom Translations', () => {
        it('should add custom translations', () => {
            const customTranslations = {
                'custom.message': {
                    en: 'Custom message',
                    es: 'Mensaje personalizado',
                },
            };

            i18n.addTranslations(customTranslations);

            const enContext = i18n.createContext('en');
            const esContext = i18n.createContext('es');

            expect(enContext.t('custom.message')).toBe('Custom message');
            expect(esContext.t('custom.message')).toBe('Mensaje personalizado');
        });

        it('should override existing translations', () => {
            const overrideTranslations = {
                'common.greeting': {
                    en: 'Hi there',
                },
            };

            i18n.addTranslations(overrideTranslations);

            const context = i18n.createContext('en');
            expect(context.t('common.greeting')).toBe('Hi there');
        });
    });

    describe('Locale Detection', () => {
        it('should detect locale from user preference', () => {
            expect(detectLocale('es')).toBe('es');
            expect(detectLocale('fr')).toBe('fr');
            expect(detectLocale('invalid' as SupportedLocale)).toBe('en');
        });

        it('should detect locale from Accept-Language header', () => {
            expect(detectLocale(undefined, 'es-ES,es;q=0.9,en;q=0.8')).toBe('es');
            expect(detectLocale(undefined, 'fr-FR,fr;q=0.9,en;q=0.8')).toBe('fr');
            expect(detectLocale(undefined, 'de-DE,de;q=0.9')).toBe('de');
        });

        it('should prioritize user preference over Accept-Language', () => {
            expect(detectLocale('fr', 'es-ES,es;q=0.9,en;q=0.8')).toBe('fr');
        });

        it('should fallback to default locale', () => {
            expect(detectLocale(undefined, undefined)).toBe('en');
            expect(detectLocale(undefined, 'invalid-locale')).toBe('en');
            expect(detectLocale(undefined, undefined, 'es')).toBe('es');
        });
    });

    describe('Supported Locales', () => {
        it('should return list of supported locales', () => {
            const locales = i18n.getSupportedLocales();
            expect(locales).toContain('en');
            expect(locales).toContain('es');
            expect(locales).toContain('fr');
            expect(locales).toContain('de');
            expect(locales).toContain('it');
            expect(locales).toContain('pt');
            expect(locales).toContain('ja');
            expect(locales).toContain('ko');
            expect(locales).toContain('zh');
        });

        it('should set fallback locale', () => {
            i18n.setFallbackLocale('es');

            const context = i18n.createContext('invalid' as SupportedLocale);
            // Should fallback to Spanish instead of English
            expect(context.t('common.greeting')).toBe('Hola');
        });
    });
});