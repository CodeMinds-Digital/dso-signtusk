import { describe, it, expect, beforeEach } from 'vitest';
import { EmailServiceFactory } from '../service';
import { MockEmailService } from '../testing';
import { EmailTemplateRegistry } from '../templates/registry';
import type { EmailMessage, SMTPConfig } from '../types';

describe('EmailService', () => {
    let mockService: MockEmailService;
    let templateRegistry: EmailTemplateRegistry;

    beforeEach(() => {
        EmailServiceFactory.initialize();
        templateRegistry = EmailServiceFactory.getTemplateRegistry();
        mockService = new MockEmailService(templateRegistry);
    });

    describe('Basic Email Sending', () => {
        it('should send a basic email successfully', async () => {
            const message: EmailMessage = {
                to: 'test@example.com',
                subject: 'Test Email',
                html: '<p>Hello, World!</p>',
                text: 'Hello, World!',
            };

            const result = await mockService.send(message);

            expect(result.success).toBe(true);
            expect(result.messageId).toBeDefined();
            expect(result.provider).toBe('smtp');
            expect(mockService.getEmailCount()).toBe(1);
        });

        it('should handle email sending failures', async () => {
            mockService.setShouldFail(true, 'Network error');

            const message: EmailMessage = {
                to: 'test@example.com',
                subject: 'Test Email',
                html: '<p>Hello, World!</p>',
            };

            const result = await mockService.send(message);

            expect(result.success).toBe(false);
            expect(result.error).toBe('Network error');
            expect(result.messageId).toBeUndefined();
        });

        it('should send emails to multiple recipients', async () => {
            const message: EmailMessage = {
                to: ['test1@example.com', 'test2@example.com'],
                subject: 'Test Email',
                html: '<p>Hello, World!</p>',
            };

            const result = await mockService.send(message);

            expect(result.success).toBe(true);
            expect(mockService.getEmailCount()).toBe(1);

            const sentEmail = mockService.getLastSentEmail();
            expect(sentEmail.message.to).toEqual(['test1@example.com', 'test2@example.com']);
        });
    });

    describe('Template Email Sending', () => {
        it('should send welcome email template', async () => {
            const result = await mockService.sendTemplate(
                'welcome',
                'newuser@example.com',
                {
                    userName: 'John Doe',
                    verificationUrl: 'https://example.com/verify/123',
                    locale: 'en',
                }
            );

            expect(result.success).toBe(true);
            expect(mockService.getEmailCount()).toBe(1);

            const sentEmail = mockService.getLastSentEmail();
            expect(sentEmail.message.to).toBe('newuser@example.com');
            expect(sentEmail.message.html).toContain('John Doe');
            expect(sentEmail.message.html).toContain('https://example.com/verify/123');
        });

        it('should send signing request email template', async () => {
            const result = await mockService.sendTemplate(
                'signing-request',
                'signer@example.com',
                {
                    recipientName: 'Jane Smith',
                    senderName: 'John Doe',
                    documentName: 'Contract Agreement',
                    signingUrl: 'https://example.com/sign/456',
                    dueDate: '2024-01-15',
                    message: 'Please review and sign this contract.',
                    locale: 'en',
                }
            );

            expect(result.success).toBe(true);
            expect(mockService.getEmailCount()).toBe(1);

            const sentEmail = mockService.getLastSentEmail();
            expect(sentEmail.message.to).toBe('signer@example.com');
            expect(sentEmail.message.html).toContain('Jane Smith');
            expect(sentEmail.message.html).toContain('Contract Agreement');
            expect(sentEmail.message.html).toContain('Please review and sign this contract.');
        });

        it('should handle template rendering errors', async () => {
            const result = await mockService.sendTemplate(
                'non-existent-template',
                'test@example.com',
                {}
            );

            expect(result.success).toBe(false);
            expect(result.error).toContain('not found');
        });
    });

    describe('Email Service Factory', () => {
        it('should create SMTP email service', () => {
            const config: SMTPConfig = {
                provider: 'smtp',
                from: 'test@example.com',
                host: 'smtp.example.com',
                port: 587,
                secure: true,
                auth: {
                    user: 'user',
                    pass: 'pass',
                },
            };

            const service = EmailServiceFactory.create(config);
            expect(service.getProvider()).toBe('smtp');
        });

        it('should throw error for unsupported provider', () => {
            const config = {
                provider: 'unsupported' as any,
                from: 'test@example.com',
            };

            expect(() => EmailServiceFactory.create(config)).toThrow('Unsupported email provider');
        });
    });

    describe('Email Tracking', () => {
        it('should track sent emails', async () => {
            await mockService.send({
                to: 'user1@example.com',
                subject: 'Email 1',
                html: '<p>Content 1</p>',
            });

            await mockService.send({
                to: 'user2@example.com',
                subject: 'Email 2',
                html: '<p>Content 2</p>',
            });

            expect(mockService.getEmailCount()).toBe(2);

            const emailsToUser1 = mockService.findEmailsByRecipient('user1@example.com');
            expect(emailsToUser1).toHaveLength(1);
            expect(emailsToUser1[0].message.subject).toBe('Email 1');

            const emailsWithSubject = mockService.findEmailsBySubject('Email 2');
            expect(emailsWithSubject).toHaveLength(1);
            expect(emailsWithSubject[0].message.to).toBe('user2@example.com');
        });

        it('should clear sent emails', async () => {
            await mockService.send({
                to: 'test@example.com',
                subject: 'Test',
                html: '<p>Test</p>',
            });

            expect(mockService.getEmailCount()).toBe(1);

            mockService.clearSentEmails();
            expect(mockService.getEmailCount()).toBe(0);
        });
    });
});