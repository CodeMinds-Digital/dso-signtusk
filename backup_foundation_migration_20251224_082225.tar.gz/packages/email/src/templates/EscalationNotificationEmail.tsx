import React from 'react';
import {
    Body,
    Button,
    Container,
    Head,
    Heading,
    Hr,
    Html,
    Preview,
    Section,
    Text,
    Tailwind,
} from '@react-email/components';
import { Layout } from './components/Layout';

interface EscalationNotificationEmailProps {
    managerName: string;
    documentTitle: string;
    originalRecipient: {
        name: string;
        email: string;
    };
    senderName: string;
    organizationName: string;
    escalationLevel: 'supervisor' | 'manager' | 'admin';
    reminderHistory: Array<{
        type: string;
        sentAt: string;
        channels: string[];
        delivered: boolean;
    }>;
    suggestedActions: string[];
    actionUrl: string;
    daysOverdue: number;
}

export const EscalationNotificationEmail = ({
    managerName,
    documentTitle,
    originalRecipient,
    senderName,
    organizationName,
    escalationLevel,
    reminderHistory,
    suggestedActions,
    actionUrl,
    daysOverdue,
}: EscalationNotificationEmailProps) => {
    const escalationLabels = {
        supervisor: 'Supervisor Escalation',
        manager: 'Manager Escalation',
        admin: 'Administrative Escalation',
    };

    const escalationColors = {
        supervisor: '#f59e0b',
        manager: '#ef4444',
        admin: '#dc2626',
    };

    return (
        <Html>
            <Head />
            <Preview>
                Escalation Required: Document signing delayed - {documentTitle}
            </Preview>
            <Tailwind>
                <Layout organizationName={organizationName}>
                    {/* Escalation Alert Banner */}
                    <Section
                        style={{
                            backgroundColor: escalationColors[escalationLevel],
                            padding: '16px 24px',
                            borderRadius: '8px',
                            marginBottom: '24px',
                        }}
                    >
                        <Text
                            style={{
                                color: '#ffffff',
                                fontSize: '16px',
                                fontWeight: 'bold',
                                margin: 0,
                                textAlign: 'center',
                            }}
                        >
                            🚨 {escalationLabels[escalationLevel]} Required
                        </Text>
                        <Text
                            style={{
                                color: '#ffffff',
                                fontSize: '14px',
                                margin: '4px 0 0 0',
                                textAlign: 'center',
                            }}
                        >
                            Document signing is {daysOverdue} days overdue
                        </Text>
                    </Section>

                    <Heading
                        style={{
                            fontSize: '24px',
                            fontWeight: 'bold',
                            color: '#1f2937',
                            marginBottom: '16px',
                        }}
                    >
                        Document Signing Escalation
                    </Heading>

                    <Text
                        style={{
                            fontSize: '16px',
                            color: '#4b5563',
                            lineHeight: '24px',
                            marginBottom: '16px',
                        }}
                    >
                        Hi {managerName},
                    </Text>

                    <Text
                        style={{
                            fontSize: '16px',
                            color: '#4b5563',
                            lineHeight: '24px',
                            marginBottom: '24px',
                        }}
                    >
                        A document signing request has been escalated to your attention due to lack of response
                        from the recipient. Your intervention may be required to ensure timely completion.
                    </Text>

                    {/* Document Details */}
                    <Section
                        style={{
                            backgroundColor: '#fef2f2',
                            border: '1px solid #fecaca',
                            borderRadius: '8px',
                            padding: '20px',
                            marginBottom: '24px',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: '14px',
                                color: '#991b1b',
                                fontWeight: '600',
                                margin: '0 0 16px 0',
                            }}
                        >
                            ESCALATION DETAILS
                        </Text>

                        <div style={{ marginBottom: '12px' }}>
                            <Text
                                style={{
                                    fontSize: '14px',
                                    color: '#6b7280',
                                    margin: '0 0 4px 0',
                                }}
                            >
                                Document
                            </Text>
                            <Text
                                style={{
                                    fontSize: '16px',
                                    fontWeight: '600',
                                    color: '#1f2937',
                                    margin: 0,
                                }}
                            >
                                {documentTitle}
                            </Text>
                        </div>

                        <div style={{ marginBottom: '12px' }}>
                            <Text
                                style={{
                                    fontSize: '14px',
                                    color: '#6b7280',
                                    margin: '0 0 4px 0',
                                }}
                            >
                                Recipient
                            </Text>
                            <Text
                                style={{
                                    fontSize: '16px',
                                    color: '#1f2937',
                                    margin: 0,
                                }}
                            >
                                {originalRecipient.name} ({originalRecipient.email})
                            </Text>
                        </div>

                        <div style={{ marginBottom: '12px' }}>
                            <Text
                                style={{
                                    fontSize: '14px',
                                    color: '#6b7280',
                                    margin: '0 0 4px 0',
                                }}
                            >
                                Sent by
                            </Text>
                            <Text
                                style={{
                                    fontSize: '16px',
                                    color: '#1f2937',
                                    margin: 0,
                                }}
                            >
                                {senderName}
                            </Text>
                        </div>

                        <div>
                            <Text
                                style={{
                                    fontSize: '14px',
                                    color: '#6b7280',
                                    margin: '0 0 4px 0',
                                }}
                            >
                                Days Overdue
                            </Text>
                            <Text
                                style={{
                                    fontSize: '16px',
                                    fontWeight: '600',
                                    color: '#dc2626',
                                    margin: 0,
                                }}
                            >
                                {daysOverdue} days
                            </Text>
                        </div>
                    </Section>

                    {/* Reminder History */}
                    <Section
                        style={{
                            backgroundColor: '#f9fafb',
                            border: '1px solid #e5e7eb',
                            borderRadius: '8px',
                            padding: '20px',
                            marginBottom: '24px',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: '16px',
                                fontWeight: '600',
                                color: '#1f2937',
                                margin: '0 0 16px 0',
                            }}
                        >
                            Reminder History
                        </Text>

                        {reminderHistory.map((reminder, index) => (
                            <div
                                key={index}
                                style={{
                                    borderLeft: `3px solid ${reminder.delivered ? '#10b981' : '#ef4444'}`,
                                    paddingLeft: '12px',
                                    marginBottom: '12px',
                                }}
                            >
                                <Text
                                    style={{
                                        fontSize: '14px',
                                        fontWeight: '600',
                                        color: '#1f2937',
                                        margin: '0 0 4px 0',
                                    }}
                                >
                                    {reminder.type} Reminder
                                </Text>
                                <Text
                                    style={{
                                        fontSize: '12px',
                                        color: '#6b7280',
                                        margin: '0 0 4px 0',
                                    }}
                                >
                                    Sent: {new Date(reminder.sentAt).toLocaleDateString()} via {reminder.channels.join(', ')}
                                </Text>
                                <Text
                                    style={{
                                        fontSize: '12px',
                                        color: reminder.delivered ? '#059669' : '#dc2626',
                                        fontWeight: '500',
                                        margin: 0,
                                    }}
                                >
                                    {reminder.delivered ? '✓ Delivered' : '✗ Failed to deliver'}
                                </Text>
                            </div>
                        ))}
                    </Section>

                    {/* Suggested Actions */}
                    <Section
                        style={{
                            backgroundColor: '#eff6ff',
                            border: '1px solid #bfdbfe',
                            borderRadius: '8px',
                            padding: '20px',
                            marginBottom: '24px',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: '16px',
                                fontWeight: '600',
                                color: '#1e40af',
                                margin: '0 0 16px 0',
                            }}
                        >
                            Suggested Actions
                        </Text>

                        {suggestedActions.map((action, index) => (
                            <Text
                                key={index}
                                style={{
                                    fontSize: '14px',
                                    color: '#1e40af',
                                    margin: '0 0 8px 0',
                                    paddingLeft: '16px',
                                    position: 'relative',
                                }}
                            >
                                <span style={{ position: 'absolute', left: 0 }}>•</span>
                                {action}
                            </Text>
                        ))}
                    </Section>

                    {/* Call to Action */}
                    <Section style={{ textAlign: 'center', marginBottom: '32px' }}>
                        <Button
                            href={actionUrl}
                            style={{
                                backgroundColor: '#dc2626',
                                color: '#ffffff',
                                fontSize: '16px',
                                fontWeight: 'bold',
                                padding: '14px 32px',
                                borderRadius: '8px',
                                textDecoration: 'none',
                                display: 'inline-block',
                            }}
                        >
                            Review Document Status
                        </Button>
                    </Section>

                    {/* Additional Information */}
                    <Hr style={{ borderColor: '#e5e7eb', margin: '32px 0' }} />

                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                            marginBottom: '16px',
                        }}
                    >
                        <strong>What happens next?</strong>
                    </Text>
                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                            marginBottom: '16px',
                        }}
                    >
                        This escalation was automatically triggered based on your organization's reminder policies.
                        Please review the situation and take appropriate action to ensure document completion.
                    </Text>

                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                        }}
                    >
                        If you believe this escalation was triggered in error or need assistance,
                        please contact your system administrator or support team.
                    </Text>
                </Layout>
            </Tailwind>
        </Html>
    );
};

export default EscalationNotificationEmail;