import React from 'react';
import {
    Body,
    Button,
    Container,
    Head,
    Heading,
    Hr,
    Html,
    Preview,
    Section,
    Text,
    Tailwind,
} from '@react-email/components';
import { Layout } from './components/Layout';

interface SigningReminderEmailProps {
    recipientName: string;
    documentTitle: string;
    senderName: string;
    organizationName: string;
    actionUrl: string;
    urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
    daysRemaining?: number;
    progressPercentage?: number;
    message?: string;
    branding?: {
        logoUrl?: string;
        primaryColor?: string;
        organizationName?: string;
    };
}

export const SigningReminderEmail = ({
    recipientName,
    documentTitle,
    senderName,
    organizationName,
    actionUrl,
    urgencyLevel = 'medium',
    daysRemaining,
    progressPercentage,
    message,
    branding,
}: SigningReminderEmailProps) => {
    const urgencyColors = {
        low: '#10b981',
        medium: '#f59e0b',
        high: '#ef4444',
        critical: '#dc2626',
    };

    const urgencyLabels = {
        low: 'Reminder',
        medium: 'Action Required',
        high: 'Urgent',
        critical: 'Critical - Immediate Action Required',
    };

    const primaryColor = branding?.primaryColor || '#2563eb';
    const urgencyColor = urgencyColors[urgencyLevel];

    return (
        <Html>
            <Head />
            <Preview>
                {urgencyLabels[urgencyLevel]}: Please sign "{documentTitle}"
            </Preview>
            <Tailwind>
                <Layout
                    organizationName={branding?.organizationName || organizationName}
                    logoUrl={branding?.logoUrl}
                >
                    {/* Urgency Banner */}
                    {(urgencyLevel === 'high' || urgencyLevel === 'critical') && (
                        <Section
                            style={{
                                backgroundColor: urgencyColor,
                                padding: '12px 24px',
                                borderRadius: '8px',
                                marginBottom: '24px',
                            }}
                        >
                            <Text
                                style={{
                                    color: '#ffffff',
                                    fontSize: '14px',
                                    fontWeight: 'bold',
                                    margin: 0,
                                    textAlign: 'center',
                                }}
                            >
                                {urgencyLabels[urgencyLevel]}
                                {daysRemaining !== undefined && daysRemaining <= 3 && (
                                    <span> - {daysRemaining} {daysRemaining === 1 ? 'day' : 'days'} remaining</span>
                                )}
                            </Text>
                        </Section>
                    )}

                    {/* Main Content */}
                    <Heading
                        style={{
                            fontSize: '24px',
                            fontWeight: 'bold',
                            color: '#1f2937',
                            marginBottom: '16px',
                        }}
                    >
                        Document Signature Required
                    </Heading>

                    <Text
                        style={{
                            fontSize: '16px',
                            color: '#4b5563',
                            lineHeight: '24px',
                            marginBottom: '16px',
                        }}
                    >
                        Hi {recipientName},
                    </Text>

                    <Text
                        style={{
                            fontSize: '16px',
                            color: '#4b5563',
                            lineHeight: '24px',
                            marginBottom: '24px',
                        }}
                    >
                        {message || (
                            <>
                                {senderName} from {organizationName} has sent you <strong>"{documentTitle}"</strong> to sign.
                                {urgencyLevel === 'critical' && ' This document requires your immediate attention.'}
                                {urgencyLevel === 'high' && ' Please review and sign this document as soon as possible.'}
                                {urgencyLevel === 'medium' && ' Please take a moment to review and sign this document.'}
                            </>
                        )}
                    </Text>

                    {/* Document Info Card */}
                    <Section
                        style={{
                            backgroundColor: '#f9fafb',
                            border: '1px solid #e5e7eb',
                            borderRadius: '8px',
                            padding: '20px',
                            marginBottom: '24px',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: '14px',
                                color: '#6b7280',
                                margin: '0 0 8px 0',
                            }}
                        >
                            Document
                        </Text>
                        <Text
                            style={{
                                fontSize: '16px',
                                fontWeight: '600',
                                color: '#1f2937',
                                margin: '0 0 16px 0',
                            }}
                        >
                            {documentTitle}
                        </Text>

                        {progressPercentage !== undefined && progressPercentage > 0 && (
                            <>
                                <Text
                                    style={{
                                        fontSize: '14px',
                                        color: '#6b7280',
                                        margin: '0 0 8px 0',
                                    }}
                                >
                                    Signing Progress
                                </Text>
                                <div
                                    style={{
                                        width: '100%',
                                        height: '8px',
                                        backgroundColor: '#e5e7eb',
                                        borderRadius: '4px',
                                        overflow: 'hidden',
                                        marginBottom: '8px',
                                    }}
                                >
                                    <div
                                        style={{
                                            width: `${progressPercentage}%`,
                                            height: '100%',
                                            backgroundColor: primaryColor,
                                            transition: 'width 0.3s ease',
                                        }}
                                    />
                                </div>
                                <Text
                                    style={{
                                        fontSize: '12px',
                                        color: '#6b7280',
                                        margin: '0 0 16px 0',
                                    }}
                                >
                                    {progressPercentage}% complete
                                </Text>
                            </>
                        )}

                        {daysRemaining !== undefined && (
                            <>
                                <Text
                                    style={{
                                        fontSize: '14px',
                                        color: '#6b7280',
                                        margin: '0 0 4px 0',
                                    }}
                                >
                                    Time Remaining
                                </Text>
                                <Text
                                    style={{
                                        fontSize: '16px',
                                        fontWeight: '600',
                                        color: daysRemaining <= 1 ? urgencyColors.critical : daysRemaining <= 3 ? urgencyColors.high : '#1f2937',
                                        margin: 0,
                                    }}
                                >
                                    {daysRemaining} {daysRemaining === 1 ? 'day' : 'days'}
                                </Text>
                            </>
                        )}
                    </Section>

                    {/* Call to Action */}
                    <Section style={{ textAlign: 'center', marginBottom: '32px' }}>
                        <Button
                            href={actionUrl}
                            style={{
                                backgroundColor: primaryColor,
                                color: '#ffffff',
                                fontSize: '16px',
                                fontWeight: 'bold',
                                padding: '14px 32px',
                                borderRadius: '8px',
                                textDecoration: 'none',
                                display: 'inline-block',
                            }}
                        >
                            Review and Sign Document
                        </Button>
                    </Section>

                    {/* Additional Information */}
                    <Hr style={{ borderColor: '#e5e7eb', margin: '32px 0' }} />

                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                            marginBottom: '8px',
                        }}
                    >
                        <strong>Why am I receiving this?</strong>
                    </Text>
                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                            marginBottom: '16px',
                        }}
                    >
                        You're receiving this reminder because {senderName} has requested your signature on "{documentTitle}".
                        This is an automated reminder to help ensure timely completion.
                    </Text>

                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                            marginBottom: '8px',
                        }}
                    >
                        <strong>Need help?</strong>
                    </Text>
                    <Text
                        style={{
                            fontSize: '14px',
                            color: '#6b7280',
                            lineHeight: '20px',
                        }}
                    >
                        If you have questions about this document, please contact {senderName} directly.
                        For technical support, visit our help center or contact support@{organizationName.toLowerCase().replace(/\s+/g, '')}.com
                    </Text>
                </Layout>
            </Tailwind>
        </Html>
    );
};

export default SigningReminderEmail;