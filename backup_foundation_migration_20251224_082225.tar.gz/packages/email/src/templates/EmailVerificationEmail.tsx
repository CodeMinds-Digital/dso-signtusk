import React from 'react';
import { Button } from '../templates/components/Button';
import { Layout } from '../templates/components/Layout';

interface EmailVerificationEmailProps {
    userName: string;
    verificationUrl: string;
    expirationHours?: number;
}

export const EmailVerificationEmail: React.FC<EmailVerificationEmailProps> = ({
    userName,
    verificationUrl,
    expirationHours = 24,
}) => {
    return (
        <Layout>
            <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
                <h1 style={{ color: '#333', fontSize: '24px', marginBottom: '20px' }}>
                    Verify Your Email Address
                </h1>

                <p style={{ fontSize: '16px', lineHeight: '1.5', color: '#555', marginBottom: '20px' }}>
                    Hi {userName},
                </p>

                <p style={{ fontSize: '16px', lineHeight: '1.5', color: '#555', marginBottom: '20px' }}>
                    Thank you for registering with our DocuSign Alternative platform. To complete your account setup and start using our e-signature services, please verify your email address by clicking the button below.
                </p>

                <div style={{ textAlign: 'center', margin: '30px 0' }}>
                    <Button href={verificationUrl}>
                        Verify Email Address
                    </Button>
                </div>

                <p style={{ fontSize: '14px', lineHeight: '1.5', color: '#777', marginBottom: '10px' }}>
                    If the button above doesn't work, you can also copy and paste the following link into your browser:
                </p>

                <p style={{
                    fontSize: '14px',
                    lineHeight: '1.5',
                    color: '#007bff',
                    wordBreak: 'break-all',
                    backgroundColor: '#f8f9fa',
                    padding: '10px',
                    borderRadius: '4px',
                    marginBottom: '20px'
                }}>
                    {verificationUrl}
                </p>

                <p style={{ fontSize: '14px', lineHeight: '1.5', color: '#777', marginBottom: '20px' }}>
                    This verification link will expire in {expirationHours} hours for security reasons. If you don't verify your email within this time, you'll need to request a new verification email.
                </p>

                <p style={{ fontSize: '14px', lineHeight: '1.5', color: '#777', marginBottom: '20px' }}>
                    If you didn't create an account with us, please ignore this email. Your email address will not be added to our system.
                </p>

                <hr style={{ border: 'none', borderTop: '1px solid #eee', margin: '30px 0' }} />

                <p style={{ fontSize: '12px', color: '#999', textAlign: 'center' }}>
                    This is an automated message. Please do not reply to this email.
                </p>
            </div>
        </Layout>
    );
};