import React from 'react';
import { Layout } from './components/Layout';
import { Button } from './components/Button';
import type { EmailTemplateProps, EmailI18nContext } from '../types';

interface WelcomeEmailProps extends EmailTemplateProps {
    userName: string;
    verificationUrl: string;
    i18n: EmailI18nContext;
}

export const WelcomeEmail: React.FC<WelcomeEmailProps> = ({
    userName,
    verificationUrl,
    i18n,
    ...layoutProps
}) => {
    return (
        <Layout
            i18n={i18n}
            previewText={i18n.t('auth.welcome')}
            {...layoutProps}
        >
            <h1 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#111827',
                marginBottom: '16px'
            }}>
                {i18n.t('common.greeting')}, {userName}!
            </h1>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('auth.welcome')}
            </p>

            <p style={{
                color: '#374151',
                marginBottom: '24px'
            }}>
                {i18n.t('auth.verifyEmail')}
            </p>

            <div style={{
                textAlign: 'center',
                marginBottom: '24px'
            }}>
                <Button href={verificationUrl}>
                    {i18n.t('auth.verifyEmailButton')}
                </Button>
            </div>

            <p style={{
                fontSize: '14px',
                color: '#6b7280'
            }}>
                {i18n.t('auth.verifyEmailHelp')}
            </p>

            <p style={{
                fontSize: '14px',
                color: '#6b7280',
                marginTop: '16px'
            }}>
                {i18n.t('common.regards')},<br />
                {i18n.t('team.signature')}
            </p>
        </Layout>
    );
};