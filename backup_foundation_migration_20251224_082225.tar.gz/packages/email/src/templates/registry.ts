import React from 'react';
import { render } from '@react-email/render';
import { pino } from 'pino';
import type { EmailTemplate, EmailTemplateProps, SupportedLocale } from '../types';
import { EmailI18n, defaultI18n, detectLocale } from '../i18n';

const logger = pino({ name: 'email-template-registry' });

export class EmailTemplateRegistry {
    private templates: Map<string, EmailTemplate> = new Map();
    private i18n: EmailI18n;

    constructor(i18n: EmailI18n = defaultI18n) {
        this.i18n = i18n;
    }

    register(template: EmailTemplate): void {
        logger.info({ templateName: template.name }, 'Registering email template');
        this.templates.set(template.name, template);
    }

    registerMultiple(templates: EmailTemplate[]): void {
        templates.forEach(template => this.register(template));
    }

    async render(
        templateName: string,
        props: EmailTemplateProps & { locale?: SupportedLocale }
    ): Promise<{ html: string; text?: string; subject: string }> {
        const template = this.templates.get(templateName);
        if (!template) {
            throw new Error(`Email template '${templateName}' not found`);
        }

        try {
            // Detect locale and create i18n context
            const locale = detectLocale(props.locale, props.acceptLanguage);
            const i18nContext = this.i18n.createContext(locale);

            // Merge default props with provided props and i18n context
            const templateProps = {
                ...template.defaultProps,
                ...props,
                i18n: i18nContext,
            };

            logger.info({ templateName, locale }, 'Rendering email template');

            // Render the React component to HTML
            const Component = template.component;
            const element = React.createElement(Component, templateProps);
            const html = render(element);

            // Generate plain text version (basic HTML stripping)
            const text = this.htmlToText(html);

            // Process subject with i18n if it contains translation keys
            const subject = this.processSubject(template.subject, templateProps, i18nContext);

            return { html, text, subject };
        } catch (error) {
            logger.error({ error, templateName }, 'Failed to render email template');
            throw new Error(`Failed to render template '${templateName}': ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    getTemplate(name: string): EmailTemplate | undefined {
        return this.templates.get(name);
    }

    listTemplates(): EmailTemplate[] {
        return Array.from(this.templates.values());
    }

    getTemplatesByCategory(category: string): EmailTemplate[] {
        return this.listTemplates().filter(template => template.category === category);
    }

    hasTemplate(name: string): boolean {
        return this.templates.has(name);
    }

    private processSubject(
        subject: string,
        props: EmailTemplateProps,
        i18nContext: { t: (key: string, params?: Record<string, any>) => string }
    ): string {
        // Check if subject is a translation key (starts with a letter and contains dots)
        if (/^[a-zA-Z][a-zA-Z0-9.]*$/.test(subject)) {
            return i18nContext.t(subject, props);
        }

        // Process template variables in subject
        return Object.entries(props).reduce((text, [key, value]) => {
            if (typeof value === 'string' || typeof value === 'number') {
                return text.replace(new RegExp(`{{\\s*${key}\\s*}}`, 'g'), String(value));
            }
            return text;
        }, subject);
    }

    private htmlToText(html: string): string {
        return html
            .replace(/<style[^>]*>.*?<\/style>/gis, '') // Remove style tags
            .replace(/<script[^>]*>.*?<\/script>/gis, '') // Remove script tags
            .replace(/<[^>]+>/g, '') // Remove HTML tags
            .replace(/&nbsp;/g, ' ') // Replace non-breaking spaces
            .replace(/&amp;/g, '&') // Replace HTML entities
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();
    }
}