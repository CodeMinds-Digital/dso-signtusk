import React from 'react';
import { Layout } from './components/Layout';
import { Button } from './components/Button';
import type { EmailTemplateProps, EmailI18nContext } from '../types';

interface DocumentCompletedEmailProps extends EmailTemplateProps {
    recipientName: string;
    documentName: string;
    completedDate: string;
    downloadUrl: string;
    signers: Array<{ name: string; signedAt: string }>;
    i18n: EmailI18nContext;
}

export const DocumentCompletedEmail: React.FC<DocumentCompletedEmailProps> = ({
    recipientName,
    documentName,
    completedDate,
    downloadUrl,
    signers,
    i18n,
    ...layoutProps
}) => {
    return (
        <Layout
            i18n={i18n}
            previewText={i18n.t('document.completed')}
            {...layoutProps}
        >
            <div style={{
                textAlign: 'center',
                marginBottom: '24px'
            }}>
                <div style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '64px',
                    height: '64px',
                    backgroundColor: '#dcfce7',
                    borderRadius: '50%',
                    marginBottom: '16px'
                }}>
                    <span style={{
                        fontSize: '32px',
                        color: '#16a34a'
                    }}>
                        ✓
                    </span>
                </div>

                <h1 style={{
                    fontSize: '24px',
                    fontWeight: 'bold',
                    color: '#111827',
                    marginBottom: '8px'
                }}>
                    {i18n.t('document.completed')}
                </h1>
            </div>

            <p style={{
                color: '#374151',
                marginBottom: '16px'
            }}>
                {i18n.t('common.greeting')} {recipientName},
            </p>

            <p style={{
                color: '#374151',
                marginBottom: '24px'
            }}>
                {i18n.t('document.completedMessage', {
                    documentName,
                    completedDate
                })}
            </p>

            <div style={{
                backgroundColor: '#f0fdf4',
                padding: '16px',
                borderRadius: '8px',
                marginBottom: '24px'
            }}>
                <p style={{
                    fontWeight: '500',
                    color: '#1f2937',
                    marginBottom: '8px'
                }}>
                    {i18n.t('document.details')}:
                </p>
                <p style={{
                    color: '#374151',
                    marginBottom: '4px'
                }}>
                    <strong>{i18n.t('document.name')}:</strong> {documentName}
                </p>
                <p style={{
                    color: '#374151',
                    marginBottom: '4px'
                }}>
                    <strong>{i18n.t('document.completedOn')}:</strong> {completedDate}
                </p>
                <p style={{
                    color: '#374151'
                }}>
                    <strong>{i18n.t('document.totalSigners')}:</strong> {signers.length}
                </p>
            </div>

            {signers.length > 0 && (
                <div style={{
                    marginBottom: '24px'
                }}>
                    <p style={{
                        fontWeight: '500',
                        color: '#1f2937',
                        marginBottom: '12px'
                    }}>
                        {i18n.t('document.signingHistory')}:
                    </p>
                    {signers.map((signer, index) => (
                        <div key={index} style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            paddingTop: '8px',
                            paddingBottom: '8px',
                            borderBottom: index < signers.length - 1 ? '1px solid #e5e7eb' : 'none'
                        }}>
                            <span style={{ color: '#374151' }}>{signer.name}</span>
                            <span style={{
                                fontSize: '14px',
                                color: '#6b7280'
                            }}>{signer.signedAt}</span>
                        </div>
                    ))}
                </div>
            )}

            <div style={{
                textAlign: 'center',
                marginBottom: '24px'
            }}>
                <Button href={downloadUrl}>
                    {i18n.t('document.downloadCompleted')}
                </Button>
            </div>

            <p style={{
                fontSize: '14px',
                color: '#6b7280'
            }}>
                {i18n.t('document.completedNote')}
            </p>

            <p style={{
                fontSize: '14px',
                color: '#6b7280',
                marginTop: '16px'
            }}>
                {i18n.t('common.regards')},<br />
                {i18n.t('team.signature')}
            </p>
        </Layout>
    );
};