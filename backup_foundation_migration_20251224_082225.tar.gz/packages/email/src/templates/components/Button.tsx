import React from 'react';

interface ButtonProps {
    href: string;
    children: React.ReactNode;
    variant?: 'primary' | 'secondary';
    style?: React.CSSProperties;
}

export const Button: React.FC<ButtonProps> = ({
    href,
    children,
    variant = 'primary',
    style = {},
}) => {
    const baseStyle: React.CSSProperties = {
        display: 'inline-block',
        padding: '12px 24px',
        borderRadius: '8px',
        fontWeight: '500',
        textAlign: 'center',
        textDecoration: 'none',
        fontSize: '16px',
        ...style,
    };

    const variantStyles = {
        primary: {
            backgroundColor: '#2563eb',
            color: 'white',
        },
        secondary: {
            backgroundColor: '#e5e7eb',
            color: '#374151',
        },
    };

    return (
        <a
            href={href}
            style={{
                ...baseStyle,
                ...variantStyles[variant],
            }}
        >
            {children}
        </a>
    );
};