import { pino } from 'pino';
import type {
    EmailService,
    EmailMessage,
    EmailDeliveryResult,
    EmailTemplateProps,
    EmailProvider,
} from './types';
import { EmailTemplateRegistry } from './templates/registry';

const logger = pino({ name: 'email-testing' });

// Mock email service for testing
export class MockEmailService implements EmailService {
    private sentEmails: Array<{
        message: EmailMessage;
        result: EmailDeliveryResult;
        timestamp: Date;
    }> = [];

    private templateRegistry: EmailTemplateRegistry;
    private shouldFail: boolean = false;
    private failureMessage: string = 'Mock failure';

    constructor(templateRegistry: EmailTemplateRegistry) {
        this.templateRegistry = templateRegistry;
    }

    async send(message: EmailMessage): Promise<EmailDeliveryResult> {
        const result: EmailDeliveryResult = {
            success: !this.shouldFail,
            messageId: this.shouldFail ? undefined : `mock-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            error: this.shouldFail ? this.failureMessage : undefined,
            provider: 'smtp', // Mock provider
            timestamp: new Date(),
        };

        this.sentEmails.push({
            message,
            result,
            timestamp: new Date(),
        });

        logger.info({
            to: message.to,
            subject: message.subject,
            success: result.success
        }, 'Mock email sent');

        return result;
    }

    async sendTemplate(
        templateName: string,
        to: string | string[],
        props: EmailTemplateProps,
        options?: Partial<EmailMessage>
    ): Promise<EmailDeliveryResult> {
        try {
            const rendered = await this.renderTemplate(templateName, props);

            const message: EmailMessage = {
                to,
                subject: rendered.subject,
                html: rendered.html,
                text: rendered.text,
                ...options,
            };

            return await this.send(message);
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Template rendering failed',
                provider: 'smtp',
                timestamp: new Date(),
            };
        }
    }

    async renderTemplate(templateName: string, props: EmailTemplateProps): Promise<{ html: string; text?: string; subject: string }> {
        return await this.templateRegistry.render(templateName, props);
    }

    async validateConfig(): Promise<boolean> {
        return !this.shouldFail;
    }

    getProvider(): EmailProvider {
        return 'smtp';
    }

    // Testing utilities
    getSentEmails() {
        return [...this.sentEmails];
    }

    getLastSentEmail() {
        return this.sentEmails[this.sentEmails.length - 1];
    }

    clearSentEmails() {
        this.sentEmails = [];
    }

    setShouldFail(shouldFail: boolean, message?: string) {
        this.shouldFail = shouldFail;
        if (message) {
            this.failureMessage = message;
        }
    }

    getEmailCount() {
        return this.sentEmails.length;
    }

    findEmailsByRecipient(email: string) {
        return this.sentEmails.filter(sent => {
            const to = Array.isArray(sent.message.to) ? sent.message.to : [sent.message.to];
            return to.includes(email);
        });
    }

    findEmailsBySubject(subject: string) {
        return this.sentEmails.filter(sent => sent.message.subject.includes(subject));
    }
}

// Email preview service for development
export class EmailPreviewService {
    private templateRegistry: EmailTemplateRegistry;

    constructor(templateRegistry: EmailTemplateRegistry) {
        this.templateRegistry = templateRegistry;
    }

    async previewTemplate(
        templateName: string,
        props: EmailTemplateProps
    ): Promise<{ html: string; text?: string; subject: string }> {
        return await this.templateRegistry.render(templateName, props);
    }

    async previewAllTemplates(): Promise<Array<{
        name: string;
        category?: string;
        description?: string;
        preview: { html: string; text?: string; subject: string };
    }>> {
        const templates = this.templateRegistry.listTemplates();
        const previews = [];

        for (const template of templates) {
            try {
                const preview = await this.previewTemplate(template.name, template.defaultProps || {});
                previews.push({
                    name: template.name,
                    category: template.category,
                    description: template.description,
                    preview,
                });
            } catch (error) {
                logger.error({ error, templateName: template.name }, 'Failed to preview template');
            }
        }

        return previews;
    }

    generatePreviewHtml(previews: Array<{
        name: string;
        category?: string;
        description?: string;
        preview: { html: string; text?: string; subject: string };
    }>): string {
        const groupedByCategory = previews.reduce((acc, preview) => {
            const category = preview.category || 'uncategorized';
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(preview);
            return acc;
        }, {} as Record<string, typeof previews>);

        let html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Email Template Previews</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .category { margin-bottom: 40px; }
            .category h2 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
            .template { margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; }
            .template-header { background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ddd; }
            .template-name { font-size: 18px; font-weight: bold; margin: 0; }
            .template-description { color: #666; margin: 5px 0 0 0; }
            .template-subject { background: #e9ecef; padding: 10px; font-weight: bold; }
            .template-content { padding: 20px; }
            .template-text { background: #f8f9fa; padding: 15px; margin-top: 20px; white-space: pre-wrap; font-family: monospace; }
          </style>
        </head>
        <body>
          <h1>Email Template Previews</h1>
    `;

        Object.entries(groupedByCategory).forEach(([category, templates]) => {
            html += `
        <div class="category">
          <h2>${category.charAt(0).toUpperCase() + category.slice(1)}</h2>
      `;

            templates.forEach(template => {
                html += `
          <div class="template">
            <div class="template-header">
              <h3 class="template-name">${template.name}</h3>
              ${template.description ? `<p class="template-description">${template.description}</p>` : ''}
            </div>
            <div class="template-subject">Subject: ${template.preview.subject}</div>
            <div class="template-content">
              ${template.preview.html}
            </div>
            ${template.preview.text ? `
              <div class="template-text">
                <strong>Plain Text Version:</strong><br>
                ${template.preview.text}
              </div>
            ` : ''}
          </div>
        `;
            });

            html += '</div>';
        });

        html += `
        </body>
      </html>
    `;

        return html;
    }
}