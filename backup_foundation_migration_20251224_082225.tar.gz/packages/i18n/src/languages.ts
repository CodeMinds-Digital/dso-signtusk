import { LanguageMetadata, SupportedLanguage } from './types';

// Comprehensive language metadata configuration
export const LANGUAGE_METADATA: Record<SupportedLanguage, LanguageMetadata> = {
    en: {
        code: 'en',
        name: 'English',
        nativeName: 'English',
        flag: '🇺🇸',
        rtl: false,
        region: 'US',
        currency: 'USD',
        dateFormat: 'MM/dd/yyyy',
        timeFormat: 'h:mm a',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: '$',
        },
        pluralRules: ['one', 'other'],
    },
    es: {
        code: 'es',
        name: 'Spanish',
        nativeName: 'Español',
        flag: '🇪🇸',
        rtl: false,
        region: 'ES',
        currency: 'EUR',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: '.',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    fr: {
        code: 'fr',
        name: 'French',
        nativeName: 'Français',
        flag: '🇫🇷',
        rtl: false,
        region: 'FR',
        currency: 'EUR',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: ' ',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    de: {
        code: 'de',
        name: 'German',
        nativeName: 'Deutsch',
        flag: '🇩🇪',
        rtl: false,
        region: 'DE',
        currency: 'EUR',
        dateFormat: 'dd.MM.yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: '.',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    it: {
        code: 'it',
        name: 'Italian',
        nativeName: 'Italiano',
        flag: '🇮🇹',
        rtl: false,
        region: 'IT',
        currency: 'EUR',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: '.',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    pt: {
        code: 'pt',
        name: 'Portuguese',
        nativeName: 'Português',
        flag: '🇵🇹',
        rtl: false,
        region: 'PT',
        currency: 'EUR',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: ' ',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    nl: {
        code: 'nl',
        name: 'Dutch',
        nativeName: 'Nederlands',
        flag: '🇳🇱',
        rtl: false,
        region: 'NL',
        currency: 'EUR',
        dateFormat: 'dd-MM-yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: ',',
            thousands: '.',
            currency: '€',
        },
        pluralRules: ['one', 'other'],
    },
    ar: {
        code: 'ar',
        name: 'Arabic',
        nativeName: 'العربية',
        flag: '🇸🇦',
        rtl: true,
        region: 'SA',
        currency: 'SAR',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: 'ر.س',
        },
        pluralRules: ['zero', 'one', 'two', 'few', 'many', 'other'],
    },
    he: {
        code: 'he',
        name: 'Hebrew',
        nativeName: 'עברית',
        flag: '🇮🇱',
        rtl: true,
        region: 'IL',
        currency: 'ILS',
        dateFormat: 'dd/MM/yyyy',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: '₪',
        },
        pluralRules: ['one', 'two', 'many', 'other'],
    },
    zh: {
        code: 'zh',
        name: 'Chinese (Simplified)',
        nativeName: '简体中文',
        flag: '🇨🇳',
        rtl: false,
        region: 'CN',
        currency: 'CNY',
        dateFormat: 'yyyy/MM/dd',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: '¥',
        },
        pluralRules: ['other'],
    },
    'zh-TW': {
        code: 'zh-TW',
        name: 'Chinese (Traditional)',
        nativeName: '繁體中文',
        flag: '🇹🇼',
        rtl: false,
        region: 'TW',
        currency: 'TWD',
        dateFormat: 'yyyy/MM/dd',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: 'NT$',
        },
        pluralRules: ['other'],
    },
    ja: {
        code: 'ja',
        name: 'Japanese',
        nativeName: '日本語',
        flag: '🇯🇵',
        rtl: false,
        region: 'JP',
        currency: 'JPY',
        dateFormat: 'yyyy/MM/dd',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: '¥',
        },
        pluralRules: ['other'],
    },
    ko: {
        code: 'ko',
        name: 'Korean',
        nativeName: '한국어',
        flag: '🇰🇷',
        rtl: false,
        region: 'KR',
        currency: 'KRW',
        dateFormat: 'yyyy. MM. dd.',
        timeFormat: 'HH:mm',
        numberFormat: {
            decimal: '.',
            thousands: ',',
            currency: '₩',
        },
        pluralRules: ['other'],
    },
    // Add more languages with basic configuration
    sv: { code: 'sv', name: 'Swedish', nativeName: 'Svenska', flag: '🇸🇪', rtl: false, region: 'SE', currency: 'SEK', dateFormat: 'yyyy-MM-dd', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'kr' }, pluralRules: ['one', 'other'] },
    da: { code: 'da', name: 'Danish', nativeName: 'Dansk', flag: '🇩🇰', rtl: false, region: 'DK', currency: 'DKK', dateFormat: 'dd-MM-yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'kr' }, pluralRules: ['one', 'other'] },
    no: { code: 'no', name: 'Norwegian', nativeName: 'Norsk', flag: '🇳🇴', rtl: false, region: 'NO', currency: 'NOK', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'kr' }, pluralRules: ['one', 'other'] },
    fi: { code: 'fi', name: 'Finnish', nativeName: 'Suomi', flag: '🇫🇮', rtl: false, region: 'FI', currency: 'EUR', dateFormat: 'd.M.yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '€' }, pluralRules: ['one', 'other'] },
    pl: { code: 'pl', name: 'Polish', nativeName: 'Polski', flag: '🇵🇱', rtl: false, region: 'PL', currency: 'PLN', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'zł' }, pluralRules: ['one', 'few', 'many', 'other'] },
    cs: { code: 'cs', name: 'Czech', nativeName: 'Čeština', flag: '🇨🇿', rtl: false, region: 'CZ', currency: 'CZK', dateFormat: 'd. M. yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'Kč' }, pluralRules: ['one', 'few', 'many', 'other'] },
    sk: { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina', flag: '🇸🇰', rtl: false, region: 'SK', currency: 'EUR', dateFormat: 'd. M. yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '€' }, pluralRules: ['one', 'few', 'many', 'other'] },
    hu: { code: 'hu', name: 'Hungarian', nativeName: 'Magyar', flag: '🇭🇺', rtl: false, region: 'HU', currency: 'HUF', dateFormat: 'yyyy. MM. dd.', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'Ft' }, pluralRules: ['one', 'other'] },
    ro: { code: 'ro', name: 'Romanian', nativeName: 'Română', flag: '🇷🇴', rtl: false, region: 'RO', currency: 'RON', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'lei' }, pluralRules: ['one', 'few', 'other'] },
    bg: { code: 'bg', name: 'Bulgarian', nativeName: 'Български', flag: '🇧🇬', rtl: false, region: 'BG', currency: 'BGN', dateFormat: 'd.MM.yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'лв' }, pluralRules: ['one', 'other'] },
    hr: { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski', flag: '🇭🇷', rtl: false, region: 'HR', currency: 'EUR', dateFormat: 'dd. MM. yyyy.', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '€' }, pluralRules: ['one', 'few', 'other'] },
    sl: { code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina', flag: '🇸🇮', rtl: false, region: 'SI', currency: 'EUR', dateFormat: 'd. M. yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: '.', currency: '€' }, pluralRules: ['one', 'two', 'few', 'other'] },
    et: { code: 'et', name: 'Estonian', nativeName: 'Eesti', flag: '🇪🇪', rtl: false, region: 'EE', currency: 'EUR', dateFormat: 'dd.MM.yyyy', timeFormat: 'H:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '€' }, pluralRules: ['one', 'other'] },
    lv: { code: 'lv', name: 'Latvian', nativeName: 'Latviešu', flag: '🇱🇻', rtl: false, region: 'LV', currency: 'EUR', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '€' }, pluralRules: ['zero', 'one', 'other'] },
    lt: { code: 'lt', name: 'Lithuanian', nativeName: 'Lietuvių', flag: '🇱🇹', rtl: false, region: 'LT', currency: 'EUR', dateFormat: 'yyyy-MM-dd', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '€' }, pluralRules: ['one', 'few', 'many', 'other'] },
    ru: { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺', rtl: false, region: 'RU', currency: 'RUB', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '₽' }, pluralRules: ['one', 'few', 'many', 'other'] },
    uk: { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', flag: '🇺🇦', rtl: false, region: 'UA', currency: 'UAH', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '₴' }, pluralRules: ['one', 'few', 'many', 'other'] },
    be: { code: 'be', name: 'Belarusian', nativeName: 'Беларуская', flag: '🇧🇾', rtl: false, region: 'BY', currency: 'BYN', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'Br' }, pluralRules: ['one', 'few', 'many', 'other'] },
    mk: { code: 'mk', name: 'Macedonian', nativeName: 'Македонски', flag: '🇲🇰', rtl: false, region: 'MK', currency: 'MKD', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'ден' }, pluralRules: ['one', 'other'] },
    sr: { code: 'sr', name: 'Serbian', nativeName: 'Српски', flag: '🇷🇸', rtl: false, region: 'RS', currency: 'RSD', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'дин' }, pluralRules: ['one', 'few', 'other'] },
    bs: { code: 'bs', name: 'Bosnian', nativeName: 'Bosanski', flag: '🇧🇦', rtl: false, region: 'BA', currency: 'BAM', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'KM' }, pluralRules: ['one', 'few', 'other'] },
    me: { code: 'me', name: 'Montenegrin', nativeName: 'Crnogorski', flag: '🇲🇪', rtl: false, region: 'ME', currency: 'EUR', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '€' }, pluralRules: ['one', 'few', 'other'] },
    sq: { code: 'sq', name: 'Albanian', nativeName: 'Shqip', flag: '🇦🇱', rtl: false, region: 'AL', currency: 'ALL', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'L' }, pluralRules: ['one', 'other'] },
    el: { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', flag: '🇬🇷', rtl: false, region: 'GR', currency: 'EUR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '€' }, pluralRules: ['one', 'other'] },
    tr: { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷', rtl: false, region: 'TR', currency: 'TRY', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '₺' }, pluralRules: ['one', 'other'] },
    // Asian languages
    fa: { code: 'fa', name: 'Persian', nativeName: 'فارسی', flag: '🇮🇷', rtl: true, region: 'IR', currency: 'IRR', dateFormat: 'yyyy/MM/dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '﷼' }, pluralRules: ['one', 'other'] },
    ur: { code: 'ur', name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰', rtl: true, region: 'PK', currency: 'PKR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₨' }, pluralRules: ['one', 'other'] },
    hi: { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    bn: { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flag: '🇧🇩', rtl: false, region: 'BD', currency: 'BDT', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '৳' }, pluralRules: ['one', 'other'] },
    ta: { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    te: { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    ml: { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    kn: { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    gu: { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    pa: { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    or: { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    as: { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া', flag: '🇮🇳', rtl: false, region: 'IN', currency: 'INR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₹' }, pluralRules: ['one', 'other'] },
    ne: { code: 'ne', name: 'Nepali', nativeName: 'नेपाली', flag: '🇳🇵', rtl: false, region: 'NP', currency: 'NPR', dateFormat: 'yyyy/MM/dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'रू' }, pluralRules: ['one', 'other'] },
    si: { code: 'si', name: 'Sinhala', nativeName: 'සිංහල', flag: '🇱🇰', rtl: false, region: 'LK', currency: 'LKR', dateFormat: 'yyyy-MM-dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'රු' }, pluralRules: ['one', 'other'] },
    my: { code: 'my', name: 'Myanmar', nativeName: 'မြန်မာ', flag: '🇲🇲', rtl: false, region: 'MM', currency: 'MMK', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'K' }, pluralRules: ['other'] },
    km: { code: 'km', name: 'Khmer', nativeName: 'ខ្មែរ', flag: '🇰🇭', rtl: false, region: 'KH', currency: 'KHR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '៛' }, pluralRules: ['other'] },
    lo: { code: 'lo', name: 'Lao', nativeName: 'ລາວ', flag: '🇱🇦', rtl: false, region: 'LA', currency: 'LAK', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₭' }, pluralRules: ['other'] },
    th: { code: 'th', name: 'Thai', nativeName: 'ไทย', flag: '🇹🇭', rtl: false, region: 'TH', currency: 'THB', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '฿' }, pluralRules: ['other'] },
    vi: { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', flag: '🇻🇳', rtl: false, region: 'VN', currency: 'VND', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '₫' }, pluralRules: ['other'] },
    id: { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', flag: '🇮🇩', rtl: false, region: 'ID', currency: 'IDR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: 'Rp' }, pluralRules: ['other'] },
    ms: { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', flag: '🇲🇾', rtl: false, region: 'MY', currency: 'MYR', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'RM' }, pluralRules: ['other'] },
    tl: { code: 'tl', name: 'Filipino', nativeName: 'Filipino', flag: '🇵🇭', rtl: false, region: 'PH', currency: 'PHP', dateFormat: 'MM/dd/yyyy', timeFormat: 'h:mm a', numberFormat: { decimal: '.', thousands: ',', currency: '₱' }, pluralRules: ['one', 'other'] },
    // Central Asian and other languages
    mn: { code: 'mn', name: 'Mongolian', nativeName: 'Монгол', flag: '🇲🇳', rtl: false, region: 'MN', currency: 'MNT', dateFormat: 'yyyy.MM.dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: '₮' }, pluralRules: ['one', 'other'] },
    kk: { code: 'kk', name: 'Kazakh', nativeName: 'Қазақша', flag: '🇰🇿', rtl: false, region: 'KZ', currency: 'KZT', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '₸' }, pluralRules: ['one', 'other'] },
    ky: { code: 'ky', name: 'Kyrgyz', nativeName: 'Кыргызча', flag: '🇰🇬', rtl: false, region: 'KG', currency: 'KGS', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'сом' }, pluralRules: ['one', 'other'] },
    uz: { code: 'uz', name: 'Uzbek', nativeName: 'Oʻzbekcha', flag: '🇺🇿', rtl: false, region: 'UZ', currency: 'UZS', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'сўм' }, pluralRules: ['one', 'other'] },
    tg: { code: 'tg', name: 'Tajik', nativeName: 'Тоҷикӣ', flag: '🇹🇯', rtl: false, region: 'TJ', currency: 'TJS', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'смн' }, pluralRules: ['one', 'other'] },
    tk: { code: 'tk', name: 'Turkmen', nativeName: 'Türkmençe', flag: '🇹🇲', rtl: false, region: 'TM', currency: 'TMT', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: 'm' }, pluralRules: ['one', 'other'] },
    az: { code: 'az', name: 'Azerbaijani', nativeName: 'Azərbaycan', flag: '🇦🇿', rtl: false, region: 'AZ', currency: 'AZN', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: '.', currency: '₼' }, pluralRules: ['one', 'other'] },
    ka: { code: 'ka', name: 'Georgian', nativeName: 'ქართული', flag: '🇬🇪', rtl: false, region: 'GE', currency: 'GEL', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '₾' }, pluralRules: ['one', 'other'] },
    hy: { code: 'hy', name: 'Armenian', nativeName: 'Հայերեն', flag: '🇦🇲', rtl: false, region: 'AM', currency: 'AMD', dateFormat: 'dd.MM.yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: ',', thousands: ' ', currency: '֏' }, pluralRules: ['one', 'other'] },
    am: { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', flag: '🇪🇹', rtl: false, region: 'ET', currency: 'ETB', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'Br' }, pluralRules: ['one', 'other'] },
    sw: { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', flag: '🇰🇪', rtl: false, region: 'KE', currency: 'KES', dateFormat: 'dd/MM/yyyy', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'KSh' }, pluralRules: ['one', 'other'] },
    zu: { code: 'zu', name: 'Zulu', nativeName: 'isiZulu', flag: '🇿🇦', rtl: false, region: 'ZA', currency: 'ZAR', dateFormat: 'yyyy/MM/dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'R' }, pluralRules: ['one', 'other'] },
    xh: { code: 'xh', name: 'Xhosa', nativeName: 'isiXhosa', flag: '🇿🇦', rtl: false, region: 'ZA', currency: 'ZAR', dateFormat: 'yyyy/MM/dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'R' }, pluralRules: ['one', 'other'] },
    af: { code: 'af', name: 'Afrikaans', nativeName: 'Afrikaans', flag: '🇿🇦', rtl: false, region: 'ZA', currency: 'ZAR', dateFormat: 'yyyy/MM/dd', timeFormat: 'HH:mm', numberFormat: { decimal: '.', thousands: ',', currency: 'R' }, pluralRules: ['one', 'other'] },
};

// Helper functions for language operations
export function getLanguageMetadata(language: SupportedLanguage): LanguageMetadata {
    return LANGUAGE_METADATA[language];
}

export function isRTLLanguage(language: SupportedLanguage): boolean {
    return LANGUAGE_METADATA[language].rtl;
}

export function getSupportedLanguages(): SupportedLanguage[] {
    return Object.keys(LANGUAGE_METADATA) as SupportedLanguage[];
}

export function getLanguagesByRegion(region: string): SupportedLanguage[] {
    return getSupportedLanguages().filter(lang =>
        LANGUAGE_METADATA[lang].region === region
    );
}

export function getRTLLanguages(): SupportedLanguage[] {
    return getSupportedLanguages().filter(lang =>
        LANGUAGE_METADATA[lang].rtl
    );
}

export function getLanguageFlag(language: SupportedLanguage): string {
    return LANGUAGE_METADATA[language].flag;
}

export function getLanguageNativeName(language: SupportedLanguage): string {
    return LANGUAGE_METADATA[language].nativeName;
}