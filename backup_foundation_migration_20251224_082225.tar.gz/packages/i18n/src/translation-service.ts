import { z } from 'zod';
import {
    SupportedLocale,
    TranslationNamespace,
    TranslationContent,
    TranslationProject,
    TranslationWorkflow,
    TranslationMemory,
    TranslationServiceProvider,
    I18nSchemas,
} from './types';

// Translation service for managing translations
export class TranslationService {
    private translations: Map<string, TranslationContent> = new Map();
    private translationMemory: Map<string, TranslationMemory> = new Map();
    private projects: Map<string, TranslationProject> = new Map();
    private workflows: Map<string, TranslationWorkflow> = new Map();
    private providers: Map<string, TranslationServiceProvider> = new Map();

    // Translation CRUD operations
    async createTranslation(translation: Omit<TranslationContent, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationContent> {
        // Validate translation data
        const validationResult = I18nSchemas.TranslationValidation.safeParse({
            key: translation.key,
            value: translation.value,
            namespace: translation.namespace,
            language: translation.language,
        });

        if (!validationResult.success) {
            throw new Error(`Translation validation failed: ${validationResult.error.message}`);
        }

        const id = this.generateId();
        const now = new Date();

        const newTranslation: TranslationContent = {
            ...translation,
            id,
            createdAt: now,
            updatedAt: now,
            version: 1,
            status: 'draft',
        };

        const key = this.getTranslationKey(translation.namespace, translation.language, translation.key);
        this.translations.set(key, newTranslation);

        return newTranslation;
    }

    async updateTranslation(id: string, updates: Partial<TranslationContent>): Promise<TranslationContent> {
        const existing = this.getTranslationById(id);
        if (!existing) {
            throw new Error(`Translation with id ${id} not found`);
        }

        const updated: TranslationContent = {
            ...existing,
            ...updates,
            id: existing.id, // Prevent ID changes
            createdAt: existing.createdAt, // Prevent creation date changes
            updatedAt: new Date(),
            version: existing.version + 1,
        };

        // Validate updated translation
        if (updates.key || updates.value || updates.namespace || updates.language) {
            const validationResult = I18nSchemas.TranslationValidation.safeParse({
                key: updated.key,
                value: updated.value,
                namespace: updated.namespace,
                language: updated.language,
            });

            if (!validationResult.success) {
                throw new Error(`Translation validation failed: ${validationResult.error.message}`);
            }
        }

        const key = this.getTranslationKey(updated.namespace, updated.language, updated.key);
        this.translations.set(key, updated);

        return updated;
    }

    async deleteTranslation(id: string): Promise<boolean> {
        const existing = this.getTranslationById(id);
        if (!existing) {
            return false;
        }

        const key = this.getTranslationKey(existing.namespace, existing.language, existing.key);
        return this.translations.delete(key);
    }

    // Translation retrieval
    getTranslation(namespace: TranslationNamespace, language: SupportedLanguage, key: string): TranslationContent | undefined {
        const translationKey = this.getTranslationKey(namespace, language, key);
        return this.translations.get(translationKey);
    }

    getTranslationsByNamespace(namespace: TranslationNamespace, language: SupportedLanguage): TranslationContent[] {
        return Array.from(this.translations.values()).filter(
            t => t.namespace === namespace && t.language === language
        );
    }

    getTranslationsByLanguage(language: SupportedLanguage): TranslationContent[] {
        return Array.from(this.translations.values()).filter(t => t.language === language);
    }

    getAllTranslations(): TranslationContent[] {
        return Array.from(this.translations.values());
    }

    // Translation memory operations
    async addToTranslationMemory(memory: Omit<TranslationMemory, 'id' | 'createdAt' | 'updatedAt' | 'usageCount'>): Promise<TranslationMemory> {
        const id = this.generateId();
        const now = new Date();

        const newMemory: TranslationMemory = {
            ...memory,
            id,
            createdAt: now,
            updatedAt: now,
            usageCount: 0,
        };

        const key = `${memory.sourceLanguage}-${memory.targetLanguage}-${this.hashText(memory.sourceText)}`;
        this.translationMemory.set(key, newMemory);

        return newMemory;
    }

    searchTranslationMemory(
        sourceText: string,
        sourceLanguage: SupportedLanguage,
        targetLanguage: SupportedLanguage,
        threshold: number = 0.8
    ): TranslationMemory[] {
        const memories = Array.from(this.translationMemory.values()).filter(
            m => m.sourceLanguage === sourceLanguage && m.targetLanguage === targetLanguage
        );

        // Simple fuzzy matching (in production, use more sophisticated algorithms)
        return memories
            .map(memory => ({
                ...memory,
                similarity: this.calculateSimilarity(sourceText, memory.sourceText),
            }))
            .filter(m => m.similarity >= threshold)
            .sort((a, b) => b.similarity - a.similarity)
            .map(({ similarity, ...memory }) => memory);
    }

    // Project management
    async createProject(project: Omit<TranslationProject, 'id' | 'createdAt' | 'updatedAt' | 'progress'>): Promise<TranslationProject> {
        const id = this.generateId();
        const now = new Date();

        const newProject: TranslationProject = {
            ...project,
            id,
            createdAt: now,
            updatedAt: now,
            progress: project.targetLocales.reduce((acc: Record<string, number>, lang) => {
                acc[lang] = 0;
                return acc;
            }, {}),
        };

        this.projects.set(id, newProject);
        return newProject;
    }

    async updateProjectProgress(projectId: string, language: SupportedLocale, progress: number): Promise<TranslationProject> {
        const project = this.projects.get(projectId);
        if (!project) {
            throw new Error(`Project with id ${projectId} not found`);
        }

        if (!project.progress) {
            project.progress = {};
        }
        project.progress[language] = Math.max(0, Math.min(100, progress));
        project.updatedAt = new Date();

        this.projects.set(projectId, project);
        return project;
    }

    getProject(id: string): TranslationProject | undefined {
        return this.projects.get(id);
    }

    getProjectsByOrganization(organizationId: string): TranslationProject[] {
        return Array.from(this.projects.values()).filter(p => p.organizationId === organizationId);
    }

    // Workflow management
    async createWorkflow(workflow: Omit<TranslationWorkflow, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationWorkflow> {
        const id = this.generateId();
        const now = new Date();

        const newWorkflow: TranslationWorkflow = {
            ...workflow,
            id,
            createdAt: now,
            updatedAt: now,
        };

        this.workflows.set(id, newWorkflow);
        return newWorkflow;
    }

    getWorkflow(id: string): TranslationWorkflow | undefined {
        return this.workflows.get(id);
    }

    getWorkflowsByOrganization(organizationId: string): TranslationWorkflow[] {
        return Array.from(this.workflows.values()).filter(w => w.organizationId === organizationId);
    }

    // Service provider management
    async addServiceProvider(provider: TranslationServiceProvider): Promise<void> {
        this.providers.set(provider.id, provider);
    }

    getServiceProvider(id: string): TranslationServiceProvider | undefined {
        return this.providers.get(id);
    }

    getServiceProviders(): TranslationServiceProvider[] {
        return Array.from(this.providers.values());
    }

    getServiceProvidersByLanguage(sourceLanguage: SupportedLanguage, targetLanguage: SupportedLanguage): TranslationServiceProvider[] {
        return Array.from(this.providers.values()).filter(
            p => p.supportedLanguages.includes(sourceLanguage) && p.supportedLanguages.includes(targetLanguage)
        );
    }

    // Bulk operations
    async bulkImportTranslations(translations: Omit<TranslationContent, 'id' | 'createdAt' | 'updatedAt'>[]): Promise<TranslationContent[]> {
        const results: TranslationContent[] = [];

        for (const translation of translations) {
            try {
                const created = await this.createTranslation(translation);
                results.push(created);
            } catch (error) {
                console.error(`Failed to import translation ${translation.key}:`, error);
            }
        }

        return results;
    }

    async bulkExportTranslations(
        namespace?: TranslationNamespace,
        language?: SupportedLanguage,
        format: 'json' | 'csv' | 'xlsx' = 'json'
    ): Promise<string> {
        let translations = this.getAllTranslations();

        if (namespace) {
            translations = translations.filter(t => t.namespace === namespace);
        }

        if (language) {
            translations = translations.filter(t => t.language === language);
        }

        switch (format) {
            case 'json':
                return JSON.stringify(translations, null, 2);
            case 'csv':
                return this.convertToCSV(translations);
            case 'xlsx':
                // In production, use a library like xlsx
                throw new Error('XLSX export not implemented');
            default:
                throw new Error(`Unsupported export format: ${format}`);
        }
    }

    // Validation and quality assurance
    validateTranslation(translation: TranslationContent): { valid: boolean; errors: string[] } {
        const errors: string[] = [];

        // Check for missing interpolation variables
        const sourceVariables = this.extractInterpolationVariables(translation.value);
        const requiredVariables = translation.context ? this.extractInterpolationVariables(translation.context) : [];

        for (const required of requiredVariables) {
            if (!sourceVariables.includes(required)) {
                errors.push(`Missing required interpolation variable: ${required}`);
            }
        }

        // Check for HTML if not allowed
        if (translation.value.includes('<') && !translation.tags?.includes('html-allowed')) {
            errors.push('HTML content detected but not allowed');
        }

        // Check length constraints
        if (translation.value.length === 0) {
            errors.push('Translation value cannot be empty');
        }

        return {
            valid: errors.length === 0,
            errors,
        };
    }

    // Helper methods
    private getTranslationById(id: string): TranslationContent | undefined {
        return Array.from(this.translations.values()).find(t => t.id === id);
    }

    private getTranslationKey(namespace: TranslationNamespace, language: SupportedLanguage, key: string): string {
        return `${namespace}:${language}:${key}`;
    }

    private generateId(): string {
        return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    private hashText(text: string): string {
        // Simple hash function (use crypto.createHash in production)
        let hash = 0;
        for (let i = 0; i < text.length; i++) {
            const char = text.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash.toString();
    }

    private calculateSimilarity(text1: string, text2: string): number {
        // Simple Levenshtein distance-based similarity (use more sophisticated algorithms in production)
        const distance = this.levenshteinDistance(text1, text2);
        const maxLength = Math.max(text1.length, text2.length);
        return maxLength === 0 ? 1 : 1 - distance / maxLength;
    }

    private levenshteinDistance(str1: string, str2: string): number {
        const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

        for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
        for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

        for (let j = 1; j <= str2.length; j++) {
            for (let i = 1; i <= str1.length; i++) {
                const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
                matrix[j][i] = Math.min(
                    matrix[j][i - 1] + 1, // deletion
                    matrix[j - 1][i] + 1, // insertion
                    matrix[j - 1][i - 1] + indicator // substitution
                );
            }
        }

        return matrix[str2.length][str1.length];
    }

    private extractInterpolationVariables(text: string): string[] {
        const regex = /\{\{(\w+)\}\}/g;
        const variables: string[] = [];
        let match;

        while ((match = regex.exec(text)) !== null) {
            variables.push(match[1]);
        }

        return variables;
    }

    private convertToCSV(translations: TranslationContent[]): string {
        const headers = ['id', 'namespace', 'language', 'key', 'value', 'description', 'status', 'version', 'createdAt', 'updatedAt'];
        const rows = translations.map(t => [
            t.id,
            t.namespace,
            t.language,
            t.key,
            `"${t.value.replace(/"/g, '""')}"`, // Escape quotes
            t.description || '',
            t.status,
            t.version.toString(),
            t.createdAt.toISOString(),
            t.updatedAt.toISOString(),
        ]);

        return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    }
}

// Singleton instance
export const translationService = new TranslationService();