import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger
} from "@docusign-alternative/ui";
import {
    Building,
    Users,
    Settings,
    CreditCard,
    BarChart3,
    Plus,
    ArrowRight,
    TrendingUp,
    Clock,
    Shield
} from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Organization - DocuSign Alternative" },
        { name: "description", content: "Manage your organization settings and members" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
    });
}

export default function Organization() {
    const { user } = useLoaderData<typeof loader>();

    // tRPC queries for organization data
    const organizationQuery = trpc.organization.get.useQuery({
        organizationId: user.organizationId,
    });

    const membersQuery = trpc.organization.listMembers.useQuery({
        organizationId: user.organizationId,
        limit: 5,
    });

    const teamsQuery = trpc.organization.listTeams.useQuery({
        organizationId: user.organizationId,
        limit: 5,
    });

    const billingQuery = trpc.organization.getBilling.useQuery({
        organizationId: user.organizationId,
    });

    const analyticsQuery = trpc.organization.getAnalytics.useQuery({
        organizationId: user.organizationId,
        period: '30d',
    });

    const organization = organizationQuery.data?.organization;
    const members = membersQuery.data?.members || [];
    const teams = teamsQuery.data?.teams || [];
    const billing = billingQuery.data?.billing;
    const analytics = analyticsQuery.data?.analytics;

    // Quick stats for overview
    const stats = [
        {
            name: "Total Members",
            value: organization?.memberCount?.toString() || "0",
            change: "+2 this month",
            changeType: "positive" as const,
            icon: Users,
            href: "/organization/members",
        },
        {
            name: "Active Teams",
            value: organization?.teamCount?.toString() || "0",
            change: "+1 this month",
            changeType: "positive" as const,
            icon: Building,
            href: "/organization/teams",
        },
        {
            name: "Documents This Month",
            value: analytics?.metrics?.documentsThisPeriod?.toString() || "0",
            change: "+12%",
            changeType: "positive" as const,
            icon: BarChart3,
            href: "/organization/analytics",
        },
        {
            name: "Plan Usage",
            value: billing ? `${Math.round((billing.usage.documentsThisMonth / billing.usage.documentsLimit) * 100)}%` : "0%",
            change: billing?.usage.documentsThisMonth + " / " + billing?.usage.documentsLimit || "0 / 0",
            changeType: "neutral" as const,
            icon: CreditCard,
            href: "/organization/billing",
        },
    ];

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">Organization</h1>
                            <p className="text-gray-600">
                                Manage your organization settings, members, and billing
                            </p>
                        </div>
                        <div className="flex gap-3">
                            <Button variant="outline" asChild>
                                <Link to="/organization/settings">
                                    <Settings className="mr-2 h-4 w-4" />
                                    Settings
                                </Link>
                            </Button>
                            <Button asChild>
                                <Link to="/organization/members/invite">
                                    <Plus className="mr-2 h-4 w-4" />
                                    Invite Member
                                </Link>
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Organization Info Card */}
                {organization && (
                    <Card className="mb-8">
                        <CardContent className="p-6">
                            <div className="flex items-start justify-between">
                                <div className="flex items-center space-x-4">
                                    <div className="h-16 w-16 bg-blue-100 rounded-lg flex items-center justify-center">
                                        <Building className="h-8 w-8 text-blue-600" />
                                    </div>
                                    <div>
                                        <h2 className="text-xl font-semibold text-gray-900">{organization.name}</h2>
                                        <p className="text-gray-600">{organization.domain}</p>
                                        <div className="flex items-center space-x-2 mt-2">
                                            <Badge variant={organization.status === 'ACTIVE' ? 'default' : 'secondary'}>
                                                {organization.status}
                                            </Badge>
                                            <Badge variant="outline">
                                                {organization.tier}
                                            </Badge>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm text-gray-600">Created</p>
                                    <p className="font-medium">
                                        {new Date(organization.createdAt).toLocaleDateString()}
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Stats Grid */}
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
                    {stats.map((stat) => {
                        const Icon = stat.icon;
                        return (
                            <Card key={stat.name} className="hover:shadow-md transition-shadow">
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                        <div className="flex-1">
                                            <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                                            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                                            <p className="text-sm text-gray-500">{stat.change}</p>
                                        </div>
                                        <div className="flex flex-col items-end space-y-2">
                                            <Icon className="h-8 w-8 text-blue-600" />
                                            <Button variant="ghost" size="sm" asChild>
                                                <Link to={stat.href}>
                                                    <ArrowRight className="h-4 w-4" />
                                                </Link>
                                            </Button>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>

                <Tabs defaultValue="overview" className="space-y-6">
                    <TabsList>
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="members">Members</TabsTrigger>
                        <TabsTrigger value="teams">Teams</TabsTrigger>
                        <TabsTrigger value="activity">Activity</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Recent Activity */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center">
                                        <Clock className="mr-2 h-5 w-5" />
                                        Recent Activity
                                    </CardTitle>
                                    <CardDescription>
                                        Latest organization activity
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div className="flex items-center space-x-3">
                                            <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                                            <div className="flex-1">
                                                <p className="text-sm font-medium">New member joined</p>
                                                <p className="text-xs text-gray-500">2 hours ago</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                                            <div className="flex-1">
                                                <p className="text-sm font-medium">Document signed</p>
                                                <p className="text-xs text-gray-500">4 hours ago</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <div className="h-2 w-2 bg-yellow-500 rounded-full"></div>
                                            <div className="flex-1">
                                                <p className="text-sm font-medium">Settings updated</p>
                                                <p className="text-xs text-gray-500">1 day ago</p>
                                            </div>
                                        </div>
                                    </div>
                                    <Button variant="outline" className="w-full mt-4" asChild>
                                        <Link to="/organization/activity">
                                            View All Activity
                                        </Link>
                                    </Button>
                                </CardContent>
                            </Card>

                            {/* Security Status */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center">
                                        <Shield className="mr-2 h-5 w-5" />
                                        Security Status
                                    </CardTitle>
                                    <CardDescription>
                                        Organization security overview
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Two-Factor Authentication</span>
                                            <Badge variant={organization?.settings?.requireTwoFactor ? 'default' : 'secondary'}>
                                                {organization?.settings?.requireTwoFactor ? 'Required' : 'Optional'}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">SSO Enabled</span>
                                            <Badge variant={organization?.settings?.enforceSSO ? 'default' : 'secondary'}>
                                                {organization?.settings?.enforceSSO ? 'Yes' : 'No'}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Audit Logging</span>
                                            <Badge variant={organization?.settings?.enableAuditLog ? 'default' : 'secondary'}>
                                                {organization?.settings?.enableAuditLog ? 'Enabled' : 'Disabled'}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Data Encryption</span>
                                            <Badge variant={organization?.settings?.enableEncryption ? 'default' : 'secondary'}>
                                                {organization?.settings?.enableEncryption ? 'Enabled' : 'Disabled'}
                                            </Badge>
                                        </div>
                                    </div>
                                    <Button variant="outline" className="w-full mt-4" asChild>
                                        <Link to="/organization/settings?tab=security">
                                            Manage Security
                                        </Link>
                                    </Button>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="members" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <CardTitle>Organization Members</CardTitle>
                                        <CardDescription>
                                            Manage your organization members and their roles
                                        </CardDescription>
                                    </div>
                                    <Button asChild>
                                        <Link to="/organization/members/invite">
                                            <Plus className="mr-2 h-4 w-4" />
                                            Invite Member
                                        </Link>
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {members.map((member) => (
                                        <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                                            <div className="flex items-center space-x-3">
                                                <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center">
                                                    <span className="text-sm font-medium">
                                                        {member.name.split(' ').map(n => n[0]).join('')}
                                                    </span>
                                                </div>
                                                <div>
                                                    <p className="font-medium">{member.name}</p>
                                                    <p className="text-sm text-gray-600">{member.email}</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                <Badge variant="outline">{member.role}</Badge>
                                                <Badge variant={member.status === 'ACTIVE' ? 'default' : 'secondary'}>
                                                    {member.status}
                                                </Badge>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <Button variant="outline" className="w-full mt-4" asChild>
                                    <Link to="/organization/members">
                                        View All Members
                                    </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="teams" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <CardTitle>Teams</CardTitle>
                                        <CardDescription>
                                            Organize members into teams for better collaboration
                                        </CardDescription>
                                    </div>
                                    <Button asChild>
                                        <Link to="/organization/teams/create">
                                            <Plus className="mr-2 h-4 w-4" />
                                            Create Team
                                        </Link>
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {teams.map((team) => (
                                        <div key={team.id} className="p-4 border rounded-lg">
                                            <div className="flex items-center justify-between mb-2">
                                                <h3 className="font-medium">{team.name}</h3>
                                                <Badge variant="outline">{team.memberCount} members</Badge>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-3">{team.description}</p>
                                            <Button variant="outline" size="sm" asChild>
                                                <Link to={`/organization/teams/${team.id}`}>
                                                    View Team
                                                </Link>
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                                <Button variant="outline" className="w-full mt-4" asChild>
                                    <Link to="/organization/teams">
                                        View All Teams
                                    </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="activity" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Organization Activity</CardTitle>
                                <CardDescription>
                                    Track all activity within your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="text-center py-8 text-gray-500">
                                        <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                                        <p>Activity feed will be displayed here</p>
                                        <p className="text-sm">Track member actions, document changes, and more</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}