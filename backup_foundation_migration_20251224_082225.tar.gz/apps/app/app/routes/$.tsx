import { useNavigate } from "@remix-run/react";
import { ErrorPage } from "@docusign-alternative/ui";

// Catch-all route for 404 errors
export default function NotFound() {
    const navigate = useNavigate();

    return (
        <ErrorPage
            type="404"
            variant="card"
            size="lg"
            onGoHome={() => navigate("/")}
            onGoBack={() => navigate(-1)}
            className="min-h-screen flex items-center justify-center bg-background"
        />
    );
}

// Handle loader errors (e.g., when a resource is not found)
export function ErrorBoundary() {
    const navigate = useNavigate();

    return (
        <ErrorPage
            type="404"
            variant="card"
            size="lg"
            onGoHome={() => navigate("/")}
            onGoBack={() => navigate(-1)}
            className="min-h-screen flex items-center justify-center bg-background"
        />
    );
}