import { json, type LoaderFunctionArgs, type MetaFunction } from '@remix-run/node';
import { useLoaderData, useNavigate, useSearchParams } from '@remix-run/react';
import { useState, useEffect } from 'react';
import { SearchInterface, type SearchResult, type SearchFilter, type SearchSuggestion } from '@docusign-alternative/ui';
import { trpc } from '~/lib/trpc';

export const meta: MetaFunction = () => {
    return [
        { title: 'Search - DocuSign Alternative' },
        { name: 'description', content: 'Search documents, templates, and more' },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    // Get search params from URL
    const url = new URL(request.url);
    const query = url.searchParams.get('q') || '';
    const status = url.searchParams.getAll('status');
    const mimeTypes = url.searchParams.getAll('type');
    const tags = url.searchParams.getAll('tag');
    const folderId = url.searchParams.get('folder') || undefined;

    return json({
        initialQuery: query,
        initialFilters: {
            status: status.length > 0 ? status as Array<'DRAFT' | 'PENDING' | 'COMPLETED' | 'CANCELLED'> : undefined,
            mimeTypes: mimeTypes.length > 0 ? mimeTypes : undefined,
            tags: tags.length > 0 ? tags : undefined,
            folderId,
        },
    });
}

export default function SearchPage() {
    const { initialQuery, initialFilters } = useLoaderData<typeof loader>();
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();

    const [query, setQuery] = useState(initialQuery);
    const [filters, setFilters] = useState<SearchFilter>(initialFilters);
    const [results, setResults] = useState<SearchResult[]>([]);
    const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [searchHistory, setSearchHistory] = useState<Array<{ query: string; timestamp: Date; filters?: SearchFilter }>>([]);
    const [savedSearches, setSavedSearches] = useState<Array<{ id: string; name: string; query: string; filters?: SearchFilter; createdAt: Date }>>([]);

    // Load search history and saved searches from localStorage
    useEffect(() => {
        try {
            const history = localStorage.getItem('docusign-search-history');
            if (history) {
                const parsedHistory = JSON.parse(history).map((item: any) => ({
                    ...item,
                    timestamp: new Date(item.timestamp),
                }));
                setSearchHistory(parsedHistory);
            }

            const saved = localStorage.getItem('docusign-saved-searches');
            if (saved) {
                const parsedSaved = JSON.parse(saved).map((item: any) => ({
                    ...item,
                    createdAt: new Date(item.createdAt),
                }));
                setSavedSearches(parsedSaved);
            }
        } catch (error) {
            console.error('Failed to load search data:', error);
        }
    }, []);

    // Perform search when query or filters change
    useEffect(() => {
        if (initialQuery) {
            handleSearch(initialQuery, initialFilters);
        }
    }, [initialQuery]);

    const handleSearch = async (searchQuery: string, searchFilters?: SearchFilter) => {
        if (!searchQuery.trim()) return;

        setIsLoading(true);

        try {
            // Update URL with search params
            const params = new URLSearchParams();
            params.set('q', searchQuery);

            if (searchFilters?.status) {
                searchFilters.status.forEach(s => params.append('status', s));
            }
            if (searchFilters?.mimeTypes) {
                searchFilters.mimeTypes.forEach(t => params.append('type', t));
            }
            if (searchFilters?.tags) {
                searchFilters.tags.forEach(t => params.append('tag', t));
            }
            if (searchFilters?.folderId) {
                params.set('folder', searchFilters.folderId);
            }

            setSearchParams(params);

            // Call tRPC search endpoint
            const response = await trpc.search.global.query({
                query: searchQuery,
                filters: searchFilters,
                pagination: {
                    page: 1,
                    limit: 50,
                },
                sortBy: 'relevance',
                sortOrder: 'desc',
                includeHighlights: true,
                includeFacets: true,
            });

            // Transform results to match SearchResult interface
            const transformedResults: SearchResult[] = response.results.map((result: any) => ({
                id: result.id,
                name: result.name,
                type: result.type,
                mimeType: result.mimeType,
                size: result.size,
                status: result.status,
                createdAt: new Date(result.createdAt),
                updatedAt: new Date(result.updatedAt),
                score: result.score,
                highlights: result.highlights,
                folder: result.folder,
                createdByUser: result.createdByUser,
            }));

            setResults(transformedResults);

            // Save to search history
            const newHistory = [
                { query: searchQuery, timestamp: new Date(), filters: searchFilters },
                ...searchHistory.filter(h => h.query !== searchQuery),
            ].slice(0, 10);

            setSearchHistory(newHistory);
            localStorage.setItem('docusign-search-history', JSON.stringify(newHistory));
        } catch (error) {
            console.error('Search failed:', error);
            setResults([]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleGetSuggestions = async (suggestionQuery: string) => {
        if (!suggestionQuery.trim()) {
            setSuggestions([]);
            return;
        }

        try {
            const response = await trpc.search.suggestions.query({
                query: suggestionQuery,
                limit: 10,
            });

            const transformedSuggestions: SearchSuggestion[] = response.suggestions.map((s: any) => ({
                type: s.type,
                value: s.value,
                label: s.label,
            }));

            setSuggestions(transformedSuggestions);
        } catch (error) {
            console.error('Failed to get suggestions:', error);
            setSuggestions([]);
        }
    };

    const handleResultClick = (result: SearchResult) => {
        // Navigate to the appropriate page based on result type
        switch (result.type) {
            case 'document':
                navigate(`/documents/${result.id}`);
                break;
            case 'folder':
                navigate(`/documents?folder=${result.id}`);
                break;
            case 'template':
                navigate(`/templates/${result.id}`);
                break;
            default:
                console.warn('Unknown result type:', result.type);
        }
    };

    return (
        <div className="container mx-auto py-8">
            <div className="mb-8">
                <h1 className="text-3xl font-bold">Search</h1>
                <p className="mt-2 text-muted-foreground">
                    Find documents, templates, and more across your organization
                </p>
            </div>

            <SearchInterface
                onSearch={handleSearch}
                onResultClick={handleResultClick}
                results={results}
                suggestions={suggestions}
                searchHistory={searchHistory}
                savedSearches={savedSearches}
                isLoading={isLoading}
                placeholder="Search documents, templates, folders..."
                showFilters={true}
                showHistory={true}
                showSuggestions={true}
            />
        </div>
    );
}
