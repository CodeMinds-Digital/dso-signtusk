import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { TwoFactorSetup } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Set up Two-Factor Authentication - DocuSign Alternative" },
        { name: "description", content: "Secure your account with two-factor authentication" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    // In a real implementation, check if 2FA is already enabled
    // and generate QR code and secret
    const mockSetupData = {
        qrCodeUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==", // Mock QR code
        secret: "JBSWY3DPEHPK3PXP",
        backupCodes: [
            "12345678",
            "87654321",
            "11223344",
            "44332211",
            "55667788",
            "88776655",
            "99001122",
            "22110099"
        ]
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        setupData: mockSetupData,
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");
    const code = formData.get("code");

    if (intent === "verify" && typeof code === "string") {
        // In a real implementation, verify the TOTP code
        if (code === "123456") { // Mock verification
            return json({ success: true });
        } else {
            return json(
                { error: "Invalid verification code. Please try again." },
                { status: 400 }
            );
        }
    }

    if (intent === "complete") {
        // In a real implementation, mark 2FA as enabled for the user
        return redirect("/settings?tab=2fa&success=enabled");
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function Setup2FA() {
    const { user, setupData } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isLoading = navigation.state === "submitting";

    const handleVerify = async (code: string) => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const intentInput = document.createElement('input');
        intentInput.name = 'intent';
        intentInput.value = 'verify';
        form.appendChild(intentInput);

        const codeInput = document.createElement('input');
        codeInput.name = 'code';
        codeInput.value = code;
        form.appendChild(codeInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleComplete = async () => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const intentInput = document.createElement('input');
        intentInput.name = 'intent';
        intentInput.value = 'complete';
        form.appendChild(intentInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleCancel = () => {
        window.location.href = '/settings';
    };

    return (
        <Layout user={user}>
            <div className="max-w-2xl mx-auto p-6">
                <TwoFactorSetup
                    qrCodeUrl={setupData.qrCodeUrl}
                    secret={setupData.secret}
                    backupCodes={setupData.backupCodes}
                    onVerify={handleVerify}
                    onComplete={handleComplete}
                    onCancel={handleCancel}
                    isLoading={isLoading}
                    error={actionData?.error}
                />
            </div>
        </Layout>
    );
}