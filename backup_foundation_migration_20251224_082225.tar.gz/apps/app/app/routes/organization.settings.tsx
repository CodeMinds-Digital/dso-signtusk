import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation, useSearchParams } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasSuccess } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Switch,
    Separator,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Badge,
    Textarea,
} from "@docusign-alternative/ui";
import {
    Settings,
    Building,
    Shield,
    Bell,
    Palette,
    Globe,
    Key,
    Webhook,
    AlertTriangle,
    Save,
    ArrowLeft
} from "@docusign-alternative/ui";
import { Link } from "@remix-run/react";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Organization Settings - DocuSign Alternative" },
        { name: "description", content: "Manage your organization settings and configuration" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId || 'default-org',
            roles: userSession.roles,
        },
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "updateGeneral") {
        // In real implementation, update organization general settings
        return json({ success: "Organization settings updated successfully" });
    }

    if (intent === "updateSecurity") {
        // In real implementation, update security settings
        return json({ success: "Security settings updated successfully" });
    }

    if (intent === "updateNotifications") {
        // In real implementation, update notification settings
        return json({ success: "Notification settings updated successfully" });
    }

    if (intent === "updateIntegrations") {
        // In real implementation, update integration settings
        return json({ success: "Integration settings updated successfully" });
    }

    if (intent === "updateBranding") {
        // In real implementation, update branding settings
        return json({ success: "Branding settings updated successfully" });
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function OrganizationSettings() {
    const { user } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const [searchParams] = useSearchParams();
    const isSubmitting = navigation.state === "submitting";

    const defaultTab = searchParams.get("tab") || "general";

    // tRPC queries
    const organizationQuery = trpc.organization.get.useQuery({
        organizationId: user.organizationId,
    });

    const settingsQuery = trpc.organization.getSettings.useQuery({
        organizationId: user.organizationId,
    });

    const organization = organizationQuery.data?.organization;
    const settings = settingsQuery.data?.settings;

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center space-x-4 mb-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/organization">
                                <ArrowLeft className="h-4 w-4 mr-2" />
                                Back to Organization
                            </Link>
                        </Button>
                    </div>
                    <h1 className="text-2xl font-bold text-gray-900">Organization Settings</h1>
                    <p className="text-gray-600">
                        Configure your organization preferences and policies
                    </p>
                </div>

                <Tabs defaultValue={defaultTab} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-5">
                        <TabsTrigger value="general">General</TabsTrigger>
                        <TabsTrigger value="security">Security</TabsTrigger>
                        <TabsTrigger value="notifications">Notifications</TabsTrigger>
                        <TabsTrigger value="integrations">Integrations</TabsTrigger>
                        <TabsTrigger value="branding">Branding</TabsTrigger>
                    </TabsList>

                    <TabsContent value="general" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Building className="mr-2 h-5 w-5" />
                                    Organization Information
                                </CardTitle>
                                <CardDescription>
                                    Basic information about your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateGeneral" />

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="name">Organization Name</Label>
                                            <Input
                                                id="name"
                                                name="name"
                                                defaultValue={organization?.name}
                                                placeholder="Enter organization name"
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="domain">Domain</Label>
                                            <Input
                                                id="domain"
                                                name="domain"
                                                defaultValue={organization?.domain}
                                                placeholder="example.com"
                                            />
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="tier">Plan Tier</Label>
                                            <Select name="tier" defaultValue={organization?.tier}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="FREE">Free</SelectItem>
                                                    <SelectItem value="STARTER">Starter</SelectItem>
                                                    <SelectItem value="PROFESSIONAL">Professional</SelectItem>
                                                    <SelectItem value="ENTERPRISE">Enterprise</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div>
                                            <Label htmlFor="status">Status</Label>
                                            <Select name="status" defaultValue={organization?.status}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="ACTIVE">Active</SelectItem>
                                                    <SelectItem value="SUSPENDED">Suspended</SelectItem>
                                                    <SelectItem value="INACTIVE">Inactive</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="allowedDomains">Allowed Email Domains</Label>
                                        <Textarea
                                            id="allowedDomains"
                                            name="allowedDomains"
                                            placeholder="Enter domains separated by commas (e.g., company.com, subsidiary.com)"
                                            defaultValue={settings?.general?.allowedDomains?.join(', ')}
                                        />
                                        <p className="text-sm text-gray-600 mt-1">
                                            Only users with these email domains can join the organization
                                        </p>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                                            <Input
                                                id="sessionTimeout"
                                                name="sessionTimeout"
                                                type="number"
                                                min="5"
                                                max="1440"
                                                defaultValue={settings?.general?.sessionTimeout}
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="documentRetention">Document Retention (days)</Label>
                                            <Input
                                                id="documentRetention"
                                                name="documentRetention"
                                                type="number"
                                                min="30"
                                                max="3650"
                                                defaultValue={settings?.general?.defaultDocumentRetention}
                                            />
                                        </div>
                                    </div>

                                    {hasSuccess(actionData) && (
                                        <div className="rounded-md bg-green-50 p-4">
                                            <div className="text-sm text-green-700">{actionData.success}</div>
                                        </div>
                                    )}

                                    <Button type="submit" disabled={isSubmitting}>
                                        <Save className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Saving..." : "Save Changes"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="security" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Shield className="mr-2 h-5 w-5" />
                                    Security Policies
                                </CardTitle>
                                <CardDescription>
                                    Configure security requirements for your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateSecurity" />

                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Enforce Single Sign-On (SSO)</p>
                                                <p className="text-sm text-gray-600">
                                                    Require all users to authenticate via SSO
                                                </p>
                                            </div>
                                            <Switch
                                                name="enforceSSO"
                                                defaultChecked={settings?.general?.enforceSSO}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Require Two-Factor Authentication</p>
                                                <p className="text-sm text-gray-600">
                                                    All users must enable 2FA to access the organization
                                                </p>
                                            </div>
                                            <Switch
                                                name="requireTwoFactor"
                                                defaultChecked={settings?.general?.requireTwoFactor}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Allow External Sharing</p>
                                                <p className="text-sm text-gray-600">
                                                    Users can share documents with external recipients
                                                </p>
                                            </div>
                                            <Switch
                                                name="allowExternalSharing"
                                                defaultChecked={settings?.general?.allowExternalSharing}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Require Document Passwords</p>
                                                <p className="text-sm text-gray-600">
                                                    All documents must be password protected
                                                </p>
                                            </div>
                                            <Switch
                                                name="requireDocumentPassword"
                                                defaultChecked={settings?.general?.requireDocumentPassword}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Enable Audit Logging</p>
                                                <p className="text-sm text-gray-600">
                                                    Track all user actions and system events
                                                </p>
                                            </div>
                                            <Switch
                                                name="enableAuditLog"
                                                defaultChecked={settings?.general?.enableAuditLog}
                                            />
                                        </div>

                                        <Separator />

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Enable Data Encryption</p>
                                                <p className="text-sm text-gray-600">
                                                    Encrypt all data at rest and in transit
                                                </p>
                                            </div>
                                            <Switch
                                                name="enableEncryption"
                                                defaultChecked={settings?.general?.enableEncryption}
                                            />
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="dataRetentionPeriod">Data Retention Period (days)</Label>
                                            <Input
                                                id="dataRetentionPeriod"
                                                name="dataRetentionPeriod"
                                                type="number"
                                                min="365"
                                                max="3650"
                                                defaultValue={settings?.general?.dataRetentionPeriod}
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="defaultSigningOrder">Default Signing Order</Label>
                                            <Select name="defaultSigningOrder" defaultValue={settings?.general?.defaultSigningOrder}>
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="sequential">Sequential</SelectItem>
                                                    <SelectItem value="parallel">Parallel</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        <Save className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Saving..." : "Save Security Settings"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="notifications" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Bell className="mr-2 h-5 w-5" />
                                    Notification Settings
                                </CardTitle>
                                <CardDescription>
                                    Configure organization-wide notification preferences
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateNotifications" />

                                    <div className="space-y-6">
                                        <div>
                                            <h3 className="text-lg font-medium mb-4">Email Notifications</h3>
                                            <div className="space-y-4">
                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="font-medium">Document Signed</p>
                                                        <p className="text-sm text-gray-600">
                                                            Notify when documents are signed
                                                        </p>
                                                    </div>
                                                    <Switch
                                                        name="emailDocumentSigned"
                                                        defaultChecked={settings?.notifications?.email?.documentSigned}
                                                    />
                                                </div>

                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="font-medium">Document Expiring</p>
                                                        <p className="text-sm text-gray-600">
                                                            Notify when documents are about to expire
                                                        </p>
                                                    </div>
                                                    <Switch
                                                        name="emailDocumentExpiring"
                                                        defaultChecked={settings?.notifications?.email?.documentExpiring}
                                                    />
                                                </div>

                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="font-medium">Member Invited</p>
                                                        <p className="text-sm text-gray-600">
                                                            Notify when new members are invited
                                                        </p>
                                                    </div>
                                                    <Switch
                                                        name="emailMemberInvited"
                                                        defaultChecked={settings?.notifications?.email?.memberInvited}
                                                    />
                                                </div>

                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="font-medium">Security Alerts</p>
                                                        <p className="text-sm text-gray-600">
                                                            Notify about security events
                                                        </p>
                                                    </div>
                                                    <Switch
                                                        name="emailSecurityAlerts"
                                                        defaultChecked={settings?.notifications?.email?.securityAlerts}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <Separator />

                                        <div>
                                            <h3 className="text-lg font-medium mb-4">Webhook Notifications</h3>
                                            <div className="space-y-4">
                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="font-medium">Enable Webhooks</p>
                                                        <p className="text-sm text-gray-600">
                                                            Send real-time notifications to external systems
                                                        </p>
                                                    </div>
                                                    <Switch
                                                        name="webhookEnabled"
                                                        defaultChecked={settings?.notifications?.webhook?.enabled}
                                                    />
                                                </div>

                                                <div>
                                                    <Label htmlFor="webhookUrl">Webhook URL</Label>
                                                    <Input
                                                        id="webhookUrl"
                                                        name="webhookUrl"
                                                        type="url"
                                                        placeholder="https://your-app.com/webhooks"
                                                        defaultValue={settings?.notifications?.webhook?.url}
                                                    />
                                                </div>

                                                <div>
                                                    <Label htmlFor="webhookSecret">Webhook Secret</Label>
                                                    <Input
                                                        id="webhookSecret"
                                                        name="webhookSecret"
                                                        type="password"
                                                        placeholder="Enter webhook secret"
                                                        defaultValue={settings?.notifications?.webhook?.secret}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        <Save className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Saving..." : "Save Notification Settings"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="integrations" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Key className="mr-2 h-5 w-5" />
                                    API & Integrations
                                </CardTitle>
                                <CardDescription>
                                    Manage API access and third-party integrations
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateIntegrations" />

                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Enable API Access</p>
                                                <p className="text-sm text-gray-600">
                                                    Allow API access for this organization
                                                </p>
                                            </div>
                                            <Switch
                                                name="enableAPIAccess"
                                                defaultChecked={settings?.general?.enableAPIAccess}
                                            />
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Enable Webhooks</p>
                                                <p className="text-sm text-gray-600">
                                                    Allow webhook integrations
                                                </p>
                                            </div>
                                            <Switch
                                                name="enableWebhooks"
                                                defaultChecked={settings?.general?.enableWebhooks}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="allowedIntegrations">Allowed Integrations</Label>
                                        <Textarea
                                            id="allowedIntegrations"
                                            name="allowedIntegrations"
                                            placeholder="Enter integration names separated by commas (e.g., salesforce, slack, zapier)"
                                            defaultValue={settings?.general?.allowedIntegrations?.join(', ')}
                                        />
                                        <p className="text-sm text-gray-600 mt-1">
                                            Specify which third-party integrations are allowed
                                        </p>
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        <Save className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Saving..." : "Save Integration Settings"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>API Keys</CardTitle>
                                <CardDescription>
                                    Manage API keys for your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="flex items-center justify-between">
                                    <p className="text-sm text-gray-600">
                                        Create and manage API keys for programmatic access
                                    </p>
                                    <Button variant="outline" asChild>
                                        <Link to="/organization/api-keys">
                                            Manage API Keys
                                        </Link>
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="branding" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center">
                                    <Palette className="mr-2 h-5 w-5" />
                                    Organization Branding
                                </CardTitle>
                                <CardDescription>
                                    Customize the appearance of your organization
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateBranding" />

                                    <div>
                                        <Label htmlFor="logo">Logo URL</Label>
                                        <Input
                                            id="logo"
                                            name="logo"
                                            type="url"
                                            placeholder="https://example.com/logo.png"
                                            defaultValue={organization?.branding?.logo}
                                        />
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="primaryColor">Primary Color</Label>
                                            <Input
                                                id="primaryColor"
                                                name="primaryColor"
                                                type="color"
                                                defaultValue={organization?.branding?.primaryColor}
                                            />
                                        </div>

                                        <div>
                                            <Label htmlFor="secondaryColor">Secondary Color</Label>
                                            <Input
                                                id="secondaryColor"
                                                name="secondaryColor"
                                                type="color"
                                                defaultValue={organization?.branding?.secondaryColor}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="fontFamily">Font Family</Label>
                                        <Select name="fontFamily" defaultValue={organization?.branding?.fontFamily}>
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Inter">Inter</SelectItem>
                                                <SelectItem value="Roboto">Roboto</SelectItem>
                                                <SelectItem value="Open Sans">Open Sans</SelectItem>
                                                <SelectItem value="Lato">Lato</SelectItem>
                                                <SelectItem value="Poppins">Poppins</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <Button type="submit" disabled={isSubmitting}>
                                        <Save className="mr-2 h-4 w-4" />
                                        {isSubmitting ? "Saving..." : "Save Branding"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}