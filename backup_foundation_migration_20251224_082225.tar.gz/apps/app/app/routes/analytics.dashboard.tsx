import React, { useState, useCallback } from 'react';
import { json, type LoaderFunctionArgs, type MetaFunction } from '@remix-run/node';
import { useLoaderData } from '@remix-run/react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Container,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from "@docusign-alternative/ui";
import {
    Save,
    Download,
    Share,
    RefreshCw,
    Settings,
    RotateCcw,
    Layout,
} from "@docusign-alternative/ui";
import { trpc } from '~/lib/trpc';
import { requireAuth } from '~/lib/session.server';
import InteractiveAnalyticsDashboard, { type DashboardWidget } from '~/components/interactive-analytics-dashboard';

export const meta: MetaFunction = () => {
    return [
        { title: "Interactive Dashboard - DocuSign Alternative" },
        { name: "description", content: "Customizable analytics dashboard with drag-and-drop widgets" },
    ];
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
    const user = await requireAuth(request);
    return json({ user });
};

interface DashboardLayout {
    id: string;
    name: string;
    description?: string;
    widgets: DashboardWidget[];
    isDefault?: boolean;
    createdAt: string;
    updatedAt: string;
}

export default function InteractiveDashboard() {
    const { user } = useLoaderData<typeof loader>();

    const [currentLayout, setCurrentLayout] = useState<DashboardLayout | null>(null);
    const [savedLayouts, setSavedLayouts] = useState<DashboardLayout[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    // tRPC queries for analytics data
    const { data: dashboardData, refetch: refetchDashboard } = trpc.analytics.getDashboardOverview.useQuery({
        timeRange: {
            startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            endDate: new Date().toISOString(),
        },
    });

    const { data: usageData } = trpc.analytics.getUsageAnalytics.useQuery({
        timeRange: {
            startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            endDate: new Date().toISOString(),
        },
        granularity: 'day',
    });

    const { data: teamData } = trpc.analytics.getTeamPerformance.useQuery({
        timeRange: {
            startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            endDate: new Date().toISOString(),
        },
    });

    // Export mutation
    const exportMutation = trpc.analytics.exportData.useMutation({
        onSuccess: (data) => {
            console.log('Dashboard export started:', data);
        },
    });

    // Default dashboard layout
    const defaultWidgets: DashboardWidget[] = [
        {
            id: 'widget-1',
            type: 'metric',
            title: 'Total Users',
            size: 'small',
            position: { x: 0, y: 0, w: 3, h: 1 },
            config: { metric: 'total_users' },
            refreshable: true,
            exportable: true,
        },
        {
            id: 'widget-2',
            type: 'metric',
            title: 'Active Users',
            size: 'small',
            position: { x: 3, y: 0, w: 3, h: 1 },
            config: { metric: 'active_users' },
            refreshable: true,
            exportable: true,
        },
        {
            id: 'widget-3',
            type: 'metric',
            title: 'Documents Completed',
            size: 'small',
            position: { x: 6, y: 0, w: 3, h: 1 },
            config: { metric: 'documents_completed' },
            refreshable: true,
            exportable: true,
        },
        {
            id: 'widget-4',
            type: 'metric',
            title: 'Completion Rate',
            size: 'small',
            position: { x: 9, y: 0, w: 3, h: 1 },
            config: { metric: 'completion_rate' },
            refreshable: true,
            exportable: true,
        },
        {
            id: 'widget-5',
            type: 'line-chart',
            title: 'Document Activity Trends',
            size: 'medium',
            position: { x: 0, y: 1, w: 6, h: 2 },
            config: { metric: 'document_trends', color: '#3b82f6' },
            refreshable: true,
            exportable: true,
            filterable: true,
        },
        {
            id: 'widget-6',
            type: 'bar-chart',
            title: 'Signing Activity',
            size: 'medium',
            position: { x: 6, y: 1, w: 6, h: 2 },
            config: { metric: 'signing_activity' },
            refreshable: true,
            exportable: true,
            filterable: true,
        },
        {
            id: 'widget-7',
            type: 'pie-chart',
            title: 'Documents by Status',
            size: 'medium',
            position: { x: 0, y: 3, w: 4, h: 2 },
            config: { metric: 'documents_by_status', showLegend: true },
            refreshable: true,
            exportable: true,
        },
        {
            id: 'widget-8',
            type: 'activity-feed',
            title: 'Recent Activity',
            size: 'medium',
            position: { x: 4, y: 3, w: 4, h: 2 },
            config: { metric: 'recent_activities' },
            refreshable: true,
        },
        {
            id: 'widget-9',
            type: 'table',
            title: 'Team Performance',
            size: 'large',
            position: { x: 8, y: 3, w: 4, h: 2 },
            config: { metric: 'team_performance' },
            refreshable: true,
            exportable: true,
            filterable: true,
        },
    ];

    const [widgets, setWidgets] = useState<DashboardWidget[]>(defaultWidgets);

    const handleWidgetUpdate = useCallback((updatedWidgets: DashboardWidget[]) => {
        setWidgets(updatedWidgets);
    }, []);

    const handleSaveLayout = useCallback(() => {
        const newLayout: DashboardLayout = {
            id: `layout-${Date.now()}`,
            name: `Custom Layout ${savedLayouts.length + 1}`,
            description: 'Custom dashboard layout',
            widgets: widgets,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };

        setSavedLayouts(prev => [...prev, newLayout]);
        setCurrentLayout(newLayout);

        // In real implementation, save to database
        console.log('Layout saved:', newLayout);
    }, [widgets, savedLayouts.length]);

    const handleLoadLayout = useCallback((layout: DashboardLayout) => {
        setWidgets(layout.widgets);
        setCurrentLayout(layout);
    }, []);

    const handleResetLayout = useCallback(() => {
        setWidgets(defaultWidgets);
        setCurrentLayout(null);
    }, []);

    const handleExportDashboard = useCallback((format: string) => {
        exportMutation.mutate({
            reportType: 'dashboard',
            format: format as 'csv' | 'xlsx' | 'pdf',
            timeRange: {
                startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
                endDate: new Date().toISOString(),
            },
            includeCharts: format === 'pdf',
        });
    }, [exportMutation]);

    const handleRefreshAll = useCallback(async () => {
        setIsLoading(true);
        await refetchDashboard();
        setIsLoading(false);
    }, [refetchDashboard]);

    const analyticsData = {
        dashboard: dashboardData,
        usage: usageData,
        team: teamData,
    };

    return (
        <Container className="py-6">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Interactive Dashboard</h1>
                        <p className="text-gray-600 mt-1">
                            Customize your analytics view with drag-and-drop widgets
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <Button
                            variant="outline"
                            onClick={handleRefreshAll}
                            disabled={isLoading}
                        >
                            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                            Refresh All
                        </Button>
                        <Button
                            variant="outline"
                            onClick={handleResetLayout}
                        >
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Reset Layout
                        </Button>
                        <Button
                            variant="outline"
                            onClick={handleSaveLayout}
                        >
                            <Save className="h-4 w-4 mr-2" />
                            Save Layout
                        </Button>
                        <Select onValueChange={handleExportDashboard}>
                            <SelectTrigger className="w-32">
                                <Download className="h-4 w-4 mr-2" />
                                <SelectValue placeholder="Export" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="png">PNG</SelectItem>
                                <SelectItem value="pdf">PDF</SelectItem>
                                <SelectItem value="csv">CSV</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                {/* Layout Selector */}
                {savedLayouts.length > 0 && (
                    <div className="flex items-center gap-4 mb-4">
                        <span className="text-sm font-medium text-gray-700">Saved Layouts:</span>
                        <div className="flex gap-2">
                            <Button
                                variant={currentLayout === null ? "default" : "outline"}
                                size="sm"
                                onClick={() => handleLoadLayout({
                                    id: 'default',
                                    name: 'Default',
                                    widgets: defaultWidgets,
                                    createdAt: '',
                                    updatedAt: ''
                                })}
                            >
                                Default
                            </Button>
                            {savedLayouts.map((layout) => (
                                <Button
                                    key={layout.id}
                                    variant={currentLayout?.id === layout.id ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => handleLoadLayout(layout)}
                                >
                                    {layout.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                )}

                {/* Current Layout Info */}
                {currentLayout && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                        <div className="flex items-center gap-2">
                            <Layout className="h-4 w-4 text-blue-600" />
                            <span className="font-medium text-blue-900">
                                Current Layout: {currentLayout.name}
                            </span>
                            {currentLayout.description && (
                                <span className="text-blue-700 text-sm">
                                    - {currentLayout.description}
                                </span>
                            )}
                        </div>
                    </div>
                )}
            </div>

            {/* Dashboard Content */}
            <Tabs defaultValue="dashboard" className="space-y-6">
                <TabsList>
                    <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                    <TabsTrigger value="layouts">Manage Layouts</TabsTrigger>
                </TabsList>

                <TabsContent value="dashboard">
                    <InteractiveAnalyticsDashboard
                        initialWidgets={widgets}
                        onWidgetUpdate={handleWidgetUpdate}
                        onExport={handleExportDashboard}
                        analyticsData={analyticsData}
                    />
                </TabsContent>

                <TabsContent value="layouts" className="space-y-6">
                    <div className="grid gap-4">
                        {/* Default Layout */}
                        <Card>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <CardTitle>Default Layout</CardTitle>
                                        <CardDescription>
                                            Standard dashboard layout with essential widgets
                                        </CardDescription>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant="outline">Built-in</Badge>
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => handleLoadLayout({
                                                id: 'default',
                                                name: 'Default',
                                                widgets: defaultWidgets,
                                                createdAt: '',
                                                updatedAt: ''
                                            })}
                                        >
                                            Load Layout
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="text-sm text-gray-600">
                                    {defaultWidgets.length} widgets • Includes metrics, charts, and activity feed
                                </div>
                            </CardContent>
                        </Card>

                        {/* Saved Layouts */}
                        {savedLayouts.map((layout) => (
                            <Card key={layout.id}>
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <CardTitle>{layout.name}</CardTitle>
                                            {layout.description && (
                                                <CardDescription>{layout.description}</CardDescription>
                                            )}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {layout.isDefault && <Badge>Default</Badge>}
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() => handleLoadLayout(layout)}
                                            >
                                                Load Layout
                                            </Button>
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() => {
                                                    setSavedLayouts(prev => prev.filter(l => l.id !== layout.id));
                                                }}
                                            >
                                                Delete
                                            </Button>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-sm text-gray-600">
                                        {layout.widgets.length} widgets •
                                        Created {new Date(layout.createdAt).toLocaleDateString()} •
                                        Updated {new Date(layout.updatedAt).toLocaleDateString()}
                                    </div>
                                </CardContent>
                            </Card>
                        ))}

                        {savedLayouts.length === 0 && (
                            <Card>
                                <CardContent className="flex flex-col items-center justify-center py-12">
                                    <Layout className="h-12 w-12 text-gray-400 mb-4" />
                                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                                        No saved layouts
                                    </h3>
                                    <p className="text-gray-600 text-center mb-6">
                                        Customize your dashboard and save layouts for quick access
                                    </p>
                                    <Button onClick={handleSaveLayout}>
                                        <Save className="h-4 w-4 mr-2" />
                                        Save Current Layout
                                    </Button>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </TabsContent>
            </Tabs>
        </Container>
    );
}