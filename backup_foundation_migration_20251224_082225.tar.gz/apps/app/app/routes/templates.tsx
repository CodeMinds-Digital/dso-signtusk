import type { LoaderFunctionArgs, MetaFunction, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link, useFetcher, useSearchParams } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { trpc } from "~/lib/trpc";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Input,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Alert,
    AlertDescription,
    Progress,
    Checkbox,
    Label,
    Textarea,
    Switch,
    Separator,
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
    useToast,
} from "@docusign-alternative/ui";
import {
    Folder,
    Search,
    Filter,
    Plus,
    MoreHorizontal,
    Copy,
    Share,
    Edit,
    Trash2,
    Eye,
    Users,
    FileText,
    Star,
    Globe,
    Lock,
    BarChart3,
    TrendingUp,
    Calendar,
    Clock,
    Download,
    Upload,
    Settings,
    LayoutGrid,
    List,
    ChevronDown,
    ChevronRight,
    ArrowUpDown,
    ExternalLink,
    UserPlus,
    Shield,
    Activity,
    AlertCircle,
    CheckCircle,
    XCircle,
    Info,
} from "@docusign-alternative/ui";
import { useState, useEffect, useMemo } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Template Management - DocuSign Alternative" },
        { name: "description", content: "Create, manage, and analyze your document templates with comprehensive insights" },
    ];
};

// Enhanced template interface
interface Template {
    id: string;
    name: string;
    description?: string;
    category?: string;
    tags: string[];
    isPublic: boolean;
    isFavorite: boolean;
    createdAt: string;
    updatedAt: string;
    usageCount: number;
    fields: number;
    recipients: number;
    createdBy: string;
    version: number;
    status: 'active' | 'draft' | 'archived';
    permissions: {
        canView: boolean;
        canEdit: boolean;
        canDelete: boolean;
        canShare: boolean;
        canUse: boolean;
    };
    analytics: {
        completionRate: number;
        averageCompletionTime: number;
        totalUsage: number;
        recentUsage: number;
    };
    sharing: {
        isShared: boolean;
        shareCount: number;
        publicLink?: string;
    };
}

interface TemplateAnalytics {
    totalTemplates: number;
    totalUsage: number;
    averageCompletionRate: number;
    topPerformingTemplates: Array<{
        id: string;
        name: string;
        usageCount: number;
        completionRate: number;
    }>;
    usageByCategory: Array<{
        category: string;
        count: number;
        percentage: number;
    }>;
    recentActivity: Array<{
        id: string;
        templateName: string;
        action: string;
        timestamp: string;
        user: string;
    }>;
    performanceMetrics: {
        totalSavings: number;
        timeReduction: number;
        errorReduction: number;
    };
}

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const url = new URL(request.url);

    // Get query parameters for filtering and pagination
    const search = url.searchParams.get('search') || '';
    const category = url.searchParams.get('category') || 'all';
    const sortBy = url.searchParams.get('sortBy') || 'updatedAt';
    const sortOrder = url.searchParams.get('sortOrder') || 'desc';
    const view = url.searchParams.get('view') || 'grid';
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '12');

    // Enhanced mock template data with comprehensive information
    const allTemplates: Template[] = [
        {
            id: "template-1",
            name: "Employment Contract Template",
            description: "Comprehensive employment contract with signature fields for HR department including salary, benefits, and terms",
            category: "HR",
            tags: ["employment", "contract", "hr", "legal"],
            isPublic: false,
            isFavorite: true,
            createdAt: "2024-01-10T10:30:00Z",
            updatedAt: "2024-01-15T14:20:00Z",
            usageCount: 24,
            fields: 8,
            recipients: 2,
            createdBy: "HR Team",
            version: 3,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 92.5,
                averageCompletionTime: 2.3,
                totalUsage: 24,
                recentUsage: 8,
            },
            sharing: {
                isShared: true,
                shareCount: 3,
                publicLink: undefined,
            },
        },
        {
            id: "template-2",
            name: "NDA Agreement",
            description: "Non-disclosure agreement template for client partnerships and vendor relationships",
            category: "Legal",
            tags: ["nda", "legal", "confidentiality", "partnership"],
            isPublic: true,
            isFavorite: false,
            createdAt: "2024-01-08T09:15:00Z",
            updatedAt: "2024-01-12T16:30:00Z",
            usageCount: 18,
            fields: 6,
            recipients: 2,
            createdBy: "Legal Team",
            version: 2,
            status: "active",
            permissions: {
                canView: true,
                canEdit: false,
                canDelete: false,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 88.9,
                averageCompletionTime: 1.8,
                totalUsage: 18,
                recentUsage: 5,
            },
            sharing: {
                isShared: true,
                shareCount: 12,
                publicLink: "https://app.example.com/templates/public/template-2",
            },
        },
        {
            id: "template-3",
            name: "Service Agreement",
            description: "Client service agreement with payment terms, deliverables, and project scope definition",
            category: "Sales",
            tags: ["service", "agreement", "sales", "client"],
            isPublic: false,
            isFavorite: true,
            createdAt: "2024-01-05T16:45:00Z",
            updatedAt: "2024-01-14T11:20:00Z",
            usageCount: 12,
            fields: 12,
            recipients: 3,
            createdBy: "Sales Team",
            version: 1,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 95.8,
                averageCompletionTime: 3.2,
                totalUsage: 12,
                recentUsage: 4,
            },
            sharing: {
                isShared: false,
                shareCount: 0,
            },
        },
        {
            id: "template-4",
            name: "Vendor Agreement",
            description: "Standard vendor partnership agreement template with terms and conditions",
            category: "Procurement",
            tags: ["vendor", "procurement", "partnership", "agreement"],
            isPublic: true,
            isFavorite: false,
            createdAt: "2024-01-03T11:20:00Z",
            updatedAt: "2024-01-10T09:45:00Z",
            usageCount: 8,
            fields: 10,
            recipients: 2,
            createdBy: "Procurement Team",
            version: 1,
            status: "active",
            permissions: {
                canView: true,
                canEdit: false,
                canDelete: false,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 87.5,
                averageCompletionTime: 2.1,
                totalUsage: 8,
                recentUsage: 2,
            },
            sharing: {
                isShared: true,
                shareCount: 5,
                publicLink: "https://app.example.com/templates/public/template-4",
            },
        },
        {
            id: "template-5",
            name: "Invoice Template",
            description: "Professional invoice template with payment terms and company branding",
            category: "Finance",
            tags: ["invoice", "finance", "billing", "payment"],
            isPublic: false,
            isFavorite: false,
            createdAt: "2024-01-02T14:30:00Z",
            updatedAt: "2024-01-08T10:15:00Z",
            usageCount: 35,
            fields: 15,
            recipients: 1,
            createdBy: "Finance Team",
            version: 4,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 98.6,
                averageCompletionTime: 1.2,
                totalUsage: 35,
                recentUsage: 12,
            },
            sharing: {
                isShared: true,
                shareCount: 2,
            },
        },
        {
            id: "template-6",
            name: "Project Proposal",
            description: "Comprehensive project proposal template with scope, timeline, and budget sections",
            category: "Sales",
            tags: ["proposal", "project", "sales", "scope"],
            isPublic: false,
            isFavorite: true,
            createdAt: "2023-12-28T09:00:00Z",
            updatedAt: "2024-01-06T15:45:00Z",
            usageCount: 16,
            fields: 20,
            recipients: 4,
            createdBy: "Sales Team",
            version: 2,
            status: "active",
            permissions: {
                canView: true,
                canEdit: true,
                canDelete: true,
                canShare: true,
                canUse: true,
            },
            analytics: {
                completionRate: 91.3,
                averageCompletionTime: 4.5,
                totalUsage: 16,
                recentUsage: 3,
            },
            sharing: {
                isShared: true,
                shareCount: 1,
            },
        },
    ];

    // Filter templates based on search and category
    let filteredTemplates = allTemplates;

    if (search) {
        filteredTemplates = filteredTemplates.filter(template =>
            template.name.toLowerCase().includes(search.toLowerCase()) ||
            template.description?.toLowerCase().includes(search.toLowerCase()) ||
            template.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase()))
        );
    }

    if (category !== 'all') {
        filteredTemplates = filteredTemplates.filter(template =>
            template.category?.toLowerCase() === category.toLowerCase()
        );
    }

    // Sort templates
    filteredTemplates.sort((a, b) => {
        let aValue: any, bValue: any;

        switch (sortBy) {
            case 'name':
                aValue = a.name.toLowerCase();
                bValue = b.name.toLowerCase();
                break;
            case 'usageCount':
                aValue = a.usageCount;
                bValue = b.usageCount;
                break;
            case 'completionRate':
                aValue = a.analytics.completionRate;
                bValue = b.analytics.completionRate;
                break;
            case 'createdAt':
                aValue = new Date(a.createdAt).getTime();
                bValue = new Date(b.createdAt).getTime();
                break;
            case 'updatedAt':
            default:
                aValue = new Date(a.updatedAt).getTime();
                bValue = new Date(b.updatedAt).getTime();
                break;
        }

        if (sortOrder === 'asc') {
            return aValue > bValue ? 1 : -1;
        } else {
            return aValue < bValue ? 1 : -1;
        }
    });

    // Paginate results
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedTemplates = filteredTemplates.slice(startIndex, endIndex);

    // Generate analytics data
    const analytics: TemplateAnalytics = {
        totalTemplates: allTemplates.length,
        totalUsage: allTemplates.reduce((sum, t) => sum + t.usageCount, 0),
        averageCompletionRate: allTemplates.reduce((sum, t) => sum + t.analytics.completionRate, 0) / allTemplates.length,
        topPerformingTemplates: allTemplates
            .sort((a, b) => b.analytics.completionRate - a.analytics.completionRate)
            .slice(0, 5)
            .map(t => ({
                id: t.id,
                name: t.name,
                usageCount: t.usageCount,
                completionRate: t.analytics.completionRate,
            })),
        usageByCategory: Object.entries(
            allTemplates.reduce((acc, t) => {
                const cat = t.category || 'Other';
                acc[cat] = (acc[cat] || 0) + t.usageCount;
                return acc;
            }, {} as Record<string, number>)
        ).map(([category, count]) => ({
            category,
            count,
            percentage: (count / allTemplates.reduce((sum, t) => sum + t.usageCount, 0)) * 100,
        })),
        recentActivity: [
            {
                id: "activity-1",
                templateName: "Employment Contract Template",
                action: "Used",
                timestamp: "2024-01-15T14:20:00Z",
                user: "John Doe",
            },
            {
                id: "activity-2",
                templateName: "NDA Agreement",
                action: "Shared",
                timestamp: "2024-01-15T13:45:00Z",
                user: "Jane Smith",
            },
            {
                id: "activity-3",
                templateName: "Service Agreement",
                action: "Updated",
                timestamp: "2024-01-15T12:30:00Z",
                user: "Mike Johnson",
            },
        ],
        performanceMetrics: {
            totalSavings: 12500,
            timeReduction: 85,
            errorReduction: 92,
        },
    };

    // Get categories for filtering
    const categories = Array.from(new Set(allTemplates.map(t => t.category).filter(Boolean)))
        .map(category => ({
            name: category!,
            count: allTemplates.filter(t => t.category === category).length,
        }));

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        templates: paginatedTemplates,
        totalTemplates: filteredTemplates.length,
        analytics,
        categories,
        pagination: {
            page,
            limit,
            totalPages: Math.ceil(filteredTemplates.length / limit),
            hasNext: endIndex < filteredTemplates.length,
            hasPrev: page > 1,
        },
        filters: {
            search,
            category,
            sortBy,
            sortOrder,
            view,
        },
    });
}

const categoryColors = {
    HR: "bg-blue-100 text-blue-800 border-blue-200",
    Legal: "bg-purple-100 text-purple-800 border-purple-200",
    Sales: "bg-green-100 text-green-800 border-green-200",
    Procurement: "bg-orange-100 text-orange-800 border-orange-200",
    Finance: "bg-red-100 text-red-800 border-red-200",
    Operations: "bg-gray-100 text-gray-800 border-gray-200",
};

const statusColors = {
    active: "bg-green-100 text-green-800 border-green-200",
    draft: "bg-yellow-100 text-yellow-800 border-yellow-200",
    archived: "bg-gray-100 text-gray-800 border-gray-200",
};

export default function Templates() {
    const { user, templates, totalTemplates, analytics, categories, pagination, filters } = useLoaderData<typeof loader>();
    const [searchParams, setSearchParams] = useSearchParams();
    const { toast } = useToast();
    const fetcher = useFetcher();

    // Local state for UI interactions
    const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
    const [showShareDialog, setShowShareDialog] = useState(false);
    const [shareTemplateId, setShareTemplateId] = useState<string | null>(null);
    const [showAnalytics, setShowAnalytics] = useState(false);
    const [viewMode, setViewMode] = useState<'grid' | 'list'>(filters.view as 'grid' | 'list');

    // Update URL when filters change
    const updateFilters = (newFilters: Partial<typeof filters>) => {
        const params = new URLSearchParams(searchParams);
        Object.entries(newFilters).forEach(([key, value]) => {
            if (value && value !== 'all') {
                params.set(key, value.toString());
            } else {
                params.delete(key);
            }
        });
        setSearchParams(params);
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
        });
    };

    const formatTime = (hours: number) => {
        if (hours < 1) {
            return `${Math.round(hours * 60)}m`;
        }
        return `${hours.toFixed(1)}h`;
    };

    const handleTemplateAction = async (action: string, templateId: string, data?: any) => {
        try {
            switch (action) {
                case 'duplicate':
                    // Handle template duplication
                    toast({
                        title: "Template duplicated",
                        description: "Template has been successfully duplicated.",
                    });
                    break;
                case 'share':
                    setShareTemplateId(templateId);
                    setShowShareDialog(true);
                    break;
                case 'delete':
                    // Handle template deletion
                    toast({
                        title: "Template deleted",
                        description: "Template has been successfully deleted.",
                        variant: "destructive",
                    });
                    break;
                case 'favorite':
                    // Handle favorite toggle
                    toast({
                        title: "Template updated",
                        description: "Template favorite status updated.",
                    });
                    break;
                default:
                    break;
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "An error occurred while performing the action.",
                variant: "destructive",
            });
        }
    };

    const handleBulkAction = async (action: string) => {
        if (selectedTemplates.length === 0) return;

        try {
            switch (action) {
                case 'delete':
                    // Handle bulk deletion
                    toast({
                        title: "Templates deleted",
                        description: `${selectedTemplates.length} templates have been deleted.`,
                        variant: "destructive",
                    });
                    break;
                case 'share':
                    // Handle bulk sharing
                    toast({
                        title: "Templates shared",
                        description: `${selectedTemplates.length} templates have been shared.`,
                    });
                    break;
                case 'export':
                    // Handle bulk export
                    toast({
                        title: "Templates exported",
                        description: `${selectedTemplates.length} templates have been exported.`,
                    });
                    break;
                default:
                    break;
            }
            setSelectedTemplates([]);
        } catch (error) {
            toast({
                title: "Error",
                description: "An error occurred while performing the bulk action.",
                variant: "destructive",
            });
        }
    };

    const renderTemplateCard = (template: Template) => (
        <Card key={template.id} className="hover:shadow-lg transition-all duration-200 group">
            <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                        <Checkbox
                            checked={selectedTemplates.includes(template.id)}
                            onCheckedChange={(checked) => {
                                if (checked) {
                                    setSelectedTemplates([...selectedTemplates, template.id]);
                                } else {
                                    setSelectedTemplates(selectedTemplates.filter(id => id !== template.id));
                                }
                            }}
                        />
                        <div className="flex items-center space-x-2">
                            <Folder className="h-5 w-5 text-blue-600" />
                            {template.isFavorite && (
                                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            )}
                            {template.isPublic ? (
                                <Globe className="h-4 w-4 text-green-600" />
                            ) : (
                                <Lock className="h-4 w-4 text-gray-400" />
                            )}
                            {template.sharing.isShared && (
                                <Users className="h-4 w-4 text-blue-600" />
                            )}
                        </div>
                    </div>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                                <Link to={`/templates/${template.id}`}>
                                    <Eye className="mr-2 h-4 w-4" />
                                    Preview
                                </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                                <Link to={`/templates/${template.id}/use`}>
                                    <FileText className="mr-2 h-4 w-4" />
                                    Use Template
                                </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleTemplateAction('duplicate', template.id)}>
                                <Copy className="mr-2 h-4 w-4" />
                                Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleTemplateAction('share', template.id)}>
                                <Share className="mr-2 h-4 w-4" />
                                Share
                            </DropdownMenuItem>
                            {template.permissions.canEdit && (
                                <DropdownMenuItem asChild>
                                    <Link to={`/templates/${template.id}/edit`}>
                                        <Edit className="mr-2 h-4 w-4" />
                                        Edit
                                    </Link>
                                </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => handleTemplateAction('favorite', template.id)}>
                                <Star className="mr-2 h-4 w-4" />
                                {template.isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                            </DropdownMenuItem>
                            <Separator />
                            {template.permissions.canDelete && (
                                <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => handleTemplateAction('delete', template.id)}
                                >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete
                                </DropdownMenuItem>
                            )}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <div className="space-y-2">
                    <CardTitle className="text-lg line-clamp-2">{template.name}</CardTitle>
                    <CardDescription className="text-sm line-clamp-2">
                        {template.description}
                    </CardDescription>
                </div>
            </CardHeader>
            <CardContent className="pt-0 space-y-4">
                {/* Status and Category */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        <Badge
                            className={categoryColors[template.category as keyof typeof categoryColors] || categoryColors.Operations}
                        >
                            {template.category}
                        </Badge>
                        <Badge
                            variant="outline"
                            className={statusColors[template.status]}
                        >
                            {template.status}
                        </Badge>
                    </div>
                    <span className="text-sm text-gray-500">
                        v{template.version}
                    </span>
                </div>

                {/* Analytics Preview */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-1">
                        <div className="flex items-center justify-between">
                            <span className="text-gray-600">Usage</span>
                            <span className="font-medium">{template.usageCount}</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-600">Completion</span>
                            <span className="font-medium">{template.analytics.completionRate.toFixed(1)}%</span>
                        </div>
                    </div>
                    <div className="space-y-1">
                        <div className="flex items-center justify-between">
                            <span className="text-gray-600">Fields</span>
                            <span className="font-medium">{template.fields}</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-600">Recipients</span>
                            <span className="font-medium">{template.recipients}</span>
                        </div>
                    </div>
                </div>

                {/* Performance Indicator */}
                <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Performance</span>
                        <span className="font-medium">{template.analytics.completionRate.toFixed(1)}%</span>
                    </div>
                    <Progress value={template.analytics.completionRate} className="h-2" />
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                    {template.tags.slice(0, 3).map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                        </Badge>
                    ))}
                    {template.tags.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                            +{template.tags.length - 3}
                        </Badge>
                    )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-2 border-t text-xs text-gray-500">
                    <div>
                        <div>Updated: {formatDate(template.updatedAt)}</div>
                        <div>By: {template.createdBy}</div>
                    </div>
                    <div className="text-right">
                        <div>Avg. Time: {formatTime(template.analytics.averageCompletionTime)}</div>
                        <div>Recent: {template.analytics.recentUsage}</div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                    <Button size="sm" className="flex-1" asChild>
                        <Link to={`/templates/${template.id}/use`}>
                            Use Template
                        </Link>
                    </Button>
                    <TooltipProvider>
                        <Tooltip>
                            <TooltipTrigger asChild>
                                <Button variant="outline" size="sm" asChild>
                                    <Link to={`/templates/${template.id}`}>
                                        <Eye className="h-4 w-4" />
                                    </Link>
                                </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                                <p>Preview Template</p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                    <TooltipProvider>
                        <Tooltip>
                            <TooltipTrigger asChild>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setShowAnalytics(true)}
                                >
                                    <BarChart3 className="h-4 w-4" />
                                </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                                <p>View Analytics</p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                </div>
            </CardContent>
        </Card>
    );

    const renderTemplateList = (template: Template) => (
        <Card key={template.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
                <div className="flex items-center gap-4">
                    <Checkbox
                        checked={selectedTemplates.includes(template.id)}
                        onCheckedChange={(checked) => {
                            if (checked) {
                                setSelectedTemplates([...selectedTemplates, template.id]);
                            } else {
                                setSelectedTemplates(selectedTemplates.filter(id => id !== template.id));
                            }
                        }}
                    />

                    <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2 mb-1">
                                    <h3 className="font-semibold truncate">{template.name}</h3>
                                    {template.isFavorite && (
                                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                                    )}
                                    {template.isPublic ? (
                                        <Globe className="h-4 w-4 text-green-600" />
                                    ) : (
                                        <Lock className="h-4 w-4 text-gray-400" />
                                    )}
                                </div>
                                {template.description && (
                                    <p className="text-sm text-gray-600 line-clamp-1 mb-2">
                                        {template.description}
                                    </p>
                                )}
                                <div className="flex items-center gap-4">
                                    <Badge
                                        className={categoryColors[template.category as keyof typeof categoryColors] || categoryColors.Operations}
                                    >
                                        {template.category}
                                    </Badge>
                                    <Badge
                                        variant="outline"
                                        className={statusColors[template.status]}
                                    >
                                        {template.status}
                                    </Badge>
                                    <span className="text-xs text-gray-500">v{template.version}</span>
                                </div>
                            </div>

                            <div className="flex items-center gap-6 ml-4">
                                <div className="text-center">
                                    <div className="text-sm font-medium">{template.usageCount}</div>
                                    <div className="text-xs text-gray-500">Usage</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-sm font-medium">{template.analytics.completionRate.toFixed(1)}%</div>
                                    <div className="text-xs text-gray-500">Completion</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-sm font-medium">{formatTime(template.analytics.averageCompletionTime)}</div>
                                    <div className="text-xs text-gray-500">Avg. Time</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-sm font-medium">{formatDate(template.updatedAt)}</div>
                                    <div className="text-xs text-gray-500">Updated</div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Button size="sm" asChild>
                                        <Link to={`/templates/${template.id}/use`}>
                                            Use
                                        </Link>
                                    </Button>
                                    <Button variant="outline" size="sm" asChild>
                                        <Link to={`/templates/${template.id}`}>
                                            <Eye className="h-4 w-4" />
                                        </Link>
                                    </Button>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="sm">
                                                <MoreHorizontal className="h-4 w-4" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem onClick={() => handleTemplateAction('duplicate', template.id)}>
                                                <Copy className="mr-2 h-4 w-4" />
                                                Duplicate
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => handleTemplateAction('share', template.id)}>
                                                <Share className="mr-2 h-4 w-4" />
                                                Share
                                            </DropdownMenuItem>
                                            {template.permissions.canEdit && (
                                                <DropdownMenuItem asChild>
                                                    <Link to={`/templates/${template.id}/edit`}>
                                                        <Edit className="mr-2 h-4 w-4" />
                                                        Edit
                                                    </Link>
                                                </DropdownMenuItem>
                                            )}
                                            {template.permissions.canDelete && (
                                                <>
                                                    <Separator />
                                                    <DropdownMenuItem
                                                        className="text-red-600"
                                                        onClick={() => handleTemplateAction('delete', template.id)}
                                                    >
                                                        <Trash2 className="mr-2 h-4 w-4" />
                                                        Delete
                                                    </DropdownMenuItem>
                                                </>
                                            )}
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );

    return (
        <Layout user={user}>
            <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Template Management</h1>
                        <p className="text-gray-600 mt-1">Create, manage, and analyze your document templates with comprehensive insights</p>
                    </div>
                    <div className="mt-4 sm:mt-0 flex items-center gap-3">
                        <Button variant="outline" onClick={() => setShowAnalytics(true)}>
                            <BarChart3 className="mr-2 h-4 w-4" />
                            Analytics
                        </Button>
                        <Button asChild>
                            <Link to="/templates/create">
                                <Plus className="mr-2 h-4 w-4" />
                                Create Template
                            </Link>
                        </Button>
                    </div>
                </div>

                {/* Analytics Overview Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Folder className="h-8 w-8 text-blue-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Templates</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.totalTemplates}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <FileText className="h-8 w-8 text-green-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Usage</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.totalUsage}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <TrendingUp className="h-8 w-8 text-purple-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Avg. Completion</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.averageCompletionRate.toFixed(1)}%</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Star className="h-8 w-8 text-yellow-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Favorites</p>
                                    <p className="text-2xl font-bold text-gray-900">
                                        {templates.filter(t => t.isFavorite).length}
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Filters and Search */}
                <Card>
                    <CardContent className="p-4">
                        <div className="flex flex-col lg:flex-row gap-4">
                            <div className="flex-1">
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        placeholder="Search templates by name, description, or tags..."
                                        className="pl-10"
                                        value={filters.search}
                                        onChange={(e) => updateFilters({ search: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                <Select
                                    value={filters.category}
                                    onValueChange={(value) => updateFilters({ category: value })}
                                >
                                    <SelectTrigger className="w-[160px]">
                                        <SelectValue placeholder="Category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">All Categories</SelectItem>
                                        {categories.map(category => (
                                            <SelectItem key={category.name} value={category.name.toLowerCase()}>
                                                {category.name} ({category.count})
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <Select
                                    value={filters.sortBy}
                                    onValueChange={(value) => updateFilters({ sortBy: value })}
                                >
                                    <SelectTrigger className="w-[160px]">
                                        <SelectValue placeholder="Sort by" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="updatedAt">Recently Updated</SelectItem>
                                        <SelectItem value="createdAt">Recently Created</SelectItem>
                                        <SelectItem value="name">Name A-Z</SelectItem>
                                        <SelectItem value="usageCount">Most Used</SelectItem>
                                        <SelectItem value="completionRate">Best Performance</SelectItem>
                                    </SelectContent>
                                </Select>
                                <Button
                                    variant="outline"
                                    onClick={() => updateFilters({ sortOrder: filters.sortOrder === 'asc' ? 'desc' : 'asc' })}
                                >
                                    <ArrowUpDownIcon className="h-4 w-4" />
                                </Button>
                                <div className="flex items-center border rounded-md">
                                    <Button
                                        variant={viewMode === 'grid' ? 'default' : 'ghost'}
                                        size="sm"
                                        onClick={() => {
                                            setViewMode('grid');
                                            updateFilters({ view: 'grid' });
                                        }}
                                    >
                                        <LayoutGrid className="w-4 h-4" />
                                    </Button>
                                    <Button
                                        variant={viewMode === 'list' ? 'default' : 'ghost'}
                                        size="sm"
                                        onClick={() => {
                                            setViewMode('list');
                                            updateFilters({ view: 'list' });
                                        }}
                                    >
                                        <List className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Bulk Actions */}
                {selectedTemplates.length > 0 && (
                    <Card className="border-blue-200 bg-blue-50">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <span className="text-sm font-medium text-blue-900">
                                        {selectedTemplates.length} template(s) selected
                                    </span>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => setSelectedTemplates([])}
                                    >
                                        Clear Selection
                                    </Button>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => handleBulkAction('share')}
                                    >
                                        <Share className="mr-2 h-4 w-4" />
                                        Share
                                    </Button>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => handleBulkAction('export')}
                                    >
                                        <Download className="mr-2 h-4 w-4" />
                                        Export
                                    </Button>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => handleBulkAction('delete')}
                                        className="text-red-600 hover:text-red-700"
                                    >
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Delete
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Templates Grid/List */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600">
                            Showing {templates.length} of {totalTemplates} templates
                        </p>
                        {pagination.totalPages > 1 && (
                            <div className="flex items-center gap-2">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    disabled={!pagination.hasPrev}
                                    onClick={() => updateFilters({ page: (pagination.page - 1).toString() })}
                                >
                                    Previous
                                </Button>
                                <span className="text-sm text-gray-600">
                                    Page {pagination.page} of {pagination.totalPages}
                                </span>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    disabled={!pagination.hasNext}
                                    onClick={() => updateFilters({ page: (pagination.page + 1).toString() })}
                                >
                                    Next
                                </Button>
                            </div>
                        )}
                    </div>

                    {templates.length === 0 ? (
                        <Card>
                            <CardContent className="p-12 text-center">
                                <Folder className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No templates found</h3>
                                <p className="text-gray-600 mb-6">
                                    {filters.search || filters.category !== 'all'
                                        ? "Try adjusting your search criteria or filters."
                                        : "Create your first template to streamline your document workflows."
                                    }
                                </p>
                                <Button asChild>
                                    <Link to="/templates/create">
                                        <Plus className="mr-2 h-4 w-4" />
                                        Create Template
                                    </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    ) : viewMode === 'grid' ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {templates.map(renderTemplateCard)}
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {templates.map(renderTemplateList)}
                        </div>
                    )}
                </div>

                {/* Template Sharing Dialog */}
                <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
                    <DialogContent className="max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Share Template</DialogTitle>
                            <DialogDescription>
                                Configure sharing permissions and access controls for this template.
                            </DialogDescription>
                        </DialogHeader>
                        <TemplateShareForm
                            templateId={shareTemplateId}
                            onClose={() => setShowShareDialog(false)}
                        />
                    </DialogContent>
                </Dialog>

                {/* Analytics Dashboard Dialog */}
                <Dialog open={showAnalytics} onOpenChange={setShowAnalytics}>
                    <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Template Analytics Dashboard</DialogTitle>
                            <DialogDescription>
                                Comprehensive insights into your template performance and usage patterns.
                            </DialogDescription>
                        </DialogHeader>
                        <TemplateAnalyticsDashboard
                            analytics={analytics}
                            onClose={() => setShowAnalytics(false)}
                        />
                    </DialogContent>
                </Dialog>
            </div>
        </Layout>
    );
}

// Template Share Form Component
function TemplateShareForm({ templateId, onClose }: { templateId: string | null; onClose: () => void }) {
    const [shareType, setShareType] = useState<'internal' | 'external' | 'public'>('internal');
    const [permissions, setPermissions] = useState({
        canView: true,
        canUse: true,
        canDuplicate: false,
        canEdit: false,
        canShare: false,
    });
    const [expiresAt, setExpiresAt] = useState<string>('');
    const [message, setMessage] = useState('');
    const [recipients, setRecipients] = useState<string>('');
    const { toast } = useToast();

    const handleShare = async () => {
        try {
            // Handle template sharing logic here
            toast({
                title: "Template shared successfully",
                description: "The template has been shared with the specified recipients.",
            });
            onClose();
        } catch (error) {
            toast({
                title: "Error sharing template",
                description: "An error occurred while sharing the template.",
                variant: "destructive",
            });
        }
    };

    return (
        <div className="space-y-6">
            <Tabs value={shareType} onValueChange={(value) => setShareType(value as any)}>
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="internal">Internal</TabsTrigger>
                    <TabsTrigger value="external">External</TabsTrigger>
                    <TabsTrigger value="public">Public</TabsTrigger>
                </TabsList>

                <TabsContent value="internal" className="space-y-4">
                    <div>
                        <Label htmlFor="internal-recipients">Team Members</Label>
                        <Textarea
                            id="internal-recipients"
                            placeholder="Enter email addresses or select team members..."
                            value={recipients}
                            onChange={(e) => setRecipients(e.target.value)}
                        />
                    </div>
                </TabsContent>

                <TabsContent value="external" className="space-y-4">
                    <div>
                        <Label htmlFor="external-recipients">External Recipients</Label>
                        <Textarea
                            id="external-recipients"
                            placeholder="Enter email addresses separated by commas..."
                            value={recipients}
                            onChange={(e) => setRecipients(e.target.value)}
                        />
                    </div>
                    <div>
                        <Label htmlFor="expiration">Expiration Date</Label>
                        <Input
                            id="expiration"
                            type="datetime-local"
                            value={expiresAt}
                            onChange={(e) => setExpiresAt(e.target.value)}
                        />
                    </div>
                </TabsContent>

                <TabsContent value="public" className="space-y-4">
                    <Alert>
                        <Info className="h-4 w-4" />
                        <AlertDescription>
                            Making this template public will allow anyone with the link to view and use it.
                        </AlertDescription>
                    </Alert>
                </TabsContent>
            </Tabs>

            {/* Permissions */}
            <div className="space-y-4">
                <Label>Permissions</Label>
                <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="can-view"
                            checked={permissions.canView}
                            onCheckedChange={(checked) => setPermissions({ ...permissions, canView: checked })}
                        />
                        <Label htmlFor="can-view">Can View</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="can-use"
                            checked={permissions.canUse}
                            onCheckedChange={(checked) => setPermissions({ ...permissions, canUse: checked })}
                        />
                        <Label htmlFor="can-use">Can Use</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="can-duplicate"
                            checked={permissions.canDuplicate}
                            onCheckedChange={(checked) => setPermissions({ ...permissions, canDuplicate: checked })}
                        />
                        <Label htmlFor="can-duplicate">Can Duplicate</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="can-edit"
                            checked={permissions.canEdit}
                            onCheckedChange={(checked) => setPermissions({ ...permissions, canEdit: checked })}
                        />
                        <Label htmlFor="can-edit">Can Edit</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="can-share"
                            checked={permissions.canShare}
                            onCheckedChange={(checked) => setPermissions({ ...permissions, canShare: checked })}
                        />
                        <Label htmlFor="can-share">Can Share</Label>
                    </div>
                </div>
            </div>

            {/* Message */}
            <div>
                <Label htmlFor="share-message">Message (Optional)</Label>
                <Textarea
                    id="share-message"
                    placeholder="Add a message for the recipients..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                />
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={onClose}>
                    Cancel
                </Button>
                <Button onClick={handleShare}>
                    Share Template
                </Button>
            </div>
        </div>
    );
}

// Template Analytics Dashboard Component
function TemplateAnalyticsDashboard({ analytics, onClose }: { analytics: TemplateAnalytics; onClose: () => void }) {
    return (
        <div className="space-y-6">
            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                    <CardContent className="p-6 text-center">
                        <div className="text-3xl font-bold text-green-600 mb-2">
                            ${analytics.performanceMetrics.totalSavings.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-600">Total Cost Savings</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6 text-center">
                        <div className="text-3xl font-bold text-blue-600 mb-2">
                            {analytics.performanceMetrics.timeReduction}%
                        </div>
                        <div className="text-sm text-gray-600">Time Reduction</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6 text-center">
                        <div className="text-3xl font-bold text-purple-600 mb-2">
                            {analytics.performanceMetrics.errorReduction}%
                        </div>
                        <div className="text-sm text-gray-600">Error Reduction</div>
                    </CardContent>
                </Card>
            </div>

            {/* Top Performing Templates */}
            <Card>
                <CardHeader>
                    <CardTitle>Top Performing Templates</CardTitle>
                    <CardDescription>Templates with the highest completion rates and usage</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {analytics.topPerformingTemplates.map((template, index) => (
                            <div key={template.id} className="flex items-center justify-between p-3 border rounded-lg">
                                <div className="flex items-center space-x-3">
                                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-sm font-medium text-blue-600">
                                        {index + 1}
                                    </div>
                                    <div>
                                        <div className="font-medium">{template.name}</div>
                                        <div className="text-sm text-gray-600">{template.usageCount} uses</div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="font-medium">{template.completionRate.toFixed(1)}%</div>
                                    <div className="text-sm text-gray-600">completion rate</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Usage by Category */}
            <Card>
                <CardHeader>
                    <CardTitle>Usage by Category</CardTitle>
                    <CardDescription>Distribution of template usage across categories</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {analytics.usageByCategory.map((category) => (
                            <div key={category.category} className="space-y-2">
                                <div className="flex justify-between text-sm">
                                    <span className="font-medium">{category.category}</span>
                                    <span>{category.count} uses ({category.percentage.toFixed(1)}%)</span>
                                </div>
                                <Progress value={category.percentage} className="h-2" />
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
                <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Latest template actions and usage</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {analytics.recentActivity.map((activity) => (
                            <div key={activity.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                                <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                                <div className="flex-1">
                                    <div className="text-sm">
                                        <span className="font-medium">{activity.user}</span>
                                        <span className="text-gray-600"> {activity.action.toLowerCase()} </span>
                                        <span className="font-medium">{activity.templateName}</span>
                                    </div>
                                    <div className="text-xs text-gray-500">
                                        {new Date(activity.timestamp).toLocaleString()}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Close Button */}
            <div className="flex justify-end">
                <Button onClick={onClose}>
                    Close
                </Button>
            </div>
        </div>
    );
}