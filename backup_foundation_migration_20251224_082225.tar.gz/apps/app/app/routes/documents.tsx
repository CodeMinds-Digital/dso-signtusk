import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link, useSearchParams, useNavigate } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { trpc } from "~/lib/trpc";
import { useState, useCallback, useEffect } from "react";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Input,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DocumentList,
    DocumentPreviewModal,
    FolderBreadcrumbs,
    FolderTree,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    Checkbox,
    Separator,
    ScrollArea,
    Toast,
    useToast,
} from "@docusign-alternative/ui";
import {
    FileText,
    Search,
    Filter,
    Upload,
    MoreHorizontal,
    Download,
    Share,
    Edit,
    Trash2,
    Eye,
    Clock,
    CheckCircle,
    XCircle,
    AlertCircle,
    Grid3X3,
    List,
    FolderOpen,
    Plus,
    SortAsc,
    SortDesc,
    RefreshCw,
    Settings,
    LayoutGrid,
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Documents - DocuSign Alternative" },
        { name: "description", content: "Manage your documents" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
    });
}

export default function Documents() {
    const { user } = useLoaderData<typeof loader>();
    const [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate();
    const { toast } = useToast();

    // State management
    const [viewMode, setViewMode] = useState<'list' | 'grid' | 'table'>('list');
    const [selectedDocuments, setSelectedDocuments] = useState<string[]>([]);
    const [selectedDocument, setSelectedDocument] = useState<any>(null);
    const [showPreviewModal, setShowPreviewModal] = useState(false);
    const [showBulkActionDialog, setShowBulkActionDialog] = useState(false);
    const [bulkAction, setBulkAction] = useState<string>('');
    const [currentFolderId, setCurrentFolderId] = useState<string | null>(
        searchParams.get('folder') || null
    );
    const [expandedFolderIds, setExpandedFolderIds] = useState<string[]>([]);
    const [showSidebar, setShowSidebar] = useState(true);

    // Search and filter state
    const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
    const [statusFilter, setStatusFilter] = useState(searchParams.get('status') || 'all');
    const [sortBy, setSortBy] = useState(searchParams.get('sortBy') || 'createdAt');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(
        (searchParams.get('sortOrder') as 'asc' | 'desc') || 'desc'
    );

    // tRPC queries
    const { data: documentsData, isLoading: documentsLoading, error: documentsError, refetch: refetchDocuments } =
        trpc.document.list.useQuery({
            search: searchQuery || undefined,
            status: statusFilter !== 'all' ? [statusFilter as any] : undefined,
            folderId: currentFolderId || undefined,
            sortBy: sortBy as any,
            sortOrder,
            limit: 50,
        });

    const { data: foldersData, isLoading: foldersLoading } = trpc.folder.getHierarchy.useQuery({
        rootFolderId: undefined,
        maxDepth: 5,
        includeDocumentCounts: true,
        expandedFolderIds,
    });

    const { data: breadcrumbsData } = trpc.folder.get.useQuery(
        { folderId: currentFolderId!, includeAncestors: true },
        { enabled: !!currentFolderId }
    );

    const { mutate: bulkOperationMutate } = trpc.document.bulkOperation.useMutation({
        onSuccess: (data) => {
            toast({
                title: "Bulk operation completed",
                description: `${data.summary.successful} documents processed successfully`,
            });
            setSelectedDocuments([]);
            setShowBulkActionDialog(false);
            refetchDocuments();
        },
        onError: (error) => {
            toast({
                title: "Bulk operation failed",
                description: error.message,
                variant: "destructive",
            });
        },
    });

    const documents = documentsData?.documents || [];
    const folders = foldersData?.hierarchy || [];
    const breadcrumbs = breadcrumbsData?.ancestors || [];

    // Update URL when filters change
    useEffect(() => {
        const params = new URLSearchParams();
        if (searchQuery) params.set('search', searchQuery);
        if (statusFilter !== 'all') params.set('status', statusFilter);
        if (currentFolderId) params.set('folder', currentFolderId);
        if (sortBy !== 'createdAt') params.set('sortBy', sortBy);
        if (sortOrder !== 'desc') params.set('sortOrder', sortOrder);

        setSearchParams(params, { replace: true });
    }, [searchQuery, statusFilter, currentFolderId, sortBy, sortOrder, setSearchParams]);

    // Event handlers
    const handleDocumentSelect = useCallback((documentId: string, selected: boolean) => {
        setSelectedDocuments(prev =>
            selected
                ? [...prev, documentId]
                : prev.filter(id => id !== documentId)
        );
    }, []);

    const handleSelectAll = useCallback((selected: boolean) => {
        setSelectedDocuments(selected ? documents.map(d => d.id) : []);
    }, [documents]);

    const handleDocumentAction = useCallback(async (action: string, documentId: string) => {
        switch (action) {
            case 'VIEW':
                // Fetch detailed document data and show preview
                const document = documents.find(d => d.id === documentId);
                if (document) {
                    setSelectedDocument(document);
                    setShowPreviewModal(true);
                }
                break;
            case 'EDIT':
                navigate(`/documents/${documentId}/edit`);
                break;
            case 'DOWNLOAD':
                // Implement download logic
                toast({ title: "Download started", description: "Document download initiated" });
                break;
            case 'SHARE':
                // Implement share logic
                toast({ title: "Share dialog", description: "Share functionality coming soon" });
                break;
            case 'DELETE':
                // Implement delete logic
                if (confirm('Are you sure you want to delete this document?')) {
                    toast({ title: "Document deleted", description: "Document has been deleted" });
                    refetchDocuments();
                }
                break;
            default:
                console.log('Unknown action:', action);
        }
    }, [documents, navigate, toast, refetchDocuments]);

    const handleBulkAction = useCallback((action: string, documentIds: string[]) => {
        setBulkAction(action);
        setShowBulkActionDialog(true);
    }, []);

    const executeBulkAction = useCallback(() => {
        if (!bulkAction || selectedDocuments.length === 0) return;

        bulkOperationMutate({
            operation: bulkAction as any,
            documentIds: selectedDocuments,
            options: {
                continueOnError: true,
                notifyOnCompletion: true,
            },
        });
    }, [bulkAction, selectedDocuments, bulkOperationMutate]);

    const handleFolderSelect = useCallback((folderId: string | null) => {
        setCurrentFolderId(folderId);
        setSelectedDocuments([]);
    }, []);

    const handleFolderExpand = useCallback((folderId: string, expanded: boolean) => {
        setExpandedFolderIds(prev =>
            expanded
                ? [...prev, folderId]
                : prev.filter(id => id !== folderId)
        );
    }, []);

    const handleSearch = useCallback((query: string) => {
        setSearchQuery(query);
    }, []);

    const handleSortChange = useCallback((newSortBy: string) => {
        if (newSortBy === sortBy) {
            setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
        } else {
            setSortBy(newSortBy);
            setSortOrder('desc');
        }
    }, [sortBy]);

    return (
        <Layout user={user}>
            <div className="flex h-screen overflow-hidden">
                {/* Sidebar */}
                {showSidebar && (
                    <div className="w-80 border-r bg-gray-50 flex flex-col">
                        <div className="p-4 border-b">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-semibold">Folders</h2>
                                <Button variant="ghost" size="sm">
                                    <Plus className="h-4 w-4" />
                                </Button>
                            </div>
                        </div>

                        <ScrollArea className="flex-1 p-4">
                            <FolderTree
                                folders={folders}
                                selectedFolderId={currentFolderId}
                                expandedFolderIds={expandedFolderIds}
                                onFolderSelect={handleFolderSelect}
                                onFolderExpand={handleFolderExpand}
                                showDocumentCounts={true}
                                showActions={true}
                            />
                        </ScrollArea>
                    </div>
                )}

                {/* Main Content */}
                <div className="flex-1 flex flex-col overflow-hidden">
                    {/* Header */}
                    <div className="border-b bg-white p-6">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                            <div className="flex items-center space-x-4">
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setShowSidebar(!showSidebar)}
                                >
                                    <FolderOpen className="h-4 w-4" />
                                </Button>
                                <div>
                                    <h1 className="text-2xl font-bold text-gray-900">Documents</h1>
                                    <p className="text-gray-600">Manage and track your document signing workflows</p>
                                </div>
                            </div>
                            <div className="mt-4 sm:mt-0 flex items-center space-x-2">
                                <Button variant="outline" size="sm" onClick={() => refetchDocuments()}>
                                    <RefreshCw className="mr-1 h-4 w-4" />
                                    Refresh
                                </Button>
                                <Button asChild>
                                    <Link to="/upload">
                                        <Upload className="mr-2 h-4 w-4" />
                                        Upload Document
                                    </Link>
                                </Button>
                            </div>
                        </div>

                        {/* Breadcrumbs */}
                        {breadcrumbs.length > 0 && (
                            <FolderBreadcrumbs
                                items={breadcrumbs}
                                onNavigate={handleFolderSelect}
                                className="mb-4"
                            />
                        )}

                        {/* Search and Filters */}
                        <Card>
                            <CardContent className="p-4">
                                <div className="flex flex-col lg:flex-row gap-4">
                                    <div className="flex-1">
                                        <div className="relative">
                                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                            <Input
                                                placeholder="Search documents..."
                                                className="pl-10"
                                                value={searchQuery}
                                                onChange={(e) => handleSearch(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                                            <SelectTrigger className="w-[140px]">
                                                <SelectValue placeholder="Status" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="all">All Status</SelectItem>
                                                <SelectItem value="DRAFT">Draft</SelectItem>
                                                <SelectItem value="PENDING">Pending</SelectItem>
                                                <SelectItem value="COMPLETED">Completed</SelectItem>
                                                <SelectItem value="EXPIRED">Expired</SelectItem>
                                                <SelectItem value="CANCELLED">Cancelled</SelectItem>
                                            </SelectContent>
                                        </Select>

                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="outline" size="sm">
                                                    {sortOrder === 'asc' ? <SortAsc className="mr-1 h-4 w-4" /> : <SortDesc className="mr-1 h-4 w-4" />}
                                                    Sort
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent>
                                                <DropdownMenuItem onClick={() => handleSortChange('name')}>
                                                    Name {sortBy === 'name' && (sortOrder === 'asc' ? '↑' : '↓')}
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleSortChange('createdAt')}>
                                                    Created {sortBy === 'createdAt' && (sortOrder === 'asc' ? '↑' : '↓')}
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleSortChange('updatedAt')}>
                                                    Modified {sortBy === 'updatedAt' && (sortOrder === 'asc' ? '↑' : '↓')}
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleSortChange('size')}>
                                                    Size {sortBy === 'size' && (sortOrder === 'asc' ? '↑' : '↓')}
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleSortChange('status')}>
                                                    Status {sortBy === 'status' && (sortOrder === 'asc' ? '↑' : '↓')}
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>

                                        <div className="flex border rounded-md">
                                            <Button
                                                variant={viewMode === 'list' ? 'default' : 'ghost'}
                                                size="sm"
                                                onClick={() => setViewMode('list')}
                                                className="rounded-r-none"
                                            >
                                                <List className="h-4 w-4" />
                                            </Button>
                                            <Button
                                                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                                                size="sm"
                                                onClick={() => setViewMode('grid')}
                                                className="rounded-none border-l"
                                            >
                                                <Grid3X3 className="h-4 w-4" />
                                            </Button>
                                            <Button
                                                variant={viewMode === 'table' ? 'default' : 'ghost'}
                                                size="sm"
                                                onClick={() => setViewMode('table')}
                                                className="rounded-l-none border-l"
                                            >
                                                <LayoutGrid className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Document List */}
                    <div className="flex-1 overflow-auto p-6">
                        {documentsError ? (
                            <Card>
                                <CardContent className="p-12 text-center">
                                    <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
                                    <h3 className="text-lg font-medium text-gray-900 mb-2">Error loading documents</h3>
                                    <p className="text-gray-600 mb-6">
                                        {documentsError.message || "Failed to load documents. Please try again."}
                                    </p>
                                    <Button onClick={() => refetchDocuments()}>
                                        Try Again
                                    </Button>
                                </CardContent>
                            </Card>
                        ) : documents.length === 0 && !documentsLoading ? (
                            <Card>
                                <CardContent className="p-12 text-center">
                                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                                        {searchQuery || statusFilter !== 'all' ? 'No documents found' : 'No documents yet'}
                                    </h3>
                                    <p className="text-gray-600 mb-6">
                                        {searchQuery || statusFilter !== 'all'
                                            ? 'Try adjusting your search or filter criteria.'
                                            : 'Get started by uploading your first document for signing.'
                                        }
                                    </p>
                                    {!searchQuery && statusFilter === 'all' && (
                                        <Button asChild>
                                            <Link to="/upload">
                                                <Upload className="mr-2 h-4 w-4" />
                                                Upload Document
                                            </Link>
                                        </Button>
                                    )}
                                </CardContent>
                            </Card>
                        ) : (
                            <DocumentList
                                documents={documents}
                                viewMode={viewMode}
                                selectedDocuments={selectedDocuments}
                                onDocumentSelect={handleDocumentSelect}
                                onSelectAll={handleSelectAll}
                                onDocumentAction={handleDocumentAction}
                                onBulkAction={handleBulkAction}
                                isLoading={documentsLoading}
                                filters={{
                                    search: searchQuery,
                                    status: statusFilter !== 'all' ? [statusFilter] : [],
                                }}
                                sortBy={sortBy}
                                sortOrder={sortOrder}
                                onSortChange={(field, order) => {
                                    setSortBy(field);
                                    setSortOrder(order);
                                }}
                                pagination={{
                                    current: 1,
                                    pageSize: 50,
                                    total: documentsData?.total || 0,
                                    onChange: (page, pageSize) => {
                                        // Handle pagination change
                                        console.log('Pagination change:', page, pageSize);
                                    }
                                }}
                            />
                        )}
                    </div>
                </div>
            </div>

            {/* Document Preview Modal */}
            <DocumentPreviewModal
                document={selectedDocument}
                isOpen={showPreviewModal}
                onClose={() => {
                    setShowPreviewModal(false);
                    setSelectedDocument(null);
                }}
                onAction={handleDocumentAction}
            />

            {/* Bulk Action Confirmation Dialog */}
            <Dialog open={showBulkActionDialog} onOpenChange={setShowBulkActionDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Bulk Action</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to {bulkAction.toLowerCase()} {selectedDocuments.length} document{selectedDocuments.length !== 1 ? 's' : ''}?
                        </DialogDescription>
                    </DialogHeader>
                    <div className="flex justify-end space-x-2 mt-4">
                        <Button variant="outline" onClick={() => setShowBulkActionDialog(false)}>
                            Cancel
                        </Button>
                        <Button onClick={executeBulkAction}>
                            Confirm
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </Layout>
    );
}