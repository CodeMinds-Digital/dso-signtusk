import React, { useState, useCallback } from 'react';
import { json, type LoaderFunctionArgs, type MetaFunction } from '@remix-run/node';
import { useLoaderData, Outlet, useNavigate, Link, useLocation } from '@remix-run/react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Calendar,
    Popover,
    PopoverContent,
    PopoverTrigger,
    StatisticCard,
    BarChart,
    LineChart,
    PieChart,
    AreaChart,
    DataTable,
    Container,
    Grid,
    Flex,
} from "@docusign-alternative/ui";
import {
    CalendarIcon,
    Download,
    Share,
    Filter,
    RefreshCw,
    Settings,
    BarChart3,
    TrendingUp,
    Users,
    FileText,
    Clock,
    Activity,
    PieChart as PieChartIcon,
    Target,
    DollarSign,
    Zap,
    Layout,
    Plus,
} from "@docusign-alternative/ui";
import { trpc } from '~/lib/trpc';
import { requireAuth } from '~/lib/session.server';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';

export const meta: MetaFunction = () => {
    return [
        { title: "Analytics Dashboard - DocuSign Alternative" },
        { name: "description", content: "Comprehensive analytics and reporting dashboard" },
    ];
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
    const user = await requireAuth(request);
    return json({ user });
};

interface DateRange {
    from: Date;
    to: Date;
}

export default function AnalyticsDashboard() {
    const { user } = useLoaderData<typeof loader>();
    const navigate = useNavigate();

    // State for date range and filters
    const [dateRange, setDateRange] = useState<DateRange>({
        from: subDays(new Date(), 30),
        to: new Date(),
    });
    const [activeTab, setActiveTab] = useState('overview');
    const [isRefreshing, setIsRefreshing] = useState(false);

    // tRPC queries
    const { data: dashboardData, refetch: refetchDashboard, isLoading: isDashboardLoading } = trpc.analytics.getDashboardOverview.useQuery({
        timeRange: {
            startDate: startOfDay(dateRange.from).toISOString(),
            endDate: endOfDay(dateRange.to).toISOString(),
        },
    });

    const { data: usageData, isLoading: isUsageLoading } = trpc.analytics.getUsageAnalytics.useQuery({
        timeRange: {
            startDate: startOfDay(dateRange.from).toISOString(),
            endDate: endOfDay(dateRange.to).toISOString(),
        },
        granularity: 'day',
    });

    const { data: teamData, isLoading: isTeamLoading } = trpc.analytics.getTeamPerformance.useQuery({
        timeRange: {
            startDate: startOfDay(dateRange.from).toISOString(),
            endDate: endOfDay(dateRange.to).toISOString(),
        },
    });

    const { data: documentData, isLoading: isDocumentLoading } = trpc.analytics.getDocumentAnalytics.useQuery({
        timeRange: {
            startDate: startOfDay(dateRange.from).toISOString(),
            endDate: endOfDay(dateRange.to).toISOString(),
        },
    });

    // Export mutation
    const exportMutation = trpc.analytics.exportData.useMutation({
        onSuccess: (data) => {
            // Handle export success
            console.log('Export started:', data);
        },
    });

    const handleRefresh = useCallback(async () => {
        setIsRefreshing(true);
        await refetchDashboard();
        setIsRefreshing(false);
    }, [refetchDashboard]);

    const handleExport = useCallback((format: 'csv' | 'xlsx' | 'pdf') => {
        exportMutation.mutate({
            reportType: 'dashboard',
            format,
            timeRange: {
                startDate: startOfDay(dateRange.from).toISOString(),
                endDate: endOfDay(dateRange.to).toISOString(),
            },
            includeCharts: format === 'pdf',
        });
    }, [dateRange, exportMutation]);

    const formatDateRange = (range: DateRange) => {
        return `${format(range.from, 'MMM dd, yyyy')} - ${format(range.to, 'MMM dd, yyyy')}`;
    };

    return (
        <Container className="py-6">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
                        <p className="text-gray-600 mt-1">
                            Comprehensive insights and performance metrics for your organization
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <Button
                            variant="outline"
                            onClick={handleRefresh}
                            disabled={isRefreshing}
                        >
                            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                            Refresh
                        </Button>
                        <Select onValueChange={(value) => handleExport(value as 'csv' | 'xlsx' | 'pdf')}>
                            <SelectTrigger className="w-32">
                                <Download className="h-4 w-4 mr-2" />
                                <SelectValue placeholder="Export" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="csv">CSV</SelectItem>
                                <SelectItem value="xlsx">Excel</SelectItem>
                                <SelectItem value="pdf">PDF</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                {/* Navigation Tabs */}
                <div className="flex items-center gap-4 mb-6">
                    <Link
                        to="/analytics"
                        className={`px-4 py-2 rounded-lg font-medium transition-colors ${location.pathname === '/analytics'
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            }`}
                    >
                        <BarChart3 className="h-4 w-4 mr-2 inline" />
                        Overview
                    </Link>
                    <Link
                        to="/analytics/dashboard"
                        className={`px-4 py-2 rounded-lg font-medium transition-colors ${location.pathname === '/analytics/dashboard'
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            }`}
                    >
                        <Layout className="h-4 w-4 mr-2 inline" />
                        Interactive Dashboard
                    </Link>
                    <Link
                        to="/analytics/reports"
                        className={`px-4 py-2 rounded-lg font-medium transition-colors ${location.pathname === '/analytics/reports'
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            }`}
                    >
                        <FileText className="h-4 w-4 mr-2 inline" />
                        Custom Reports
                    </Link>
                </div>

                {/* Show date range selector only on main analytics page */}
                {location.pathname === '/analytics' && (
                    <div className="flex items-center gap-4">
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="w-80 justify-start text-left font-normal">
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {formatDateRange(dateRange)}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                    mode="range"
                                    selected={{ from: dateRange.from, to: dateRange.to }}
                                    onSelect={(range) => {
                                        if (range?.from && range?.to) {
                                            setDateRange({ from: range.from, to: range.to });
                                        }
                                    }}
                                    numberOfMonths={2}
                                />
                            </PopoverContent>
                        </Popover>
                        <div className="flex gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setDateRange({
                                    from: subDays(new Date(), 7),
                                    to: new Date(),
                                })}
                            >
                                Last 7 days
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setDateRange({
                                    from: subDays(new Date(), 30),
                                    to: new Date(),
                                })}
                            >
                                Last 30 days
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setDateRange({
                                    from: subDays(new Date(), 90),
                                    to: new Date(),
                                })}
                            >
                                Last 90 days
                            </Button>
                        </div>
                    </div>
                )}
            </div>

            {/* Render sub-routes or main content */}
            {location.pathname !== '/analytics' ? (
                <Outlet />
            ) : (
                /* Main Content */
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
                        <TabsTrigger value="performance">Team Performance</TabsTrigger>
                        <TabsTrigger value="documents">Document Analytics</TabsTrigger>
                    </TabsList>

                    {/* Overview Tab */}
                    <TabsContent value="overview" className="space-y-6">
                        {/* Key Metrics */}
                        <Grid cols={4} gap={6}>
                            <StatisticCard
                                title="Total Users"
                                value={dashboardData?.metrics.totalUsers || 0}
                                change={{
                                    value: dashboardData?.metrics.monthlyGrowthRate || 0,
                                    type: 'increase',
                                    period: 'vs last month',
                                }}
                                icon={<Users className="h-5 w-5 text-blue-600" />}
                            />
                            <StatisticCard
                                title="Active Users"
                                value={dashboardData?.metrics.activeUsers || 0}
                                change={{
                                    value: 8.2,
                                    type: 'increase',
                                    period: 'vs last month',
                                }}
                                icon={<Activity className="h-5 w-5 text-green-600" />}
                            />
                            <StatisticCard
                                title="Documents Completed"
                                value={dashboardData?.metrics.documentsCompleted || 0}
                                change={{
                                    value: dashboardData?.metrics.completionRate || 0,
                                    type: 'increase',
                                    period: 'completion rate',
                                }}
                                icon={<FileText className="h-5 w-5 text-purple-600" />}
                            />
                            <StatisticCard
                                title="Avg. Completion Time"
                                value={`${dashboardData?.metrics.averageTimeToComplete || 0}h`}
                                change={{
                                    value: 15.3,
                                    type: 'decrease',
                                    period: 'vs last month',
                                }}
                                icon={<Clock className="h-5 w-5 text-orange-600" />}
                            />
                        </Grid>

                        {/* Charts */}
                        <Grid cols={2} gap={6}>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Document Activity Trends</CardTitle>
                                    <CardDescription>
                                        Daily document creation and completion over time
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <LineChart
                                        data={dashboardData?.trends.documentsCreated.map(item => ({
                                            date: format(new Date(item.date), 'MMM dd'),
                                            created: item.value,
                                        })) || []}
                                        height={300}
                                        color="#3b82f6"
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Signing Activity</CardTitle>
                                    <CardDescription>
                                        Signing requests vs completions
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <BarChart
                                        data={dashboardData?.trends.signingActivity.map(item => ({
                                            date: format(new Date(item.date), 'MMM dd'),
                                            requested: item.requested,
                                            completed: item.completed,
                                        })) || []}
                                        height={300}
                                    />
                                </CardContent>
                            </Card>
                        </Grid>

                        {/* User Activity Chart */}
                        <Card>
                            <CardHeader>
                                <CardTitle>User Activity Overview</CardTitle>
                                <CardDescription>
                                    Daily active users and engagement patterns
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <AreaChart
                                    data={dashboardData?.trends.userActivity.map(item => ({
                                        date: format(new Date(item.date), 'MMM dd'),
                                        activeUsers: item.activeUsers,
                                    })) || []}
                                    height={300}
                                    color="#10b981"
                                />
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Usage Analytics Tab */}
                    <TabsContent value="usage" className="space-y-6">
                        <Grid cols={3} gap={6}>
                            <StatisticCard
                                title="API Calls"
                                value={usageData?.metrics.apiCalls || 0}
                                icon={<Zap className="h-5 w-5 text-yellow-600" />}
                            />
                            <StatisticCard
                                title="Storage Used"
                                value={`${((usageData?.metrics.storageUsed || 0) / (1024 ** 3)).toFixed(1)} GB`}
                                icon={<Target className="h-5 w-5 text-indigo-600" />}
                            />
                            <StatisticCard
                                title="Webhook Deliveries"
                                value={usageData?.metrics.webhookDeliveries || 0}
                                icon={<Activity className="h-5 w-5 text-pink-600" />}
                            />
                        </Grid>

                        <Grid cols={2} gap={6}>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Documents by Status</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <PieChart
                                        data={usageData?.breakdown.documentsByStatus.map(item => ({
                                            name: item.status,
                                            value: item.count,
                                        })) || []}
                                        showLegend={true}
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Top Templates</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {usageData?.breakdown.topTemplates.map((template, index) => (
                                            <div key={template.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                                <div className="flex items-center gap-3">
                                                    <Badge variant="outline">{index + 1}</Badge>
                                                    <span className="font-medium">{template.name}</span>
                                                </div>
                                                <span className="text-sm text-gray-600">{template.usage} uses</span>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </Grid>
                    </TabsContent>

                    {/* Team Performance Tab */}
                    <TabsContent value="performance" className="space-y-6">
                        <Grid cols={3} gap={6}>
                            <StatisticCard
                                title="Avg. Completion Rate"
                                value={`${teamData?.organizationAverages.averageCompletionRate || 0}%`}
                                icon={<Target className="h-5 w-5 text-green-600" />}
                            />
                            <StatisticCard
                                title="Avg. Completion Time"
                                value={`${teamData?.organizationAverages.averageCompletionTime || 0}h`}
                                icon={<Clock className="h-5 w-5 text-blue-600" />}
                            />
                            <StatisticCard
                                title="Avg. Documents/Team"
                                value={teamData?.organizationAverages.averageDocumentsPerTeam || 0}
                                icon={<FileText className="h-5 w-5 text-purple-600" />}
                            />
                        </Grid>

                        <Card>
                            <CardHeader>
                                <CardTitle>Team Performance Comparison</CardTitle>
                                <CardDescription>
                                    Performance metrics across all teams
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <DataTable
                                    columns={[
                                        { key: 'teamName', title: 'Team Name' },
                                        { key: 'memberCount', title: 'Members' },
                                        { key: 'documentsCompleted', title: 'Documents Completed' },
                                        { key: 'completionRate', title: 'Completion Rate', render: (value) => `${value}%` },
                                        { key: 'averageCompletionTime', title: 'Avg. Time', render: (value) => `${value}h` },
                                    ]}
                                    data={teamData?.teams.map(team => ({
                                        teamName: team.teamName,
                                        memberCount: team.memberCount,
                                        documentsCompleted: team.metrics.documentsCompleted,
                                        completionRate: team.metrics.completionRate,
                                        averageCompletionTime: team.metrics.averageCompletionTime,
                                    })) || []}
                                />
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Document Analytics Tab */}
                    <TabsContent value="documents" className="space-y-6">
                        <Grid cols={4} gap={6}>
                            <StatisticCard
                                title="Total Documents"
                                value={documentData?.summary.totalDocuments || 0}
                                icon={<FileText className="h-5 w-5 text-blue-600" />}
                            />
                            <StatisticCard
                                title="Completed"
                                value={documentData?.summary.completedDocuments || 0}
                                icon={<Target className="h-5 w-5 text-green-600" />}
                            />
                            <StatisticCard
                                title="Pending"
                                value={documentData?.summary.pendingDocuments || 0}
                                icon={<Clock className="h-5 w-5 text-yellow-600" />}
                            />
                            <StatisticCard
                                title="Drafts"
                                value={documentData?.summary.draftDocuments || 0}
                                icon={<FileText className="h-5 w-5 text-gray-600" />}
                            />
                        </Grid>

                        <Grid cols={2} gap={6}>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Document Activity Trends</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <LineChart
                                        data={documentData?.trends.daily.map(item => ({
                                            date: format(new Date(item.date), 'MMM dd'),
                                            created: item.created,
                                            completed: item.completed,
                                        })) || []}
                                        height={300}
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Completion Time Distribution</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <PieChart
                                        data={documentData?.completionTimeDistribution.map(item => ({
                                            name: item.range,
                                            value: item.count,
                                        })) || []}
                                        showLegend={true}
                                    />
                                </CardContent>
                            </Card>
                        </Grid>
                    </TabsContent>
                </Tabs>
            )}
        </Container>
    );
}