import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasError, hasSuccess } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Textarea,
    Avatar,
    AvatarFallback,
    Badge,
    Separator,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    AvatarUpload,
    APITokenManagement,
    NotificationPreferences,
} from "@docusign-alternative/ui";
import {
    User,
    Mail,
    Phone,
    MapPin,
    Building,
    Calendar,
    Shield,
    Key,
    Bell,
    Smartphone,
    Upload
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Profile - DocuSign Alternative" },
        { name: "description", content: "Manage your profile and account settings" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    // Mock user profile data - in real implementation, fetch from database
    const userProfile = {
        id: userSession.userId,
        email: "user@example.com",
        firstName: "John",
        lastName: "Doe",
        phone: "+1 (555) 123-4567",
        title: "Senior Manager",
        department: "Human Resources",
        company: "Acme Corporation",
        address: "123 Business St, Suite 100",
        city: "San Francisco",
        state: "CA",
        zipCode: "94105",
        country: "United States",
        bio: "Experienced HR professional with over 10 years in talent acquisition and employee relations.",
        joinedAt: "2023-06-15T10:30:00Z",
        lastLoginAt: "2024-01-17T09:15:00Z",
        twoFactorEnabled: true,
        emailNotifications: true,
        smsNotifications: false,
        organizationId: userSession.organizationId,
        roles: userSession.roles,
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        userProfile,
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();
    const intent = formData.get("intent");

    if (intent === "updateProfile") {
        const firstName = formData.get("firstName");
        const lastName = formData.get("lastName");
        const phone = formData.get("phone");
        const title = formData.get("title");
        const department = formData.get("department");
        const bio = formData.get("bio");

        // Validate required fields
        if (!firstName || !lastName) {
            return json(
                { error: "First name and last name are required" },
                { status: 400 }
            );
        }

        // In real implementation, update user profile in database
        return json({ success: "Profile updated successfully" });
    }

    if (intent === "updateAvatar") {
        // In real implementation, handle avatar upload
        return json({ success: "Avatar updated successfully" });
    }

    if (intent === "removeAvatar") {
        // In real implementation, remove avatar from storage
        return json({ success: "Avatar removed successfully" });
    }

    if (intent === "updateNotifications") {
        const emailNotifications = formData.get("emailNotifications") === "on";
        const smsNotifications = formData.get("smsNotifications") === "on";

        // In real implementation, update notification preferences
        return json({ success: "Notification preferences updated" });
    }

    return json({ error: "Invalid action" }, { status: 400 });
}

export default function Profile() {
    const { user, userProfile } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const getUserInitials = (firstName: string, lastName: string) => {
        return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
        });
    };

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900">Profile</h1>
                    <p className="text-gray-600">Manage your account information and preferences</p>
                </div>

                <Tabs defaultValue="profile" className="space-y-6">
                    <TabsList>
                        <TabsTrigger value="profile">Profile</TabsTrigger>
                        <TabsTrigger value="security">Security</TabsTrigger>
                        <TabsTrigger value="notifications">Notifications</TabsTrigger>
                        <TabsTrigger value="api">API Tokens</TabsTrigger>
                    </TabsList>

                    <TabsContent value="profile" className="space-y-6">
                        {/* Avatar Upload */}
                        <AvatarUpload
                            currentAvatar={undefined}
                            userInitials={getUserInitials(userProfile.firstName, userProfile.lastName)}
                            onAvatarChange={(file) => {
                                if (file) {
                                    // In real implementation, upload avatar
                                    console.log('Upload avatar:', file);
                                }
                            }}
                            onAvatarRemove={() => {
                                // In real implementation, remove avatar
                                console.log('Remove avatar');
                            }}
                            isLoading={isSubmitting}
                        />

                        {/* Profile Overview */}
                        <Card>
                            <CardHeader>
                                <div className="flex items-center space-x-4">
                                    <Avatar className="h-16 w-16">
                                        <AvatarFallback className="text-lg">
                                            {getUserInitials(userProfile.firstName, userProfile.lastName)}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-xl">
                                            {userProfile.firstName} {userProfile.lastName}
                                        </CardTitle>
                                        <CardDescription className="text-base">
                                            {userProfile.title} • {userProfile.department}
                                        </CardDescription>
                                        <div className="flex gap-2 mt-2">
                                            {userProfile.roles.map((role) => (
                                                <Badge key={role} variant="secondary">
                                                    {role}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-4">
                                        <div className="flex items-center space-x-3">
                                            <Mail className="h-5 w-5 text-gray-400" />
                                            <span>{userProfile.email}</span>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <Phone className="h-5 w-5 text-gray-400" />
                                            <span>{userProfile.phone}</span>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <Building className="h-5 w-5 text-gray-400" />
                                            <span>{userProfile.company}</span>
                                        </div>
                                    </div>
                                    <div className="space-y-4">
                                        <div className="flex items-center space-x-3">
                                            <MapPin className="h-5 w-5 text-gray-400" />
                                            <span>{userProfile.city}, {userProfile.state}</span>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <Calendar className="h-5 w-5 text-gray-400" />
                                            <span>Joined {formatDate(userProfile.joinedAt)}</span>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <User className="h-5 w-5 text-gray-400" />
                                            <span>Last login {formatDate(userProfile.lastLoginAt)}</span>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Edit Profile Form */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Edit Profile</CardTitle>
                                <CardDescription>
                                    Update your personal information and professional details
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Form method="post" className="space-y-6">
                                    <input type="hidden" name="intent" value="updateProfile" />

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="firstName">First Name</Label>
                                            <Input
                                                id="firstName"
                                                name="firstName"
                                                defaultValue={userProfile.firstName}
                                                required
                                            />
                                        </div>
                                        <div>
                                            <Label htmlFor="lastName">Last Name</Label>
                                            <Input
                                                id="lastName"
                                                name="lastName"
                                                defaultValue={userProfile.lastName}
                                                required
                                            />
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label htmlFor="phone">Phone Number</Label>
                                            <Input
                                                id="phone"
                                                name="phone"
                                                type="tel"
                                                defaultValue={userProfile.phone}
                                            />
                                        </div>
                                        <div>
                                            <Label htmlFor="title">Job Title</Label>
                                            <Input
                                                id="title"
                                                name="title"
                                                defaultValue={userProfile.title}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="department">Department</Label>
                                        <Input
                                            id="department"
                                            name="department"
                                            defaultValue={userProfile.department}
                                        />
                                    </div>

                                    <div>
                                        <Label htmlFor="bio">Bio</Label>
                                        <Textarea
                                            id="bio"
                                            name="bio"
                                            rows={4}
                                            defaultValue={userProfile.bio}
                                            placeholder="Tell us about yourself..."
                                        />
                                    </div>

                                    {hasError(actionData) && (
                                        <div className="rounded-md bg-red-50 p-4">
                                            <div className="text-sm text-red-700">{actionData.error}</div>
                                        </div>
                                    )}

                                    {hasSuccess(actionData) && (
                                        <div className="rounded-md bg-green-50 p-4">
                                            <div className="text-sm text-green-700">{actionData.success}</div>
                                        </div>
                                    )}

                                    <Button type="submit" disabled={isSubmitting}>
                                        {isSubmitting ? "Saving..." : "Save Changes"}
                                    </Button>
                                </Form>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="security" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Security Settings</CardTitle>
                                <CardDescription>
                                    Manage your account security and authentication methods
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                        <Shield className="h-5 w-5 text-green-600" />
                                        <div>
                                            <p className="font-medium">Two-Factor Authentication</p>
                                            <p className="text-sm text-gray-600">
                                                {userProfile.twoFactorEnabled ? "Enabled" : "Disabled"}
                                            </p>
                                        </div>
                                    </div>
                                    <Button variant="outline">
                                        {userProfile.twoFactorEnabled ? "Manage" : "Enable"}
                                    </Button>
                                </div>

                                <Separator />

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                        <Key className="h-5 w-5 text-blue-600" />
                                        <div>
                                            <p className="font-medium">Password</p>
                                            <p className="text-sm text-gray-600">
                                                Last changed 30 days ago
                                            </p>
                                        </div>
                                    </div>
                                    <Button variant="outline">
                                        Change Password
                                    </Button>
                                </div>

                                <Separator />

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                        <Smartphone className="h-5 w-5 text-purple-600" />
                                        <div>
                                            <p className="font-medium">Connected Devices</p>
                                            <p className="text-sm text-gray-600">
                                                Manage your logged-in devices
                                            </p>
                                        </div>
                                    </div>
                                    <Button variant="outline">
                                        Manage Devices
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="notifications" className="space-y-6">
                        <NotificationPreferences
                            preferences={{
                                emailEnabled: userProfile.emailNotifications,
                                documentSigned: true,
                                documentExpired: true,
                                documentShared: true,
                                reminderEmails: true,
                                weeklyDigest: false,
                                monthlyReport: false,
                                marketingEmails: false,
                                productUpdates: true,
                                securityAlerts: true,
                                smsEnabled: userProfile.smsNotifications,
                                urgentDocuments: false,
                                securitySMS: true,
                                inAppEnabled: true,
                                realTimeUpdates: true,
                                commentNotifications: true,
                                mentionNotifications: true,
                                frequency: 'immediate',
                                quietHours: {
                                    enabled: false,
                                    start: '22:00',
                                    end: '08:00',
                                    timezone: 'America/Los_Angeles',
                                },
                                preferredMethod: 'email',
                                language: 'en',
                            }}
                            onUpdatePreferences={async (preferences) => {
                                console.log('Update preferences:', preferences);
                                // In real implementation, update preferences
                            }}
                            isLoading={isSubmitting}
                        />
                    </TabsContent>

                    <TabsContent value="api" className="space-y-6">
                        <APITokenManagement
                            tokens={[
                                // Mock data - in real implementation, fetch from API
                                {
                                    id: '1',
                                    name: 'Production API',
                                    token: 'dsa_1234567890abcdef1234567890abcdef',
                                    permissions: ['documents:read', 'documents:write', 'signatures:read'],
                                    createdAt: new Date('2024-01-15'),
                                    expiresAt: new Date('2024-07-15'),
                                    lastUsed: new Date('2024-01-20'),
                                    isActive: true,
                                },
                                {
                                    id: '2',
                                    name: 'Development Testing',
                                    token: 'dsa_abcdef1234567890abcdef1234567890',
                                    permissions: ['documents:read', 'templates:read'],
                                    createdAt: new Date('2024-01-10'),
                                    lastUsed: new Date('2024-01-18'),
                                    isActive: true,
                                },
                            ]}
                            onCreateToken={async (tokenData) => {
                                console.log('Create token:', tokenData);
                                // In real implementation, create token via API
                                return {
                                    id: Date.now().toString(),
                                    name: tokenData.name,
                                    token: `dsa_${Math.random().toString(36).substring(2)}`,
                                    permissions: tokenData.permissions,
                                    createdAt: new Date(),
                                    expiresAt: tokenData.expiresAt,
                                    isActive: true,
                                };
                            }}
                            onRevokeToken={async (tokenId) => {
                                console.log('Revoke token:', tokenId);
                                // In real implementation, revoke token via API
                            }}
                            onRegenerateToken={async (tokenId) => {
                                console.log('Regenerate token:', tokenId);
                                // In real implementation, regenerate token via API
                                return {
                                    id: tokenId,
                                    name: 'Regenerated Token',
                                    token: `dsa_${Math.random().toString(36).substring(2)}`,
                                    permissions: ['documents:read'],
                                    createdAt: new Date(),
                                    isActive: true,
                                };
                            }}
                            isLoading={isSubmitting}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}