import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { Link, useActionData, useSearchParams, useNavigation } from "@remix-run/react";
import { getUserSession, createUserSession } from "~/lib/session.server";
import { LoginForm, LoginFormData, Card, CardContent, CardDescription, CardHeader, CardTitle, defaultProviders } from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Login - DocuSign Alternative" },
        { name: "description", content: "Sign in to your account" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await getUserSession(request);
    if (userSession) {
        return redirect("/dashboard");
    }
    return json({});
}

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const intent = formData.get("intent");

    // Handle OAuth provider authentication
    if (intent === "oauth") {
        const provider = formData.get("provider");
        const redirectTo = formData.get("redirectTo") || "/dashboard";

        if (typeof provider !== "string") {
            return json(
                { error: "Invalid OAuth provider" },
                { status: 400 }
            );
        }

        try {
            // In a real implementation, redirect to OAuth provider
            // For now, we'll simulate OAuth success
            const mockUserId = `oauth-${provider}-${Date.now()}`;

            return await createUserSession({
                request,
                userId: mockUserId,
                remember: false,
                redirectTo: typeof redirectTo === "string" ? redirectTo : "/dashboard",
            });
        } catch (error) {
            return json(
                { error: `Failed to authenticate with ${provider}` },
                { status: 400 }
            );
        }
    }

    // Handle regular email/password authentication
    const email = formData.get("email");
    const password = formData.get("password");
    const remember = formData.get("rememberMe") === "true";
    const redirectTo = formData.get("redirectTo") || "/dashboard";

    if (typeof email !== "string" || typeof password !== "string") {
        return json(
            { error: "Email and password are required" },
            { status: 400 }
        );
    }

    if (!email || !password) {
        return json(
            { error: "Email and password are required" },
            { status: 400 }
        );
    }

    try {
        // In a real implementation, you would validate credentials here
        // For now, we'll create a mock user session
        const mockUserId = "user-123"; // This should come from actual authentication

        return await createUserSession({
            request,
            userId: mockUserId,
            remember,
            redirectTo: typeof redirectTo === "string" ? redirectTo : "/dashboard",
        });
    } catch (error) {
        return json(
            { error: "Invalid email or password" },
            { status: 400 }
        );
    }
}

export default function Login() {
    const actionData = useActionData<typeof action>();
    const [searchParams] = useSearchParams();
    const navigation = useNavigation();
    const redirectTo = searchParams.get("redirectTo") || "/dashboard";
    const isSubmitting = navigation.state === "submitting";

    // OAuth providers configuration
    const oauthProviders = [
        defaultProviders.google,
        defaultProviders.microsoft,
        defaultProviders.github,
    ];

    const handleLogin = async (data: LoginFormData) => {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        // Add form data
        const emailInput = document.createElement('input');
        emailInput.name = 'email';
        emailInput.value = data.email;
        form.appendChild(emailInput);

        const passwordInput = document.createElement('input');
        passwordInput.name = 'password';
        passwordInput.value = data.password;
        form.appendChild(passwordInput);

        const rememberInput = document.createElement('input');
        rememberInput.name = 'rememberMe';
        rememberInput.value = data.rememberMe ? 'true' : 'false';
        form.appendChild(rememberInput);

        const redirectInput = document.createElement('input');
        redirectInput.name = 'redirectTo';
        redirectInput.value = redirectTo;
        form.appendChild(redirectInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleOAuthProvider = async (providerId: string) => {
        // Create a form and submit it for OAuth
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const intentInput = document.createElement('input');
        intentInput.name = 'intent';
        intentInput.value = 'oauth';
        form.appendChild(intentInput);

        const providerInput = document.createElement('input');
        providerInput.name = 'provider';
        providerInput.value = providerId;
        form.appendChild(providerInput);

        const redirectInput = document.createElement('input');
        redirectInput.name = 'redirectTo';
        redirectInput.value = redirectTo;
        form.appendChild(redirectInput);

        document.body.appendChild(form);
        form.submit();
    };

    const handleForgotPassword = () => {
        window.location.href = '/forgot-password';
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full">
                <Card>
                    <CardHeader className="text-center">
                        <CardTitle className="text-2xl font-bold">Sign in to your account</CardTitle>
                        <CardDescription>
                            Don't have an account?{" "}
                            <Link
                                to="/register"
                                className="font-medium text-blue-600 hover:text-blue-500"
                            >
                                Create one
                            </Link>
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <LoginForm
                            onSubmit={handleLogin}
                            onOAuthProvider={handleOAuthProvider}
                            onForgotPassword={handleForgotPassword}
                            error={actionData?.error}
                            isLoading={isSubmitting}
                            oauthProviders={oauthProviders}
                            oauthLoading={isSubmitting}
                        />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}