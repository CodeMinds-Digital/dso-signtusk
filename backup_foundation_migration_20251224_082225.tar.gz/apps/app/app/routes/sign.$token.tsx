import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, useActionData, Form, useNavigation } from "@remix-run/react";
import { useState, useEffect } from "react";
import { trpc } from "~/lib/trpc";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Progress,
    Alert,
    AlertDescription,
    SignatureCapture,
    type SignatureData,
    CheckCircle,
    FileText,
    User,
    Mail,
    Clock,
    AlertTriangle,
    ArrowRight,
    Download,
    Shield,
} from "@docusign-alternative/ui";

interface SigningField {
    id: string;
    type: "signature" | "initial" | "text" | "date" | "checkbox";
    name: string;
    x: number;
    y: number;
    width: number;
    height: number;
    page: number;
    required: boolean;
    recipientId?: string;
    value?: string;
}

interface SigningSession {
    recipient: {
        id: string;
        name: string;
        email: string;
        role: string;
        status: string;
    };
    signingRequest: {
        id: string;
        title: string;
        message?: string;
        customMessage?: string;
    };
    document: {
        id: string;
        name: string;
        mimeType: string;
        fields: SigningField[];
    };
}

export async function loader({ params }: LoaderFunctionArgs) {
    const { token } = params;

    if (!token) {
        throw new Response("Invalid signing link", { status: 400 });
    }

    try {
        // Get signing session data
        const { signingSession } = await trpc.signing.getSigningSession.query({ token });

        return json({ signingSession, token });
    } catch (error: any) {
        // Handle specific error cases
        if (error.message?.includes("Invalid signing token")) {
            throw new Response("Invalid or expired signing link", { status: 404 });
        }
        if (error.message?.includes("no longer active")) {
            throw new Response("This signing request is no longer active", { status: 410 });
        }
        if (error.message?.includes("expired")) {
            throw new Response("This signing request has expired", { status: 410 });
        }
        if (error.message?.includes("already signed")) {
            throw new Response("You have already signed this document", { status: 409 });
        }

        throw new Response("Unable to load signing session", { status: 500 });
    }
}

export async function action({ request, params }: ActionFunctionArgs) {
    const { token } = params;
    const formData = await request.formData();
    const action = formData.get("_action");

    if (!token) {
        return json({ error: "Invalid signing token" }, { status: 400 });
    }

    try {
        if (action === "submit_signatures") {
            const signaturesData = formData.get("signatures");
            const signatures = signaturesData ? JSON.parse(signaturesData as string) : [];

            const result = await trpc.signing.submitSignature.mutate({
                token,
                signatures,
                ipAddress: request.headers.get("x-forwarded-for") || "unknown",
                userAgent: request.headers.get("user-agent") || "unknown",
            });

            return json({ success: true, result });
        }

        if (action === "decline") {
            const reason = formData.get("reason") as string;

            if (!reason?.trim()) {
                return json({ error: "Please provide a reason for declining" }, { status: 400 });
            }

            const result = await trpc.signing.declineToSign.mutate({
                token,
                reason: reason.trim(),
            });

            return json({ success: true, result, declined: true });
        }

        return json({ error: "Invalid action" }, { status: 400 });
    } catch (error: any) {
        return json({ error: error.message || "An error occurred" }, { status: 500 });
    }
}

export default function SigningPage() {
    const { signingSession, token } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();

    const [currentStep, setCurrentStep] = useState<"review" | "sign" | "complete">("review");
    const [fieldValues, setFieldValues] = useState<Record<string, any>>({});
    const [signatures, setSignatures] = useState<Record<string, SignatureData>>({});
    const [showDeclineDialog, setShowDeclineDialog] = useState(false);
    const [declineReason, setDeclineReason] = useState("");
    const [currentFieldIndex, setCurrentFieldIndex] = useState(0);

    const isSubmitting = navigation.state === "submitting";
    const requiredFields = signingSession.document.fields.filter(field => field.required);
    const totalFields = signingSession.document.fields.length;
    const completedFields = Object.keys(fieldValues).length;
    const progress = totalFields > 0 ? (completedFields / totalFields) * 100 : 0;

    // Handle successful completion
    useEffect(() => {
        if (actionData?.success && !actionData?.declined) {
            setCurrentStep("complete");
        }
    }, [actionData]);

    // Handle field value changes
    const handleFieldChange = (fieldId: string, value: any, signatureData?: SignatureData) => {
        setFieldValues(prev => ({ ...prev, [fieldId]: value }));
        if (signatureData) {
            setSignatures(prev => ({ ...prev, [fieldId]: signatureData }));
        }
    };

    // Navigate to next field
    const goToNextField = () => {
        if (currentFieldIndex < signingSession.document.fields.length - 1) {
            setCurrentFieldIndex(currentFieldIndex + 1);
        } else {
            setCurrentStep("sign");
        }
    };

    // Navigate to previous field
    const goToPreviousField = () => {
        if (currentFieldIndex > 0) {
            setCurrentFieldIndex(currentFieldIndex - 1);
        } else {
            setCurrentStep("review");
        }
    };

    // Check if all required fields are completed
    const canSubmit = requiredFields.every(field =>
        fieldValues[field.id] !== undefined && fieldValues[field.id] !== ""
    );

    // Prepare signatures for submission
    const prepareSignatures = () => {
        return signingSession.document.fields
            .filter(field => fieldValues[field.id] !== undefined)
            .map(field => ({
                fieldId: field.id,
                value: fieldValues[field.id],
                type: field.type,
                signatureData: signatures[field.id] ? {
                    imageData: signatures[field.id].data,
                    method: signatures[field.id].type === "draw" ? "drawn" :
                        signatures[field.id].type === "type" ? "typed" : "uploaded",
                } : undefined,
            }));
    };

    // Handle form submission
    const handleSubmit = () => {
        const signaturesData = prepareSignatures();
        const form = document.createElement("form");
        form.method = "POST";
        form.style.display = "none";

        const actionInput = document.createElement("input");
        actionInput.name = "_action";
        actionInput.value = "submit_signatures";
        form.appendChild(actionInput);

        const signaturesInput = document.createElement("input");
        signaturesInput.name = "signatures";
        signaturesInput.value = JSON.stringify(signaturesData);
        form.appendChild(signaturesInput);

        document.body.appendChild(form);
        form.submit();
    };

    // Handle decline
    const handleDecline = () => {
        if (!declineReason.trim()) return;

        const form = document.createElement("form");
        form.method = "POST";
        form.style.display = "none";

        const actionInput = document.createElement("input");
        actionInput.name = "_action";
        actionInput.value = "decline";
        form.appendChild(actionInput);

        const reasonInput = document.createElement("input");
        reasonInput.name = "reason";
        reasonInput.value = declineReason.trim();
        form.appendChild(reasonInput);

        document.body.appendChild(form);
        form.submit();
    };

    // Show completion screen
    if (currentStep === "complete" || actionData?.declined) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
                <Card className="w-full max-w-2xl">
                    <CardContent className="pt-6">
                        <div className="text-center space-y-6">
                            {actionData?.declined ? (
                                <>
                                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
                                        <AlertTriangle className="h-8 w-8 text-orange-600" />
                                    </div>
                                    <div>
                                        <h1 className="text-2xl font-bold text-gray-900 mb-2">
                                            Document Declined
                                        </h1>
                                        <p className="text-gray-600">
                                            You have declined to sign this document. The sender has been notified.
                                        </p>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                        <CheckCircle className="h-8 w-8 text-green-600" />
                                    </div>
                                    <div>
                                        <h1 className="text-2xl font-bold text-gray-900 mb-2">
                                            Document Signed Successfully!
                                        </h1>
                                        <p className="text-gray-600">
                                            Thank you for signing "{signingSession.document.name}".
                                            {actionData?.result?.isComplete && " All parties have now signed this document."}
                                        </p>
                                    </div>
                                    <div className="flex justify-center space-x-4">
                                        <Button variant="outline" className="flex items-center space-x-2">
                                            <Download className="h-4 w-4" />
                                            <span>Download Copy</span>
                                        </Button>
                                    </div>
                                </>
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    const currentField = signingSession.document.fields[currentFieldIndex];

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="bg-white border-b border-gray-200">
                <div className="max-w-4xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <FileText className="h-4 w-4 text-blue-600" />
                            </div>
                            <div>
                                <h1 className="text-lg font-semibold text-gray-900">
                                    {signingSession.signingRequest.title}
                                </h1>
                                <p className="text-sm text-gray-600">
                                    {signingSession.document.name}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <Shield className="h-4 w-4 text-green-600" />
                            <span className="text-sm text-green-600 font-medium">Secure</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-4xl mx-auto px-4 py-8">
                {/* Progress Bar */}
                <div className="mb-8">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700">
                            {currentStep === "review" ? "Review Document" :
                                currentStep === "sign" ? "Complete Signing" : "Complete"}
                        </span>
                        <span className="text-sm text-gray-500">
                            {completedFields} of {totalFields} fields completed
                        </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                </div>

                {/* Error Display */}
                {actionData?.error && (
                    <Alert className="mb-6 border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-700">
                            {actionData.error}
                        </AlertDescription>
                    </Alert>
                )}

                {/* Review Step */}
                {currentStep === "review" && (
                    <div className="space-y-6">
                        {/* Recipient Info */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center space-x-2">
                                    <User className="h-5 w-5" />
                                    <span>Signing as</span>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex items-center space-x-4">
                                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                        <span className="text-blue-600 font-semibold">
                                            {signingSession.recipient.name.charAt(0)}
                                        </span>
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900">
                                            {signingSession.recipient.name}
                                        </p>
                                        <p className="text-sm text-gray-600 flex items-center space-x-1">
                                            <Mail className="h-3 w-3" />
                                            <span>{signingSession.recipient.email}</span>
                                        </p>
                                        <Badge variant="outline" className="mt-1">
                                            {signingSession.recipient.role}
                                        </Badge>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Document Info */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center space-x-2">
                                    <FileText className="h-5 w-5" />
                                    <span>Document Details</span>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <h3 className="font-medium text-gray-900">
                                            {signingSession.document.name}
                                        </h3>
                                        <p className="text-sm text-gray-600">
                                            {totalFields} field{totalFields !== 1 ? "s" : ""} to complete
                                            {requiredFields.length > 0 && (
                                                <span className="text-red-600">
                                                    {" "}({requiredFields.length} required)
                                                </span>
                                            )}
                                        </p>
                                    </div>

                                    {signingSession.signingRequest.message && (
                                        <div className="bg-blue-50 p-4 rounded-lg">
                                            <p className="text-sm text-blue-800">
                                                <strong>Message from sender:</strong><br />
                                                {signingSession.signingRequest.message}
                                            </p>
                                        </div>
                                    )}

                                    {signingSession.signingRequest.customMessage && (
                                        <div className="bg-green-50 p-4 rounded-lg">
                                            <p className="text-sm text-green-800">
                                                <strong>Personal message:</strong><br />
                                                {signingSession.signingRequest.customMessage}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Action Buttons */}
                        <div className="flex items-center justify-between">
                            <Button
                                variant="outline"
                                onClick={() => setShowDeclineDialog(true)}
                                className="text-red-600 hover:text-red-700"
                            >
                                Decline to Sign
                            </Button>

                            <Button
                                onClick={() => {
                                    if (totalFields > 0) {
                                        setCurrentStep("sign");
                                    } else {
                                        handleSubmit();
                                    }
                                }}
                                className="flex items-center space-x-2"
                            >
                                <span>Start Signing</span>
                                <ArrowRight className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                )}

                {/* Signing Step */}
                {currentStep === "sign" && currentField && (
                    <div className="space-y-6">
                        {/* Field Navigation */}
                        <Card>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <CardTitle>
                                        Field {currentFieldIndex + 1} of {totalFields}
                                    </CardTitle>
                                    <Badge variant={currentField.required ? "destructive" : "secondary"}>
                                        {currentField.required ? "Required" : "Optional"}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <h3 className="font-medium text-gray-900 mb-2">
                                            {currentField.name || `${currentField.type} field`}
                                        </h3>
                                        <p className="text-sm text-gray-600">
                                            Please complete this {currentField.type} field
                                            {currentField.required && " (required)"}.
                                        </p>
                                    </div>

                                    {/* Field Input */}
                                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                                        {currentField.type === "signature" && (
                                            <SignatureCapture
                                                required={currentField.required}
                                                placeholder={`Sign as ${signingSession.recipient.name}`}
                                                onSignatureCapture={(signature) =>
                                                    handleFieldChange(currentField.id, signature.data, signature)
                                                }
                                                onSignatureClear={() => {
                                                    const newValues = { ...fieldValues };
                                                    delete newValues[currentField.id];
                                                    setFieldValues(newValues);
                                                    const newSignatures = { ...signatures };
                                                    delete newSignatures[currentField.id];
                                                    setSignatures(newSignatures);
                                                }}
                                            />
                                        )}

                                        {currentField.type === "text" && (
                                            <div className="space-y-2">
                                                <label className="block text-sm font-medium text-gray-700">
                                                    Enter text
                                                </label>
                                                <input
                                                    type="text"
                                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                    value={fieldValues[currentField.id] || ""}
                                                    onChange={(e) => handleFieldChange(currentField.id, e.target.value)}
                                                    placeholder="Enter your text here"
                                                />
                                            </div>
                                        )}

                                        {currentField.type === "date" && (
                                            <div className="space-y-2">
                                                <label className="block text-sm font-medium text-gray-700">
                                                    Select date
                                                </label>
                                                <input
                                                    type="date"
                                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                    value={fieldValues[currentField.id] || ""}
                                                    onChange={(e) => handleFieldChange(currentField.id, e.target.value)}
                                                />
                                            </div>
                                        )}

                                        {currentField.type === "checkbox" && (
                                            <div className="flex items-center space-x-2">
                                                <input
                                                    type="checkbox"
                                                    id={currentField.id}
                                                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                                    checked={fieldValues[currentField.id] || false}
                                                    onChange={(e) => handleFieldChange(currentField.id, e.target.checked)}
                                                />
                                                <label htmlFor={currentField.id} className="text-sm text-gray-700">
                                                    {currentField.name || "Check this box"}
                                                </label>
                                            </div>
                                        )}
                                    </div>

                                    {/* Navigation Buttons */}
                                    <div className="flex items-center justify-between">
                                        <Button
                                            variant="outline"
                                            onClick={goToPreviousField}
                                            disabled={currentFieldIndex === 0}
                                        >
                                            Previous
                                        </Button>

                                        <div className="flex items-center space-x-2">
                                            {currentFieldIndex < signingSession.document.fields.length - 1 ? (
                                                <Button
                                                    onClick={goToNextField}
                                                    disabled={currentField.required && !fieldValues[currentField.id]}
                                                >
                                                    Next
                                                </Button>
                                            ) : (
                                                <Button
                                                    onClick={handleSubmit}
                                                    disabled={!canSubmit || isSubmitting}
                                                    className="flex items-center space-x-2"
                                                >
                                                    {isSubmitting ? (
                                                        <>
                                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                                            <span>Signing...</span>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <CheckCircle className="h-4 w-4" />
                                                            <span>Complete Signing</span>
                                                        </>
                                                    )}
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {/* Decline Dialog */}
                {showDeclineDialog && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                        <Card className="w-full max-w-md">
                            <CardHeader>
                                <CardTitle className="text-red-600">Decline to Sign</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <p className="text-sm text-gray-600">
                                        Please provide a reason for declining to sign this document.
                                    </p>
                                    <textarea
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                                        rows={3}
                                        placeholder="Enter your reason for declining..."
                                        value={declineReason}
                                        onChange={(e) => setDeclineReason(e.target.value)}
                                    />
                                    <div className="flex items-center justify-end space-x-2">
                                        <Button
                                            variant="outline"
                                            onClick={() => {
                                                setShowDeclineDialog(false);
                                                setDeclineReason("");
                                            }}
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            variant="destructive"
                                            onClick={handleDecline}
                                            disabled={!declineReason.trim() || isSubmitting}
                                        >
                                            {isSubmitting ? "Declining..." : "Decline Document"}
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}
            </div>
        </div>
    );
}