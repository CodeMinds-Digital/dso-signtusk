import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useSearchParams, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Progress,
    Separator,
} from "@docusign-alternative/ui";
import {
    BarChart3,
    TrendingUp,
    TrendingDown,
    Users,
    FileText,
    Clock,
    DollarSign,
    Calendar,
    Download,
    Filter,
    ArrowLeft,
    Star,
    Eye,
    Share,
    Activity,
    Target,
    Zap,
    CheckCircle,
    AlertTriangle,
} from "@docusign-alternative/ui";
import { useState } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Template Analytics - DocuSign Alternative" },
        { name: "description", content: "Comprehensive analytics and insights for your document templates" },
    ];
};

interface TemplateAnalyticsData {
    overview: {
        totalTemplates: number;
        totalUsage: number;
        averageCompletionRate: number;
        totalTimeSaved: number;
        costSavings: number;
        errorReduction: number;
    };
    performance: {
        topPerformers: Array<{
            id: string;
            name: string;
            category: string;
            usageCount: number;
            completionRate: number;
            avgCompletionTime: number;
            trend: 'up' | 'down' | 'stable';
        }>;
        underPerformers: Array<{
            id: string;
            name: string;
            category: string;
            usageCount: number;
            completionRate: number;
            issues: string[];
        }>;
    };
    usage: {
        byCategory: Array<{
            category: string;
            count: number;
            percentage: number;
            trend: number;
        }>;
        byTimeframe: Array<{
            period: string;
            usage: number;
            completions: number;
            newTemplates: number;
        }>;
        recentActivity: Array<{
            id: string;
            templateName: string;
            action: string;
            user: string;
            timestamp: string;
            details?: string;
        }>;
    };
    insights: {
        recommendations: Array<{
            type: 'optimization' | 'usage' | 'performance' | 'adoption';
            title: string;
            description: string;
            impact: 'high' | 'medium' | 'low';
            actionable: boolean;
        }>;
        trends: Array<{
            metric: string;
            value: number;
            change: number;
            period: string;
            direction: 'up' | 'down' | 'stable';
        }>;
    };
    roi: {
        totalSavings: number;
        timeReduction: number;
        errorReduction: number;
        adoptionRate: number;
        efficiency: number;
        breakdown: Array<{
            category: string;
            savings: number;
            timeReduced: number;
            documentsProcessed: number;
        }>;
    };
}

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);
    const url = new URL(request.url);

    const timeframe = url.searchParams.get('timeframe') || '30d';
    const category = url.searchParams.get('category') || 'all';

    // Mock comprehensive analytics data
    const analyticsData: TemplateAnalyticsData = {
        overview: {
            totalTemplates: 24,
            totalUsage: 1247,
            averageCompletionRate: 91.3,
            totalTimeSaved: 342.5, // hours
            costSavings: 28750, // dollars
            errorReduction: 87.2, // percentage
        },
        performance: {
            topPerformers: [
                {
                    id: "template-1",
                    name: "Employment Contract Template",
                    category: "HR",
                    usageCount: 156,
                    completionRate: 97.4,
                    avgCompletionTime: 2.3,
                    trend: 'up',
                },
                {
                    id: "template-5",
                    name: "Invoice Template",
                    category: "Finance",
                    usageCount: 234,
                    completionRate: 98.6,
                    avgCompletionTime: 1.2,
                    trend: 'up',
                },
                {
                    id: "template-3",
                    name: "Service Agreement",
                    category: "Sales",
                    usageCount: 89,
                    completionRate: 95.8,
                    avgCompletionTime: 3.2,
                    trend: 'stable',
                },
            ],
            underPerformers: [
                {
                    id: "template-7",
                    name: "Complex Legal Document",
                    category: "Legal",
                    usageCount: 12,
                    completionRate: 67.3,
                    issues: ["Too many fields", "Unclear instructions", "Long completion time"],
                },
                {
                    id: "template-8",
                    name: "Vendor Onboarding",
                    category: "Procurement",
                    usageCount: 8,
                    completionRate: 72.1,
                    issues: ["Missing required fields", "Confusing workflow"],
                },
            ],
        },
        usage: {
            byCategory: [
                { category: "Finance", count: 387, percentage: 31.0, trend: 12.5 },
                { category: "HR", count: 298, percentage: 23.9, trend: 8.3 },
                { category: "Sales", count: 234, percentage: 18.8, trend: -2.1 },
                { category: "Legal", count: 189, percentage: 15.2, trend: 5.7 },
                { category: "Procurement", count: 139, percentage: 11.1, trend: -1.2 },
            ],
            byTimeframe: [
                { period: "Week 1", usage: 89, completions: 82, newTemplates: 2 },
                { period: "Week 2", usage: 124, completions: 115, newTemplates: 1 },
                { period: "Week 3", usage: 156, completions: 143, newTemplates: 3 },
                { period: "Week 4", usage: 178, completions: 162, newTemplates: 1 },
            ],
            recentActivity: [
                {
                    id: "activity-1",
                    templateName: "Employment Contract Template",
                    action: "Used",
                    user: "Sarah Johnson",
                    timestamp: "2024-01-20T14:30:00Z",
                    details: "Created new employment contract for John Doe",
                },
                {
                    id: "activity-2",
                    templateName: "Invoice Template",
                    action: "Updated",
                    user: "Mike Chen",
                    timestamp: "2024-01-20T13:45:00Z",
                    details: "Modified payment terms section",
                },
                {
                    id: "activity-3",
                    templateName: "NDA Agreement",
                    action: "Shared",
                    user: "Lisa Wang",
                    timestamp: "2024-01-20T12:15:00Z",
                    details: "Shared with Legal team",
                },
                {
                    id: "activity-4",
                    templateName: "Service Agreement",
                    action: "Duplicated",
                    user: "Tom Wilson",
                    timestamp: "2024-01-20T11:30:00Z",
                    details: "Created custom version for enterprise clients",
                },
            ],
        },
        insights: {
            recommendations: [
                {
                    type: 'optimization',
                    title: "Optimize Complex Legal Document",
                    description: "This template has a low completion rate (67.3%). Consider simplifying the field layout and adding clearer instructions.",
                    impact: 'high',
                    actionable: true,
                },
                {
                    type: 'usage',
                    title: "Promote Invoice Template",
                    description: "Your Invoice Template has excellent performance (98.6% completion rate). Consider making it a recommended template.",
                    impact: 'medium',
                    actionable: true,
                },
                {
                    type: 'adoption',
                    title: "Increase Template Adoption",
                    description: "Only 68% of eligible documents are using templates. Training sessions could improve adoption rates.",
                    impact: 'high',
                    actionable: true,
                },
                {
                    type: 'performance',
                    title: "Review Vendor Onboarding Workflow",
                    description: "This template has workflow issues causing delays. Review the recipient order and field requirements.",
                    impact: 'medium',
                    actionable: true,
                },
            ],
            trends: [
                { metric: "Template Usage", value: 1247, change: 18.5, period: "vs last month", direction: 'up' },
                { metric: "Completion Rate", value: 91.3, change: 3.2, period: "vs last month", direction: 'up' },
                { metric: "Avg. Completion Time", value: 2.4, change: -12.8, period: "vs last month", direction: 'down' },
                { metric: "New Templates", value: 7, change: 40.0, period: "vs last month", direction: 'up' },
            ],
        },
        roi: {
            totalSavings: 28750,
            timeReduction: 85.3,
            errorReduction: 87.2,
            adoptionRate: 68.4,
            efficiency: 92.1,
            breakdown: [
                { category: "Finance", savings: 12400, timeReduced: 156.2, documentsProcessed: 387 },
                { category: "HR", savings: 8900, timeReduced: 98.7, documentsProcessed: 298 },
                { category: "Sales", savings: 4200, timeReduced: 67.3, documentsProcessed: 234 },
                { category: "Legal", savings: 2100, timeReduced: 45.8, documentsProcessed: 189 },
                { category: "Procurement", savings: 1150, timeReduced: 23.4, documentsProcessed: 139 },
            ],
        },
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        analytics: analyticsData,
        filters: {
            timeframe,
            category,
        },
    });
}

export default function TemplateAnalytics() {
    const { user, analytics, filters } = useLoaderData<typeof loader>();
    const [searchParams, setSearchParams] = useSearchParams();

    const updateFilter = (key: string, value: string) => {
        const params = new URLSearchParams(searchParams);
        if (value && value !== 'all') {
            params.set(key, value);
        } else {
            params.delete(key);
        }
        setSearchParams(params);
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    const formatTime = (hours: number) => {
        if (hours < 1) {
            return `${Math.round(hours * 60)}m`;
        }
        return `${hours.toFixed(1)}h`;
    };

    const getTrendIcon = (direction: 'up' | 'down' | 'stable') => {
        switch (direction) {
            case 'up':
                return <TrendingUp className="h-4 w-4 text-green-600" />;
            case 'down':
                return <TrendingDown className="h-4 w-4 text-red-600" />;
            default:
                return <Activity className="h-4 w-4 text-gray-600" />;
        }
    };

    const getImpactColor = (impact: 'high' | 'medium' | 'low') => {
        switch (impact) {
            case 'high':
                return 'bg-red-100 text-red-800 border-red-200';
            case 'medium':
                return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'low':
                return 'bg-green-100 text-green-800 border-green-200';
        }
    };

    return (
        <Layout user={user}>
            <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center space-x-4">
                        <Button variant="ghost" size="sm" asChild>
                            <Link to="/templates">
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to Templates
                            </Link>
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">Template Analytics</h1>
                            <p className="text-gray-600 mt-1">Comprehensive insights into your template performance and usage</p>
                        </div>
                    </div>
                    <div className="mt-4 sm:mt-0 flex items-center gap-3">
                        <Select value={filters.timeframe} onValueChange={(value) => updateFilter('timeframe', value)}>
                            <SelectTrigger className="w-32">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="7d">Last 7 days</SelectItem>
                                <SelectItem value="30d">Last 30 days</SelectItem>
                                <SelectItem value="90d">Last 90 days</SelectItem>
                                <SelectItem value="1y">Last year</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={filters.category} onValueChange={(value) => updateFilter('category', value)}>
                            <SelectTrigger className="w-40">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Categories</SelectItem>
                                <SelectItem value="finance">Finance</SelectItem>
                                <SelectItem value="hr">HR</SelectItem>
                                <SelectItem value="sales">Sales</SelectItem>
                                <SelectItem value="legal">Legal</SelectItem>
                                <SelectItem value="procurement">Procurement</SelectItem>
                            </SelectContent>
                        </Select>
                        <Button variant="outline">
                            <Download className="mr-2 h-4 w-4" />
                            Export Report
                        </Button>
                    </div>
                </div>

                {/* Overview Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <FileText className="h-8 w-8 text-blue-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Templates</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.overview.totalTemplates}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Activity className="h-8 w-8 text-green-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Usage</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.overview.totalUsage.toLocaleString()}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Target className="h-8 w-8 text-purple-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.overview.averageCompletionRate.toFixed(1)}%</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Clock className="h-8 w-8 text-orange-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Time Saved</p>
                                    <p className="text-2xl font-bold text-gray-900">{formatTime(analytics.overview.totalTimeSaved)}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <DollarSign className="h-8 w-8 text-green-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Cost Savings</p>
                                    <p className="text-2xl font-bold text-gray-900">{formatCurrency(analytics.overview.costSavings)}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Zap className="h-8 w-8 text-red-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Error Reduction</p>
                                    <p className="text-2xl font-bold text-gray-900">{analytics.overview.errorReduction.toFixed(1)}%</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Main Analytics Tabs */}
                <Tabs defaultValue="performance" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="performance">Performance</TabsTrigger>
                        <TabsTrigger value="usage">Usage</TabsTrigger>
                        <TabsTrigger value="insights">Insights</TabsTrigger>
                        <TabsTrigger value="roi">ROI Analysis</TabsTrigger>
                    </TabsList>

                    {/* Performance Tab */}
                    <TabsContent value="performance" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Top Performers */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center">
                                        <Star className="mr-2 h-5 w-5 text-yellow-600" />
                                        Top Performing Templates
                                    </CardTitle>
                                    <CardDescription>
                                        Templates with highest completion rates and usage
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {analytics.performance.topPerformers.map((template, index) => (
                                            <div key={template.id} className="flex items-center justify-between p-4 border rounded-lg">
                                                <div className="flex items-center space-x-3">
                                                    <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center text-sm font-medium text-yellow-600">
                                                        {index + 1}
                                                    </div>
                                                    <div>
                                                        <div className="font-medium">{template.name}</div>
                                                        <div className="text-sm text-gray-600">
                                                            {template.category} • {template.usageCount} uses
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-right flex items-center space-x-2">
                                                    <div>
                                                        <div className="font-medium">{template.completionRate.toFixed(1)}%</div>
                                                        <div className="text-sm text-gray-600">{formatTime(template.avgCompletionTime)}</div>
                                                    </div>
                                                    {getTrendIcon(template.trend)}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Under Performers */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center">
                                        <AlertTriangle className="mr-2 h-5 w-5 text-red-600" />
                                        Templates Needing Attention
                                    </CardTitle>
                                    <CardDescription>
                                        Templates with low completion rates or issues
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {analytics.performance.underPerformers.map((template) => (
                                            <div key={template.id} className="p-4 border border-red-200 rounded-lg bg-red-50">
                                                <div className="flex items-start justify-between mb-3">
                                                    <div>
                                                        <div className="font-medium text-red-900">{template.name}</div>
                                                        <div className="text-sm text-red-700">
                                                            {template.category} • {template.usageCount} uses
                                                        </div>
                                                    </div>
                                                    <div className="text-right">
                                                        <div className="font-medium text-red-900">{template.completionRate.toFixed(1)}%</div>
                                                        <div className="text-sm text-red-700">completion rate</div>
                                                    </div>
                                                </div>
                                                <div className="space-y-1">
                                                    <div className="text-sm font-medium text-red-800">Issues:</div>
                                                    {template.issues.map((issue, index) => (
                                                        <div key={index} className="text-sm text-red-700">• {issue}</div>
                                                    ))}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Trends */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Performance Trends</CardTitle>
                                <CardDescription>Key metrics compared to previous period</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                    {analytics.insights.trends.map((trend) => (
                                        <div key={trend.metric} className="text-center">
                                            <div className="flex items-center justify-center space-x-2 mb-2">
                                                {getTrendIcon(trend.direction)}
                                                <span className="text-2xl font-bold">{trend.value.toLocaleString()}</span>
                                            </div>
                                            <div className="text-sm font-medium text-gray-900">{trend.metric}</div>
                                            <div className={`text-sm ${trend.direction === 'up' ? 'text-green-600' : trend.direction === 'down' ? 'text-red-600' : 'text-gray-600'}`}>
                                                {trend.change > 0 ? '+' : ''}{trend.change.toFixed(1)}% {trend.period}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Usage Tab */}
                    <TabsContent value="usage" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Usage by Category */}
                            <Card>
                                <CardHeader>
                                    <CardTitle>Usage by Category</CardTitle>
                                    <CardDescription>Template usage distribution across categories</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {analytics.usage.byCategory.map((category) => (
                                            <div key={category.category} className="space-y-2">
                                                <div className="flex justify-between items-center">
                                                    <span className="font-medium">{category.category}</span>
                                                    <div className="flex items-center space-x-2">
                                                        <span className="text-sm text-gray-600">{category.count} uses</span>
                                                        <span className={`text-sm ${category.trend > 0 ? 'text-green-600' : category.trend < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                                                            {category.trend > 0 ? '+' : ''}{category.trend.toFixed(1)}%
                                                        </span>
                                                    </div>
                                                </div>
                                                <Progress value={category.percentage} className="h-2" />
                                                <div className="text-sm text-gray-500">{category.percentage.toFixed(1)}% of total usage</div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Usage Timeline */}
                            <Card>
                                <CardHeader>
                                    <CardTitle>Usage Timeline</CardTitle>
                                    <CardDescription>Template usage over time</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {analytics.usage.byTimeframe.map((period) => (
                                            <div key={period.period} className="flex items-center justify-between p-3 border rounded-lg">
                                                <div className="font-medium">{period.period}</div>
                                                <div className="flex items-center space-x-4 text-sm">
                                                    <div className="text-center">
                                                        <div className="font-medium">{period.usage}</div>
                                                        <div className="text-gray-600">Uses</div>
                                                    </div>
                                                    <div className="text-center">
                                                        <div className="font-medium">{period.completions}</div>
                                                        <div className="text-gray-600">Completed</div>
                                                    </div>
                                                    <div className="text-center">
                                                        <div className="font-medium">{period.newTemplates}</div>
                                                        <div className="text-gray-600">New</div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Recent Activity */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Recent Activity</CardTitle>
                                <CardDescription>Latest template actions and usage</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analytics.usage.recentActivity.map((activity) => (
                                        <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                                            <div className="w-2 h-2 rounded-full bg-blue-600 mt-2"></div>
                                            <div className="flex-1">
                                                <div className="text-sm">
                                                    <span className="font-medium">{activity.user}</span>
                                                    <span className="text-gray-600"> {activity.action.toLowerCase()} </span>
                                                    <span className="font-medium">{activity.templateName}</span>
                                                </div>
                                                {activity.details && (
                                                    <div className="text-sm text-gray-600 mt-1">{activity.details}</div>
                                                )}
                                                <div className="text-xs text-gray-500 mt-1">
                                                    {new Date(activity.timestamp).toLocaleString()}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Insights Tab */}
                    <TabsContent value="insights" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Recommendations</CardTitle>
                                <CardDescription>AI-powered insights to improve your template performance</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analytics.insights.recommendations.map((rec, index) => (
                                        <div key={index} className="p-4 border rounded-lg">
                                            <div className="flex items-start justify-between mb-3">
                                                <div className="flex items-center space-x-3">
                                                    <Badge className={getImpactColor(rec.impact)}>
                                                        {rec.impact} impact
                                                    </Badge>
                                                    <Badge variant="outline">{rec.type}</Badge>
                                                </div>
                                                {rec.actionable && (
                                                    <Button size="sm" variant="outline">
                                                        Take Action
                                                    </Button>
                                                )}
                                            </div>
                                            <h4 className="font-medium text-gray-900 mb-2">{rec.title}</h4>
                                            <p className="text-gray-600">{rec.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* ROI Analysis Tab */}
                    <TabsContent value="roi" className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                            <Card>
                                <CardContent className="p-6 text-center">
                                    <DollarSign className="h-8 w-8 text-green-600 mx-auto mb-2" />
                                    <div className="text-2xl font-bold text-green-600 mb-1">
                                        {formatCurrency(analytics.roi.totalSavings)}
                                    </div>
                                    <div className="text-sm text-gray-600">Total Savings</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardContent className="p-6 text-center">
                                    <Clock className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                                    <div className="text-2xl font-bold text-blue-600 mb-1">
                                        {analytics.roi.timeReduction.toFixed(1)}%
                                    </div>
                                    <div className="text-sm text-gray-600">Time Reduction</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardContent className="p-6 text-center">
                                    <CheckCircle className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                                    <div className="text-2xl font-bold text-purple-600 mb-1">
                                        {analytics.roi.errorReduction.toFixed(1)}%
                                    </div>
                                    <div className="text-sm text-gray-600">Error Reduction</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardContent className="p-6 text-center">
                                    <Users className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                                    <div className="text-2xl font-bold text-orange-600 mb-1">
                                        {analytics.roi.adoptionRate.toFixed(1)}%
                                    </div>
                                    <div className="text-sm text-gray-600">Adoption Rate</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardContent className="p-6 text-center">
                                    <Zap className="h-8 w-8 text-red-600 mx-auto mb-2" />
                                    <div className="text-2xl font-bold text-red-600 mb-1">
                                        {analytics.roi.efficiency.toFixed(1)}%
                                    </div>
                                    <div className="text-sm text-gray-600">Efficiency</div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* ROI Breakdown */}
                        <Card>
                            <CardHeader>
                                <CardTitle>ROI Breakdown by Category</CardTitle>
                                <CardDescription>Detailed savings and efficiency metrics by template category</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analytics.roi.breakdown.map((item) => (
                                        <div key={item.category} className="p-4 border rounded-lg">
                                            <div className="flex items-center justify-between mb-3">
                                                <h4 className="font-medium text-gray-900">{item.category}</h4>
                                                <div className="text-right">
                                                    <div className="font-bold text-green-600">{formatCurrency(item.savings)}</div>
                                                    <div className="text-sm text-gray-600">saved</div>
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-3 gap-4 text-sm">
                                                <div className="text-center">
                                                    <div className="font-medium">{formatTime(item.timeReduced)}</div>
                                                    <div className="text-gray-600">Time Saved</div>
                                                </div>
                                                <div className="text-center">
                                                    <div className="font-medium">{item.documentsProcessed}</div>
                                                    <div className="text-gray-600">Documents</div>
                                                </div>
                                                <div className="text-center">
                                                    <div className="font-medium">{formatCurrency(item.savings / item.documentsProcessed)}</div>
                                                    <div className="text-gray-600">Per Document</div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}