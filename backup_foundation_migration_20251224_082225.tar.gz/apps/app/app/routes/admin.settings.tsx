import { useState } from 'react';
import {
    Save,
    RefreshCw,
    Download,
    Upload,
    AlertTriangle,
    CheckCircle,
    Settings,
    Shield,
    Mail,
    Database,
    Globe,
    Zap
} from 'lucide-react';

export default function AdminSettings() {
    const [activeTab, setActiveTab] = useState('general');
    const [saving, setSaving] = useState(false);
    const [settings, setSettings] = useState({
        general: {
            siteName: 'DocuSign Alternative',
            siteUrl: 'https://app.example.com',
            supportEmail: 'support@example.com',
            maintenanceMode: false,
            registrationEnabled: true,
            emailVerificationRequired: true,
        },
        security: {
            sessionTimeout: 3600,
            maxLoginAttempts: 5,
            lockoutDuration: 900,
            passwordMinLength: 8,
            requireStrongPasswords: true,
            twoFactorRequired: false,
            allowedDomains: '',
            ipWhitelist: '',
        },
        features: {
            documentsEnabled: true,
            templatesEnabled: true,
            signingEnabled: true,
            analyticsEnabled: true,
            integrationsEnabled: true,
            webhooksEnabled: true,
        },
        limits: {
            maxDocumentSize: 50,
            maxDocumentsPerUser: 1000,
            maxTemplatesPerOrg: 500,
            maxUsersPerOrg: 100,
            apiRateLimit: 1000,
        },
        email: {
            provider: 'smtp',
            smtpHost: 'smtp.example.com',
            smtpPort: 587,
            smtpSecure: true,
            fromAddress: 'noreply@example.com',
            fromName: 'DocuSign Alternative',
        },
        storage: {
            provider: 's3',
            bucket: 'documents-bucket',
            region: 'us-east-1',
            maxFileSize: 50,
            allowedMimeTypes: [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'image/png',
                'image/jpeg',
            ],
        },
    });

    const tabs = [
        { id: 'general', name: 'General', icon: Settings },
        { id: 'security', name: 'Security', icon: Shield },
        { id: 'features', name: 'Features', icon: Zap },
        { id: 'limits', name: 'Limits', icon: AlertTriangle },
        { id: 'email', name: 'Email', icon: Mail },
        { id: 'storage', name: 'Storage', icon: Database },
    ];

    const handleSave = async (section: string) => {
        setSaving(true);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setSaving(false);
        // Show success message
    };

    const handleBackup = async () => {
        // Simulate backup creation
        console.log('Creating backup...');
    };

    const handleRestore = async () => {
        // Simulate restore
        console.log('Restoring from backup...');
    };

    const updateSetting = (section: string, key: string, value: any) => {
        setSettings(prev => ({
            ...prev,
            [section]: {
                ...prev[section as keyof typeof prev],
                [key]: value,
            },
        }));
    };

    const renderGeneralSettings = () => (
        <div className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Site Name
                </label>
                <input
                    type="text"
                    value={settings.general.siteName}
                    onChange={(e) => updateSetting('general', 'siteName', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Site URL
                </label>
                <input
                    type="url"
                    value={settings.general.siteUrl}
                    onChange={(e) => updateSetting('general', 'siteUrl', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Support Email
                </label>
                <input
                    type="email"
                    value={settings.general.supportEmail}
                    onChange={(e) => updateSetting('general', 'supportEmail', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                />
            </div>

            <div className="space-y-4">
                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="maintenanceMode"
                        checked={settings.general.maintenanceMode}
                        onChange={(e) => updateSetting('general', 'maintenanceMode', e.target.checked)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                    />
                    <label htmlFor="maintenanceMode" className="ml-2 block text-sm text-gray-900">
                        Maintenance Mode
                    </label>
                </div>

                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="registrationEnabled"
                        checked={settings.general.registrationEnabled}
                        onChange={(e) => updateSetting('general', 'registrationEnabled', e.target.checked)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                    />
                    <label htmlFor="registrationEnabled" className="ml-2 block text-sm text-gray-900">
                        Allow User Registration
                    </label>
                </div>

                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="emailVerificationRequired"
                        checked={settings.general.emailVerificationRequired}
                        onChange={(e) => updateSetting('general', 'emailVerificationRequired', e.target.checked)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                    />
                    <label htmlFor="emailVerificationRequired" className="ml-2 block text-sm text-gray-900">
                        Require Email Verification
                    </label>
                </div>
            </div>
        </div>
    );

    const renderSecuritySettings = () => (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Session Timeout (seconds)
                    </label>
                    <input
                        type="number"
                        value={settings.security.sessionTimeout}
                        onChange={(e) => updateSetting('security', 'sessionTimeout', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Login Attempts
                    </label>
                    <input
                        type="number"
                        value={settings.security.maxLoginAttempts}
                        onChange={(e) => updateSetting('security', 'maxLoginAttempts', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Lockout Duration (seconds)
                    </label>
                    <input
                        type="number"
                        value={settings.security.lockoutDuration}
                        onChange={(e) => updateSetting('security', 'lockoutDuration', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Minimum Password Length
                    </label>
                    <input
                        type="number"
                        value={settings.security.passwordMinLength}
                        onChange={(e) => updateSetting('security', 'passwordMinLength', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="requireStrongPasswords"
                        checked={settings.security.requireStrongPasswords}
                        onChange={(e) => updateSetting('security', 'requireStrongPasswords', e.target.checked)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                    />
                    <label htmlFor="requireStrongPasswords" className="ml-2 block text-sm text-gray-900">
                        Require Strong Passwords
                    </label>
                </div>

                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="twoFactorRequired"
                        checked={settings.security.twoFactorRequired}
                        onChange={(e) => updateSetting('security', 'twoFactorRequired', e.target.checked)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                    />
                    <label htmlFor="twoFactorRequired" className="ml-2 block text-sm text-gray-900">
                        Require Two-Factor Authentication
                    </label>
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Allowed Domains (one per line)
                </label>
                <textarea
                    value={settings.security.allowedDomains}
                    onChange={(e) => updateSetting('security', 'allowedDomains', e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="example.com&#10;company.org"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    IP Whitelist (one per line)
                </label>
                <textarea
                    value={settings.security.ipWhitelist}
                    onChange={(e) => updateSetting('security', 'ipWhitelist', e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="192.168.1.0/24&#10;10.0.0.0/8"
                />
            </div>
        </div>
    );

    const renderFeaturesSettings = () => (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(settings.features).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                            <h4 className="font-medium text-gray-900 capitalize">
                                {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                            </h4>
                            <p className="text-sm text-gray-600">
                                {key === 'documentsEnabled' && 'Allow document upload and management'}
                                {key === 'templatesEnabled' && 'Enable template creation and sharing'}
                                {key === 'signingEnabled' && 'Allow document signing workflows'}
                                {key === 'analyticsEnabled' && 'Enable analytics and reporting'}
                                {key === 'integrationsEnabled' && 'Allow third-party integrations'}
                                {key === 'webhooksEnabled' && 'Enable webhook notifications'}
                            </p>
                        </div>
                        <input
                            type="checkbox"
                            checked={value as boolean}
                            onChange={(e) => updateSetting('features', key, e.target.checked)}
                            className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                        />
                    </div>
                ))}
            </div>
        </div>
    );

    const renderLimitsSettings = () => (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Document Size (MB)
                    </label>
                    <input
                        type="number"
                        value={settings.limits.maxDocumentSize}
                        onChange={(e) => updateSetting('limits', 'maxDocumentSize', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Documents per User
                    </label>
                    <input
                        type="number"
                        value={settings.limits.maxDocumentsPerUser}
                        onChange={(e) => updateSetting('limits', 'maxDocumentsPerUser', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Templates per Organization
                    </label>
                    <input
                        type="number"
                        value={settings.limits.maxTemplatesPerOrg}
                        onChange={(e) => updateSetting('limits', 'maxTemplatesPerOrg', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Users per Organization
                    </label>
                    <input
                        type="number"
                        value={settings.limits.maxUsersPerOrg}
                        onChange={(e) => updateSetting('limits', 'maxUsersPerOrg', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        API Rate Limit (requests/hour)
                    </label>
                    <input
                        type="number"
                        value={settings.limits.apiRateLimit}
                        onChange={(e) => updateSetting('limits', 'apiRateLimit', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>
            </div>
        </div>
    );

    const renderEmailSettings = () => (
        <div className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Provider
                </label>
                <select
                    value={settings.email.provider}
                    onChange={(e) => updateSetting('email', 'provider', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                    <option value="smtp">SMTP</option>
                    <option value="sendgrid">SendGrid</option>
                    <option value="mailgun">Mailgun</option>
                    <option value="ses">Amazon SES</option>
                </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        SMTP Host
                    </label>
                    <input
                        type="text"
                        value={settings.email.smtpHost}
                        onChange={(e) => updateSetting('email', 'smtpHost', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        SMTP Port
                    </label>
                    <input
                        type="number"
                        value={settings.email.smtpPort}
                        onChange={(e) => updateSetting('email', 'smtpPort', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        From Address
                    </label>
                    <input
                        type="email"
                        value={settings.email.fromAddress}
                        onChange={(e) => updateSetting('email', 'fromAddress', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        From Name
                    </label>
                    <input
                        type="text"
                        value={settings.email.fromName}
                        onChange={(e) => updateSetting('email', 'fromName', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>
            </div>

            <div className="flex items-center">
                <input
                    type="checkbox"
                    id="smtpSecure"
                    checked={settings.email.smtpSecure}
                    onChange={(e) => updateSetting('email', 'smtpSecure', e.target.checked)}
                    className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                />
                <label htmlFor="smtpSecure" className="ml-2 block text-sm text-gray-900">
                    Use Secure Connection (TLS/SSL)
                </label>
            </div>
        </div>
    );

    const renderStorageSettings = () => (
        <div className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Storage Provider
                </label>
                <select
                    value={settings.storage.provider}
                    onChange={(e) => updateSetting('storage', 'provider', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                    <option value="s3">Amazon S3</option>
                    <option value="gcs">Google Cloud Storage</option>
                    <option value="azure">Azure Blob Storage</option>
                    <option value="local">Local Storage</option>
                </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Bucket Name
                    </label>
                    <input
                        type="text"
                        value={settings.storage.bucket}
                        onChange={(e) => updateSetting('storage', 'bucket', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Region
                    </label>
                    <input
                        type="text"
                        value={settings.storage.region}
                        onChange={(e) => updateSetting('storage', 'region', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max File Size (MB)
                    </label>
                    <input
                        type="number"
                        value={settings.storage.maxFileSize}
                        onChange={(e) => updateSetting('storage', 'maxFileSize', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Allowed MIME Types (one per line)
                </label>
                <textarea
                    value={settings.storage.allowedMimeTypes.join('\n')}
                    onChange={(e) => updateSetting('storage', 'allowedMimeTypes', e.target.value.split('\n').filter(Boolean))}
                    rows={6}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                />
            </div>
        </div>
    );

    const renderTabContent = () => {
        switch (activeTab) {
            case 'general':
                return renderGeneralSettings();
            case 'security':
                return renderSecuritySettings();
            case 'features':
                return renderFeaturesSettings();
            case 'limits':
                return renderLimitsSettings();
            case 'email':
                return renderEmailSettings();
            case 'storage':
                return renderStorageSettings();
            default:
                return null;
        }
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">System Settings</h1>
                    <p className="text-gray-600">Configure system-wide settings and preferences</p>
                </div>
                <div className="flex items-center space-x-3">
                    <button
                        onClick={handleBackup}
                        className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                    >
                        <Download className="h-4 w-4" />
                        <span>Backup</span>
                    </button>
                    <button
                        onClick={handleRestore}
                        className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                    >
                        <Upload className="h-4 w-4" />
                        <span>Restore</span>
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow">
                {/* Tab Navigation */}
                <div className="border-b border-gray-200">
                    <nav className="flex space-x-8 px-6">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${activeTab === tab.id
                                        ? 'border-red-500 text-red-600'
                                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                    }`}
                            >
                                <tab.icon className="h-4 w-4" />
                                <span>{tab.name}</span>
                            </button>
                        ))}
                    </nav>
                </div>

                {/* Tab Content */}
                <div className="p-6">
                    {renderTabContent()}
                </div>

                {/* Save Button */}
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end">
                    <button
                        onClick={() => handleSave(activeTab)}
                        disabled={saving}
                        className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50"
                    >
                        {saving ? (
                            <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                            <Save className="h-4 w-4" />
                        )}
                        <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                </div>
            </div>
        </div>
    );
}