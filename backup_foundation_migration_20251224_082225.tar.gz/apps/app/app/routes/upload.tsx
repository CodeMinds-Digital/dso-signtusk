import type { ActionFunctionArgs, LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import { hasError, hasSuccess, hasRedirectTo } from "~/lib/utils";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Input,
    Label,
    Textarea,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Progress,
    Badge,
} from "@docusign-alternative/ui";
import {
    Upload as UploadIcon,
    FileText,
    X,
    CheckCircle,
    AlertCircle,
    File,
    Image,
    FileType
} from "@docusign-alternative/ui";
import { useState } from "react";

export const meta: MetaFunction = () => {
    return [
        { title: "Upload Document - DocuSign Alternative" },
        { name: "description", content: "Upload documents for signing" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
    });
}

export async function action({ request }: ActionFunctionArgs) {
    const userSession = await requireUserSession(request);
    const formData = await request.formData();

    const title = formData.get("title");
    const description = formData.get("description");
    const category = formData.get("category");
    const file = formData.get("file") as File;

    if (!title || !file) {
        return json(
            { error: "Title and file are required" },
            { status: 400 }
        );
    }

    // Validate file type
    const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'image/jpeg',
        'image/png',
        'image/gif'
    ];

    if (!allowedTypes.includes(file.type)) {
        return json(
            { error: "File type not supported. Please upload PDF, Word, or image files." },
            { status: 400 }
        );
    }

    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
        return json(
            { error: "File size too large. Maximum size is 10MB." },
            { status: 400 }
        );
    }

    try {
        // In real implementation, upload file to storage service
        // For now, we'll simulate a successful upload
        const documentId = `doc-${Date.now()}`;

        return json({
            success: "Document uploaded successfully",
            documentId,
            redirectTo: `/documents/${documentId}`,
        });
    } catch (error) {
        return json(
            { error: "Failed to upload document. Please try again." },
            { status: 500 }
        );
    }
}

const fileTypeIcons = {
    'application/pdf': FileText,
    'application/msword': FileType,
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': FileType,
    'image/jpeg': Image,
    'image/png': Image,
    'image/gif': Image,
    default: File,
};

export default function Upload() {
    const { user } = useLoaderData<typeof loader>();
    const actionData = useActionData<typeof action>();
    const navigation = useNavigation();
    const isSubmitting = navigation.state === "submitting";

    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [dragActive, setDragActive] = useState(false);

    const handleDrag = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);

        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            setSelectedFile(e.dataTransfer.files[0]);
        }
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const formatFileSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const getFileIcon = (fileType: string) => {
        const IconComponent = fileTypeIcons[fileType as keyof typeof fileTypeIcons] || fileTypeIcons.default;
        return IconComponent;
    };

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900">Upload Document</h1>
                    <p className="text-gray-600">Upload a document to prepare for signing</p>
                </div>

                <div className="max-w-2xl mx-auto">
                    <Card>
                        <CardHeader>
                            <CardTitle>Document Upload</CardTitle>
                            <CardDescription>
                                Upload your document and provide details for the signing process
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Form method="post" encType="multipart/form-data" className="space-y-6">
                                {/* File Upload Area */}
                                <div>
                                    <Label>Document File</Label>
                                    <div
                                        className={`mt-2 border-2 border-dashed rounded-lg p-6 text-center transition-colors ${dragActive
                                            ? "border-blue-400 bg-blue-50"
                                            : "border-gray-300 hover:border-gray-400"
                                            }`}
                                        onDragEnter={handleDrag}
                                        onDragLeave={handleDrag}
                                        onDragOver={handleDrag}
                                        onDrop={handleDrop}
                                    >
                                        {selectedFile ? (
                                            <div className="space-y-4">
                                                <div className="flex items-center justify-center space-x-3">
                                                    {(() => {
                                                        const IconComponent = getFileIcon(selectedFile.type);
                                                        return <IconComponent className="h-8 w-8 text-blue-600" />;
                                                    })()}
                                                    <div className="text-left">
                                                        <p className="font-medium text-gray-900">{selectedFile.name}</p>
                                                        <p className="text-sm text-gray-500">
                                                            {formatFileSize(selectedFile.size)}
                                                        </p>
                                                    </div>
                                                    <Button
                                                        type="button"
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => setSelectedFile(null)}
                                                    >
                                                        <X className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                                <Badge variant="default" className="bg-green-100 text-green-800">
                                                    <CheckCircle className="mr-1 h-3 w-3" />
                                                    File selected
                                                </Badge>
                                            </div>
                                        ) : (
                                            <div className="space-y-4">
                                                <UploadIcon className="mx-auto h-12 w-12 text-gray-400" />
                                                <div>
                                                    <p className="text-lg font-medium text-gray-900">
                                                        Drop your file here, or{" "}
                                                        <label className="text-blue-600 hover:text-blue-500 cursor-pointer">
                                                            browse
                                                            <input
                                                                type="file"
                                                                name="file"
                                                                className="sr-only"
                                                                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
                                                                onChange={handleFileSelect}
                                                                required
                                                            />
                                                        </label>
                                                    </p>
                                                    <p className="text-sm text-gray-500">
                                                        PDF, Word, or image files up to 10MB
                                                    </p>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    {selectedFile && (
                                        <input
                                            type="file"
                                            name="file"
                                            className="sr-only"
                                            onChange={handleFileSelect}
                                        />
                                    )}
                                </div>

                                {/* Document Details */}
                                <div>
                                    <Label htmlFor="title">Document Title</Label>
                                    <Input
                                        id="title"
                                        name="title"
                                        placeholder="Enter a descriptive title for your document"
                                        required
                                    />
                                </div>

                                <div>
                                    <Label htmlFor="description">Description (Optional)</Label>
                                    <Textarea
                                        id="description"
                                        name="description"
                                        rows={3}
                                        placeholder="Add any additional details about this document..."
                                    />
                                </div>

                                <div>
                                    <Label htmlFor="category">Category</Label>
                                    <Select name="category" defaultValue="general">
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="general">General</SelectItem>
                                            <SelectItem value="contract">Contract</SelectItem>
                                            <SelectItem value="agreement">Agreement</SelectItem>
                                            <SelectItem value="nda">NDA</SelectItem>
                                            <SelectItem value="hr">HR Document</SelectItem>
                                            <SelectItem value="legal">Legal Document</SelectItem>
                                            <SelectItem value="financial">Financial</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                {/* Upload Progress */}
                                {isSubmitting && (
                                    <div className="space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm font-medium">Uploading...</span>
                                            <span className="text-sm text-gray-500">Processing</span>
                                        </div>
                                        <Progress value={75} className="w-full" />
                                    </div>
                                )}

                                {/* Error/Success Messages */}
                                {hasError(actionData) && (
                                    <div className="rounded-md bg-red-50 p-4">
                                        <div className="flex">
                                            <AlertCircle className="h-5 w-5 text-red-400" />
                                            <div className="ml-3">
                                                <div className="text-sm text-red-700">{actionData.error}</div>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {hasSuccess(actionData) && (
                                    <div className="rounded-md bg-green-50 p-4">
                                        <div className="flex">
                                            <CheckCircle className="h-5 w-5 text-green-400" />
                                            <div className="ml-3">
                                                <div className="text-sm text-green-700">{actionData.success}</div>
                                                {hasRedirectTo(actionData) && (
                                                    <div className="mt-2">
                                                        <a
                                                            href={actionData.redirectTo}
                                                            className="text-sm font-medium text-green-600 hover:text-green-500"
                                                        >
                                                            View document →
                                                        </a>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Submit Button */}
                                <div className="flex justify-end space-x-3">
                                    <Button type="button" variant="outline">
                                        Cancel
                                    </Button>
                                    <Button
                                        type="submit"
                                        disabled={isSubmitting || !selectedFile}
                                    >
                                        {isSubmitting ? "Uploading..." : "Upload Document"}
                                    </Button>
                                </div>
                            </Form>
                        </CardContent>
                    </Card>

                    {/* Upload Tips */}
                    <Card className="mt-6">
                        <CardHeader>
                            <CardTitle className="text-lg">Upload Tips</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2 text-sm text-gray-600">
                                <li className="flex items-start">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                                    PDF files work best for document signing
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                                    Word documents will be converted to PDF automatically
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                                    Images will be embedded in a PDF document
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                                    Maximum file size is 10MB
                                </li>
                            </ul>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </Layout>
    );
}