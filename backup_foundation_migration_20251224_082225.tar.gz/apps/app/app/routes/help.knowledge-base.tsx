import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useSearchParams } from "@remix-run/react";
import { useState, useEffect } from "react";
import { KnowledgeBase } from "@docusign-alternative/ui";
import { trpc } from "~/lib/trpc";

export const meta: MetaFunction = () => {
    return [
        { title: "Knowledge Base - DocuSign Alternative" },
        { name: "description", content: "Browse our comprehensive knowledge base and documentation" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    return json({});
}

export default function KnowledgeBasePage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const [selectedArticleId, setSelectedArticleId] = useState<string | null>(
        searchParams.get('article')
    );
    const [searchResults, setSearchResults] = useState<any>({
        articles: [],
        totalResults: 0,
    });

    // Fetch categories and articles
    const { data: categories } = trpc.helpSupport.getCategories.useQuery();
    const { data: popularArticles } = trpc.helpSupport.getPopularArticles.useQuery();

    // Fetch selected article
    const { data: selectedArticle } = trpc.helpSupport.getArticle.useQuery(
        { id: selectedArticleId! },
        { enabled: !!selectedArticleId }
    );

    // Search mutation
    const searchMutation = trpc.helpSupport.searchHelp.useMutation({
        onSuccess: (data) => {
            setSearchResults(data);
        },
    });

    // Rate article mutation
    const rateArticleMutation = trpc.helpSupport.rateArticle.useMutation();

    useEffect(() => {
        const articleId = searchParams.get('article');
        setSelectedArticleId(articleId);
    }, [searchParams]);

    const handleSelectArticle = (articleId: string) => {
        if (articleId) {
            setSelectedArticleId(articleId);
            setSearchParams({ article: articleId });
        } else {
            setSelectedArticleId(null);
            setSearchParams({});
        }
    };

    const handleSearch = (query: string, filters?: any) => {
        searchMutation.mutate({
            query,
            category: filters?.category,
            limit: 20,
        });
    };

    const handleRateArticle = (articleId: string, rating: number, feedback?: string) => {
        rateArticleMutation.mutate({
            articleId,
            rating,
            feedback,
        });
    };

    const handleBookmarkArticle = (articleId: string) => {
        // In a real implementation, you'd have a bookmark mutation
        console.log('Bookmark article:', articleId);
    };

    const handleShareArticle = (articleId: string) => {
        // In a real implementation, you'd handle sharing
        const url = `${window.location.origin}/help/knowledge-base?article=${articleId}`;
        navigator.clipboard.writeText(url);
    };

    // Transform categories for the knowledge base component
    const knowledgeCategories = (categories || []).map(cat => ({
        id: cat.id,
        name: cat.name,
        description: `Browse ${cat.name.toLowerCase()} articles and guides`,
        icon: cat.icon,
        articleCount: cat.count,
    }));

    // Transform articles for the knowledge base component
    const articles = searchResults.articles.length > 0
        ? searchResults.articles.map((article: any) => ({
            ...article,
            excerpt: article.content.substring(0, 200) + '...',
            readTime: Math.ceil(article.content.length / 1000), // Rough estimate
            ratingCount: 50, // Mock data
            author: {
                name: 'Support Team',
                avatar: undefined,
            },
            relatedArticles: [],
        }))
        : (popularArticles || []).map((article: any) => ({
            ...article,
            excerpt: article.content.substring(0, 200) + '...',
            readTime: Math.ceil(article.content.length / 1000),
            ratingCount: 50,
            author: {
                name: 'Support Team',
                avatar: undefined,
            },
            relatedArticles: [],
        }));

    // Transform selected article
    const transformedSelectedArticle = selectedArticle ? {
        ...selectedArticle,
        excerpt: selectedArticle.content.substring(0, 200) + '...',
        readTime: Math.ceil(selectedArticle.content.length / 1000),
        ratingCount: 50,
        author: {
            name: 'Support Team',
            avatar: undefined,
        },
        relatedArticles: [],
    } : null;

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <KnowledgeBase
                articles={articles}
                categories={knowledgeCategories}
                selectedArticle={transformedSelectedArticle}
                onSelectArticle={handleSelectArticle}
                onSearch={handleSearch}
                onRateArticle={handleRateArticle}
                onBookmarkArticle={handleBookmarkArticle}
                onShareArticle={handleShareArticle}
            />
        </div>
    );
}