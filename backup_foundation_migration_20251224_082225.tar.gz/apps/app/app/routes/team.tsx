import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import { requireUserSession } from "~/lib/session.server";
import { Layout } from "~/components/layout";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Input,
    Avatar,
    AvatarFallback,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from "@docusign-alternative/ui";
import {
    Users,
    Search,
    UserPlus,
    MoreHorizontal,
    Mail,
    Shield,
    Crown,
    User,
    Calendar,
    Activity,
    Settings,
    Trash2,
    Edit
} from "@docusign-alternative/ui";

export const meta: MetaFunction = () => {
    return [
        { title: "Team - DocuSign Alternative" },
        { name: "description", content: "Manage your team members and permissions" },
    ];
};

export async function loader({ request }: LoaderFunctionArgs) {
    const userSession = await requireUserSession(request);

    // Mock team data - in real implementation, fetch from database
    const teamMembers = [
        {
            id: "user-1",
            email: "john.doe@acme.com",
            firstName: "John",
            lastName: "Doe",
            role: "admin",
            status: "active",
            joinedAt: "2023-06-15T10:30:00Z",
            lastActiveAt: "2024-01-17T09:15:00Z",
            documentsCount: 45,
            signaturesCount: 128,
        },
        {
            id: "user-2",
            email: "jane.smith@acme.com",
            firstName: "Jane",
            lastName: "Smith",
            role: "manager",
            status: "active",
            joinedAt: "2023-08-22T14:20:00Z",
            lastActiveAt: "2024-01-16T16:45:00Z",
            documentsCount: 32,
            signaturesCount: 89,
        },
        {
            id: "user-3",
            email: "mike.johnson@acme.com",
            firstName: "Mike",
            lastName: "Johnson",
            role: "user",
            status: "active",
            joinedAt: "2023-10-10T11:15:00Z",
            lastActiveAt: "2024-01-15T13:30:00Z",
            documentsCount: 18,
            signaturesCount: 42,
        },
        {
            id: "user-4",
            email: "sarah.wilson@acme.com",
            firstName: "Sarah",
            lastName: "Wilson",
            role: "user",
            status: "invited",
            joinedAt: "2024-01-10T09:00:00Z",
            lastActiveAt: null,
            documentsCount: 0,
            signaturesCount: 0,
        },
    ];

    const teamStats = {
        totalMembers: teamMembers.length,
        activeMembers: teamMembers.filter(m => m.status === "active").length,
        pendingInvites: teamMembers.filter(m => m.status === "invited").length,
        totalDocuments: teamMembers.reduce((sum, m) => sum + m.documentsCount, 0),
    };

    return json({
        user: {
            userId: userSession.userId,
            organizationId: userSession.organizationId,
            roles: userSession.roles,
        },
        teamMembers,
        teamStats,
    });
}

const roleConfig = {
    admin: { label: "Admin", variant: "default" as const, icon: Crown, color: "text-purple-600" },
    manager: { label: "Manager", variant: "secondary" as const, icon: Shield, color: "text-blue-600" },
    user: { label: "User", variant: "outline" as const, icon: User, color: "text-gray-600" },
};

const statusConfig = {
    active: { label: "Active", variant: "default" as const, color: "bg-green-100 text-green-800" },
    invited: { label: "Invited", variant: "secondary" as const, color: "bg-yellow-100 text-yellow-800" },
    inactive: { label: "Inactive", variant: "outline" as const, color: "bg-gray-100 text-gray-800" },
};

export default function Team() {
    const { user, teamMembers, teamStats } = useLoaderData<typeof loader>();

    const getUserInitials = (firstName: string, lastName: string) => {
        return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
        });
    };

    const getRelativeTime = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

        if (diffInHours < 1) return "Just now";
        if (diffInHours < 24) return `${diffInHours}h ago`;
        const diffInDays = Math.floor(diffInHours / 24);
        if (diffInDays < 7) return `${diffInDays}d ago`;
        return formatDate(dateString);
    };

    return (
        <Layout user={user}>
            <div className="p-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Team</h1>
                        <p className="text-gray-600">Manage your team members and their permissions</p>
                    </div>
                    <div className="mt-4 sm:mt-0">
                        <Button>
                            <UserPlus className="mr-2 h-4 w-4" />
                            Invite Member
                        </Button>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Users className="h-8 w-8 text-blue-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Members</p>
                                    <p className="text-2xl font-bold text-gray-900">{teamStats.totalMembers}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Activity className="h-8 w-8 text-green-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Active Members</p>
                                    <p className="text-2xl font-bold text-gray-900">{teamStats.activeMembers}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Mail className="h-8 w-8 text-yellow-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Pending Invites</p>
                                    <p className="text-2xl font-bold text-gray-900">{teamStats.pendingInvites}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center">
                                <Activity className="h-8 w-8 text-purple-600" />
                                <div className="ml-4">
                                    <p className="text-sm font-medium text-gray-600">Total Documents</p>
                                    <p className="text-2xl font-bold text-gray-900">{teamStats.totalDocuments}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="members" className="space-y-6">
                    <TabsList>
                        <TabsTrigger value="members">Members</TabsTrigger>
                        <TabsTrigger value="roles">Roles & Permissions</TabsTrigger>
                        <TabsTrigger value="activity">Activity</TabsTrigger>
                    </TabsList>

                    <TabsContent value="members" className="space-y-6">
                        {/* Search and Filters */}
                        <Card>
                            <CardContent className="p-4">
                                <div className="flex flex-col sm:flex-row gap-4">
                                    <div className="flex-1">
                                        <div className="relative">
                                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                            <Input
                                                placeholder="Search team members..."
                                                className="pl-10"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Team Members List */}
                        <div className="space-y-4">
                            {teamMembers.map((member) => {
                                const roleInfo = roleConfig[member.role as keyof typeof roleConfig];
                                const statusInfo = statusConfig[member.status as keyof typeof statusConfig];
                                const RoleIcon = roleInfo.icon;

                                return (
                                    <Card key={member.id} className="hover:shadow-md transition-shadow">
                                        <CardContent className="p-6">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center space-x-4 flex-1">
                                                    <Avatar className="h-12 w-12">
                                                        <AvatarFallback>
                                                            {getUserInitials(member.firstName, member.lastName)}
                                                        </AvatarFallback>
                                                    </Avatar>

                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center space-x-2 mb-1">
                                                            <h3 className="text-lg font-medium text-gray-900">
                                                                {member.firstName} {member.lastName}
                                                            </h3>
                                                            <Badge variant={roleInfo.variant}>
                                                                <RoleIcon className="mr-1 h-3 w-3" />
                                                                {roleInfo.label}
                                                            </Badge>
                                                            <Badge className={statusInfo.color}>
                                                                {statusInfo.label}
                                                            </Badge>
                                                        </div>

                                                        <p className="text-sm text-gray-600 mb-2">{member.email}</p>

                                                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm text-gray-600">
                                                            <div>
                                                                <span className="font-medium">Joined:</span> {formatDate(member.joinedAt)}
                                                            </div>
                                                            <div>
                                                                <span className="font-medium">Last active:</span>{" "}
                                                                {member.lastActiveAt ? getRelativeTime(member.lastActiveAt) : "Never"}
                                                            </div>
                                                            <div>
                                                                <span className="font-medium">Documents:</span> {member.documentsCount}
                                                            </div>
                                                            <div>
                                                                <span className="font-medium">Signatures:</span> {member.signaturesCount}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="flex items-center space-x-2 ml-4">
                                                    <Button variant="outline" size="sm" asChild>
                                                        <Link to={`/team/${member.id}`}>
                                                            View Profile
                                                        </Link>
                                                    </Button>

                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <Button variant="outline" size="sm">
                                                                <MoreHorizontal className="h-4 w-4" />
                                                            </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent align="end">
                                                            <DropdownMenuItem>
                                                                <Edit className="mr-2 h-4 w-4" />
                                                                Edit Role
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem>
                                                                <Settings className="mr-2 h-4 w-4" />
                                                                Permissions
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem>
                                                                <Mail className="mr-2 h-4 w-4" />
                                                                Resend Invite
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem className="text-red-600">
                                                                <Trash2 className="mr-2 h-4 w-4" />
                                                                Remove
                                                            </DropdownMenuItem>
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                );
                            })}
                        </div>
                    </TabsContent>

                    <TabsContent value="roles" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Roles & Permissions</CardTitle>
                                <CardDescription>
                                    Manage team roles and their associated permissions
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                {Object.entries(roleConfig).map(([roleKey, roleInfo]) => {
                                    const RoleIcon = roleInfo.icon;
                                    const memberCount = teamMembers.filter(m => m.role === roleKey).length;

                                    return (
                                        <div key={roleKey} className="flex items-center justify-between p-4 border rounded-lg">
                                            <div className="flex items-center space-x-4">
                                                <RoleIcon className={`h-8 w-8 ${roleInfo.color}`} />
                                                <div>
                                                    <h3 className="font-medium text-gray-900">{roleInfo.label}</h3>
                                                    <p className="text-sm text-gray-600">
                                                        {memberCount} member{memberCount !== 1 ? 's' : ''}
                                                    </p>
                                                </div>
                                            </div>
                                            <Button variant="outline" size="sm">
                                                Edit Permissions
                                            </Button>
                                        </div>
                                    );
                                })}
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="activity" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Recent Activity</CardTitle>
                                <CardDescription>
                                    Track team member activity and engagement
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="text-center py-8 text-gray-500">
                                        <Activity className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                                        <p>Activity tracking coming soon</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </Layout>
    );
}