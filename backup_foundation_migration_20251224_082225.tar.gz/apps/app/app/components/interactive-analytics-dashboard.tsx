import React, { useState, useCallback, useMemo } from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    StatisticCard,
    BarChart,
    LineChart,
    PieChart,
    AreaChart,
    DataTable,
    Grid,
} from "@docusign-alternative/ui";
import {
    Plus,
    Settings,
    X,
    Maximize2,
    Minimize2,
    RefreshCw,
    Download,
    Share,
    Filter,
    Move,
    RotateCcw,
    BarChart3,
    TrendingUp,
    Users,
    FileText,
    Clock,
    Activity,
    PieChart as PieChartIcon,
    Target,
    DollarSign,
    Zap,
} from "@docusign-alternative/ui";

export interface DashboardWidget {
    id: string;
    type: 'metric' | 'bar-chart' | 'line-chart' | 'pie-chart' | 'area-chart' | 'table' | 'activity-feed';
    title: string;
    size: 'small' | 'medium' | 'large';
    position: { x: number; y: number; w: number; h: number };
    data?: any;
    config?: {
        metric?: string;
        chartType?: string;
        timeRange?: string;
        filters?: any;
        color?: string;
        showLegend?: boolean;
    };
    refreshable?: boolean;
    exportable?: boolean;
    filterable?: boolean;
}

interface InteractiveAnalyticsDashboardProps {
    initialWidgets?: DashboardWidget[];
    onWidgetUpdate?: (widgets: DashboardWidget[]) => void;
    onExport?: (format: string, widgets: DashboardWidget[]) => void;
    analyticsData?: any;
}

export const InteractiveAnalyticsDashboard: React.FC<InteractiveAnalyticsDashboardProps> = ({
    initialWidgets = [],
    onWidgetUpdate,
    onExport,
    analyticsData,
}) => {
    const [widgets, setWidgets] = useState<DashboardWidget[]>(initialWidgets);
    const [selectedWidget, setSelectedWidget] = useState<string | null>(null);
    const [isCustomizing, setIsCustomizing] = useState(false);
    const [draggedWidget, setDraggedWidget] = useState<string | null>(null);

    // Available widget templates
    const widgetTemplates = [
        {
            type: 'metric',
            title: 'Key Performance Indicator',
            description: 'Display a single metric with trend',
            icon: <TrendingUp className="h-5 w-5" />,
            defaultSize: 'small',
            defaultConfig: { metric: 'total_users' },
        },
        {
            type: 'bar-chart',
            title: 'Bar Chart',
            description: 'Compare values across categories',
            icon: <BarChart3 className="h-5 w-5" />,
            defaultSize: 'medium',
            defaultConfig: { chartType: 'bar', metric: 'documents_by_status' },
        },
        {
            type: 'line-chart',
            title: 'Line Chart',
            description: 'Show trends over time',
            icon: <Activity className="h-5 w-5" />,
            defaultSize: 'medium',
            defaultConfig: { chartType: 'line', metric: 'daily_activity' },
        },
        {
            type: 'pie-chart',
            title: 'Pie Chart',
            description: 'Show proportional data',
            icon: <PieChartIcon className="h-5 w-5" />,
            defaultSize: 'medium',
            defaultConfig: { chartType: 'pie', metric: 'completion_rate' },
        },
        {
            type: 'area-chart',
            title: 'Area Chart',
            description: 'Show cumulative trends',
            icon: <Activity className="h-5 w-5" />,
            defaultSize: 'medium',
            defaultConfig: { chartType: 'area', metric: 'user_growth' },
        },
        {
            type: 'table',
            title: 'Data Table',
            description: 'Tabular data display',
            icon: <FileText className="h-5 w-5" />,
            defaultSize: 'large',
            defaultConfig: { metric: 'team_performance' },
        },
        {
            type: 'activity-feed',
            title: 'Activity Feed',
            description: 'Recent system activities',
            icon: <Activity className="h-5 w-5" />,
            defaultSize: 'medium',
            defaultConfig: { metric: 'recent_activities' },
        },
    ];

    const addWidget = useCallback((template: any) => {
        const newWidget: DashboardWidget = {
            id: `widget-${Date.now()}`,
            type: template.type,
            title: template.title,
            size: template.defaultSize,
            position: {
                x: 0,
                y: 0,
                w: template.defaultSize === 'small' ? 1 : template.defaultSize === 'medium' ? 2 : 3,
                h: template.defaultSize === 'small' ? 1 : 2,
            },
            config: template.defaultConfig,
            refreshable: true,
            exportable: true,
            filterable: true,
        };

        setWidgets(prev => [...prev, newWidget]);
        onWidgetUpdate?.([...widgets, newWidget]);
        setIsCustomizing(false);
    }, [widgets, onWidgetUpdate]);

    const removeWidget = useCallback((widgetId: string) => {
        const updatedWidgets = widgets.filter(w => w.id !== widgetId);
        setWidgets(updatedWidgets);
        onWidgetUpdate?.(updatedWidgets);
    }, [widgets, onWidgetUpdate]);

    const updateWidget = useCallback((widgetId: string, updates: Partial<DashboardWidget>) => {
        const updatedWidgets = widgets.map(w =>
            w.id === widgetId ? { ...w, ...updates } : w
        );
        setWidgets(updatedWidgets);
        onWidgetUpdate?.(updatedWidgets);
    }, [widgets, onWidgetUpdate]);

    const refreshWidget = useCallback(async (widgetId: string) => {
        // Mock refresh - in real implementation, this would refetch data
        console.log(`Refreshing widget: ${widgetId}`);
    }, []);

    const exportWidget = useCallback((widgetId: string, format: string) => {
        const widget = widgets.find(w => w.id === widgetId);
        if (widget) {
            onExport?.(format, [widget]);
        }
    }, [widgets, onExport]);

    const renderWidget = useCallback((widget: DashboardWidget) => {
        const mockData = getMockDataForWidget(widget, analyticsData);

        switch (widget.type) {
            case 'metric':
                return (
                    <StatisticCard
                        title={widget.title}
                        value={mockData.value}
                        change={mockData.change}
                        icon={mockData.icon}
                        trend={mockData.trend}
                        className="border-0 shadow-none h-full"
                    />
                );
            case 'bar-chart':
                return (
                    <BarChart
                        data={mockData.data}
                        title={widget.title}
                        height={200}
                        className="border-0 shadow-none"
                    />
                );
            case 'line-chart':
                return (
                    <LineChart
                        data={mockData.data}
                        title={widget.title}
                        height={200}
                        color={widget.config?.color}
                        className="border-0 shadow-none"
                    />
                );
            case 'pie-chart':
                return (
                    <PieChart
                        data={mockData.data}
                        title={widget.title}
                        showLegend={widget.config?.showLegend !== false}
                        className="border-0 shadow-none"
                    />
                );
            case 'area-chart':
                return (
                    <AreaChart
                        data={mockData.data}
                        title={widget.title}
                        height={200}
                        color={widget.config?.color}
                        className="border-0 shadow-none"
                    />
                );
            case 'table':
                return (
                    <DataTable
                        columns={mockData.columns}
                        data={mockData.data}
                        size="small"
                        className="border-0 shadow-none"
                    />
                );
            case 'activity-feed':
                return (
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                        {mockData.activities?.map((activity: any, index: number) => (
                            <div key={index} className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-50">
                                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                                    <Activity className="h-4 w-4 text-blue-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-gray-900 truncate">
                                        {activity.title}
                                    </p>
                                    <p className="text-xs text-gray-600">{activity.description}</p>
                                    <p className="text-xs text-gray-400">{activity.timestamp}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                );
            default:
                return <div className="p-4 text-center text-gray-500">Widget type not supported</div>;
        }
    }, [analyticsData]);

    const gridCols = 12;
    const gridRows = 8;

    return (
        <div className="space-y-6">
            {/* Dashboard Controls */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-gray-900">Interactive Dashboard</h2>
                    <p className="text-gray-600">Customize your analytics view with drag-and-drop widgets</p>
                </div>
                <div className="flex items-center gap-3">
                    <Button
                        variant="outline"
                        onClick={() => setIsCustomizing(true)}
                    >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Widget
                    </Button>
                    <Select onValueChange={(format) => onExport?.(format, widgets)}>
                        <SelectTrigger className="w-32">
                            <Download className="h-4 w-4 mr-2" />
                            <SelectValue placeholder="Export" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="png">PNG</SelectItem>
                            <SelectItem value="pdf">PDF</SelectItem>
                            <SelectItem value="csv">CSV</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button variant="outline">
                        <Share className="h-4 w-4 mr-2" />
                        Share
                    </Button>
                </div>
            </div>

            {/* Dashboard Grid */}
            <div className="relative">
                <div
                    className="grid gap-4"
                    style={{
                        gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
                        gridTemplateRows: `repeat(${gridRows}, 120px)`,
                        minHeight: `${gridRows * 120 + (gridRows - 1) * 16}px`,
                    }}
                >
                    {widgets.map((widget) => (
                        <div
                            key={widget.id}
                            className={`relative group ${selectedWidget === widget.id ? 'ring-2 ring-blue-500' : ''
                                }`}
                            style={{
                                gridColumn: `span ${widget.position.w}`,
                                gridRow: `span ${widget.position.h}`,
                            }}
                            onClick={() => setSelectedWidget(widget.id)}
                        >
                            <Card className="h-full">
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">{widget.title}</CardTitle>
                                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        {widget.refreshable && (
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    refreshWidget(widget.id);
                                                }}
                                            >
                                                <RefreshCw className="h-4 w-4" />
                                            </Button>
                                        )}
                                        {widget.exportable && (
                                            <Select onValueChange={(format) => exportWidget(widget.id, format)}>
                                                <SelectTrigger className="w-8 h-8 p-0">
                                                    <Download className="h-4 w-4" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="png">PNG</SelectItem>
                                                    <SelectItem value="csv">CSV</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        )}
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                // Open widget settings
                                            }}
                                        >
                                            <Settings className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                removeWidget(widget.id);
                                            }}
                                        >
                                            <X className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardHeader>
                                <CardContent className="pt-0">
                                    {renderWidget(widget)}
                                </CardContent>
                            </Card>
                        </div>
                    ))}
                </div>

                {/* Empty State */}
                {widgets.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                        <BarChart3 className="h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No widgets added yet</h3>
                        <p className="text-gray-600 mb-4">
                            Start building your dashboard by adding some widgets
                        </p>
                        <Button onClick={() => setIsCustomizing(true)}>
                            <Plus className="h-4 w-4 mr-2" />
                            Add Your First Widget
                        </Button>
                    </div>
                )}
            </div>

            {/* Widget Customizer Dialog */}
            <Dialog open={isCustomizing} onOpenChange={setIsCustomizing}>
                <DialogContent className="max-w-4xl">
                    <DialogHeader>
                        <DialogTitle>Add Widget</DialogTitle>
                        <DialogDescription>
                            Choose a widget type to add to your dashboard
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-4 py-4">
                        {widgetTemplates.map((template) => (
                            <Card
                                key={template.type}
                                className="cursor-pointer hover:shadow-md transition-shadow"
                                onClick={() => addWidget(template)}
                            >
                                <CardContent className="p-4">
                                    <div className="flex items-start gap-3">
                                        <div className="flex-shrink-0 p-2 bg-blue-100 rounded-lg">
                                            {template.icon}
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="font-medium text-gray-900 mb-1">
                                                {template.title}
                                            </h3>
                                            <p className="text-sm text-gray-600">
                                                {template.description}
                                            </p>
                                            <Badge variant="outline" className="mt-2">
                                                {template.defaultSize}
                                            </Badge>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
};

// Helper function to generate mock data for widgets
function getMockDataForWidget(widget: DashboardWidget, analyticsData?: any) {
    switch (widget.type) {
        case 'metric':
            return {
                value: 1247,
                change: { value: 12.5, type: 'increase', period: 'vs last month' },
                icon: <Users className="h-5 w-5 text-blue-600" />,
                trend: [
                    { date: '2024-01-01', value: 1100 },
                    { date: '2024-01-02', value: 1150 },
                    { date: '2024-01-03', value: 1200 },
                    { date: '2024-01-04', value: 1247 },
                ],
            };
        case 'bar-chart':
        case 'line-chart':
        case 'area-chart':
            return {
                data: [
                    { name: 'Jan', value: 400 },
                    { name: 'Feb', value: 300 },
                    { name: 'Mar', value: 600 },
                    { name: 'Apr', value: 800 },
                    { name: 'May', value: 500 },
                ],
            };
        case 'pie-chart':
            return {
                data: [
                    { name: 'Completed', value: 65 },
                    { name: 'Pending', value: 25 },
                    { name: 'Draft', value: 10 },
                ],
            };
        case 'table':
            return {
                columns: [
                    { key: 'name', title: 'Name' },
                    { key: 'value', title: 'Value' },
                    { key: 'status', title: 'Status' },
                ],
                data: [
                    { name: 'Item 1', value: 100, status: 'Active' },
                    { name: 'Item 2', value: 200, status: 'Pending' },
                    { name: 'Item 3', value: 150, status: 'Active' },
                ],
            };
        case 'activity-feed':
            return {
                activities: [
                    {
                        title: 'Document signed',
                        description: 'Employment contract completed by John Doe',
                        timestamp: '2 minutes ago',
                    },
                    {
                        title: 'New user registered',
                        description: 'Alice Johnson joined the organization',
                        timestamp: '15 minutes ago',
                    },
                    {
                        title: 'Template created',
                        description: 'NDA template added to library',
                        timestamp: '1 hour ago',
                    },
                ],
            };
        default:
            return {};
    }
}

export default InteractiveAnalyticsDashboard;