import React, { useState } from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Checkbox,
    Label,
    Input,
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogFooter,
    Grid,
} from "@docusign-alternative/ui";
import {
    Plus,
    X,
    Download,
    Save,
    BarChart3,
    PieChart,
    LineChart as LineChartIcon,
    Table,
    Filter,
    Calendar,
} from "@docusign-alternative/ui";

export interface ReportConfig {
    name: string;
    description?: string;
    reportType: 'usage' | 'performance' | 'compliance' | 'cost';
    timeRange: {
        startDate: string;
        endDate: string;
    };
    filters: {
        teams?: string[];
        users?: string[];
        documentTypes?: string[];
        statuses?: string[];
    };
    groupBy: 'day' | 'week' | 'month' | 'team' | 'user';
    metrics: string[];
    visualizations: Array<{
        type: 'bar' | 'line' | 'pie' | 'table';
        metric: string;
        title: string;
    }>;
}

interface CustomReportBuilderProps {
    onSave?: (config: ReportConfig) => void;
    onGenerate?: (config: ReportConfig) => void;
    initialConfig?: Partial<ReportConfig>;
}

export const CustomReportBuilder: React.FC<CustomReportBuilderProps> = ({
    onSave,
    onGenerate,
    initialConfig,
}) => {
    const [config, setConfig] = useState<ReportConfig>({
        name: initialConfig?.name || '',
        description: initialConfig?.description || '',
        reportType: initialConfig?.reportType || 'usage',
        timeRange: initialConfig?.timeRange || {
            startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            endDate: new Date().toISOString(),
        },
        filters: initialConfig?.filters || {},
        groupBy: initialConfig?.groupBy || 'day',
        metrics: initialConfig?.metrics || [],
        visualizations: initialConfig?.visualizations || [],
    });

    const [activeStep, setActiveStep] = useState(0);

    const availableMetrics = {
        usage: [
            { id: 'documents_created', label: 'Documents Created' },
            { id: 'documents_completed', label: 'Documents Completed' },
            { id: 'signatures_collected', label: 'Signatures Collected' },
            { id: 'active_users', label: 'Active Users' },
            { id: 'api_calls', label: 'API Calls' },
            { id: 'storage_used', label: 'Storage Used' },
        ],
        performance: [
            { id: 'completion_rate', label: 'Completion Rate' },
            { id: 'average_completion_time', label: 'Average Completion Time' },
            { id: 'user_engagement', label: 'User Engagement' },
            { id: 'template_usage', label: 'Template Usage' },
            { id: 'error_rate', label: 'Error Rate' },
        ],
        compliance: [
            { id: 'audit_trail_completeness', label: 'Audit Trail Completeness' },
            { id: 'signature_validity', label: 'Signature Validity' },
            { id: 'document_retention', label: 'Document Retention' },
            { id: 'access_logs', label: 'Access Logs' },
        ],
        cost: [
            { id: 'total_cost', label: 'Total Cost' },
            { id: 'cost_per_user', label: 'Cost Per User' },
            { id: 'cost_per_document', label: 'Cost Per Document' },
            { id: 'overage_charges', label: 'Overage Charges' },
        ],
    };

    const handleMetricToggle = (metricId: string) => {
        setConfig(prev => ({
            ...prev,
            metrics: prev.metrics.includes(metricId)
                ? prev.metrics.filter(m => m !== metricId)
                : [...prev.metrics, metricId],
        }));
    };

    const handleAddVisualization = (type: 'bar' | 'line' | 'pie' | 'table', metric: string) => {
        setConfig(prev => ({
            ...prev,
            visualizations: [
                ...prev.visualizations,
                {
                    type,
                    metric,
                    title: `${metric} - ${type} chart`,
                },
            ],
        }));
    };

    const handleRemoveVisualization = (index: number) => {
        setConfig(prev => ({
            ...prev,
            visualizations: prev.visualizations.filter((_, i) => i !== index),
        }));
    };

    const steps = [
        { id: 'basic', label: 'Basic Info' },
        { id: 'metrics', label: 'Select Metrics' },
        { id: 'filters', label: 'Apply Filters' },
        { id: 'visualizations', label: 'Visualizations' },
        { id: 'preview', label: 'Preview & Generate' },
    ];

    return (
        <Card className="w-full">
            <CardHeader>
                <CardTitle>Custom Report Builder</CardTitle>
                <CardDescription>
                    Create custom reports with advanced filtering and visualization options
                </CardDescription>
            </CardHeader>
            <CardContent>
                {/* Progress Steps */}
                <div className="mb-8">
                    <div className="flex items-center justify-between">
                        {steps.map((step, index) => (
                            <React.Fragment key={step.id}>
                                <div className="flex flex-col items-center">
                                    <div
                                        className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${index <= activeStep
                                                ? 'bg-blue-600 text-white'
                                                : 'bg-gray-200 text-gray-600'
                                            }`}
                                    >
                                        {index + 1}
                                    </div>
                                    <span className="text-xs mt-2 text-center">{step.label}</span>
                                </div>
                                {index < steps.length - 1 && (
                                    <div
                                        className={`flex-1 h-1 mx-2 ${index < activeStep ? 'bg-blue-600' : 'bg-gray-200'
                                            }`}
                                    />
                                )}
                            </React.Fragment>
                        ))}
                    </div>
                </div>

                {/* Step Content */}
                <div className="min-h-[400px]">
                    {/* Step 1: Basic Info */}
                    {activeStep === 0 && (
                        <div className="space-y-6">
                            <div>
                                <Label htmlFor="report-name">Report Name *</Label>
                                <Input
                                    id="report-name"
                                    value={config.name}
                                    onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
                                    placeholder="e.g., Monthly Usage Report"
                                    className="mt-2"
                                />
                            </div>
                            <div>
                                <Label htmlFor="report-description">Description</Label>
                                <Input
                                    id="report-description"
                                    value={config.description}
                                    onChange={(e) => setConfig(prev => ({ ...prev, description: e.target.value }))}
                                    placeholder="Brief description of the report"
                                    className="mt-2"
                                />
                            </div>
                            <div>
                                <Label htmlFor="report-type">Report Type *</Label>
                                <Select
                                    value={config.reportType}
                                    onValueChange={(value: any) => setConfig(prev => ({ ...prev, reportType: value }))}
                                >
                                    <SelectTrigger className="mt-2">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="usage">Usage Analytics</SelectItem>
                                        <SelectItem value="performance">Performance Metrics</SelectItem>
                                        <SelectItem value="compliance">Compliance Report</SelectItem>
                                        <SelectItem value="cost">Cost Analysis</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="group-by">Group By</Label>
                                <Select
                                    value={config.groupBy}
                                    onValueChange={(value: any) => setConfig(prev => ({ ...prev, groupBy: value }))}
                                >
                                    <SelectTrigger className="mt-2">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="day">Day</SelectItem>
                                        <SelectItem value="week">Week</SelectItem>
                                        <SelectItem value="month">Month</SelectItem>
                                        <SelectItem value="team">Team</SelectItem>
                                        <SelectItem value="user">User</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    )}

                    {/* Step 2: Select Metrics */}
                    {activeStep === 1 && (
                        <div className="space-y-4">
                            <p className="text-sm text-gray-600 mb-4">
                                Select the metrics you want to include in your report
                            </p>
                            <div className="grid grid-cols-2 gap-4">
                                {availableMetrics[config.reportType].map((metric) => (
                                    <div key={metric.id} className="flex items-center space-x-2 p-3 border rounded-lg">
                                        <Checkbox
                                            id={metric.id}
                                            checked={config.metrics.includes(metric.id)}
                                            onCheckedChange={() => handleMetricToggle(metric.id)}
                                        />
                                        <Label htmlFor={metric.id} className="cursor-pointer">
                                            {metric.label}
                                        </Label>
                                    </div>
                                ))}
                            </div>
                            {config.metrics.length === 0 && (
                                <p className="text-sm text-amber-600 mt-4">
                                    Please select at least one metric to continue
                                </p>
                            )}
                        </div>
                    )}

                    {/* Step 3: Apply Filters */}
                    {activeStep === 2 && (
                        <div className="space-y-6">
                            <p className="text-sm text-gray-600 mb-4">
                                Apply filters to narrow down your report data
                            </p>
                            <div>
                                <Label>Document Status</Label>
                                <div className="grid grid-cols-3 gap-3 mt-2">
                                    {['completed', 'pending', 'draft', 'cancelled'].map((status) => (
                                        <div key={status} className="flex items-center space-x-2">
                                            <Checkbox id={`status-${status}`} />
                                            <Label htmlFor={`status-${status}`} className="capitalize">
                                                {status}
                                            </Label>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <Label>Document Types</Label>
                                <div className="grid grid-cols-3 gap-3 mt-2">
                                    {['contracts', 'agreements', 'forms', 'invoices'].map((type) => (
                                        <div key={type} className="flex items-center space-x-2">
                                            <Checkbox id={`type-${type}`} />
                                            <Label htmlFor={`type-${type}`} className="capitalize">
                                                {type}
                                            </Label>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Step 4: Visualizations */}
                    {activeStep === 3 && (
                        <div className="space-y-6">
                            <p className="text-sm text-gray-600 mb-4">
                                Add visualizations for your selected metrics
                            </p>

                            {config.visualizations.length > 0 && (
                                <div className="space-y-3 mb-6">
                                    {config.visualizations.map((viz, index) => (
                                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                                            <div className="flex items-center gap-3">
                                                {viz.type === 'bar' && <BarChart3 className="h-5 w-5 text-blue-600" />}
                                                {viz.type === 'line' && <LineChartIcon className="h-5 w-5 text-green-600" />}
                                                {viz.type === 'pie' && <PieChart className="h-5 w-5 text-purple-600" />}
                                                {viz.type === 'table' && <Table className="h-5 w-5 text-gray-600" />}
                                                <div>
                                                    <p className="font-medium">{viz.title}</p>
                                                    <p className="text-sm text-gray-600">{viz.metric}</p>
                                                </div>
                                            </div>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => handleRemoveVisualization(index)}
                                            >
                                                <X className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            )}

                            <div>
                                <Label className="mb-3 block">Add Visualization</Label>
                                <Grid cols={2} gap={4}>
                                    {config.metrics.map((metric) => (
                                        <Card key={metric} className="p-4">
                                            <p className="font-medium mb-3 text-sm">{metric}</p>
                                            <div className="flex gap-2">
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleAddVisualization('bar', metric)}
                                                >
                                                    <BarChart3 className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleAddVisualization('line', metric)}
                                                >
                                                    <LineChartIcon className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleAddVisualization('pie', metric)}
                                                >
                                                    <PieChart className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleAddVisualization('table', metric)}
                                                >
                                                    <Table className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </Card>
                                    ))}
                                </Grid>
                            </div>
                        </div>
                    )}

                    {/* Step 5: Preview */}
                    {activeStep === 4 && (
                        <div className="space-y-6">
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                <h3 className="font-semibold text-blue-900 mb-2">Report Summary</h3>
                                <dl className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <dt className="text-gray-600">Name:</dt>
                                        <dd className="font-medium">{config.name || 'Untitled Report'}</dd>
                                    </div>
                                    <div className="flex justify-between">
                                        <dt className="text-gray-600">Type:</dt>
                                        <dd className="font-medium capitalize">{config.reportType}</dd>
                                    </div>
                                    <div className="flex justify-between">
                                        <dt className="text-gray-600">Metrics:</dt>
                                        <dd className="font-medium">{config.metrics.length} selected</dd>
                                    </div>
                                    <div className="flex justify-between">
                                        <dt className="text-gray-600">Visualizations:</dt>
                                        <dd className="font-medium">{config.visualizations.length} added</dd>
                                    </div>
                                    <div className="flex justify-between">
                                        <dt className="text-gray-600">Group By:</dt>
                                        <dd className="font-medium capitalize">{config.groupBy}</dd>
                                    </div>
                                </dl>
                            </div>

                            <div className="space-y-3">
                                <h4 className="font-semibold">Selected Metrics:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {config.metrics.map((metric) => (
                                        <Badge key={metric} variant="secondary">
                                            {metric}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-3">
                                <h4 className="font-semibold">Visualizations:</h4>
                                <div className="space-y-2">
                                    {config.visualizations.map((viz, index) => (
                                        <div key={index} className="flex items-center gap-2 text-sm">
                                            <Badge variant="outline">{viz.type}</Badge>
                                            <span>{viz.metric}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t">
                    <Button
                        variant="outline"
                        onClick={() => setActiveStep(Math.max(0, activeStep - 1))}
                        disabled={activeStep === 0}
                    >
                        Previous
                    </Button>
                    <div className="flex gap-3">
                        {activeStep === steps.length - 1 ? (
                            <>
                                <Button
                                    variant="outline"
                                    onClick={() => onSave?.(config)}
                                    disabled={!config.name || config.metrics.length === 0}
                                >
                                    <Save className="h-4 w-4 mr-2" />
                                    Save Template
                                </Button>
                                <Button
                                    onClick={() => onGenerate?.(config)}
                                    disabled={!config.name || config.metrics.length === 0}
                                >
                                    <Download className="h-4 w-4 mr-2" />
                                    Generate Report
                                </Button>
                            </>
                        ) : (
                            <Button
                                onClick={() => setActiveStep(Math.min(steps.length - 1, activeStep + 1))}
                                disabled={
                                    (activeStep === 0 && !config.name) ||
                                    (activeStep === 1 && config.metrics.length === 0)
                                }
                            >
                                Next
                            </Button>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default CustomReportBuilder;