import React, { useState, useEffect, useCallback } from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Avatar
} from "@docusign-alternative/ui";
import {
    Bell,
    CheckCircle,
    Upload,
    Users,
    Clock,
    AlertCircle,
    FileText,
    Plus,
    Activity,
    Filter,
    RefreshCw,
    Eye,
    MoreHorizontal,
    Calendar,
    User
} from "@docusign-alternative/ui";

export interface ActivityItem {
    id: string;
    type: 'document_signed' | 'document_uploaded' | 'reminder_sent' | 'template_created' | 'user_invited' | 'document_viewed' | 'document_shared' | 'workflow_completed';
    title: string;
    description: string;
    timestamp: string;
    relativeTime: string;
    status: 'success' | 'warning' | 'error' | 'info';
    actor: {
        name: string;
        avatar?: string;
        initials: string;
        role?: string;
    };
    target?: {
        type: 'document' | 'template' | 'user' | 'organization';
        name: string;
        id: string;
    };
    metadata?: {
        [key: string]: any;
    };
}

export interface ActivityFeedProps {
    activities: ActivityItem[];
    onRefresh?: () => Promise<void>;
    onLoadMore?: () => Promise<void>;
    onFilterChange?: (filters: ActivityFilters) => void;
    realTimeUpdates?: boolean;
    maxItems?: number;
    showFilters?: boolean;
    compact?: boolean;
}

export interface ActivityFilters {
    types: string[];
    dateRange: 'today' | 'week' | 'month' | 'all';
    actors: string[];
    status: string[];
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({
    activities,
    onRefresh,
    onLoadMore,
    onFilterChange,
    realTimeUpdates = true,
    maxItems = 10,
    showFilters = true,
    compact = false
}) => {
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [filters, setFilters] = useState<ActivityFilters>({
        types: [],
        dateRange: 'all',
        actors: [],
        status: []
    });
    const [showAllFilters, setShowAllFilters] = useState(false);

    // Real-time updates simulation
    useEffect(() => {
        if (!realTimeUpdates) return;

        const interval = setInterval(() => {
            // Simulate new activity
            if (Math.random() > 0.8) {
                onRefresh?.();
            }
        }, 30000); // Check every 30 seconds

        return () => clearInterval(interval);
    }, [realTimeUpdates, onRefresh]);

    const handleRefresh = async () => {
        if (!onRefresh) return;
        setIsRefreshing(true);
        try {
            await onRefresh();
        } finally {
            setIsRefreshing(false);
        }
    };

    const handleLoadMore = async () => {
        if (!onLoadMore) return;
        setIsLoadingMore(true);
        try {
            await onLoadMore();
        } finally {
            setIsLoadingMore(false);
        }
    };

    const handleFilterChange = useCallback((newFilters: Partial<ActivityFilters>) => {
        const updatedFilters = { ...filters, ...newFilters };
        setFilters(updatedFilters);
        onFilterChange?.(updatedFilters);
    }, [filters, onFilterChange]);

    const getActivityIcon = (type: string, status: string) => {
        const iconClass = `h-4 w-4 ${status === 'success' ? 'text-green-600' :
                status === 'warning' ? 'text-yellow-600' :
                    status === 'error' ? 'text-red-600' :
                        'text-blue-600'
            }`;

        switch (type) {
            case 'document_signed':
                return <CheckCircle className={iconClass} />;
            case 'document_uploaded':
                return <Upload className={iconClass} />;
            case 'document_viewed':
                return <Eye className={iconClass} />;
            case 'document_shared':
                return <Users className={iconClass} />;
            case 'reminder_sent':
                return <Bell className={iconClass} />;
            case 'template_created':
                return <Plus className={iconClass} />;
            case 'user_invited':
                return <User className={iconClass} />;
            case 'workflow_completed':
                return <CheckCircle className={iconClass} />;
            default:
                return <Activity className={iconClass} />;
        }
    };

    const getStatusBadge = (status: string) => {
        const variants = {
            success: 'default',
            warning: 'secondary',
            error: 'destructive',
            info: 'outline'
        } as const;

        return (
            <Badge variant={variants[status as keyof typeof variants] || 'outline'} className="text-xs">
                {status}
            </Badge>
        );
    };

    const formatRelativeTime = (timestamp: string) => {
        const now = new Date();
        const activityTime = new Date(timestamp);
        const diffMs = now.getTime() - activityTime.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 7) return `${diffDays}d ago`;
        return activityTime.toLocaleDateString();
    };

    const displayActivities = activities.slice(0, maxItems);

    return (
        <Card>
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <Bell className="h-5 w-5" />
                            Activity Feed
                            {realTimeUpdates && (
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                            )}
                        </CardTitle>
                        <CardDescription>
                            Real-time updates on system activities
                        </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                        {showFilters && (
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowAllFilters(!showAllFilters)}
                            >
                                <Filter className="h-4 w-4" />
                            </Button>
                        )}
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={handleRefresh}
                            disabled={isRefreshing}
                        >
                            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                        </Button>
                    </div>
                </div>
            </CardHeader>

            {/* Filters */}
            {showFilters && showAllFilters && (
                <CardContent className="border-b">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label className="text-sm font-medium text-gray-700 mb-2 block">
                                Activity Type
                            </label>
                            <select
                                className="w-full p-2 border rounded-md text-sm"
                                onChange={(e) => handleFilterChange({
                                    types: e.target.value ? [e.target.value] : []
                                })}
                            >
                                <option value="">All Types</option>
                                <option value="document_signed">Document Signed</option>
                                <option value="document_uploaded">Document Uploaded</option>
                                <option value="reminder_sent">Reminder Sent</option>
                                <option value="template_created">Template Created</option>
                                <option value="user_invited">User Invited</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-700 mb-2 block">
                                Date Range
                            </label>
                            <select
                                className="w-full p-2 border rounded-md text-sm"
                                value={filters.dateRange}
                                onChange={(e) => handleFilterChange({
                                    dateRange: e.target.value as ActivityFilters['dateRange']
                                })}
                            >
                                <option value="all">All Time</option>
                                <option value="today">Today</option>
                                <option value="week">This Week</option>
                                <option value="month">This Month</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-700 mb-2 block">
                                Status
                            </label>
                            <select
                                className="w-full p-2 border rounded-md text-sm"
                                onChange={(e) => handleFilterChange({
                                    status: e.target.value ? [e.target.value] : []
                                })}
                            >
                                <option value="">All Status</option>
                                <option value="success">Success</option>
                                <option value="warning">Warning</option>
                                <option value="error">Error</option>
                                <option value="info">Info</option>
                            </select>
                        </div>
                        <div className="flex items-end">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleFilterChange({
                                    types: [],
                                    dateRange: 'all',
                                    actors: [],
                                    status: []
                                })}
                            >
                                Clear Filters
                            </Button>
                        </div>
                    </div>
                </CardContent>
            )}

            <CardContent className={compact ? "p-4" : "p-6"}>
                {displayActivities.length === 0 ? (
                    <div className="text-center py-8">
                        <Activity className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                            No recent activity
                        </h3>
                        <p className="text-gray-500">
                            Activity will appear here as users interact with the system.
                        </p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {displayActivities.map((activity, index) => (
                            <div
                                key={activity.id}
                                className={`flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors ${index === 0 && realTimeUpdates ? 'animate-pulse' : ''
                                    }`}
                            >
                                {/* Avatar */}
                                <div className="flex-shrink-0">
                                    {activity.actor.avatar ? (
                                        <Avatar className="w-8 h-8">
                                            <img src={activity.actor.avatar} alt={activity.actor.name} />
                                        </Avatar>
                                    ) : (
                                        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium">
                                            {activity.actor.initials}
                                        </div>
                                    )}
                                </div>

                                {/* Content */}
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1">
                                        {getActivityIcon(activity.type, activity.status)}
                                        <p className="text-sm font-medium text-gray-900 truncate">
                                            {activity.title}
                                        </p>
                                        {!compact && getStatusBadge(activity.status)}
                                    </div>

                                    <p className="text-sm text-gray-600 mb-1">
                                        <span className="font-medium">{activity.actor.name}</span>
                                        {activity.actor.role && (
                                            <span className="text-gray-400"> ({activity.actor.role})</span>
                                        )}
                                        {' '}{activity.description}
                                        {activity.target && (
                                            <span className="font-medium"> {activity.target.name}</span>
                                        )}
                                    </p>

                                    <div className="flex items-center gap-2 text-xs text-gray-400">
                                        <Calendar className="h-3 w-3" />
                                        <span>{formatRelativeTime(activity.timestamp)}</span>
                                        {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                                            <Button variant="ghost" size="sm" className="h-auto p-0 text-xs">
                                                <MoreHorizontal className="h-3 w-3" />
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}

                        {/* Load More */}
                        {activities.length > maxItems && onLoadMore && (
                            <div className="text-center pt-4 border-t">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={handleLoadMore}
                                    disabled={isLoadingMore}
                                >
                                    {isLoadingMore ? (
                                        <>
                                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                            Loading...
                                        </>
                                    ) : (
                                        <>
                                            Load More ({activities.length - maxItems} remaining)
                                        </>
                                    )}
                                </Button>
                            </div>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default ActivityFeed;