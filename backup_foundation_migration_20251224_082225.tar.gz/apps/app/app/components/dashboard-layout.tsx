import React, { useState, useCallback } from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    Button,
    Badge,
    Select
} from "@docusign-alternative/ui";
import {
    Grid3X3,
    List,
    Save,
    RotateCcw,
    Plus,
    Settings,
    Eye,
    EyeOff,
    Move,
    Trash2
} from "@docusign-alternative/ui";
import {
    DashboardWidget,
    WidgetContainer,
    MetricWidget,
    ChartWidget,
    ActivityWidget,
    TableWidget,
    DashboardCustomizer,
    availableWidgetTypes
} from './dashboard-widgets';

export interface DashboardLayoutProps {
    widgets: DashboardWidget[];
    onWidgetsChange: (widgets: DashboardWidget[]) => void;
    onSaveLayout: () => void;
    onResetLayout: () => void;
    editMode?: boolean;
    onEditModeChange?: (editMode: boolean) => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
    widgets,
    onWidgetsChange,
    onSaveLayout,
    onResetLayout,
    editMode = false,
    onEditModeChange
}) => {
    const [showCustomizer, setShowCustomizer] = useState(false);
    const [layoutType, setLayoutType] = useState<'grid' | 'list' | 'columns'>('grid');
    const [draggedWidget, setDraggedWidget] = useState<string | null>(null);

    const handleAddWidget = useCallback((type: string) => {
        const widgetType = availableWidgetTypes.find(w => w.type === type);
        if (!widgetType) return;

        const newWidget: DashboardWidget = {
            id: `widget-${Date.now()}`,
            type: type as any,
            title: widgetType.title,
            size: widgetType.defaultSize,
            position: { x: 0, y: widgets.length },
            refreshable: true,
            exportable: true,
            filterable: type.includes('chart') || type === 'data-table'
        };

        onWidgetsChange([...widgets, newWidget]);
        setShowCustomizer(false);
    }, [widgets, onWidgetsChange]);

    const handleRemoveWidget = useCallback((id: string) => {
        onWidgetsChange(widgets.filter(w => w.id !== id));
    }, [widgets, onWidgetsChange]);

    const handleResizeWidget = useCallback((id: string, size: 'small' | 'medium' | 'large') => {
        onWidgetsChange(widgets.map(w =>
            w.id === id ? { ...w, size } : w
        ));
    }, [widgets, onWidgetsChange]);

    const handleRefreshWidget = useCallback(async (id: string) => {
        // Simulate refresh delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        console.log(`Refreshed widget: ${id}`);
    }, []);

    const handleExportWidget = useCallback((id: string) => {
        const widget = widgets.find(w => w.id === id);
        if (widget) {
            // Simulate export
            console.log(`Exporting widget: ${widget.title}`);
        }
    }, [widgets]);

    const handleConfigureWidget = useCallback((id: string) => {
        console.log(`Configuring widget: ${id}`);
    }, []);

    const handleDragStart = (e: React.DragEvent, widgetId: string) => {
        setDraggedWidget(widgetId);
        e.dataTransfer.effectAllowed = 'move';
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    };

    const handleDrop = (e: React.DragEvent, targetId: string) => {
        e.preventDefault();
        if (!draggedWidget || draggedWidget === targetId) return;

        const draggedIndex = widgets.findIndex(w => w.id === draggedWidget);
        const targetIndex = widgets.findIndex(w => w.id === targetId);

        if (draggedIndex === -1 || targetIndex === -1) return;

        const newWidgets = [...widgets];
        const [draggedItem] = newWidgets.splice(draggedIndex, 1);
        newWidgets.splice(targetIndex, 0, draggedItem);

        onWidgetsChange(newWidgets);
        setDraggedWidget(null);
    };

    const renderWidget = (widget: DashboardWidget) => {
        const widgetContent = () => {
            switch (widget.type) {
                case 'metric':
                    return (
                        <MetricWidget
                            title={widget.title}
                            value={widget.data?.value || 0}
                            change={widget.data?.change}
                            icon={widget.data?.icon}
                            trend={widget.data?.trend}
                        />
                    );
                case 'chart':
                    return (
                        <ChartWidget
                            type={widget.config?.chartType || 'bar'}
                            data={widget.data || []}
                            height={widget.size === 'small' ? 150 : 200}
                        />
                    );
                case 'activity':
                    return (
                        <ActivityWidget
                            activities={widget.data || []}
                            maxItems={widget.size === 'small' ? 3 : 5}
                        />
                    );
                case 'table':
                    return (
                        <TableWidget
                            columns={widget.config?.columns || []}
                            data={widget.data || []}
                            maxRows={widget.size === 'small' ? 3 : 5}
                        />
                    );
                default:
                    return <div>Widget type not supported</div>;
            }
        };

        return (
            <div
                key={widget.id}
                draggable={editMode}
                onDragStart={(e) => handleDragStart(e, widget.id)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, widget.id)}
                className={`${editMode ? 'cursor-move' : ''} ${draggedWidget === widget.id ? 'opacity-50' : ''}`}
            >
                <WidgetContainer
                    widget={widget}
                    onRemove={editMode ? handleRemoveWidget : undefined}
                    onResize={editMode ? handleResizeWidget : undefined}
                    onRefresh={handleRefreshWidget}
                    onExport={handleExportWidget}
                    onConfigure={handleConfigureWidget}
                >
                    {widgetContent()}
                </WidgetContainer>
            </div>
        );
    };

    const getLayoutClasses = () => {
        switch (layoutType) {
            case 'grid':
                return 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6';
            case 'list':
                return 'space-y-6';
            case 'columns':
                return 'grid grid-cols-1 lg:grid-cols-2 gap-6';
            default:
                return 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6';
        }
    };

    return (
        <div className="space-y-6">
            {/* Dashboard Controls */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle className="flex items-center gap-2">
                                <Grid3X3 className="h-5 w-5" />
                                Dashboard Layout
                            </CardTitle>
                            <CardDescription>
                                Customize your dashboard layout and widgets
                            </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                            <Select
                                value={layoutType}
                                onValueChange={(value: 'grid' | 'list' | 'columns') => setLayoutType(value)}
                            >
                                <option value="grid">Grid Layout</option>
                                <option value="list">List Layout</option>
                                <option value="columns">Column Layout</option>
                            </Select>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => onEditModeChange?.(!editMode)}
                            >
                                {editMode ? (
                                    <>
                                        <EyeOff className="h-4 w-4 mr-2" />
                                        Exit Edit
                                    </>
                                ) : (
                                    <>
                                        <Settings className="h-4 w-4 mr-2" />
                                        Edit Layout
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                {editMode && (
                    <CardContent>
                        <div className="flex items-center gap-2 flex-wrap">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowCustomizer(true)}
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Widget
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={onSaveLayout}
                            >
                                <Save className="h-4 w-4 mr-2" />
                                Save Layout
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={onResetLayout}
                            >
                                <RotateCcw className="h-4 w-4 mr-2" />
                                Reset to Default
                            </Button>
                            <Badge variant="secondary" className="ml-auto">
                                {widgets.length} widgets
                            </Badge>
                        </div>
                    </CardContent>
                )}
            </Card>

            {/* Widget Customizer */}
            {showCustomizer && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <DashboardCustomizer
                        availableWidgets={availableWidgetTypes}
                        onAddWidget={handleAddWidget}
                        onClose={() => setShowCustomizer(false)}
                    />
                </div>
            )}

            {/* Dashboard Widgets */}
            <div className={getLayoutClasses()}>
                {widgets.map(renderWidget)}

                {/* Empty State */}
                {widgets.length === 0 && (
                    <Card className="col-span-full">
                        <CardContent className="flex flex-col items-center justify-center py-12">
                            <Grid3X3 className="h-12 w-12 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">
                                No widgets configured
                            </h3>
                            <p className="text-gray-500 text-center mb-4">
                                Add widgets to customize your dashboard and track important metrics.
                            </p>
                            <Button onClick={() => setShowCustomizer(true)}>
                                <Plus className="h-4 w-4 mr-2" />
                                Add Your First Widget
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* Edit Mode Overlay */}
            {editMode && (
                <div className="fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-lg shadow-lg">
                    <div className="flex items-center gap-2">
                        <Move className="h-4 w-4" />
                        <span className="text-sm font-medium">
                            Drag widgets to reorder • Click settings to configure
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DashboardLayout;