import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Document {
    id: string;
    name: string;
    status: 'draft' | 'pending' | 'completed' | 'cancelled';
    createdAt: string;
    updatedAt: string;
    size: number;
    mimeType: string;
    thumbnailUrl?: string;
    isOfflineAvailable: boolean;
}

interface DocumentsState {
    documents: Document[];
    selectedDocument: Document | null;
    isLoading: boolean;
    searchQuery: string;
    filter: 'all' | 'pending' | 'completed' | 'draft';
    sortBy: 'name' | 'date' | 'status';
    sortOrder: 'asc' | 'desc';
}

const initialState: DocumentsState = {
    documents: [],
    selectedDocument: null,
    isLoading: false,
    searchQuery: '',
    filter: 'all',
    sortBy: 'date',
    sortOrder: 'desc',
};

const documentsSlice = createSlice({
    name: 'documents',
    initialState,
    reducers: {
        setLoading: (state, action: PayloadAction<boolean>) => {
            state.isLoading = action.payload;
        },
        setDocuments: (state, action: PayloadAction<Document[]>) => {
            state.documents = action.payload;
        },
        addDocument: (state, action: PayloadAction<Document>) => {
            state.documents.unshift(action.payload);
        },
        updateDocument: (state, action: PayloadAction<{ id: string; updates: Partial<Document> }>) => {
            const index = state.documents.findIndex(doc => doc.id === action.payload.id);
            if (index !== -1) {
                state.documents[index] = { ...state.documents[index], ...action.payload.updates };
            }
        },
        removeDocument: (state, action: PayloadAction<string>) => {
            state.documents = state.documents.filter(doc => doc.id !== action.payload);
        },
        setSelectedDocument: (state, action: PayloadAction<Document | null>) => {
            state.selectedDocument = action.payload;
        },
        setSearchQuery: (state, action: PayloadAction<string>) => {
            state.searchQuery = action.payload;
        },
        setFilter: (state, action: PayloadAction<DocumentsState['filter']>) => {
            state.filter = action.payload;
        },
        setSorting: (state, action: PayloadAction<{ sortBy: DocumentsState['sortBy']; sortOrder: DocumentsState['sortOrder'] }>) => {
            state.sortBy = action.payload.sortBy;
            state.sortOrder = action.payload.sortOrder;
        },
        markOfflineAvailable: (state, action: PayloadAction<string>) => {
            const document = state.documents.find(doc => doc.id === action.payload);
            if (document) {
                document.isOfflineAvailable = true;
            }
        },
    },
});

export const {
    setLoading,
    setDocuments,
    addDocument,
    updateDocument,
    removeDocument,
    setSelectedDocument,
    setSearchQuery,
    setFilter,
    setSorting,
    markOfflineAvailable,
} = documentsSlice.actions;

export default documentsSlice.reducer;