import React, { useState } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    TextInput,
    Alert,
} from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../store';
import { setSearchQuery, setFilter } from '../../store/slices/documentsSlice';
import { useOffline } from '../../providers/OfflineProvider';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DocumentPicker from 'react-native-document-picker';

export const DocumentsScreen: React.FC = () => {
    const dispatch = useDispatch();
    const { documents, searchQuery, filter } = useSelector((state: RootState) => state.documents);
    const { isOnline } = useSelector((state: RootState) => state.offline);
    const { downloadDocumentForOffline, isDocumentAvailableOffline } = useOffline();
    const [isUploading, setIsUploading] = useState(false);

    const filteredDocuments = documents.filter(doc => {
        const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = filter === 'all' || doc.status === filter;
        return matchesSearch && matchesFilter;
    });

    const handleUploadDocument = async () => {
        try {
            const result = await DocumentPicker.pick({
                type: [DocumentPicker.types.pdf, DocumentPicker.types.doc, DocumentPicker.types.docx],
            });

            setIsUploading(true);
            // Upload logic would go here
            Alert.alert('Success', 'Document uploaded successfully');
        } catch (error) {
            if (!DocumentPicker.isCancel(error)) {
                Alert.alert('Error', 'Failed to upload document');
            }
        } finally {
            setIsUploading(false);
        }
    };

    const handleDownloadForOffline = async (documentId: string) => {
        if (!isOnline) {
            Alert.alert('Error', 'You need to be online to download documents');
            return;
        }

        try {
            await downloadDocumentForOffline(documentId);
            Alert.alert('Success', 'Document downloaded for offline access');
        } catch (error) {
            Alert.alert('Error', 'Failed to download document');
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'completed':
                return '#34C759';
            case 'pending':
                return '#FF9500';
            case 'draft':
                return '#8E8E93';
            default:
                return '#8E8E93';
        }
    };

    const renderDocument = ({ item }: { item: any }) => (
        <TouchableOpacity style={styles.documentCard}>
            <View style={styles.documentIcon}>
                <Icon name="description" size={32} color="#007AFF" />
                {isDocumentAvailableOffline(item.id) && (
                    <View style={styles.offlineBadge}>
                        <Icon name="offline-pin" size={12} color="#34C759" />
                    </View>
                )}
            </View>

            <View style={styles.documentInfo}>
                <Text style={styles.documentName} numberOfLines={2}>
                    {item.name}
                </Text>
                <Text style={styles.documentDate}>
                    {new Date(item.updatedAt).toLocaleDateString()}
                </Text>
                <View style={styles.statusContainer}>
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
                        <Text style={styles.statusText}>{item.status.toUpperCase()}</Text>
                    </View>
                </View>
            </View>

            <View style={styles.documentActions}>
                <TouchableOpacity
                    style={styles.actionButton}
                    onPress={() => handleDownloadForOffline(item.id)}>
                    <Icon name="cloud-download" size={20} color="#007AFF" />
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                    <Icon name="more-vert" size={20} color="#8E8E93" />
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Documents</Text>
                <TouchableOpacity
                    style={styles.uploadButton}
                    onPress={handleUploadDocument}
                    disabled={isUploading}>
                    <Icon name="add" size={24} color="#ffffff" />
                </TouchableOpacity>
            </View>

            <View style={styles.searchContainer}>
                <Icon name="search" size={20} color="#8E8E93" style={styles.searchIcon} />
                <TextInput
                    style={styles.searchInput}
                    placeholder="Search documents..."
                    value={searchQuery}
                    onChangeText={(text) => dispatch(setSearchQuery(text))}
                />
            </View>

            <View style={styles.filterContainer}>
                {['all', 'pending', 'completed', 'draft'].map((filterOption) => (
                    <TouchableOpacity
                        key={filterOption}
                        style={[
                            styles.filterButton,
                            filter === filterOption && styles.filterButtonActive,
                        ]}
                        onPress={() => dispatch(setFilter(filterOption as any))}>
                        <Text
                            style={[
                                styles.filterText,
                                filter === filterOption && styles.filterTextActive,
                            ]}>
                            {filterOption.charAt(0).toUpperCase() + filterOption.slice(1)}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>

            {!isOnline && (
                <View style={styles.offlineNotice}>
                    <Icon name="cloud-off" size={16} color="#FF9500" />
                    <Text style={styles.offlineText}>You're offline. Showing cached documents.</Text>
                </View>
            )}

            <FlatList
                data={filteredDocuments}
                renderItem={renderDocument}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.documentsList}
                showsVerticalScrollIndicator={false}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F2F2F7',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#ffffff',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333333',
    },
    uploadButton: {
        backgroundColor: '#007AFF',
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        marginHorizontal: 16,
        marginTop: 16,
        paddingHorizontal: 12,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#E0E0E0',
    },
    searchIcon: {
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        paddingVertical: 12,
        fontSize: 16,
    },
    filterContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingVertical: 12,
    },
    filterButton: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        marginRight: 8,
        borderRadius: 16,
        backgroundColor: '#E0E0E0',
    },
    filterButtonActive: {
        backgroundColor: '#007AFF',
    },
    filterText: {
        fontSize: 14,
        color: '#666666',
        fontWeight: '500',
    },
    filterTextActive: {
        color: '#ffffff',
    },
    offlineNotice: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFF3CD',
        paddingHorizontal: 16,
        paddingVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
        marginBottom: 8,
    },
    offlineText: {
        marginLeft: 8,
        fontSize: 14,
        color: '#856404',
    },
    documentsList: {
        paddingHorizontal: 16,
    },
    documentCard: {
        flexDirection: 'row',
        backgroundColor: '#ffffff',
        padding: 16,
        marginBottom: 8,
        borderRadius: 12,
        alignItems: 'center',
    },
    documentIcon: {
        position: 'relative',
        marginRight: 12,
    },
    offlineBadge: {
        position: 'absolute',
        top: -4,
        right: -4,
        backgroundColor: '#ffffff',
        borderRadius: 8,
        padding: 2,
    },
    documentInfo: {
        flex: 1,
    },
    documentName: {
        fontSize: 16,
        fontWeight: '500',
        color: '#333333',
        marginBottom: 4,
    },
    documentDate: {
        fontSize: 14,
        color: '#666666',
        marginBottom: 8,
    },
    statusContainer: {
        flexDirection: 'row',
    },
    statusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
    },
    statusText: {
        fontSize: 12,
        color: '#ffffff',
        fontWeight: '600',
    },
    documentActions: {
        flexDirection: 'row',
    },
    actionButton: {
        padding: 8,
        marginLeft: 4,
    },
});