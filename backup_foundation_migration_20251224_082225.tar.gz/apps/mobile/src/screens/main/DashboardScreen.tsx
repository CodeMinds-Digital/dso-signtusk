import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import Icon from 'react-native-vector-icons/MaterialIcons';

export const DashboardScreen: React.FC = () => {
    const { user } = useSelector((state: RootState) => state.auth);
    const { documents } = useSelector((state: RootState) => state.documents);

    const pendingDocuments = documents.filter(doc => doc.status === 'pending');
    const completedDocuments = documents.filter(doc => doc.status === 'completed');

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.greeting}>Hello, {user?.name || 'User'}!</Text>
                <Text style={styles.subtitle}>Welcome back to DocuSign Alternative</Text>
            </View>

            <View style={styles.statsContainer}>
                <View style={styles.statCard}>
                    <Icon name="pending-actions" size={32} color="#FF9500" />
                    <Text style={styles.statNumber}>{pendingDocuments.length}</Text>
                    <Text style={styles.statLabel}>Pending</Text>
                </View>

                <View style={styles.statCard}>
                    <Icon name="check-circle" size={32} color="#34C759" />
                    <Text style={styles.statNumber}>{completedDocuments.length}</Text>
                    <Text style={styles.statLabel}>Completed</Text>
                </View>

                <View style={styles.statCard}>
                    <Icon name="folder" size={32} color="#007AFF" />
                    <Text style={styles.statNumber}>{documents.length}</Text>
                    <Text style={styles.statLabel}>Total</Text>
                </View>
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Quick Actions</Text>

                <TouchableOpacity style={styles.actionCard}>
                    <Icon name="add-circle" size={24} color="#007AFF" />
                    <View style={styles.actionContent}>
                        <Text style={styles.actionTitle}>Upload Document</Text>
                        <Text style={styles.actionSubtitle}>Add a new document for signing</Text>
                    </View>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.actionCard}>
                    <Icon name="edit" size={24} color="#007AFF" />
                    <View style={styles.actionContent}>
                        <Text style={styles.actionTitle}>Create Template</Text>
                        <Text style={styles.actionSubtitle}>Save time with reusable templates</Text>
                    </View>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.actionCard}>
                    <Icon name="camera-alt" size={24} color="#007AFF" />
                    <View style={styles.actionContent}>
                        <Text style={styles.actionTitle}>Scan Document</Text>
                        <Text style={styles.actionSubtitle}>Use camera to capture documents</Text>
                    </View>
                    <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </TouchableOpacity>
            </View>

            {pendingDocuments.length > 0 && (
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Pending Documents</Text>
                    {pendingDocuments.slice(0, 3).map((doc) => (
                        <TouchableOpacity key={doc.id} style={styles.documentCard}>
                            <Icon name="description" size={24} color="#FF9500" />
                            <View style={styles.documentContent}>
                                <Text style={styles.documentTitle}>{doc.name}</Text>
                                <Text style={styles.documentSubtitle}>
                                    Created {new Date(doc.createdAt).toLocaleDateString()}
                                </Text>
                            </View>
                            <Icon name="chevron-right" size={24} color="#C7C7CC" />
                        </TouchableOpacity>
                    ))}

                    {pendingDocuments.length > 3 && (
                        <TouchableOpacity style={styles.viewAllButton}>
                            <Text style={styles.viewAllText}>View All Pending Documents</Text>
                        </TouchableOpacity>
                    )}
                </View>
            )}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F2F2F7',
    },
    header: {
        padding: 20,
        backgroundColor: '#ffffff',
        marginBottom: 16,
    },
    greeting: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333333',
        marginBottom: 4,
    },
    subtitle: {
        fontSize: 16,
        color: '#666666',
    },
    statsContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        marginBottom: 16,
    },
    statCard: {
        flex: 1,
        backgroundColor: '#ffffff',
        padding: 16,
        marginHorizontal: 4,
        borderRadius: 12,
        alignItems: 'center',
    },
    statNumber: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333333',
        marginTop: 8,
    },
    statLabel: {
        fontSize: 14,
        color: '#666666',
        marginTop: 4,
    },
    section: {
        marginBottom: 24,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: '600',
        color: '#333333',
        paddingHorizontal: 16,
        marginBottom: 12,
    },
    actionCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        padding: 16,
        marginHorizontal: 16,
        marginBottom: 8,
        borderRadius: 12,
    },
    actionContent: {
        flex: 1,
        marginLeft: 12,
    },
    actionTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333333',
    },
    actionSubtitle: {
        fontSize: 14,
        color: '#666666',
        marginTop: 2,
    },
    documentCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        padding: 16,
        marginHorizontal: 16,
        marginBottom: 8,
        borderRadius: 12,
    },
    documentContent: {
        flex: 1,
        marginLeft: 12,
    },
    documentTitle: {
        fontSize: 16,
        fontWeight: '500',
        color: '#333333',
    },
    documentSubtitle: {
        fontSize: 14,
        color: '#666666',
        marginTop: 2,
    },
    viewAllButton: {
        backgroundColor: '#ffffff',
        padding: 16,
        marginHorizontal: 16,
        borderRadius: 12,
        alignItems: 'center',
    },
    viewAllText: {
        fontSize: 16,
        color: '#007AFF',
        fontWeight: '500',
    },
});