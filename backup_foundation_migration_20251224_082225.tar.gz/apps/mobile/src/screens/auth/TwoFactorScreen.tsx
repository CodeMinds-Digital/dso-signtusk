import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export const TwoFactorScreen: React.FC = () => {
    const [code, setCode] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleVerifyCode = async () => {
        if (!code || code.length !== 6) {
            Alert.alert('Error', 'Please enter a valid 6-digit code');
            return;
        }

        setIsLoading(true);
        try {
            // 2FA verification logic would go here
            Alert.alert('Success', 'Two-factor authentication verified');
        } catch (error) {
            Alert.alert('Error', 'Invalid verification code');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Two-Factor Authentication</Text>
            <Text style={styles.subtitle}>
                Enter the 6-digit code from your authenticator app
            </Text>

            <TextInput
                style={styles.input}
                placeholder="000000"
                value={code}
                onChangeText={setCode}
                keyboardType="number-pad"
                maxLength={6}
                textAlign="center"
            />

            <TouchableOpacity
                style={[styles.button, isLoading && styles.buttonDisabled]}
                onPress={handleVerifyCode}
                disabled={isLoading}>
                <Text style={styles.buttonText}>
                    {isLoading ? 'Verifying...' : 'Verify Code'}
                </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.linkButton}>
                <Text style={styles.linkText}>Use backup code instead</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: 24,
        backgroundColor: '#ffffff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#333333',
        textAlign: 'center',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 16,
        color: '#666666',
        textAlign: 'center',
        marginBottom: 48,
        lineHeight: 24,
    },
    input: {
        borderWidth: 1,
        borderColor: '#E0E0E0',
        borderRadius: 8,
        paddingHorizontal: 16,
        paddingVertical: 12,
        fontSize: 24,
        marginBottom: 24,
        backgroundColor: '#F8F8F8',
        letterSpacing: 8,
    },
    button: {
        backgroundColor: '#007AFF',
        borderRadius: 8,
        paddingVertical: 16,
        marginBottom: 16,
    },
    buttonDisabled: {
        backgroundColor: '#CCCCCC',
    },
    buttonText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '600',
        textAlign: 'center',
    },
    linkButton: {
        paddingVertical: 8,
    },
    linkText: {
        color: '#007AFF',
        fontSize: 16,
        textAlign: 'center',
    },
});