import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import NetInfo from '@react-native-community/netinfo';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RootState } from '../store';
import {
    setOnlineStatus,
    setSyncInProgress,
    setLastSyncTime,
    removePendingAction,
    incrementRetryCount,
} from '../store/slices/offlineSlice';
import { trpc } from '../utils/trpc';

interface OfflineContextType {
    syncPendingActions: () => Promise<void>;
    downloadDocumentForOffline: (documentId: string) => Promise<void>;
    removeOfflineDocument: (documentId: string) => Promise<void>;
    isDocumentAvailableOffline: (documentId: string) => boolean;
}

const OfflineContext = createContext<OfflineContextType | undefined>(undefined);

interface OfflineProviderProps {
    children: ReactNode;
}

export const OfflineProvider: React.FC<OfflineProviderProps> = ({ children }) => {
    const dispatch = useDispatch();
    const { isOnline, pendingActions, syncInProgress } = useSelector((state: RootState) => state.offline);
    const { offlineDocuments } = useSelector((state: RootState) => state.offline);

    const uploadDocumentMutation = trpc.documents.upload.useMutation();
    const updateDocumentMutation = trpc.documents.update.useMutation();
    const deleteDocumentMutation = trpc.documents.delete.useMutation();

    useEffect(() => {
        // Monitor network connectivity
        const unsubscribe = NetInfo.addEventListener(state => {
            const wasOffline = !isOnline;
            const isNowOnline = state.isConnected && state.isInternetReachable;

            dispatch(setOnlineStatus(isNowOnline));

            // Auto-sync when coming back online
            if (wasOffline && isNowOnline && pendingActions.length > 0) {
                syncPendingActions();
            }
        });

        return unsubscribe;
    }, [isOnline, pendingActions.length]);

    const syncPendingActions = async () => {
        if (!isOnline || syncInProgress || pendingActions.length === 0) {
            return;
        }

        dispatch(setSyncInProgress(true));

        try {
            for (const action of pendingActions) {
                try {
                    switch (action.type) {
                        case 'upload':
                            await uploadDocumentMutation.mutateAsync(action.data);
                            break;
                        case 'update':
                            await updateDocumentMutation.mutateAsync(action.data);
                            break;
                        case 'delete':
                            await deleteDocumentMutation.mutateAsync({ id: action.data.id });
                            break;
                        case 'sign':
                            // Handle signing action
                            break;
                    }

                    dispatch(removePendingAction(action.id));
                } catch (error) {
                    console.error(`Failed to sync action ${action.id}:`, error);

                    // Increment retry count
                    dispatch(incrementRetryCount(action.id));

                    // Remove action if max retries reached
                    if (action.retryCount >= 3) {
                        dispatch(removePendingAction(action.id));
                    }
                }
            }

            dispatch(setLastSyncTime(Date.now()));
        } catch (error) {
            console.error('Sync error:', error);
        } finally {
            dispatch(setSyncInProgress(false));
        }
    };

    const downloadDocumentForOffline = async (documentId: string) => {
        try {
            // Download document data
            const documentData = await trpc.documents.getById.query({ id: documentId });

            // Store document data locally
            await AsyncStorage.setItem(
                `offline_document_${documentId}`,
                JSON.stringify(documentData)
            );

            // Download PDF file if available
            if (documentData.fileUrl) {
                const response = await fetch(documentData.fileUrl);
                const blob = await response.blob();

                // Store file data (in a real app, you'd use a proper file storage solution)
                await AsyncStorage.setItem(
                    `offline_file_${documentId}`,
                    JSON.stringify({
                        data: blob,
                        mimeType: documentData.mimeType,
                    })
                );
            }

            // Update offline documents list
            dispatch({ type: 'offline/addOfflineDocument', payload: documentId });
        } catch (error) {
            console.error('Failed to download document for offline:', error);
            throw error;
        }
    };

    const removeOfflineDocument = async (documentId: string) => {
        try {
            await AsyncStorage.removeItem(`offline_document_${documentId}`);
            await AsyncStorage.removeItem(`offline_file_${documentId}`);

            dispatch({ type: 'offline/removeOfflineDocument', payload: documentId });
        } catch (error) {
            console.error('Failed to remove offline document:', error);
        }
    };

    const isDocumentAvailableOffline = (documentId: string): boolean => {
        return offlineDocuments.includes(documentId);
    };

    const contextValue: OfflineContextType = {
        syncPendingActions,
        downloadDocumentForOffline,
        removeOfflineDocument,
        isDocumentAvailableOffline,
    };

    return (
        <OfflineContext.Provider value={contextValue}>
            {children}
        </OfflineContext.Provider>
    );
};

export const useOffline = (): OfflineContextType => {
    const context = useContext(OfflineContext);
    if (!context) {
        throw new Error('useOffline must be used within an OfflineProvider');
    }
    return context;
};