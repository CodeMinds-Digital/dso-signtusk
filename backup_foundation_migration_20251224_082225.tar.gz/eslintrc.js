module.exports = {
    root: true,
    extends: ["@docusign-alternative/eslint-config"],
    parserOptions: {
        project: "./tsconfig.json",
    },
};